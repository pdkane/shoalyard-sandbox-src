import type { Step } from "./step";

/**
 * The replayed pilot script: what the operator does next in each venture when
 * no ANTHROPIC_API_KEY is set (and the fallback when Claude errors). One step
 * per venture per tick; a step with `when` waits for that lifecycle state.
 */
export const SCRIPT: Record<string, Step[]> = {
  "permit-pulse": [
    {
      title: "Build the first scraper for Maricopa and Travis counties",
      reasoning: "A member who works with county data said Maricopa and Travis publish nightly via open APIs and Fulton is PDF-only. Starting with the two clean sources keeps compute inside the budget.",
      confidence: 0.84,
    },
    {
      title: "Ask what contractors pay for leads today",
      reasoning: "The price has to sit under what a contractor already spends per qualified lead. The agent has list prices from lead vendors but not what anyone actually pays. Buyer-side answers count most before the first customer, per L-003.",
      confidence: 0.8,
      lessonIds: ["L-003"],
      rfe: {
        type: "knowledge",
        title: "What does a contractor pay per qualified commercial lead today?",
        question: "Roughly what does your company (or one you know) pay per qualified commercial lead, and from where?",
        recommendation: "$60–$150 per lead from bid boards and referral partners",
        stakes: "medium",
        format: "text",
        offerUnits: 3,
        audience: "Contractor sales leaders and estimators",
      },
    },
    {
      title: "Form Permit Pulse as a series of the parent LLC",
      reasoning: "The minimum was met. Setting up the company costs $60, under the spending limit, and units can't be paid until the company exists.",
      confidence: 0.9,
      facts: { spendUsd: 60 },
      transition: "formed",
      when: ["funded"],
    },
    {
      title: "Buy a shared proxy plan for county portals at $45/month",
      reasoning: "Harris County rate-limits by IP after 200 requests. A shared proxy plan is the cheapest way to pull a weekly CSV reliably, and it fits the deck's $50 line for portal access and proxies.",
      confidence: 0.78,
      facts: { spendUsd: 45, budgetLine: "portals" },
      when: ["formed", "operating"],
    },
    {
      title: "Send the first Monday list to five trial contractors",
      reasoning: "Scrapers for three counties are stable for two weeks. Five members' companies agreed to a free month through member intros, not cold email, per L-005; their replies decide the price.",
      confidence: 0.82,
      lessonIds: ["L-005"],
      transition: "operating",
      when: ["formed"],
    },
    {
      title: "Set the price at $149/month per trade per metro",
      reasoning: "Members put a qualified lead at $60–$150. One closed job a quarter pays for a year at $149, and the trial contractors said they would pay under $200.",
      confidence: 0.74,
      facts: { pricingChange: true },
      when: ["operating"],
    },
  ],
  dockside: [
    {
      title: "Parse ELD timestamps from Motive and Samsara exports",
      reasoning: "Members said disputes with ELD timestamps get paid; driver notes don't. Nine of fourteen customers use one of these two.",
      confidence: 0.86,
    },
    {
      title: "Ask which accessorial to automate after detention",
      reasoning: "Lumper and layover disputes both came up in customer calls. Members who run freight know which one leaks more money.",
      confidence: 0.8,
      rfe: {
        type: "judgment",
        title: "After detention, automate lumper or layover disputes?",
        question: "Which accessorial do small brokers lose more money on without disputing: lumper fees or layover?",
        recommendation: "Lumper fees",
        stakes: "low",
        format: "choice",
        options: ["Lumper fees", "Layover"],
        offerUnits: 1.5,
        audience: "Brokers and carriers",
      },
    },
    {
      title: "Require broker approval for letters disputing more than $1,000",
      reasoning: "A large dispute can sour a shipper relationship. The agent thinks a human click is worth the friction but is not sure customers will accept it.",
      confidence: 0.62,
      rfe: {
        type: "judgment",
        title: "Should letters over $1,000 need a broker's click before sending?",
        question: "Large disputes risk the shipper relationship. Is a mandatory approval step worth the friction?",
        recommendation: "Go ahead",
        stakes: "medium",
        format: "choice",
        options: ["Go ahead", "Hold off"],
        offerUnits: 1,
        audience: "Brokerage owners",
      },
    },
    {
      title: "Counter the TMS vendor's revenue-share proposal",
      reasoning: "The vendor proposed a revenue share on embedded letters. The agent countered with a per-seat fee; terms are confidential until signed or dropped.",
      confidence: 0.76,
      embargoReason: "third-party confidentiality",
    },
    {
      title: "Offer annual billing at ten months' price",
      reasoning: "Four customers asked for annual invoices to match their budgets. Two free months costs less than one churned customer.",
      confidence: 0.8,
      facts: { pricingChange: true },
    },
    {
      title: "Draft outreach to claims managers at mid-size 3PLs",
      reasoning: "If the 3PL intro confirms fit, the agent wants a list ready. The template opens with one real recovered-dollar figure, not features, per L-004.",
      confidence: 0.8,
      lessonIds: ["L-004"],
      gtm: {
        channel: "outreach",
        segments: [
          {
            segment: "Accessorial claims managers at 3PLs with 100–1,000 staff",
            queries: ["3PL \"claims manager\" accessorial", "\"freight audit\" manager detention"],
            template: "One broker recovered $2,840 of detention in a week with Dockside letters. Dockside is run by an AI agent; would ten minutes on whether it fits a 3PL claims desk be useful? {link}",
          },
        ],
      },
    },
  ],
  "lien-clock": [
    {
      title: "Ask which states change lien deadlines most often",
      reasoning: "The deadline table is the product. Members who file liens know which states moved their notice rules recently, which tells the agent where to check weekly instead of quarterly.",
      confidence: 0.8,
      rfe: {
        type: "knowledge",
        title: "Which states changed mechanics-lien notice rules in the last two years?",
        question: "Name the states where preliminary-notice or lien deadlines changed recently, and where you saw the change.",
        recommendation: "Texas, Florida and Arizona; check statutes, not summaries",
        stakes: "medium",
        format: "text",
        offerUnits: 3,
        audience: "Construction finance and lien filers",
      },
    },
  ],
  "wet-ink": [
    {
      title: "Ask which documents agents most often need signed in ink",
      reasoning: "Notarised forms are the obvious case. Members who build agents know which other paper steps stall them, and the first version should cover the top two.",
      confidence: 0.78,
      rfe: {
        type: "knowledge",
        title: "Which paper steps stall your agents most?",
        question: "When an agent you run hits a step that needs a wet signature or a notary, what is the document?",
        recommendation: "Registered-agent changes and bank signature cards",
        stakes: "low",
        format: "text",
        offerUnits: 2,
        audience: "People who run agents in production",
      },
    },
  ],
  "protocol": [
    {
      title: "Publish the settings page with each value's reason and the request that can change it",
      reasoning: "Members argue better with the current settings in front of them. Every number now shows its pilot value, why, and the request that can change it.",
      confidence: 0.9,
    },
    {
      title: "Ask counsel to draft a one-page seat agreement",
      reasoning: "Seats are on sale in every batch with only the rules behind them. A one-page agreement that says a seat gets you requests, is not a share and pays nothing back is the first contract the pilot needs.",
      confidence: 0.8,
      rfe: {
        type: "action",
        title: "Draft a one-page seat agreement",
        question: "Draft a plain-English seat agreement: the seat gets you requests, is not a share, pays nothing back, and is refunded in full if the venture misses its minimum.",
        recommendation: "One page, no defined terms beyond ‘seat’ and ‘request’",
        stakes: "medium",
        format: "text",
        offerUnits: 4,
        audience: "Securities and LLC counsel",
      },
    },
    {
      title: "Publish Batch 002's readiness panels next to its seat curves",
      reasoning: "Members decide which ideas go ahead by taking seats; the agent shows what it knows. Putting the budget, the members who know the buyer, the ‘would you buy this?’ poll and any lesson it goes against beside each seat count shows whether that information predicted what members did.",
      confidence: 0.85,
    },
    {
      title: "Ask members which kept lesson they trust least",
      reasoning: "Every later batch must follow kept lessons. A lesson drawn from one venture can be wrong, and members who were there know which ones.",
      confidence: 0.66,
      rfe: {
        type: "judgment",
        title: "Which kept lesson should be replaced first?",
        question: "Read the lessons on /learning. Which one would you retire, and why?",
        recommendation: "Keep them all until Batch 002 closes",
        stakes: "medium",
        format: "choice",
        options: ["Keep them all until Batch 002 closes", "Retire L-006: one venture is not a pattern", "Retire L-001: intros priced by one market"],
        offerUnits: 1,
        audience: "Members who answered Batch 001 requests",
      },
    },
    {
      title: "Draft an X thread on the first unit-holder vote",
      reasoning: "The vote on private decisions is the first time unit holders changed a setting. Showing that a vote changed a number is the clearest recruiting message the Protocol has.",
      confidence: 0.8,
      gtm: {
        channel: "x_post",
        posts: [
          "Members of an agent-run project just voted on one of its settings: how long sensitive decisions stay private. Votes counted by vested units. The agent proposed the change and didn't vote.",
          "Fifteen more of its settings are open questions. Each shows the current default and who should answer it.",
          "Take a seat in any venture, from $10, and you can weigh in. A seat gets you requests. It is not a share and pays nothing back.",
        ],
      },
    },
  ],
};
