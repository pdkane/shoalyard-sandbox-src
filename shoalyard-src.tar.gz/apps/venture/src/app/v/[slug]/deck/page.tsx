import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, History, MessageCircleQuestion } from "lucide-react";
import { businessPlanFor, classificationOf, deckVersion, latestDeck, lookupVenture, seatPriceStatus, shareText } from "@av/protocol";
import { ShareMenu } from "@/components/share-menu";
import type { PitchDeck, SlideKey } from "@av/schema";
import { AskBlock, BudgetTable, BusinessPlanBlock, DeckNav, HonestyBar, MarketBars, MilestoneList, ProofBlock, RisksBlock, SlideCard, versionLine } from "@/components/deck-ui";
import { RosterTable } from "@/components/protocol-ui";
import { buttonVariants } from "@/components/ui/button";
import { getData } from "@/lib/data";
import { formatUsd } from "@/lib/format";
import { resolveVenture, rosterView } from "@/lib/venture";

export async function generateMetadata(props: PageProps<"/v/[slug]/deck">): Promise<Metadata> {
  const { slug } = await props.params;
  const { store } = await getData();
  const v = lookupVenture(store, slug)?.venture;
  return { title: v ? `${v.name}: deck` : "Deck" };
}

const CADENCE: Record<PitchDeck["pricing"]["cadence"], string> = { month: "a month", year: "a year", "one-time": "once", "per-use": "each time" };
const ALT_KIND: Record<PitchDeck["alternatives"][number]["kind"], string> = { incumbent: "Incumbent", workaround: "Workaround", "do-nothing": "Do nothing", adjacent: "Adjacent" };

export default async function DeckPage(props: PageProps<"/v/[slug]/deck">) {
  const { slug } = await props.params;
  const sp = await props.searchParams;
  const data = await getData();
  const { store, params } = data;
  const venture = resolveVenture(store, slug, "/deck");
  const latest = latestDeck(store, venture.id);
  if (!latest) notFound();
  const asked = typeof sp.v === "string" ? Number(sp.v) : undefined;
  const deck = asked === undefined ? latest : Number.isInteger(asked) ? deckVersion(store, venture.id, asked) : undefined;
  if (!deck) notFound();
  const isLatest = deck.version === latest.version;
  const roster = isLatest ? rosterView(data, venture) : undefined;
  const keys = deck.slides.map((s) => s.key);
  const style = { "--accent-color": venture.accent } as React.CSSProperties;
  const plan = businessPlanFor(deck, classificationOf(venture).customer, params);

  const extra: Partial<Record<SlideKey, React.ReactNode>> = {
    market: <MarketBars deck={deck} />,
    alternatives: deck.alternatives.length > 0 && (
      <ul className="flex flex-wrap gap-1.5 text-xs">
        {deck.alternatives.map((a) => (
          <li key={a.name}>
            <a href={`#${a.claimId}`} className="inline-block rounded-md border border-zinc-200 px-2 py-1 text-zinc-700 hover:border-zinc-400">
              <span className="text-zinc-400">{ALT_KIND[a.kind]}:</span> {a.name}
            </a>
          </li>
        ))}
      </ul>
    ),
    model: (
      <p className="rounded-lg bg-zinc-50 px-3 py-2 text-sm text-zinc-700">
        Price: <span className="font-medium text-zinc-900">{formatUsd(deck.pricing.price)}</span> per {deck.pricing.unit} {CADENCE[deck.pricing.cadence]}.
      </p>
    ),
    howItRuns: deck.proof && <ProofBlock proof={deck.proof} />,
    budget: <BudgetTable deck={deck} />,
    plan: plan && <BusinessPlanBlock plan={plan} unit={deck.pricing.unit} />,
    milestones: <MilestoneList deck={deck} />,
    risks: <RisksBlock deck={deck} />,
    ask: (
      <AskBlock
        deck={deck}
        params={params}
        priceStatus={seatPriceStatus(store, deck)}
        slug={venture.slug}
        roster={
          roster ? (
            <RosterTable rows={roster.rows} slug={venture.slug} gate={roster.gate} claim={roster.claim} />
          ) : (
            <p className="text-sm text-zinc-600">
              This version planned {deck.roster.reduce((s, r) => s + r.count, 0)} roles: {deck.roster.map((r) => `${r.label} (${r.count})`).join(", ")}.
            </p>
          )
        }
      />
    ),
  };

  return (
    <div style={style} className="space-y-6">
      <div className="space-y-3 print:hidden">
        <Link href={`/v/${venture.slug}`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> {venture.name}
        </Link>
        {!isLatest && (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
            You&apos;re reading v{deck.version}. It was superseded by{" "}
            <Link href={`/v/${venture.slug}/deck`} className="font-medium underline underline-offset-2">
              v{latest.version}
            </Link>
            .
          </p>
        )}
        {deck.banner && <p className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-700">{deck.banner}</p>}
      </div>
      <header className="space-y-3">
        <div className="h-1.5 w-16 rounded-full bg-[var(--accent-color)]" />
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{venture.name}: the deck</h1>
        <p className="max-w-2xl text-lg text-pretty text-zinc-700">{deck.purpose}</p>
        <p className="text-sm text-zinc-500">
          {versionLine(deck)} · written by {deck.author === "reconstructed" ? "the agent from the record" : "the agent"} · Protocol {deck.protocolVersion}
        </p>
        <HonestyBar deck={deck} className="max-w-md" />
        <div className="flex flex-wrap gap-2 print:hidden">
          <ShareMenu path={`/v/${venture.slug}/deck`} text={shareText({ kind: "venture", name: `${venture.name}'s deck`, announced: false, line: deck.purpose })} />
          <Link href={`/v/${venture.slug}/deck/changes`} className={buttonVariants({ variant: "outline", size: "sm" })}>
            <History /> What changed
          </Link>
          <Link href={`/v/${venture.slug}/qa`} className={buttonVariants({ variant: "outline", size: "sm" })}>
            <MessageCircleQuestion /> Questions and answers
          </Link>        </div>
      </header>
      <div className="lg:grid lg:grid-cols-[200px_minmax(0,720px)] lg:gap-8">
        <div className="sticky top-14 z-30 -mx-4 border-b border-zinc-200 bg-zinc-50/95 px-4 py-2 backdrop-blur sm:-mx-6 sm:px-6 lg:top-20 lg:mx-0 lg:self-start lg:border-0 lg:bg-transparent lg:p-0">
          <DeckNav slides={deck.slides} />
        </div>
        <div className="mt-4 space-y-4 lg:mt-0">
          {deck.slides.map((s, i) => (
            <SlideCard key={s.key} slide={s} index={i} prev={keys[i - 1]} next={keys[i + 1]} slug={venture.slug}>
              {extra[s.key]}
            </SlideCard>
          ))}
        </div>
      </div>
    </div>
  );
}
