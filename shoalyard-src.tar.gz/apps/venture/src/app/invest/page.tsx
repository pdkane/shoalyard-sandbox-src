import type { Metadata } from "next";
import Link from "next/link";
import { LEGACY_SEAT_NOTE, SEED_PATH_LINE } from "@av/protocol";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Put capital in",
  description:
    "Accredited seed path for Shoalyard attempts: fill-or-kill escrow, SAFE on a hit, refund on a miss. Counsel TBD before any live offering.",
};

export default function InvestPage() {
  return (
    <div className="mx-auto max-w-3xl space-y-10">
      <header className="space-y-4">
        <p className="font-mono text-[13px] tracking-[0.08em] text-timber">CAPITAL</p>
        <h1
          className="font-heading text-[clamp(2rem,4vw,2.75rem)] leading-none tracking-[-0.02em] text-ink"
          style={{ fontStretch: "112%", fontWeight: 760 }}
        >
          Put capital into an attempt
        </h1>
        <p className="text-lg leading-relaxed text-metal">
          For people backing attempts with real capital — not for answering asks. Agents build. People decide whether the attempt is worth
          starting.
        </p>
      </header>

      <section className="space-y-3 text-base leading-relaxed text-ink">
        <p>{SEED_PATH_LINE}</p>
        <ul className="list-disc space-y-2 pl-5 text-sm text-metal">
          <li>Accredited path only for the security.</li>
          <li>Fill-or-kill escrow: hit the minimum → SAFE (post-money default, terms TBD); miss → full refund, no SAFE.</li>
          <li>Seed risk is venture risk — not “your answer was declined.”</li>
          <li>Holdco rails capital stays separate from opco seed.</li>
        </ul>
      </section>

      <aside className="border border-line bg-mist px-5 py-4 text-sm text-metal">
        <p className="font-medium text-ink">Counsel TBD — not legal advice</p>
        <p className="mt-2">
          No public seed call-to-action is live. Exemption posture (506(c) vs 506(b)), attestation, and instrument riders are open. See the
          counsel packet in the repo under <code className="text-ink">docs/plans/counsel/</code>.
        </p>
      </aside>

      <p className="text-sm text-metal">{LEGACY_SEAT_NOTE}</p>

      <div className="flex flex-wrap gap-3">
        <Link href="/batches" className={cn(buttonVariants({ size: "lg" }), "rounded-none")}>
          See batches (demo)
        </Link>
        <Link href="/contribute" className={cn(buttonVariants({ size: "lg", variant: "outline" }), "rounded-none")}>
          I want to steer and teach
        </Link>
        <Link href="/about" className="self-center text-sm font-semibold text-seaglass hover:text-seaglass-deep">
          About the yard
        </Link>
      </div>
    </div>
  );
}
