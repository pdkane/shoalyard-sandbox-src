import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { defaultParams } from "@av/schema";
import { renderConstitution } from "../src/constitution";

const out = join(dirname(fileURLToPath(import.meta.url)), "..", "CONSTITUTION.md");
writeFileSync(out, renderConstitution(defaultParams()));
console.log(`Wrote ${out}`);
