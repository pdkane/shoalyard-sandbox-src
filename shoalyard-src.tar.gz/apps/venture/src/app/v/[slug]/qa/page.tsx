import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, FileText, MessageCircleQuestion } from "lucide-react";
import { latestDeck, lookupVenture, qaFor, qaWindow, questionsLeft, type QaSort , shareText } from "@av/protocol";
import { ShareMenu } from "@/components/share-menu";
import { EmptyState } from "@/components/empty-state";
import { AskForm } from "@/components/qa-forms";
import { QuestionCard, questionCards } from "@/components/qa-ui";
import { buttonVariants } from "@/components/ui/button";
import { getData } from "@/lib/data";
import { resolveVenture } from "@/lib/venture";
import { cn } from "@/lib/utils";

export async function generateMetadata(props: PageProps<"/v/[slug]/qa">): Promise<Metadata> {
  const { slug } = await props.params;
  const { store } = await getData();
  const v = lookupVenture(store, slug)?.venture;
  return { title: v ? `${v.name}: questions` : "Questions" };
}

const SORTS: { key: QaSort; label: string }[] = [
  { key: "top", label: "Top" },
  { key: "new", label: "New" },
  { key: "unanswered", label: "Unanswered" },
  { key: "routed", label: "Sent to members" },
];

export default async function QaPage(props: PageProps<"/v/[slug]/qa">) {
  const { slug } = await props.params;
  const sp = await props.searchParams;
  const data = await getData();
  const { store, params, viewer, member } = data;
  const venture = resolveVenture(store, slug, "/qa");
  if (venture.isProtocol) notFound();
  const deck = latestDeck(store, venture.id);
  const sort = SORTS.some((s) => s.key === sp.sort) ? (sp.sort as QaSort) : "top";
  const w = qaWindow(store, venture, params);
  const all = qaFor(store, venture, { viewer: member ? viewer : undefined, sort });
  const cards = questionCards(data, venture, all);
  const canAsk = w.state === "open" || (w.state === "early" && member?.qualification === "qualified");
  const left = questionsLeft(store, venture, member, params);

  return (
    <div className="mx-auto max-w-3xl space-y-6" style={{ "--accent-color": venture.accent } as React.CSSProperties}>
      <div className="space-y-2">
        <Link href={`/v/${venture.slug}`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> {venture.name}
        </Link>
        <h1 className="text-2xl font-semibold tracking-tight">Questions about {venture.name}</h1>
        <p className="text-sm text-pretty text-zinc-500">
          Anyone can ask; the operating agent answers from the deck only, cites the claims it used, and says when it doesn&apos;t know. Questions it can&apos;t answer go to members
          as requests. The most upvoted are answered first.
        </p>
        <div className="flex flex-wrap gap-2">
          {deck && (
            <Link href={`/v/${venture.slug}/deck`} className={buttonVariants({ variant: "outline", size: "sm" })}>
              <FileText /> Read the deck (v{deck.version})
            </Link>
          )}
          <ShareMenu path={`/v/${venture.slug}/qa`} text={shareText({ kind: "venture", name: `Questions about ${venture.name}`, announced: false, line: "anyone can ask; the agent answers from the deck and says when it doesn't know." })} />
        </div>
      </div>

      {canAsk ? (
        <AskForm
          slug={venture.slug}
          left={left}
          visitor={!member}
          maxChars={params.QA_MAX_CHARS}
          note={member?.qualification === "pending" ? `Before you're verified: ${params.QA_PENDING_DAILY} a day.` : undefined}
        />
      ) : (
        <p className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-600">{w.reason}</p>
      )}

      <nav aria-label="Sort questions" className="inline-flex h-8 w-fit max-w-full items-center overflow-x-auto rounded-lg bg-muted p-[3px]">
        {SORTS.map((s) => (
          <Link
            key={s.key}
            href={`/v/${venture.slug}/qa${s.key === "top" ? "" : `?sort=${s.key}`}`}
            aria-current={s.key === sort ? "page" : undefined}
            className={cn(
              "inline-flex h-[calc(100%-1px)] items-center rounded-md px-2.5 text-sm font-medium whitespace-nowrap text-zinc-600 hover:text-zinc-900",
              s.key === sort && "bg-white text-zinc-900 shadow-sm",
            )}
          >
            {s.label}
          </Link>
        ))}
      </nav>

      {cards.length === 0 ? (
        <EmptyState icon={MessageCircleQuestion} title={sort === "top" ? "No questions yet" : "Nothing here"}>
          {sort === "top" ? "Ask the first one." : "Try another tab."}
        </EmptyState>
      ) : (
        <div className="space-y-3">
          {cards.map((c) => (
            <QuestionCard key={c.q.id} {...c} />
          ))}
        </div>
      )}
    </div>
  );
}
