import type { Rfe } from "@av/schema";

export interface Extraction {
  choice?: string;
  scale?: number;
  summary: string;
  extractedBy: string;
}

const STOP = new Set(["the", "and", "for", "with", "that", "this", "from", "your", "are", "but", "not", "you", "our", "per"]);

function tokens(s: string): string[] {
  return s
    .toLowerCase()
    .split(/[^a-z0-9$%]+/)
    .filter((t) => t.length > 2 && !STOP.has(t));
}

/**
 * Heuristic extraction from a short text or voice transcript: match an option
 * by word overlap, read a scale number, and keep a one-line summary. Claude
 * Haiku replaces this when ANTHROPIC_API_KEY is set (see agent/claude.ts).
 */
export function extractHeuristic(rfe: Pick<Rfe, "format" | "options" | "scaleLabels">, text: string): Extraction {
  const clean = text.trim().replace(/\s+/g, " ");
  const summary = clean.length > 180 ? `${clean.slice(0, 177)}…` : clean;
  const out: Extraction = { summary, extractedBy: "heuristic" };
  if (rfe.format === "scale") {
    const m = clean.match(/\b([1-5])\b/);
    if (m) out.scale = Number(m[1]);
  }
  if (rfe.options?.length) {
    const words = new Set(tokens(clean));
    const negated = /\b(no|not|don't|dont|never|against|hold off)\b/i.test(clean);
    let best: { option: string; score: number } | undefined;
    for (const option of rfe.options) {
      const ot = tokens(option);
      const score = ot.filter((t) => words.has(t)).length / Math.max(1, ot.length);
      if (!best || score > best.score) best = { option, score };
    }
    if (best && best.score >= 0.34) out.choice = best.option;
    else if (rfe.options.length === 2 && /\b(yes|agree|go ahead|do it|sounds right)\b/i.test(clean) && !negated) {
      out.choice = rfe.options[0];
    } else if (rfe.options.length === 2 && negated) {
      out.choice = rfe.options[1];
    }
  }
  return out;
}
