import Link from "next/link";
import { Lock } from "lucide-react";
import { TIER_NOTE, type DecisionTier, type DecisionView } from "@av/protocol";
import type { DecisionBin, Lesson } from "@av/schema";
import { BIN_LABELS, BinBadge, Pill } from "@/components/badges";
import { EmptyState } from "@/components/empty-state";
import { lessonCitation } from "@/components/lessons-gate";
import { FlagForm } from "@/components/protocol-forms";
import { formatDate, formatDateTime, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const STATUS_TEXT: Record<string, string> = {
  awaiting_members: "Asking members",
  awaiting_steward: "Waiting for the steward",
  taken: "Taken",
  rejected: "Not taken",
};

export function modelLabel(model?: string) {
  if (!model) return undefined;
  return model === "script" ? "Pre-written replies" : model === "steward" ? "The steward" : model === "rule" ? "A fixed rule" : model;
}

export function DecisionStatus({ status }: { status: DecisionView["status"] }) {
  return (
    <Pill
      className={cn(
        status === "taken" && "border-zinc-200 bg-white",
        status === "rejected" && "border-zinc-200 bg-zinc-100 text-zinc-500",
        status === "awaiting_steward" && "border-rose-200 bg-rose-50 text-rose-800",
        status === "awaiting_members" && "border-amber-200 bg-amber-50 text-amber-800",
      )}
    >
      {STATUS_TEXT[status]}
    </Pill>
  );
}

export function TierNote({ tier, className }: { tier: DecisionTier; className?: string }) {
  return <p className={cn("text-xs text-zinc-500", className)}>{TIER_NOTE[tier]}</p>;
}

/** The private-decision notice: what the public still sees while the text is held back. */
export function PrivateNotice({ d }: { d: DecisionView }) {
  if (!d.private) return null;
  return (
    <div className="rounded-lg border border-dashed border-zinc-300 bg-zinc-50 p-4">
      <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
        <Lock className="size-3.5" />
        <span className="font-medium text-zinc-700">Published later</span>
        <BinBadge bin={d.bin} />
        <span>{formatDateTime(d.at)}</span>
      </div>
      <p className="mt-2 text-sm text-zinc-700">
        Kept private for now: {d.private.reason}. Published on <strong>{formatDate(d.private.until)}</strong>.
      </p>
    </div>
  );
}

/** Lessons followed: names for those who can read lessons, a count for the rest. */
export function DecisionLessons({
  d,
  lessonsVisible,
  headline,
}: {
  d: DecisionView;
  lessonsVisible: boolean;
  headline: (id: string) => string | undefined;
}) {
  if (!d.lessonIds?.length && !d.contradicts?.length) return null;
  if (!lessonsVisible)
    return (
      <p className="mt-2 flex flex-wrap items-center gap-1.5 text-xs text-zinc-500">
        {!!d.lessonIds?.length && <span className="rounded-md border border-zinc-200 bg-zinc-50 px-2 py-0.5">{lessonCitation(d.lessonIds.length)}</span>}
        {!!d.contradicts?.length && (
          <span className="rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-amber-900">Went against an earlier lesson, so it needed more review</span>
        )}
      </p>
    );
  return (
    <div className="mt-2 flex flex-wrap items-center gap-1.5 text-xs">
      {d.lessonIds?.map((id) => (
        <Link key={id} href={`/learning#${id}`} className="rounded-md border border-sky-200 bg-sky-50 px-2 py-0.5 text-sky-900 hover:underline">
          <span className="font-medium">Follows {id}</span>
          {headline(id) ? `: ${headline(id)}` : ""}
        </Link>
      ))}
      {d.contradicts?.map((id) => (
        <Link key={id} href={`/learning#${id}`} className="rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-amber-900 hover:underline">
          <span className="font-medium">Goes against {id}, so it needed more review</span>
          {headline(id) ? `: ${headline(id)}` : ""}
        </Link>
      ))}
    </div>
  );
}

export function ConductNote({ d }: { d: DecisionView }) {
  if (!d.conduct || d.conduct.result === "pass") return null;
  return (
    <div
      className={cn(
        "mt-2 rounded-md border px-3 py-2 text-xs",
        d.conduct.result === "stop" ? "border-rose-200 bg-rose-50 text-rose-900" : "border-amber-200 bg-amber-50 text-amber-900",
      )}
    >
      <p className="font-medium">Conduct check: {d.conduct.result === "stop" ? "blocked" : "concern"}</p>
      {d.conduct.findings.length > 0 && <p className="mt-0.5">{d.conduct.findings.join(" ")}</p>}
      {d.conduct.counselNote && <p className="mt-0.5">Note for lawyers: {d.conduct.counselNote}</p>}
    </div>
  );
}

export function DecisionLog({
  decisions,
  tier,
  ventureSlug,
  basePath,
  bin,
  limit,
  flaggable,
  lessons = [],
  lessonsVisible = false,
}: {
  decisions: DecisionView[];
  tier: DecisionTier;
  ventureSlug: string;
  basePath: string;
  bin?: DecisionBin;
  limit?: number;
  flaggable?: boolean;
  /** For citations: a cited lesson shows its headline. */
  lessons?: Pick<Lesson, "id" | "headline">[];
  /** Lessons are for members (Article 3): others see how many were followed, not which. */
  lessonsVisible?: boolean;
}) {
  const headline = (id: string) => lessons.find((l) => l.id === id)?.headline;
  const filtered = bin ? decisions.filter((d) => d.bin === bin) : decisions;
  const shown = limit ? filtered.slice(0, limit) : filtered;
  const tabs: { key?: DecisionBin; label: string; count: number }[] = [
    { label: "All", count: decisions.length },
    ...(["auto", "advisory", "gated"] as const).map((b) => ({
      key: b,
      label: BIN_LABELS[b],
      count: decisions.filter((d) => d.bin === b).length,
    })),
  ];
  return (
    <div className="space-y-4">
      <TierNote tier={tier} />
      <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Filter by who approved">
        {tabs.map((t) => (
          <Link
            key={t.label}
            href={t.key ? `${basePath}?approval=${t.key}#log` : `${basePath}#log`}
            scroll={false}
            role="tab"
            aria-selected={bin === t.key}
            className={cn(
              "inline-flex h-7 items-center gap-1.5 rounded-full border px-3 text-xs font-medium transition",
              bin === t.key ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white text-zinc-600 hover:border-zinc-300",
            )}
          >
            {t.label} <span className="tabular-nums opacity-70">{t.count}</span>
          </Link>
        ))}
      </div>
      {shown.length === 0 ? (
        <EmptyState icon={Lock} title="No decisions of this kind yet" />
      ) : (
        <ol className="relative space-y-3 border-l border-zinc-200 pl-5">
          {shown.map((d) => (
            <li key={d.id} id={d.id} className="relative">
              <span
                className={cn(
                  "absolute top-4 -left-[25px] size-2.5 rounded-full border-2 border-white",
                  d.redacted ? "bg-zinc-400" : d.bin === "gated" ? "bg-rose-500" : d.bin === "advisory" ? "bg-amber-500" : "bg-emerald-500",
                )}
              />
              {d.redacted ? (
                <PrivateNotice d={d} />
              ) : (
                <div className="rounded-lg border border-zinc-200 bg-white p-4">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
                    <BinBadge bin={d.bin} />
                    <DecisionStatus status={d.status} />
                    <span>{formatDateTime(d.at)}</span>
                    {d.spendUsd !== undefined && <span className="tabular-nums">{formatUsd(d.spendUsd)}</span>}
                    {d.confidence !== undefined && <span className="ml-auto tabular-nums">{Math.round(d.confidence * 100)}% sure</span>}
                  </div>
                  <p className="mt-2 font-medium text-zinc-900">
                    <Link href={`/v/${ventureSlug}/decisions/${d.id}`} className="hover:underline">
                      {d.title}
                    </Link>
                  </p>
                  {d.reasoning ? (
                    <p className="mt-1 text-sm text-zinc-600">{d.reasoning}</p>
                  ) : (
                    d.summary && <p className="mt-1 text-sm text-zinc-600">{d.summary}</p>
                  )}
                  {!!d.binReasons?.length && <p className="mt-2 text-xs text-zinc-500">Why it did or didn&apos;t need approval: {d.binReasons.join("; ")}</p>}
                  <DecisionLessons d={d} lessonsVisible={lessonsVisible} headline={headline} />
                  <ConductNote d={d} />
                  {d.outcome && <p className="mt-2 text-sm text-zinc-800">Outcome: {d.outcome}</p>}
                  {d.stewardNote && <p className="mt-1 text-sm text-zinc-700">Steward note: “{d.stewardNote}”</p>}
                  <div className="mt-2 flex flex-wrap gap-3 text-xs text-zinc-500">
                    <span>Decided by {d.decidedBy.charAt(0).toLowerCase() + d.decidedBy.slice(1)}</span>
                    {modelLabel(d.model) && <span>Agent: {modelLabel(d.model)}</span>}
                    {d.rfeId && (
                      <Link href={`/rfe/${d.rfeId}`} className="underline underline-offset-2 hover:text-zinc-800">
                        Related request
                      </Link>
                    )}
                    {d.private && <span>{tier === "steward" ? "Private until" : "Published"} {formatDate(d.private.until)}</span>}
                    {flaggable && d.status !== "rejected" && <FlagForm kind="decision" id={d.id} label={d.title ?? ""} />}
                  </div>
                </div>
              )}
            </li>
          ))}
        </ol>
      )}
      {limit && filtered.length > limit && (
        <p className="text-sm text-zinc-500">
          Showing {limit} of {filtered.length}.{" "}
          <Link href={`/v/${ventureSlug}/ledger`} className="font-medium text-zinc-900 underline underline-offset-2">
            Full public record
          </Link>
        </p>
      )}
    </div>
  );
}
