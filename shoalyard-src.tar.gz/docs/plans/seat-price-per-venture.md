# Per-venture seat price (decided Oct 31, 2026)

Status: all three sections below are built (commits da5a5cb, 16bbfa3, 3153f51, f834c02, 2cbaf3d). The summary of what was built is in `foundation-plan.md`, under "Seat price, sharing, scarcity and the proof". It differs from these notes in four places:
- The embeddable badge is not built yet.
- Sell-through is tracked by price and customer type (the learning page's "Seats sold, by price") and by channel (the share funnel). Recruiting drafts already existed, but the deck has no promotion plan of its own yet.
- The seat maximum shown in "N of M seats left" is the deck's own maximum (the minimum × 1.5). Code enforces it, so the count is true. It is not a cap on what the network can sell: a venture that fills up gets a waitlist.
- The operability check is on the proof only. The licence rule applies to the Protocol: it holds no licence while its legal form is open, so a licensed step stops at signed letters of intent and the venture is marked "hand-off expected".

The agent proposes each venture's seat price. The steward signs off (it's a pricing decision).

Bounds computed by code:
- Upper bound from people: price <= proof budget / headcount needed (headcount = max(roster size, seats for answer coverage)), so the venture always has enough seat holders to staff its roster and answer its requests.
- Protocol-wide SEAT_PRICE_MIN and SEAT_PRICE_MAX settings (e.g. $10 and $100). SEAT_PRICE_MAX is protected: a high price starts to look like an investment rather than access; add it to the counsel request.
- NO cap based on what the network can "realistically sell". The user: "that's a question for the market to decide... a huge element of this is promotion of the ventures, so our market will be growing fairly virally." The market decides through the raise: a miss means a full refund.

The agent picks a price within the bounds and justifies it with tagged claims from the idea:
- Roster: who it needs (enterprise buyers or licensed professionals support a higher price and filter for seriousness; consumer ideas need many everyday users, so a lower price).
- TAM and ICP: a narrow, high-value niche means a smaller, pricier roster; a broad consumer market means a wider, cheaper one.

Seats needed = proof budget / price (rounded up), never below the headcount needed.

Promotion is first-class: the pitch includes a promotion plan (role-targeted recruiting posts the agent drafts and the steward approves, a referral link per member, a share card). Track seat sell-through by price, classification and channel in the learning loop, so future agents price from market evidence, not our guess.

Ventures already pitched keep their price (Article 6).

## Sharing and scarcity (decided Oct 31, 2026)
- Sharing tools are open to EVERYONE, including visitors with no account. Every public venture, batch, deck and Q&A page has a share action: copy link, a native share sheet on mobile, prefilled X/LinkedIn posts, a generated share card (Open Graph image per venture/batch showing name, one-line problem, seats left, roles open, window closes), and an embeddable badge.
- Every share link carries an anonymous ref code (no account needed; create one on first share and store it in a cookie). Attribution is tracked through visit, candidate, qualified, seat and role claimed.
- Rewards: a referral earns units ONLY when the referred person fills a roster role and does the work (that's an access contribution). Never reward seat sales with units; that would tie money to earnings and look like a pyramid. Show referrers their funnel.
- Scarcity drives conversion, and it must be REAL (Article 8: no lying). No fake counters, no fake urgency:
  - Max seats per venture (the deck's seat maximum) shown as "N of M seats left".
  - Batch windows with a countdown to close.
  - Early access for qualified members before a batch goes public; a visitor sees "Members got first look 48h ago".
  - Codenamed announced ventures (already built) as teasers: shareable, with details unlocked for members.
  - Roster roles shown as "2 of 3 claimed".
  - A waitlist for full ventures and the next batch.
- Conversion path on every share landing: visitor, then "Get notified / claim a role / qualify", then a seat. The CTA copy explains that members see more (lessons, reasoning) and get first access.
- Track the conversion funnel by channel and venture in the learning loop.

## Constrain the proof, not the idea (decided Oct 31, 2026)
- Ideas are NOT limited to businesses agents can run end to end forever. The PROOF PHASE must be operable by the agent, plus members (via requests), plus contractors (level 2, with steward sign-off). No employees, and no licence the venture itself would have to hold, unless the Protocol already holds it.
- Every idea includes a proof plan: the narrowest wedge that tests real demand (pre-orders, a concierge or manual version, a paid pilot, a waitlist with deposits), listed as tasks, each with who does it: agent / member request / contractor.
- An operability check in code rejects ideas whose proof needs an employee, a licence or an in-person presence nobody can cover. The agent must reshape the proof, e.g. a hardware idea is proven by pre-orders, not manufacturing.
- Ideas whose eventual business needs employees are welcome; that's what the hand-off is for. The deck states "What the entrepreneur would need to build" beyond the proof.
- Add a classification/disclosure field: "Proof run by: agent / agent + members / agent + contractors". Add the "Long-term operator: agents / hand-off expected" estimate to the deck.
