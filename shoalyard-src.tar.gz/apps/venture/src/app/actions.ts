"use server";

import { cookies } from "next/headers";
import { refresh } from "next/cache";
import { redirect } from "next/navigation";
import {
  answerQuestion,
  approveHeld,
  askQuestion,
  buySeat,
  certifyFlag,
  claimRole,
  hideQuestion,
  toggleUpvote,
  withdrawRole,
  withdrawSeat,
  type AnswerDraft,
  completeOnboarding,
  confirmTag,
  decideVerification,
  declineMember,
  flagItem,
  HANDLE_RE,
  killVenture,
  linkAccount,
  markGtmPosted,
  memberByHandle,
  ProtocolError,
  publishPostMortem,
  resolveParams,
  respond,
  rewriteTagValue,
  rfeById,
  stewardDecide,
  stewardVerifyAttribute,
  stewardCheckOffer,
  submitOffer,
  withdrawOffer,
  ensureShareCode,
  recordVisit,
  shareCodeOf,
  shareCodesFor,
  lookupVenture,
  cohortByNumber,
  SHARE_CODE_RE,
  joinWaitlist,
  type OnboardingProfile,
} from "@av/protocol";
import { advanceAgent, answerWithClaude, claudeEnabled, clusterWithClaude, extractAnswer, formatLog, spawnBatch } from "@av/protocol/agent";
import { loadStore, mutateStore, resetStore } from "@av/protocol/store";
import {
  KILL_REASONS,
  MEMBER_ATTRIBUTES,
  ROSTER_ROLE_KEYS,
  TAG_AXES,
  type KillReason,
  type Member,
  type MemberAttribute,
  type RosterRoleKey,
  type TagAxis,
} from "@av/schema";
import { getData, VIEWER_COOKIE, VISITOR } from "@/lib/data";
import { FROM_COOKIE, newCode, readShareCookies, setShareCookie, SHARE_COOKIE, VISITOR_ID_COOKIE } from "@/lib/share";
import { SHARE_CHANNELS, type ShareChannel, type Store } from "@av/schema";

export interface ActionState {
  ok: boolean;
  error?: string;
  message?: string;
  lines?: string[];
}

const fail = (err: unknown): ActionState => ({
  ok: false,
  error: err instanceof ProtocolError ? err.message : err instanceof Error ? err.message : "Something went wrong.",
});

const str = (fd: FormData, key: string) => String(fd.get(key) ?? "").trim();

async function setViewer(handle: string) {
  (await cookies()).set(VIEWER_COOKIE, handle, { path: "/", sameSite: "lax", maxAge: 60 * 60 * 24 * 90 });
}

export async function setViewerAction(formData: FormData) {
  const handle = str(formData, "handle");
  const store = loadStore();
  const m = memberByHandle(store, handle);
  if (m) await setViewer(m.handle);
  else if (handle === VISITOR) await setViewer(VISITOR);
  refresh();
}

export async function buySeatAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const slug = str(formData, "slug");
  const handle = str(formData, "handle").replace(/^@/, "");
  const source = str(formData, "ref") || undefined;
  if (!HANDLE_RE.test(handle)) return { ok: false, error: "Choose a handle: 2–24 letters, numbers or underscores." };
  if (formData.get("agree") !== "on") return { ok: false, error: "Please confirm you understand a seat gets you requests, is not a share, and pays nothing back." };
  let onboarded = false;
  let qualified = false;
  const share = await readShareCookies();
  try {
    await mutateStore((store) => {
      const r = buySeat(store, { slug, handle, source, referredBy: share.from });
      linkOwnCode(store, share.own, r.member.handle);
      onboarded = !!r.member.onboardedAt;
      qualified = r.member.qualification === "qualified";
    });
  } catch (err) {
    return fail(err);
  }
  await setViewer(handle);
  redirect(!onboarded ? `/onboarding?v=${slug}` : qualified ? `/inbox?joined=${slug}` : "/onboarding?step=qualify");
}

export async function completeOnboardingAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer, store } = await getData();
  const list = (k: string) =>
    str(formData, k)
      .split(/[,;\n]/)
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 8);
  const profile: OnboardingProfile = {
    role: str(formData, "role"),
    industry: str(formData, "industry"),
    seniority: (str(formData, "seniority") || "mid") as Member["seniority"],
    companies: list("companies"),
    buyingAuthority: str(formData, "buyingAuthority") || "Not stated",
    tools: list("tools"),
    verticals: list("verticals"),
    canReach: list("canReach"),
    dailyPushCap: Math.min(10, Math.max(1, Number(str(formData, "dailyPushCap")) || 3)),
  };
  if (!profile.role || !profile.industry) return { ok: false, error: "Tell the agent your role and industry." };
  const params = resolveParams(store);
  const clusters = [...new Set(store.members.map((m) => m.cluster))];
  profile.cluster = await clusterWithClaude(profile, clusters, params);
  let first: string | undefined;
  let qualified = false;
  try {
    await mutateStore((s) => {
      const r = completeOnboarding(s, viewer, profile);
      first = r.firstRfe?.id;
      qualified = memberByHandle(s, viewer)?.qualification === "qualified";
    });
  } catch (err) {
    return fail(err);
  }
  if (!qualified) redirect("/onboarding?step=qualify");
  redirect(first ? `/inbox?welcome=${first}` : "/inbox?welcome=1");
}

export async function linkAccountAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  const source = str(formData, "source") === "x" ? "x" : "linkedin";
  try {
    await mutateStore((s) => linkAccount(s, viewer, source, str(formData, "ref")));
    refresh();
    return { ok: true, message: `${source === "x" ? "X" : "LinkedIn"} linked. It waits for the steward's review.` };
  } catch (err) {
    return fail(err);
  }
}

export async function decideVerificationAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  const approve = str(formData, "approve") === "yes";
  const handle = str(formData, "handle");
  try {
    const r = await mutateStore((s) => decideVerification(s, { by: viewer, handle, verificationId: str(formData, "verificationId"), approve }));
    refresh();
    return { ok: true, message: approve ? (r.qualified ? `Confirmed. @${handle} is now qualified.` : "Confirmed.") : "Rejected." };
  } catch (err) {
    return fail(err);
  }
}

export async function verifyAttributeAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  const attribute = str(formData, "attribute") as MemberAttribute;
  if (!MEMBER_ATTRIBUTES.includes(attribute)) return { ok: false, error: "Pick an attribute." };
  const handle = str(formData, "handle");
  try {
    const r = await mutateStore((s) => stewardVerifyAttribute(s, { by: viewer, handle, attribute }));
    refresh();
    return { ok: true, message: r.qualified ? `Verified. @${handle} is now qualified.` : "Verified." };
  } catch (err) {
    return fail(err);
  }
}

export async function declineMemberAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => declineMember(s, { by: viewer, handle: str(formData, "handle") }));
    refresh();
    return { ok: true, message: "Declined. They keep their seats but can't answer requests." };
  } catch (err) {
    return fail(err);
  }
}

const asAxis = (s: string): TagAxis => {
  if (!TAG_AXES.includes(s as TagAxis)) throw new ProtocolError("Unknown tag axis.");
  return s as TagAxis;
};

export async function confirmTagAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer, isSteward } = await getData();
  if (!isSteward) return { ok: false, error: "Only a steward confirms tags." };
  const kind = str(formData, "kind") as "venture" | "rfe" | "lesson";
  const value = str(formData, "value");
  const newValue = str(formData, "newValue") || undefined;
  try {
    await mutateStore((s) => confirmTag(s, { kind, id: str(formData, "id"), axis: asAxis(str(formData, "axis")), value, newValue, by: viewer }));
    refresh();
    return { ok: true, message: newValue && newValue !== value ? `Edited to “${newValue}” and confirmed.` : "Confirmed." };
  } catch (err) {
    return fail(err);
  }
}

export async function rewriteTagAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer, isSteward } = await getData();
  if (!isSteward) return { ok: false, error: "Only a steward edits the vocabulary." };
  try {
    const r = await mutateStore((s) =>
      rewriteTagValue(s, { axis: asAxis(str(formData, "axis")), from: str(formData, "from"), to: str(formData, "to"), by: viewer }),
    );
    refresh();
    return { ok: true, message: `${r.action === "merge" ? "Merged" : "Renamed"}; ${r.affected} item${r.affected === 1 ? "" : "s"} rewritten and logged.` };
  } catch (err) {
    return fail(err);
  }
}

export async function flagAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  const kind = str(formData, "kind") as "decision" | "rfe" | "venture";
  try {
    await mutateStore((s) => flagItem(s, { by: viewer, kind, id: str(formData, "id"), reason: str(formData, "reason") }));
    refresh();
    return { ok: true, message: "Flagged. Members now vote on it; the result stands unless it breaks the rules." };
  } catch (err) {
    return fail(err);
  }
}

export async function certifyFlagAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => certifyFlag(s, str(formData, "flagId"), viewer));
    refresh();
    return { ok: true, message: "Confirmed and logged." };
  } catch (err) {
    return fail(err);
  }
}

const asKillReason = (s: string): KillReason | undefined => (KILL_REASONS.includes(s as KillReason) ? (s as KillReason) : undefined);

export async function publishPostMortemAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  const killReason = asKillReason(str(formData, "killReason"));
  if (!killReason) return { ok: false, error: "Pick a kill reason." };
  try {
    await mutateStore((s) => publishPostMortem(s, { slug: str(formData, "slug"), by: viewer, killReason, summary: str(formData, "summary") || undefined }));
    refresh();
    return { ok: true, message: "Post-mortem published. The learning loop has read it." };
  } catch (err) {
    return fail(err);
  }
}

export async function spawnBatchAction(): Promise<ActionState> {
  const { isSteward } = await getData();
  if (!isSteward) return { ok: false, error: "Only a steward can announce a batch." };
  try {
    const logs = await mutateStore((s) => spawnBatch(s));
    refresh();
    return { ok: true, lines: logs.map(formatLog), message: "Next batch announced." };
  } catch (err) {
    return fail(err);
  }
}

export async function extractAction(rfeId: string, text: string) {
  const store = loadStore();
  const rfe = rfeById(store, rfeId);
  if (!rfe || !text.trim()) return null;
  return extractAnswer(rfe, text, resolveParams(store));
}

export async function answerAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer, store, params } = await getData();
  const rfe = rfeById(store, str(formData, "rfeId"));
  if (!rfe) return { ok: false, error: "That request no longer exists." };
  const via = (str(formData, "via") || "structured") as "structured" | "text" | "voice";
  let choice = str(formData, "choice") || undefined;
  const scaleRaw = str(formData, "scale");
  let scale = scaleRaw ? Number(scaleRaw) : undefined;
  const text = str(formData, "text") || undefined;
  const transcript = via === "voice" ? text : undefined;
  let extractedBy: string | undefined;
  if (via !== "structured" && !text) return { ok: false, error: "Write or record an answer first." };
  if (via !== "structured" && text && ((rfe.format === "choice" && !choice) || (rfe.format === "scale" && !scale))) {
    const ex = await extractAnswer(rfe, text, params);
    choice = choice ?? ex.choice;
    scale = scale ?? ex.scale;
    extractedBy = ex.extractedBy;
    if (rfe.format === "choice" && !choice) {
      return { ok: false, error: "The agent couldn't tell which option you meant. Pick one under “Extracted answer”." };
    }
  }
  const counter = str(formData, "offer") === "counter" ? Number(str(formData, "counterUnits")) : undefined;
  if (counter !== undefined && !(counter > 0)) return { ok: false, error: "Enter the units you'd accept." };
  try {
    const res = await mutateStore((s) =>
      respond(s, {
        rfeId: rfe.id,
        handle: viewer,
        via,
        choice,
        scale,
        text: via === "voice" ? undefined : text,
        transcript,
        extractedBy,
        counterUnits: counter,
      }),
    );
    refresh();
    if (rfe.kind === "governance") {
      return { ok: true, message: `Vote recorded with weight ${res.response.weight ?? 0} vested units.` };
    }
    return {
      ok: true,
      message: res.resolved
        ? "Your answer closed the request. Your grant is on the ledger."
        : `Answer recorded. ${res.n ? `${res.n.effective} of ${res.n.target} distinct responses so far.` : ""}`,
    };
  } catch (err) {
    return fail(err);
  }
}

export async function stewardDecisionAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  const approve = str(formData, "approve") === "yes";
  try {
    await mutateStore((s) => stewardDecide(s, str(formData, "decisionId"), approve, str(formData, "note"), viewer));
    refresh();
    return { ok: true, message: approve ? "Approved and logged." : "Rejected and logged." };
  } catch (err) {
    return fail(err);
  }
}

export async function killAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  if (str(formData, "confirm") !== str(formData, "slug")) return { ok: false, error: "Type the venture's slug to confirm." };
  const killReason = asKillReason(str(formData, "killReason"));
  if (!killReason) return { ok: false, error: "Pick a kill reason." };
  try {
    await mutateStore((s) => killVenture(s, str(formData, "slug"), viewer, str(formData, "note"), killReason));
    refresh();
    return { ok: true, message: "Venture killed. Open requests closed; post-mortem drafted." };
  } catch (err) {
    return fail(err);
  }
}

export async function markPostedAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => markGtmPosted(s, str(formData, "rfeId"), viewer, str(formData, "url") || undefined));
    refresh();
    return { ok: true, message: "Marked as posted. Arrivals with this draft's ref will be attributed to it." };
  } catch (err) {
    return fail(err);
  }
}

export async function advanceAgentAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const { isSteward } = await getData();
  if (!isSteward) return { ok: false, error: "Only a steward can advance the agent in this demo." };
  const ticks = Math.min(5, Math.max(1, Number(str(formData, "ticks")) || 1));
  try {
    const logs = await advanceAgent({ ticks, venture: str(formData, "venture") || undefined });
    refresh();
    return { ok: true, lines: logs.filter((l) => l.kind !== "clock").map(formatLog), message: `Ran ${ticks} step${ticks > 1 ? "s" : ""}.` };
  } catch (err) {
    return fail(err);
  }
}

/** A visitor names a handle the first time they act; after that the cookie carries it. */
function actingHandle(fd: FormData, viewer: string, member: Member | undefined): string | ActionState {
  if (member) return member.handle;
  const handle = str(fd, "handle").replace(/^@/, "");
  if (!handle || handle === viewer) return { ok: false, error: "Choose a handle first." };
  if (!HANDLE_RE.test(handle)) return { ok: false, error: "Choose a handle: 2–24 letters, numbers or underscores." };
  return handle;
}

export async function askQuestionAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer, member, params } = await getData();
  const handle = actingHandle(fd, viewer, member);
  if (typeof handle !== "string") return handle;
  const slug = str(fd, "slug");
  let asked;
  try {
    const share = await readShareCookies();
    asked = await mutateStore((s) => {
      const q = askQuestion(s, { slug, handle, text: str(fd, "text"), source: str(fd, "ref") || undefined, referredBy: share.from });
      linkOwnCode(s, share.own, handle);
      return q;
    });
  } catch (err) {
    return fail(err);
  }
  if (!member) await setViewer(handle);
  if (asked.status === "held") {
    refresh();
    return { ok: true, message: "Your question is waiting for the steward's conduct check. Only you and the steward can see it until then." };
  }
  let draft: AnswerDraft | undefined;
  if (claudeEnabled()) {
    const store = loadStore();
    const venture = store.ventures.find((v) => v.id === asked.ventureId)!;
    draft = await answerWithClaude(store, venture, asked, params).catch(() => undefined);
  }
  try {
    const q = await mutateStore((s) => answerQuestion(s, s.questions.find((x) => x.id === asked.id)!, draft));
    refresh();
    const said = { answered: "The agent answered from the deck.", partial: "The agent answered part of it and sent the rest to members.", unknown: "The agent didn't know, and sent it to members as a request." };
    return { ok: true, message: q.status === "held" ? "The answer is waiting for the steward's conduct check." : q.answer ? said[q.answer.status] : "Question posted." };
  } catch (err) {
    return fail(err);
  }
}

export async function upvoteAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer, member } = await getData();
  if (!member) return { ok: false, error: "Ask a question or claim a role first, so your upvote has a handle." };
  try {
    await mutateStore((s) => toggleUpvote(s, { id: str(fd, "id"), handle: viewer }));
    refresh();
    return { ok: true };
  } catch (err) {
    return fail(err);
  }
}

export async function hideQuestionAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => hideQuestion(s, { by: viewer, id: str(fd, "id"), reason: str(fd, "reason") }));
    refresh();
    return { ok: true, message: "Hidden. The placeholder and the record show who hid it and why." };
  } catch (err) {
    return fail(err);
  }
}

export async function approveQuestionAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => approveHeld(s, { by: viewer, id: str(fd, "id"), note: str(fd, "note") || undefined }));
    refresh();
    return { ok: true, message: "Approved and public." };
  } catch (err) {
    return fail(err);
  }
}

export async function claimRoleAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer, member } = await getData();
  const handle = actingHandle(fd, viewer, member);
  if (typeof handle !== "string") return handle;
  const roleKey = str(fd, "roleKey") as RosterRoleKey;
  if (!ROSTER_ROLE_KEYS.includes(roleKey)) return { ok: false, error: "Pick a role." };
  try {
    const share = await readShareCookies();
    const r = await mutateStore((s) => {
      const out = claimRole(s, { slug: str(fd, "slug"), roleKey, handle, note: str(fd, "note") || undefined, source: str(fd, "ref") || undefined, referredBy: share.from });
      linkOwnCode(s, share.own, handle);
      return out;
    });
    if (!member) await setViewer(handle);
    refresh();
    return {
      ok: true,
      message: r.status === "filled" ? "You're on the roster." : "Claimed. It counts once you're verified: finish onboarding and link LinkedIn or X.",
    };
  } catch (err) {
    return fail(err);
  }
}

export async function withdrawRoleAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => withdrawRole(s, { slug: str(fd, "slug"), handle: viewer }));
    refresh();
    return { ok: true, message: "Role withdrawn. It's open again." };
  } catch (err) {
    return fail(err);
  }
}

export async function withdrawSeatAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    const r = await mutateStore((s) => withdrawSeat(s, { slug: str(fd, "slug"), handle: viewer }));
    refresh();
    return { ok: true, message: `Seat withdrawn. ${formatUsdPlain(r.usd)} refunded in full.` };
  } catch (err) {
    return fail(err);
  }
}

const formatUsdPlain = (n: number) => `$${n.toLocaleString("en-US")}`;

const num = (fd: FormData, key: string) => Number(str(fd, key).replace(/[$,%\s]/g, "") || "0");

export async function submitOfferAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) =>
      submitOffer(s, {
        slug: str(fd, "slug"),
        handle: viewer,
        priceUsd: num(fd, "price"),
        cashUsd: num(fd, "cash"),
        retainedSharePct: num(fd, "retained"),
        plan: str(fd, "plan"),
        note: str(fd, "note") || undefined,
      }),
    );
    refresh();
    return { ok: true, message: "Offer sent. The agent summarised it; the steward checks it next, then unit holders vote." };
  } catch (err) {
    return fail(err);
  }
}

export async function checkOfferAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    const o = await mutateStore((s) => stewardCheckOffer(s, { offerId: str(fd, "offerId"), by: viewer }));
    refresh();
    return o.status === "voting" ? { ok: true, message: "It follows the rules. Unit holders are voting." } : { ok: true, message: "It didn't pass the check, so it won't go to a vote." };
  } catch (err) {
    return fail(err);
  }
}

export async function withdrawOfferAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { viewer } = await getData();
  try {
    await mutateStore((s) => withdrawOffer(s, { offerId: str(fd, "offerId"), by: viewer }));
    refresh();
    return { ok: true, message: "Offer withdrawn." };
  } catch (err) {
    return fail(err);
  }
}

export async function resetDemoAction(): Promise<void> {
  resetStore();
  refresh();
}

/* ---------- sharing: open to everyone, no account needed ---------- */

/** An anonymous code made on someone's first share is theirs once they pick a handle. */
function linkOwnCode(store: Store, code: string | undefined, handle: string) {
  const c = shareCodeOf(store, code);
  if (c && !c.handle) ensureShareCode(store, c.code, handle);
}

/**
 * The share code for whoever is sharing: a signed-in member's linked code, or an anonymous one kept in a
 * cookie. Only an explicit sign-in links a code; the demo's default view doesn't.
 */
export async function shareCodeAction(): Promise<{ code: string }> {
  const jar = await cookies();
  const requested = jar.get(VIEWER_COOKIE)?.value;
  const { own } = await readShareCookies();
  const code = await mutateStore((s) => {
    const member = requested && requested !== VISITOR ? memberByHandle(s, requested) : undefined;
    if (member) return (shareCodesFor(s, member.handle)[0] ?? ensureShareCode(s, newCode(), member.handle)).code;
    return ensureShareCode(s, own ?? newCode()).code;
  });
  if (!requested || requested === VISITOR) {
    if (code !== own) await setShareCookie(SHARE_COOKIE, code);
  }
  return { code };
}

/** A visit through a share link: remember the first code that brought this visitor, and count the visit once. */
export async function recordVisitAction(input: { code: string; path: string; channel?: string }): Promise<void> {
  if (!SHARE_CODE_RE.test(input.code)) return;
  const { own, from, visitor } = await readShareCookies();
  if (input.code === own) return;
  const vid = visitor ?? newCode();
  const channel = (SHARE_CHANNELS as readonly string[]).includes(input.channel ?? "") ? (input.channel as ShareChannel) : "other";
  const known = await mutateStore((s) => {
    if (!shareCodeOf(s, input.code)) return false;
    const [, kind, key] = input.path.split("/");
    const ventureId = kind === "v" && key ? lookupVenture(s, key)?.venture.id : undefined;
    const cohortId = kind === "batches" && key ? cohortByNumber(s, Number(key))?.id : undefined;
    recordVisit(s, { code: input.code, visitor: vid, ventureId, cohortId, channel });
    return true;
  });
  if (!known) return;
  if (!visitor) await setShareCookie(VISITOR_ID_COOKIE, vid);
  if (!from) await setShareCookie(FROM_COOKIE, input.code);
}

/** Join a full venture's waitlist or the next batch's. A visitor picks a handle; a member joins in one click. */
export async function joinWaitlistAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const jar = await cookies();
  const requested = jar.get(VIEWER_COOKIE)?.value;
  const typed = str(formData, "handle").replace(/^@/, "");
  const handle = typed || (requested && requested !== VISITOR ? requested : "");
  if (!HANDLE_RE.test(handle)) return { ok: false, error: "Choose a handle: 2–24 letters, numbers or underscores." };
  const slug = str(formData, "slug") || undefined;
  const batch = str(formData, "batch");
  const share = await readShareCookies();
  let message = "";
  try {
    await mutateStore((s) => {
      const signedIn = requested && requested !== VISITOR ? memberByHandle(s, requested) : undefined;
      if (typed && memberByHandle(s, typed) && signedIn?.handle !== typed) throw new ProtocolError(`@${typed} is taken. Pick another handle, or switch to it from the You menu.`);
      const from = shareCodeOf(s, share.from);
      const channel = from ? s.refEvents.filter((e) => e.code === from.code && e.stage === "visit" && e.visitor === share.visitor).at(-1)?.channel : undefined;
      const w = joinWaitlist(s, { handle, slug, cohortNumber: batch ? Number(batch) : undefined, referredBy: share.from, channel });
      linkOwnCode(s, share.own, handle);
      message = w.kind === "venture" ? "You're on the waitlist. You'll hear the moment a seat frees up." : "You're on the list. You'll hear when the batch opens.";
    });
  } catch (err) {
    return fail(err);
  }
  if (typed) await setViewer(handle);
  refresh();
  return { ok: true, message };
}
