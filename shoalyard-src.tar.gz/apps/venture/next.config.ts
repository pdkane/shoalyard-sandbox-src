import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@av/schema", "@av/protocol"],
  async redirects() {
    return [
      { source: "/drops", destination: "/batches", permanent: true },
      { source: "/drops/:n", destination: "/batches/:n", permanent: true },
      { source: "/v/venture-0", destination: "/v/protocol", permanent: true },
      { source: "/v/venture-0/:path*", destination: "/v/protocol/:path*", permanent: true },
    ];
  },
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
