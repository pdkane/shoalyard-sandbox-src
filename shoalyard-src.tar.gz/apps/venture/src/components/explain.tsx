"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { useFocusPopover } from "@/lib/use-focus-popover";
import { Popover, PopoverContent, PopoverDescription, PopoverTitle, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

/**
 * A badge or chip that explains itself. Opens on hover, keyboard focus or tap
 * and closes on an outside tap or Escape, like the glossary terms. Never put
 * it inside a link: render the plain badge there instead.
 */
export function Explain({
  title,
  text,
  href,
  hrefLabel = "More in the glossary →",
  className,
  children,
}: {
  title: string;
  text: string;
  href?: string;
  hrefLabel?: string;
  className?: string;
  children: ReactNode;
}) {
  const { open, onOpenChange, onFocus } = useFocusPopover();
  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger
        openOnHover
        delay={150}
        closeDelay={100}
        onFocus={onFocus}
        aria-label={`${title}: what this means`}
        className={cn(
          "inline-flex cursor-help rounded-full bg-transparent p-0 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400",
          className,
        )}
      >
        {children}
      </PopoverTrigger>
      <PopoverContent>
        <PopoverTitle className="font-semibold text-zinc-900">{title}</PopoverTitle>
        <PopoverDescription className="mt-1 leading-relaxed">{text}</PopoverDescription>
        {href && (
          <Link href={href} className="mt-2 inline-block text-xs font-medium text-zinc-900 underline underline-offset-2">
            {hrefLabel}
          </Link>
        )}
      </PopoverContent>
    </Popover>
  );
}
