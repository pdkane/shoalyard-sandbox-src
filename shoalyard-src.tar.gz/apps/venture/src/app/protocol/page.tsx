import type { Metadata } from "next";
import Link from "next/link";
import { History, Vote } from "lucide-react";
import { ARTICLES, CONSTITUTION_VERSION, MEMBERS_STEER, fillArticle, settingValueText, voteStatus, isOpen, protocolCoveringLine, servicesAccount, type TermId } from "@av/protocol";
import { PARAM_GROUP_LABELS, PARAMS, type ParamGroup, type ParamKey, type ParamValue } from "@av/schema";
import { EmptyState } from "@/components/empty-state";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { linkTerms } from "@/lib/terms";
import { formatAgo, formatDate, formatPct, formatUnits } from "@/lib/format";

export const metadata: Metadata = { title: "Rules" };

const ENDINGS = [
  { title: "Shut down", text: "Its kill rule fires or the steward stops it. The post-mortem and its lessons stay on the record for every venture after it." },
  { title: "Keep running", text: "It pays its own way. The agent keeps operating it under these rules, and profit goes to the people with earned units." },
  {
    title: "Hand off",
    text: "An entrepreneur adopts it with their own money. People with earned units are paid by vested units; seats never share in a hand-off.",
  },
];

function ArticleBody({ text, terms }: { text: string; terms: readonly TermId[] }) {
  const used = new Set<TermId>();
  const link = (chunk: string) => linkTerms(chunk, terms, used);
  return (
    <div className="mt-2 space-y-2 text-sm text-pretty text-zinc-600">
      {text.split("\n\n").map((para, i) => {
        const lines = para.split("\n");
        const items = lines.filter((l) => l.startsWith("- "));
        const lead = lines.filter((l) => !l.startsWith("- ")).join(" ");
        return (
          <div key={i} className="space-y-1">
            {lead && <p>{link(lead)}</p>}
            {items.length > 0 && (
              <ul className="list-disc space-y-1 pl-4">
                {items.map((l, j) => (
                  <li key={j}>{link(l.slice(2))}</li>
                ))}
              </ul>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default async function ProtocolPage() {
  const { store, params } = await getData();
  const covering = protocolCoveringLine(servicesAccount(store));
  const rfeTitles = new Map(store.rfes.map((r) => [r.id, r]));
  const groups = new Map<ParamGroup, ParamKey[]>();
  for (const key of Object.keys(PARAMS) as ParamKey[]) {
    const g = PARAMS[key].group;
    groups.set(g, [...(groups.get(g) ?? []), key]);
  }
  const votes = store.rfes.filter((r) => r.kind === "governance").sort((a, b) => b.postedAt.localeCompare(a.postedAt));
  const amendments = [...store.amendments].sort((a, b) => b.at.localeCompare(a.at));

  return (
    <div className="space-y-12">
      <header className="max-w-3xl space-y-3">
        <p className="flex flex-wrap gap-x-3 text-sm font-medium text-zinc-500">
          <span>Rules v{CONSTITUTION_VERSION}</span>
          <span>Settings v{store.meta.protocolVersion}</span>
        </p>
        <h1 className="text-3xl font-semibold tracking-tight text-balance">
          The rules every venture follows
        </h1>
        <p className="text-pretty text-zinc-600">
          These eight rules apply to every {params.BRAND_NAME} venture. The numbers they depend on, like the seat price and the fee, are settings,
          listed below with the reason for each. Anyone with vested units in the Protocol can vote to change a setting. Changing a rule itself
          takes {params.CONSTITUTION_NOTICE_DAYS} days&apos; notice and a two-thirds vote.
        </p>
        <p className="text-pretty text-zinc-600">{MEMBERS_STEER}</p>
        <p className="text-pretty text-zinc-600">
          Every venture runs on one shared back office, billed at cost:{" "}
          <Link href="/protocol/services" className="font-medium underline underline-offset-2">
            see what it covers and what it cost
          </Link>
          .{covering ? ` ${covering}.` : ""}
        </p>
        <details className="text-sm text-zinc-500">
          <summary className="cursor-pointer font-medium text-zinc-600">Legal structure (for lawyers)</summary>
          <p className="mt-2 text-pretty">
            Units are compensatory profits interests in each venture&apos;s series, with the Protocol fee paid to the umbrella. Which legal form and which
            state the umbrella takes is{" "}
            <Link href="/rfe/rfe-v0-legal-form" className="underline underline-offset-2">
              an open question for counsel
            </Link>
            .
          </p>
        </details>
      </header>

      <section id="endings" className="scroll-mt-20 space-y-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">How a venture ends</h2>
          <p className="max-w-3xl text-sm text-pretty text-zinc-500">
            Each venture is an experiment whose job is to prove a named buyer will pay. Pivoting is a monthly-review outcome, not an ending. It ends one of
            three ways:
          </p>
        </div>
        <ol className="grid gap-3 md:grid-cols-3">
          {ENDINGS.map((e, i) => (
            <li key={e.title} className="rounded-xl border border-zinc-200 bg-white p-4">
              <p className="text-xs font-medium text-zinc-500">Ending {i + 1}</p>
              <p className="mt-1 font-semibold">{e.title}</p>
              <p className="mt-1 text-sm text-pretty text-zinc-600">{e.text}</p>
            </li>
          ))}
        </ol>
        <p className="max-w-3xl text-sm text-pretty text-zinc-600">
          A hand-off needs a{" "}
          <Link href="/protocol#HANDOFF_MIN_CUSTOMERS" className="underline underline-offset-2">
            ready checklist
          </Link>
          , the steward&apos;s check that the offer follows the rules, and a two-thirds vote of unit holders. Still open:{" "}
          <Link href="/rfe/rfe-v0-handoff-price" className="underline underline-offset-2">
            is the hand-off price fixed by formula or set by bids?
          </Link>
        </p>
      </section>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold tracking-tight">The {ARTICLES.length} rules</h2>
        <ol className="grid gap-3 md:grid-cols-2">
          {ARTICLES.map((a) => (
            <li key={a.number} className="rounded-xl border border-zinc-200 bg-white p-5">
              <p className="text-xs font-medium text-zinc-500">Rule {a.number}</p>
              <p className="mt-1 font-semibold">{a.title}</p>
              <ArticleBody text={fillArticle(a.text, params)} terms={a.terms} />
            </li>
          ))}
        </ol>
      </section>

      <section id="votes" className="scroll-mt-20 space-y-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Votes on the rules</h2>
          <p className="text-sm text-zinc-500">
            Each vote counts by vested units. A vote counts only if {formatPct(params.QUORUM_PCT * 100, 0)} of units take part. Most pass with more
            than {formatPct(params.SIMPLE_MAJORITY * 100, 0)}; rule changes need {formatPct(params.SUPERMAJORITY * 100, 1)}.
          </p>
        </div>
        {votes.length === 0 ? (
          <EmptyState icon={Vote} title="No votes yet" />
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {votes.map((r) => {
              const t = voteStatus(store, r, params);
              const open = isOpen(r);
              return (
                <Link key={r.id} href={`/rfe/${r.id}`} className="rounded-xl border border-zinc-200 bg-white p-4 transition hover:border-zinc-300">
                  <div className="flex items-center justify-between gap-2 text-xs text-zinc-500">
                    <span>{open ? `Open · closes ${formatAgo(r.governance!.windowEndsAt, store.meta.clock)}` : `Closed ${r.resolvedAt ? formatDate(r.resolvedAt) : ""}`}</span>
                    <span>{r.governance?.threshold === "super" ? "Needs two-thirds" : "Needs a majority"}</span>
                  </div>
                  <p className="mt-2 font-medium">{r.title}</p>
                  {r.governance?.paramKey && (
                    <p className="mt-1 text-sm text-zinc-600">
                      {PARAMS[r.governance.paramKey as ParamKey]?.label ?? r.governance.paramKey}:{" "}
                      {settingValueText(r.governance.paramKey as ParamKey, r.governance.currentValue)} →{" "}
                      {settingValueText(r.governance.paramKey as ParamKey, r.governance.proposedValue)}
                    </p>
                  )}
                  <div className="mt-3 flex h-2 overflow-hidden rounded-full bg-zinc-100">
                    <div className="bg-fuchsia-500" style={{ width: `${t.yesShare * 100}%` }} />
                  </div>
                  <p className="mt-1.5 text-xs text-zinc-600">
                    {formatPct(t.yesShare * 100, 0)} yes · {formatUnits(t.votedWeight)} voted · {formatPct(t.turnout * 100, 0)} of units voted
                    {open ? (t.passes ? " · passing" : " · not passing yet") : r.resolution ? ` · ${r.resolution}` : ""}
                  </p>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      <section id="params" className="scroll-mt-20 space-y-6">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Settings</h2>
          <p className="text-sm text-zinc-500">
            The current value of every number the rules use. Each links to the open question where you can argue for a change.
          </p>
        </div>
        {[...groups.entries()].map(([group, keys]) => (
          <Card key={group}>
            <CardHeader>
              <CardTitle>{PARAM_GROUP_LABELS[group]}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ul className="divide-y divide-zinc-100">
                {keys.map((key) => {
                  const def = PARAMS[key];
                  const value = params[key] as ParamValue;
                  const changed = amendments.filter((a) => a.paramKey === key);
                  const gov = rfeTitles.get(def.governedBy);
                  return (
                    <li key={key} id={key} className="grid scroll-mt-20 gap-2 px-4 py-3 md:grid-cols-[1.1fr_0.8fr_1.4fr]">
                      <div>
                        <p className="text-sm font-medium">{def.label}</p>
                        <code className="text-[11px] text-zinc-500">{key}</code>
                      </div>
                      <div className="text-sm font-medium tabular-nums">
                        {settingValueText(key, value)}
                        {"unit" in def && def.unit ? <span className="font-normal text-zinc-500"> {def.unit}</span> : null}
                        {changed.length > 0 && (
                          <p className="text-xs font-normal text-fuchsia-700">
                            Changed {formatDate(changed[0].at)} (was {settingValueText(key, changed[0].oldValue)})
                          </p>
                        )}
                      </div>
                      <div className="text-sm text-zinc-600">
                        <p>{def.reason}</p>
                        <p className="mt-1 text-xs">
                          Discuss it here:{" "}
                          {gov ? (
                            <Link href={`/rfe/${gov.id}`} className="underline underline-offset-2 hover:text-zinc-900">
                              {gov.title}
                            </Link>
                          ) : (
                            <code>{def.governedBy}</code>
                          )}
                        </p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold tracking-tight">Change history</h2>
        {amendments.length === 0 ? (
          <EmptyState icon={History} title="No settings have changed yet">
            Settings v{store.meta.protocolVersion} are the starting values. Passed votes appear here.
          </EmptyState>
        ) : (
          <Card>
            <CardHeader>
              <CardDescription>Each change gets a new settings version and is recorded on the Protocol&apos;s public record. Changes to the rules themselves get a new rules version.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                {amendments.map((a) => (
                  <li key={a.id} className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span className="font-medium">v{a.version}</span>
                    <span className="text-zinc-500">{formatDate(a.at)}</span>
                    <span className="font-medium">{PARAMS[a.paramKey as ParamKey]?.label ?? a.paramKey}</span>
                    <span>
                      {settingValueText(a.paramKey as ParamKey, a.oldValue)} → {settingValueText(a.paramKey as ParamKey, a.newValue)}
                    </span>
                    <Link href={`/rfe/${a.rfeId}`} className="text-xs underline">
                      vote
                    </Link>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </section>
    </div>
  );
}
