import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join, relative } from "node:path";
import { test } from "node:test";
import { defaultParams, PARAMS } from "@av/schema";
import { ARTICLES } from "../src/constitution";
import { DERIVED_PLACEHOLDERS, GLOSSARY, RETIRED_WORDS, renderTerm, type GlossaryTerm } from "../src/glossary";
import { BANNED } from "./banned";
import { root, walk } from "./copy-text";

const terms: readonly GlossaryTerm[] = GLOSSARY;
const ids = new Set(terms.map((t) => t.id));
const appFiles = walk(join(root, "apps/venture/src"), /\.tsx?$/);

test("every <Term id> and /glossary#id link in the app names a glossary term", () => {
  const missing: string[] = [];
  for (const f of appFiles) {
    const src = readFileSync(f, "utf8");
    for (const m of src.matchAll(/<Term(?:Server)?\s+id="([a-z-]+)"|\/glossary#([a-z-]+)/g)) {
      const id = m[1] ?? m[2];
      if (!ids.has(id)) missing.push(`${relative(root, f)}: ${id}`);
    }
  }
  assert.deepEqual(missing, []);
  assert.ok(appFiles.some((f) => /<Term(Server)?\s+id="/.test(readFileSync(f, "utf8"))), "the app links at least one term");
});

test("every article's terms are glossary terms", () => {
  for (const a of ARTICLES) for (const t of a.terms) assert.ok(ids.has(t), `Article ${a.number}: ${t}`);
});

test("every short definition is one sentence of at most 200 characters, ending with a period", () => {
  const params = defaultParams();
  for (const t of terms) {
    const short = renderTerm(t, params).short;
    assert.ok(short.length <= 200, `${t.id} is ${short.length} characters`);
    assert.ok(short.endsWith("."), `${t.id} ends with a period`);
  }
});

test("placeholders name real settings, and listed settings exist", () => {
  for (const t of terms) {
    for (const text of [t.short, t.long, t.example]) {
      for (const m of (text ?? "").matchAll(/\{([A-Z_]+)\}/g)) {
        assert.ok(m[1] in PARAMS || (DERIVED_PLACEHOLDERS as readonly string[]).includes(m[1]), `${t.id}: {${m[1]}}`);
      }
    }
    for (const p of t.params ?? []) assert.ok(p in PARAMS, `${t.id}: ${p}`);
    const rendered = renderTerm(t, defaultParams());
    assert.doesNotMatch(`${rendered.short} ${rendered.long ?? ""} ${rendered.example ?? ""}`, /\{[A-Za-z_]+\}/, t.id);
  }
});

test("definitions avoid banned and retired words", () => {
  const found: string[] = [];
  for (const t of terms) {
    // The profit-share entry names the legal term once, so readers can match it to counsel's documents.
    const text = [t.short, t.long, t.example].join(" ").replace(t.id === "profit-share" ? /a profits interest/ : /$^/, "");
    for (const re of [...BANNED, ...RETIRED_WORDS.map((r) => r.word)]) if (re.test(text)) found.push(`${t.id}: ${re}`);
  }
  assert.deepEqual(found, []);
});

test("related terms resolve, and no id or alias is used twice", () => {
  const seen = new Map<string, string>();
  for (const t of terms) {
    for (const s of t.see ?? []) assert.ok(ids.has(s), `${t.id} → ${s}`);
    for (const name of [t.id, t.term, ...(t.aka ?? [])].map((x) => x.toLowerCase())) {
      const prev = seen.get(name);
      assert.ok(!prev || prev === t.id, `"${name}" is used by ${prev} and ${t.id}`);
      seen.set(name, t.id);
    }
  }
  assert.equal(terms.length, 26);
});
