import type { Metadata } from "next";
import Link from "next/link";
import { BadgeCheck, Flag, Handshake, Megaphone, MessageCircleQuestion, ShieldCheck, ShieldOff, Tags } from "lucide-react";
import {
  ATTRIBUTE_LABELS,
  attributeStatuses,
  gtmStats,
  heldQuestions,
  isLive,
  isOpen,
  pendingVerifications,
  SOURCE_LABELS,
  stewardQueue,
  tagQueue,
  verifiedShare,
  isGovernedAxis,
  flagConfirmer,
  MEMBER_VOTE_STANDS,
  openOffer,
  payoutPreview,
  pendingConductVotes,
  conductHoldNote,
  vocabFor,
} from "@av/protocol";
import { TAG_AXES, TAG_AXIS_LABELS } from "@av/schema";
import { BinBadge, Pill, StatusBadge } from "@/components/badges";
import { AccountLabel } from "@/components/account-label";
import { EmptyState } from "@/components/empty-state";
import {
  CertifyFlagForm,
  DeclineMemberForm,
  PublishPostMortemForm,
  SpawnBatchForm,
  TagConfirmForm,
  TagRewriteForm,
  VerificationDecision,
  VerifyAttributeForm,
} from "@/components/protocol-forms";
import { VerifiedShareBar } from "@/components/protocol-ui";
import { OfferCard } from "@/components/handoff-ui";
import { ApproveQuestionForm, HideQuestionForm } from "@/components/qa-forms";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { formatAgo, formatUsd } from "@/lib/format";
import { AdvanceAgent, DecisionForm, KillDialog, MarkPostedForm, ResetDemo } from "./steward-forms";

export const metadata: Metadata = { title: "Steward" };

const CHANNEL: Record<string, string> = { x_post: "X post", linkedin: "LinkedIn post", outreach: "Outreach" };
const PURPOSE: Record<string, string> = { launch: "Launch", gap: "Finding people", teaser: "Batch teaser" };

function SectionHead({ title, children, count }: { title: string; children?: React.ReactNode; count?: number }) {
  return (
    <div>
      <h2 className="flex items-center gap-2 text-lg font-semibold tracking-tight">
        {title}
        {count !== undefined && count > 0 && <span className="rounded-full bg-zinc-900 px-2 py-0.5 text-xs font-medium text-white tabular-nums">{count}</span>}
      </h2>
      {children && <p className="text-sm text-zinc-500">{children}</p>}
    </div>
  );
}

export default async function StewardPage() {
  const { store, params, viewer, isSteward } = await getData();
  if (!isSteward) {
    return (
      <EmptyState icon={ShieldOff} title="Stewards only">
        @{viewer} doesn&apos;t steward a venture. Switch “view as” to @{params.FOUNDING_STEWARD_HANDLE} to see this page.
      </EmptyState>
    );
  }
  const ventures = store.ventures.filter((v) => v.stewardHandle === viewer);
  const ids = new Set(ventures.map((v) => v.id));
  const queue = stewardQueue(store, viewer);
  const drafts = store.rfes
    .filter((r) => r.gtm && ids.has(r.ventureId))
    .sort((a, b) => Number(isOpen(b)) - Number(isOpen(a)) || b.postedAt.localeCompare(a.postedAt));
  const clock = store.meta.clock;
  const byId = new Map(store.ventures.map((v) => [v.id, v]));
  const verifications = pendingVerifications(store);
  const pendingMembers = store.members.filter((m) => m.qualification === "pending" && m.onboardedAt);
  const tags = tagQueue(store);
  const vocab = vocabFor(store);
  const flags = store.flags.filter((f) => (ids.has(f.ventureId) || flagConfirmer(store, f).handle === viewer) && !f.certifiedAt);
  const standing = store.flags.filter((f) => ids.has(f.ventureId) && f.certifiedBy === MEMBER_VOTE_STANDS).length;
  const held = heldQuestions(store, viewer);
  const unpublished = ventures.filter((v) => v.status === "killed" && v.postMortem && !v.postMortem.publishedAt);
  const offers = store.offers
    .filter((o) => ids.has(o.ventureId) && openOffer(o))
    .map((offer) => ({
      offer,
      venture: byId.get(offer.ventureId)!,
      preview: payoutPreview(store, byId.get(offer.ventureId)!, offer.contributors.cashUsd, params),
      vote: offer.voteRfeId ? store.rfes.find((r) => r.id === offer.voteRfeId) : undefined,
      held: pendingConductVotes(store, offer.ventureId) ? conductHoldNote(pendingConductVotes(store, offer.ventureId)) : undefined,
    }));
  const toCheck = offers.filter((o) => o.offer.status === "submitted").length;

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <AccountLabel />
          <h1 className="text-2xl font-semibold tracking-tight">Steward tools</h1>
          <p className="text-sm text-zinc-500">
            @{viewer} · {params.FOUNDING_STEWARD_TITLE} · {ventures.length} venture{ventures.length === 1 ? "" : "s"}. Approve risky decisions, verify
            members, confirm categories and confirm votes on reported concerns.
          </p>
        </div>
        <ResetDemo />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle>Run the demo forward</CardTitle>
            <CardDescription>
              Each step moves demo time {params.SIM_TICK_HOURS} hours: units vest, votes close, batches open and close, demo members answer and take
              seats, and the agent takes its next step
              {process.env.ANTHROPIC_API_KEY
                ? ` with ${params.MODEL_OPERATOR}`
                : ". Demo mode: the agent's replies are pre-written. Connect a Claude API key to run it live"}
              .
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AdvanceAgent ventures={ventures.filter((v) => isLive(v) && v.status !== "generated").map((v) => ({ slug: v.slug, name: v.name }))} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Next batch</CardTitle>
            <CardDescription>
              The agent picks {params.VENTURES_PER_BATCH} kinds of venture based on past results, writes hidden-name teasers, and drafts a post for
              you. Seats open {params.BATCH_ANNOUNCE_LEAD_DAYS} days later.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SpawnBatchForm />
          </CardContent>
        </Card>
      </div>

      <section className="space-y-4">
        <SectionHead title="Member verification" count={verifications.length}>
          Linked accounts wait for you. Only you see the profile link; the public sees a badge and how much is verified.
        </SectionHead>
        {verifications.length === 0 && pendingMembers.length === 0 ? (
          <EmptyState icon={BadgeCheck} title="No one waiting">
            New members appear here after they link LinkedIn or X.
          </EmptyState>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {verifications.map(({ member: m, verification: v }) => (
              <Card key={v.id} size="sm">
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Pill>{SOURCE_LABELS[v.source]}</Pill>
                    <Link href={`/m/${m.handle}`} className="font-medium hover:underline">
                      @{m.handle}
                    </Link>
                    <span className="ml-auto text-xs text-zinc-500">{formatAgo(v.requestedAt, clock)}</span>
                  </div>
                  <CardDescription>
                    Says: {m.role} · {m.industry}
                    {m.profile.companies.length ? ` · ${m.profile.companies.join(", ")}` : ""} · {m.seniority}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <p>
                    Linked account (private): <code className="rounded bg-zinc-100 px-1 text-xs break-all">{v.ref}</code>
                  </p>
                  <p className="text-xs text-zinc-500">Confirming verifies: {v.attributes.map((a) => ATTRIBUTE_LABELS[a]).join(", ")}</p>
                  <VerificationDecision handle={m.handle} verificationId={v.id} />
                </CardContent>
              </Card>
            ))}
            {pendingMembers.map((m) => (
              <Card key={m.handle} size="sm">
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Pill className="border-amber-200 bg-amber-50 text-amber-800">Pending</Pill>
                    <Link href={`/m/${m.handle}`} className="font-medium hover:underline">
                      @{m.handle}
                    </Link>
                  </div>
                  <CardDescription>
                    {attributeStatuses(m, params)
                      .filter((a) => a.status === "verified")
                      .map((a) => ATTRIBUTE_LABELS[a.attribute])
                      .join(", ") || "Nothing verified yet"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <VerifiedShareBar share={verifiedShare(m, params)} />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <VerifyAttributeForm handle={m.handle} labels={ATTRIBUTE_LABELS} />
                    <DeclineMemberForm handle={m.handle} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section id="sign-off" className="scroll-mt-20 space-y-4">
        <SectionHead title="Waiting for your sign-off" count={queue.length}>
          Spend over {formatUsd(params.GATE_SPEND_USD)}, contracts, pricing, new outbound domains, public posts, and anything that goes against a
          kept lesson.
        </SectionHead>
        {queue.length === 0 ? (
          <EmptyState icon={ShieldCheck} title="Nothing waiting for sign-off">
            Decisions that need sign-off appear here as the agent proposes them.
          </EmptyState>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {queue.map(({ decision: d, venture }) => (
              <Card key={d.id} size="sm" style={{ "--accent-color": venture.accent } as React.CSSProperties}>
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <BinBadge bin={d.bin} />
                    <Pill>{venture.name}</Pill>
                    <span className="ml-auto text-xs text-zinc-500">{formatAgo(d.at, clock)}</span>
                  </div>
                  <CardTitle className="pt-1">{d.title}</CardTitle>
                  <CardDescription>{d.reasoning}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-xs text-zinc-500">Needs sign-off because: {d.binReasons.join("; ")}</p>
                  {d.conduct?.counselNote && (
                    <p className="rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-xs text-amber-900">Counsel note: {d.conduct.counselNote}</p>
                  )}
                  {d.embargo && <p className="text-xs text-zinc-500">Published later: {d.embargo.reason}</p>}
                  {d.rfeId && (
                    <Link href={`/rfe/${d.rfeId}`} className="text-xs underline">
                      Open the linked request
                    </Link>
                  )}
                  <DecisionForm decisionId={d.id} publicPost={d.facts.publicPost} />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section id="hand-off" className="scroll-mt-20 space-y-4">
        <SectionHead title="Offers to adopt a venture" count={toCheck}>
          Check that each offer follows the rules: the venture is ready, the entrepreneur is verified, and only earned units are paid. You don&apos;t judge the
          price; unit holders vote on it.
        </SectionHead>
        {offers.length === 0 ? (
          <EmptyState icon={Handshake} title="No open offers" />
        ) : (
          <div className="grid gap-3 lg:grid-cols-2">
            {offers.map((o) => (
              <div key={o.offer.id} className="space-y-1.5">
                <Link href={`/v/${o.venture.slug}#hand-off`} className="text-sm font-medium text-zinc-500 hover:text-zinc-900">
                  {o.venture.name}
                </Link>
                <OfferCard view={o} viewer={viewer} isSteward />
              </div>
            ))}
          </div>
        )}
      </section>

      <section id="held-questions" className="scroll-mt-20 space-y-4">
        <SectionHead title="Q&A held for conduct" count={held.length}>
          Questions, or the agent&apos;s answers, that the conduct screen held. Approve to publish, or hide with one of the listed reasons; a hide leaves a placeholder and a
          row on the record.
        </SectionHead>
        {held.length === 0 ? (
          <EmptyState icon={MessageCircleQuestion} title="Nothing held" />
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {held.map((q) => {
              const venture = byId.get(q.ventureId)!;
              return (
                <Card key={q.id} size="sm">
                  <CardHeader>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Pill>{venture.name}</Pill>
                      <Link href={`/m/${q.handle}`} className="text-sm font-medium hover:underline">
                        @{q.handle}
                      </Link>
                      <span className="ml-auto text-xs text-zinc-500">{formatAgo(q.at, clock)}</span>
                    </div>
                    <CardTitle className="pt-1 text-base">{q.text}</CardTitle>
                    {q.stewardNote && <CardDescription>{q.stewardNote}</CardDescription>}
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    {q.answer && (
                      <p className="rounded-md bg-zinc-50 p-2 text-zinc-700">
                        <span className="text-xs text-zinc-500">The agent&apos;s held answer: </span>
                        {q.answer.text}
                      </p>
                    )}
                    <ApproveQuestionForm id={q.id} />
                    <HideQuestionForm id={q.id} reasons={params.QA_HIDE_REASONS as string[]} />
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <SectionHead title="Reported concerns" count={flags.filter((f) => f.status !== "voting" && !flagConfirmer(store, f).conflicted).length}>
          Members vote on each reported concern. For a venture you run, you&apos;re conflicted: the member vote stands without your confirmation
          {standing ? ` (${standing} so far)` : ""}. Otherwise you confirm the vote was done by the rules. If upheld, it&apos;s recorded as a
          breach. {params.MARK_WITHDRAW_BREACHES} breaches and the venture loses the mark.
        </SectionHead>
        {flags.length === 0 ? (
          <EmptyState icon={Flag} title="No open concerns" />
        ) : (
          <ul className="divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white">
            {flags.map((f) => (
              <li key={f.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0 space-y-1 text-sm">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Pill>{byId.get(f.ventureId)?.name}</Pill>
                    <Pill
                      className={
                        f.status === "voting"
                          ? "border-amber-200 bg-amber-50 text-amber-800"
                          : f.status === "upheld"
                            ? "border-rose-200 bg-rose-50 text-rose-800"
                            : "border-zinc-200 bg-zinc-100 text-zinc-600"
                      }
                    >
                      {f.status === "voting" ? "Members voting" : f.status === "upheld" ? "Upheld by vote" : "Dismissed by vote"}
                    </Pill>
                    <span className="text-xs text-zinc-500">by @{f.by}</span>
                  </div>
                  <p className="font-medium">{f.target.label}</p>
                  <p className="text-zinc-600">“{f.reason}”</p>
                  {f.voteRfeId && (
                    <Link href={`/rfe/${f.voteRfeId}`} className="text-xs underline">
                      Open the vote
                    </Link>
                  )}
                </div>
                {f.status === "voting" && flagConfirmer(store, f).conflicted && (
                  <span className="text-xs text-zinc-500">You run this venture, so the vote will stand on its own.</span>
                )}
                {f.status !== "voting" && !flagConfirmer(store, f).conflicted && <CertifyFlagForm flagId={f.id} />}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section id="classification" className="scroll-mt-20 space-y-4">
        <SectionHead title="Classification to confirm" count={tags.length}>
          The agent suggests categories for every venture and request. Nothing waits on you. Confirm each one, or fix the value first from the
          standard list. Sub-verticals are free text; a new end market, customer, business model, go-to-market or market type needs a Protocol vote.
        </SectionHead>
        {tags.length === 0 ? (
          <EmptyState icon={Tags} title="Every category is confirmed" />
        ) : (
          <ul className="divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white">
            {tags.map((t) => (
              <li key={`${t.kind}-${t.id}-${t.tag.axis}-${t.tag.value}`} className="flex flex-col gap-2 p-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0 text-sm">
                  <span className="text-xs text-zinc-500">
                    {t.kind} · {TAG_AXIS_LABELS[t.tag.axis]} · proposed by {t.tag.by}
                  </span>
                  <p className="truncate font-medium">{t.label}</p>
                </div>
                <TagConfirmForm
                  kind={t.kind}
                  id={t.id}
                  axis={t.tag.axis}
                  value={t.tag.value}
                  vocab={vocab[t.tag.axis]}
                  governed={isGovernedAxis(t.tag.axis)}
                />
              </li>
            ))}
          </ul>
        )}
        <Card size="sm">
          <CardHeader>
            <CardTitle className="text-sm">Rename or merge a value</CardTitle>
            <CardDescription>
              Rewrites the value everywhere and logs it on /learning, so cuts stay comparable. Standard values can only be merged into each other;
              renaming one needs a Protocol vote.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <TagRewriteForm axes={TAG_AXES} vocab={vocab} axisLabels={TAG_AXIS_LABELS} />
          </CardContent>
        </Card>
      </section>

      {unpublished.length > 0 && (
        <section className="space-y-4">
          <SectionHead title="Post-mortems to publish" count={unpublished.length}>
            A batch can&apos;t close until every venture that ended in it has published its post-mortem.
          </SectionHead>
          <div className="grid gap-3 md:grid-cols-2">
            {unpublished.map((v) => (
              <Card key={v.id} size="sm">
                <CardHeader>
                  <CardTitle>
                    <Link href={`/v/${v.slug}`} className="hover:underline">
                      {v.name}
                    </Link>
                  </CardTitle>
                  <CardDescription>{v.postMortem!.whyItEnded}</CardDescription>
                </CardHeader>
                <CardContent>
                  <PublishPostMortemForm slug={v.slug} summary={v.postMortem!.summary} killReason={v.postMortem!.killReason} />
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      <section className="space-y-4">
        <SectionHead title="Recruiting drafts">
          The agent drafts posts and outreach, including posts to find people for open spots. It never posts or sends DMs itself. You post by hand,
          then mark it here so the people who join are counted against the right post.
        </SectionHead>
        {drafts.length === 0 ? (
          <EmptyState icon={Megaphone} title="No drafts yet" />
        ) : (
          <div className="overflow-hidden rounded-xl border border-zinc-200 bg-white">
            <ul className="divide-y divide-zinc-100">
              {drafts.map((r) => {
                const s = gtmStats(store, r.id);
                const decision = r.decisionId ? store.decisions.find((d) => d.id === r.decisionId) : undefined;
                const awaiting = decision?.status === "awaiting_steward";
                return (
                  <li key={r.id} className="space-y-3 p-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <Pill>{byId.get(r.ventureId)?.name}</Pill>
                      <Pill>{CHANNEL[r.gtm!.channel] ?? r.gtm!.channel}</Pill>
                      {r.gtm!.purpose && <Pill>{PURPOSE[r.gtm!.purpose]}</Pill>}
                      {r.gtm!.postedAt ? (
                        <Pill className="border-emerald-200 bg-emerald-50 text-emerald-800">Posted {formatAgo(r.gtm!.postedAt, clock)}</Pill>
                      ) : awaiting ? (
                        <Pill className="border-rose-200 bg-rose-50 text-rose-800">Needs approval first</Pill>
                      ) : isOpen(r) ? (
                        <Pill className="border-amber-200 bg-amber-50 text-amber-800">Approved · not posted</Pill>
                      ) : (
                        <Pill>Closed</Pill>
                      )}
                      <span className="ml-auto text-xs text-zinc-500 tabular-nums">
                        {s.arrivals} joined · {s.qualified} verified · {s.seats} seats · {s.followed} answers followed · {s.right} held up
                      </span>
                    </div>
                    <Link href={`/rfe/${r.id}`} className="block font-medium hover:underline">
                      {r.title}
                    </Link>
                    {!r.gtm!.postedAt && isOpen(r) && !awaiting && <MarkPostedForm rfeId={r.id} />}
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </section>

      <section className="space-y-4">
        <SectionHead title="Shut down a venture">
          Each venture lists its shut-down rules. You can also shut one down at any time; you must give a reason, and it&apos;s published.
        </SectionHead>
        <div className="grid gap-3 md:grid-cols-2">
          {ventures
            .filter((v) => !v.isProtocol && v.status !== "generated")
            .map((v) => (
              <div key={v.id} className="flex items-center justify-between gap-3 rounded-xl border border-zinc-200 bg-white p-4">
                <div className="min-w-0">
                  <Link href={`/v/${v.slug}`} className="font-medium hover:underline">
                    {v.name}
                  </Link>
                  <div className="mt-1">
                    <StatusBadge status={v.status} />
                  </div>
                </div>
                {isLive(v) ? <KillDialog slug={v.slug} name={v.name} /> : <span className="text-xs text-zinc-500">Closed</span>}
              </div>
            ))}
        </div>
      </section>
    </div>
  );
}
