import { cache, type ReactNode } from "react";
import { GLOSSARY, renderTerm, resolveParams, termById, type TermId } from "@av/protocol";
import { loadStore } from "@av/protocol/store";
import { Term } from "@/components/term";

const liveParams = cache(() => resolveParams(loadStore()));

/** A glossary term with its definition filled from live settings. Server components only. */
export function TermServer({ id, children }: { id: TermId; children?: ReactNode }) {
  const t = termById(id);
  const { short, example } = renderTerm(t, liveParams());
  return (
    <Term id={t.id} term={t.term} short={short} example={example}>
      {children}
    </Term>
  );
}

function namesFor(id: TermId): string[] {
  const t = termById(id);
  return [t.term, ...(t.aka ?? [])].sort((a, b) => b.length - a.length);
}

const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * Wraps the first use of each listed term in `text` in a glossary popover.
 * Pass the same `used` set across chunks of one block to link each term once.
 */
export function linkTerms(text: string, ids: readonly TermId[], used = new Set<TermId>()): ReactNode[] {
  const spans: { start: number; end: number; id: TermId }[] = [];
  for (const id of ids) {
    if (used.has(id)) continue;
    const re = new RegExp(`\\b(${namesFor(id).map(escape).join("|")})\\b`, "gi");
    for (const m of text.matchAll(re)) {
      const start = m.index;
      const end = start + m[0].length;
      if (spans.some((s) => start < s.end && end > s.start)) continue;
      spans.push({ start, end, id });
      used.add(id);
      break;
    }
  }
  spans.sort((a, b) => a.start - b.start);
  const out: ReactNode[] = [];
  let at = 0;
  for (const s of spans) {
    out.push(text.slice(at, s.start));
    out.push(
      <TermServer key={`${s.id}-${s.start}`} id={s.id}>
        {text.slice(s.start, s.end)}
      </TermServer>,
    );
    at = s.end;
  }
  out.push(text.slice(at));
  return out;
}

export const GLOSSARY_SORTED = [...GLOSSARY].sort((a, b) => a.term.replace(/^The /, "").localeCompare(b.term.replace(/^The /, "")));
