"use client";

import { useEffect, useState } from "react";

function parts(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return { d: Math.floor(s / 86400), h: Math.floor((s % 86400) / 3600), m: Math.floor((s % 3600) / 60), s: s % 60 };
}

/**
 * Counts down to `to` on the simulated clock. The server passes the simulated
 * "now"; the client advances it with real seconds so the page feels live.
 */
export function Countdown({ to, now, label }: { to: string; now: string; label?: string }) {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    const start = Date.now();
    const id = setInterval(() => setElapsed(Date.now() - start), 1000);
    return () => clearInterval(id);
  }, []);
  const left = Date.parse(to) - Date.parse(now) - elapsed;
  const p = parts(left);
  const cells: [number, string][] = [
    [p.d, "days"],
    [p.h, "hours"],
    [p.m, "min"],
    [p.s, "sec"],
  ];
  return (
    <div className="space-y-1.5" role="timer" aria-label={label ?? "Countdown"}>
      {label && <p className="text-xs font-medium tracking-wide text-zinc-500 uppercase">{label}</p>}
      <div className="flex gap-2">
        {cells.map(([n, u]) => (
          <div key={u} className="min-w-14 rounded-lg border border-zinc-200 bg-white px-2.5 py-2 text-center">
            <p className="text-2xl font-semibold tabular-nums">{String(n).padStart(2, "0")}</p>
            <p className="text-[11px] text-zinc-500">{u}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
