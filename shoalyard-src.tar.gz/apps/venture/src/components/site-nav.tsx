"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useRef, useTransition } from "react";
import { ChevronDown, FlaskConical, Inbox, Menu } from "lucide-react";
import { setViewerAction } from "@/app/actions";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuLabel,
  DropdownMenuLinkItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetClose, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export interface NavItem {
  href: string;
  label: string;
  count?: number;
}

export interface NavModel {
  /** Sitewide pages anyone can browse. */
  explore: NavItem[];
  /** The "How it works" menu: the rules, the glossary and the explainer. */
  explain: NavItem[];
  /** Pages about the person viewing. */
  you: NavItem[];
  /** Only for the steward. */
  steward: NavItem[];
  viewer: string;
  inboxCount: number;
  handles: { handle: string; label: string }[];
}

const viewerName = (viewer: string) => (viewer === "visitor" ? "Visitor" : `@${viewer}`);

function isActive(pathname: string, href: string) {
  if (href.includes("#")) return false;
  return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
}

function Count({ n }: { n?: number }) {
  if (!n) return null;
  return (
    <span className="ml-auto inline-flex min-w-5 items-center justify-center rounded-full bg-ink px-1.5 text-[11px] font-semibold text-white">
      {n}
    </span>
  );
}

const linkClass = (active: boolean) =>
  cn(
    "inline-flex h-8 items-center gap-1 rounded-md px-2.5 text-sm font-medium transition-colors",
    active ? "bg-mist text-ink" : "text-metal hover:bg-mist hover:text-ink",
  );

/** Left side: the sitewide pages. */
export function NavLinks({ explore, explain }: Pick<NavModel, "explore" | "explain">) {
  const pathname = usePathname();
  return (
    <nav className="hidden items-center gap-1 md:flex" aria-label="Explore">
      {explore.map((item) => (
        <Link key={item.href} href={item.href} className={linkClass(isActive(pathname, item.href))}>
          {item.label}
        </Link>
      ))}
      <DropdownMenu>
        <DropdownMenuTrigger className={linkClass(explain.some((i) => isActive(pathname, i.href)))}>
          How it works
          <ChevronDown className="size-3.5 text-metal" aria-hidden />
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-48">
          {explain.map((item) => (
            <DropdownMenuLinkItem key={item.href} render={<Link href={item.href} />}>
              {item.label}
            </DropdownMenuLinkItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </nav>
  );
}

function useSetViewer() {
  const [pending, start] = useTransition();
  const set = (handle: string) => {
    const fd = new FormData();
    fd.set("handle", handle);
    start(() => setViewerAction(fd));
  };
  return { pending, set };
}

/** Right side: the viewer's own inbox and account menu, set apart from the sitewide links. */
export function AccountNav({ you, steward, viewer, inboxCount, handles }: Omit<NavModel, "explore" | "explain">) {
  const pathname = usePathname();
  const { pending, set } = useSetViewer();
  return (
    <div className="flex items-center gap-1 border-l border-line pl-2 sm:pl-3">
      <Link
        href="/inbox"
        className={cn(
          "relative inline-flex size-9 items-center justify-center rounded-md transition-colors",
          isActive(pathname, "/inbox") ? "bg-mist text-ink" : "text-metal hover:bg-mist hover:text-ink",
        )}
        aria-label={inboxCount ? `Inbox, ${inboxCount} unread` : "Inbox"}
      >
        <Inbox className="size-5" aria-hidden />
        {inboxCount > 0 && (
          <span
            className="absolute -top-0.5 -right-0.5 inline-flex min-w-4.5 items-center justify-center rounded-full bg-rose-600 px-1 text-[10px] leading-4.5 font-semibold text-white tabular-nums"
            aria-hidden
          >
            {inboxCount > 99 ? "99+" : inboxCount}
          </span>
        )}
      </Link>
      <DropdownMenu>
        <DropdownMenuTrigger
          className="hidden h-8 max-w-40 items-center gap-1 rounded-md border border-line bg-white px-2.5 text-sm font-medium text-ink shadow-xs hover:bg-mist md:inline-flex"
          aria-label={`Your account, ${viewerName(viewer)}`}
        >
          <span className="truncate">{viewerName(viewer)}</span>
          <ChevronDown className="size-3.5 shrink-0 text-metal" aria-hidden />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuGroup>
            <DropdownMenuLabel>You</DropdownMenuLabel>
            {you.map((item) => (
              <DropdownMenuLinkItem key={item.href} render={<Link href={item.href} />}>
                {item.label}
                <Count n={item.count} />
              </DropdownMenuLinkItem>
            ))}
          </DropdownMenuGroup>
          {steward.length > 0 && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuLabel>Steward tools</DropdownMenuLabel>
                {steward.map((item) => (
                  <DropdownMenuLinkItem key={item.href} render={<Link href={item.href} />}>
                    {item.label}
                    <Count n={item.count} />
                  </DropdownMenuLinkItem>
                ))}
              </DropdownMenuGroup>
            </>
          )}
          <DropdownMenuSeparator />
          <DropdownMenuSub>
            <DropdownMenuSubTrigger className="text-amber-800">
              <FlaskConical aria-hidden />
              Demo: view as…
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent side="left" className="max-h-80 w-56">
              <DropdownMenuGroup>
                <DropdownMenuLabel>Demo only: switch member</DropdownMenuLabel>
                <DropdownMenuRadioGroup value={viewer} onValueChange={(v) => set(String(v))}>
                  {handles.map((h) => (
                    <DropdownMenuRadioItem key={h.handle} value={h.handle} disabled={pending} closeOnClick>
                      {h.label}
                    </DropdownMenuRadioItem>
                  ))}
                </DropdownMenuRadioGroup>
              </DropdownMenuGroup>
            </DropdownMenuSubContent>
          </DropdownMenuSub>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

function SheetSection({ title, items, pathname }: { title: string; items: NavItem[]; pathname: string }) {
  return (
    <div className="space-y-1">
      <p className="px-3 text-xs font-medium tracking-wide text-metal uppercase">{title}</p>
      {items.map((item) => (
        <SheetClose
          key={item.href}
          nativeButton={false}
          render={<Link href={item.href} />}
          className={cn(
            "flex h-10 items-center rounded-md px-3 text-sm font-medium",
            isActive(pathname, item.href) ? "bg-mist text-ink" : "text-metal",
          )}
        >
          {item.label}
          <Count n={item.count} />
        </SheetClose>
      ))}
    </div>
  );
}

export function MobileNav({ brand, explore, explain, you, steward, viewer, handles }: NavModel & { brand: string }) {
  const pathname = usePathname();
  return (
    <Sheet>
      <SheetTrigger
        className="inline-flex size-9 items-center justify-center rounded-md text-metal hover:bg-mist md:hidden"
        aria-label="Open menu"
      >
        <Menu className="size-5" />
      </SheetTrigger>
      <SheetContent side="left" className="w-72 overflow-y-auto">
        <SheetHeader>
          <SheetTitle>{brand}</SheetTitle>
        </SheetHeader>
        <nav className="flex flex-col gap-6 px-4 pb-6" aria-label="Main">
          <SheetSection title="Explore" items={[...explore, ...explain]} pathname={pathname} />
          <div className="space-y-4 rounded-lg border border-line bg-mist/60 py-3">
            <SheetSection title={`You · ${viewerName(viewer)}`} items={you} pathname={pathname} />
            {steward.length > 0 && <SheetSection title="Steward tools" items={steward} pathname={pathname} />}
            <div className="space-y-1 px-3">
              <p className="text-xs font-medium tracking-wide text-amber-800 uppercase">Demo: view as…</p>
              <ViewerSwitcher viewer={viewer} handles={handles} />
            </div>
          </div>
        </nav>
      </SheetContent>
    </Sheet>
  );
}

export function ViewerSwitcher({ viewer, handles }: { viewer: string; handles: { handle: string; label: string }[] }) {
  const form = useRef<HTMLFormElement>(null);
  return (
    <form ref={form} action={setViewerAction}>
      <select
        name="handle"
        defaultValue={viewer}
        key={viewer}
        onChange={() => form.current?.requestSubmit()}
        className="h-9 w-full rounded-md border border-line bg-white px-2 text-sm font-medium text-ink shadow-xs outline-none focus-visible:ring-2 focus-visible:ring-seaglass-light"
        aria-label="Demo: view as member"
      >
        {handles.map((h) => (
          <option key={h.handle} value={h.handle}>
            {h.label}
          </option>
        ))}
      </select>
    </form>
  );
}
