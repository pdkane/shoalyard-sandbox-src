import { defaultParams, PARAMS } from "@av/schema";
import type { BudgetLine, Claim, ContractorLine, KillReason, PitchDeck, PlanInput, RosterRoleKey, Slide, SlideKey, Source } from "@av/schema";
import type { DeckDraft } from "./deck";
import type { IdeaTemplate } from "./ideas";
import { proofLine } from "./plan";
import { sharedServicesCharge } from "./services";
import type { RoleHint } from "./sizing";

/* ---------- claim helpers: every claim says what it rests on ---------- */

const val = (n: number, unit: string) => ({ n, unit });
/** Named public data the agent cites; it stays "not yet checked by a member" until one confirms it. */
export const pub = (ref: string, label: string): Source => ({ kind: "public-data", ref, label, verified: false });
export const rec = (kind: Exclude<Source["kind"], "public-data">, ref: string, label: string): Source => ({ kind, ref, label, verified: true });

export const ev = (id: string, text: string, sources: Source[], value?: Claim["value"]): Claim => ({ id, text, basis: "evidence", sources, value });
export const est = (id: string, text: string, method: string, sources: Source[] = [], value?: Claim["value"]): Claim => ({ id, text, basis: "estimate", sources, method, value });
export const asm = (id: string, text: string, how: string, value?: Claim["value"], rfeId?: string): Claim => ({ id, text, basis: "assumption", sources: [], test: { how, rfeId }, value });

const slide = (key: SlideKey, headline: string, ...claims: Claim[]): Slide => ({ key, headline, claims });
const date = (d: string) => `${d}T00:00:00.000Z`;

interface LineSpec {
  key: string;
  label: string;
  category: BudgetLine["category"];
  /** One-time amount. */
  usd?: number;
  /** Recurring amount: the proof budget carries it for the proof months, the plan for every month. */
  monthly?: number;
  /** How the figure was worked out, at 2026 list prices. A quote on the record would make it evidence. */
  method: string;
  stretch?: boolean;
}

/** The plan inputs the agent fills in. Code turns each into a claim and computes the months. */
interface PlanSpec {
  proofMonths: number;
  /** Per-use prices only: uses per customer a month, and how that gets tested. */
  uses?: { n: number; how: string };
  variable: { usd: number; per: string; method: string };
  leads: { n: number; from?: number; growthPct: number; what: string; how: string; rfeId?: string };
  churn: { pct: number; how: string; basis?: { text: string; method: string } };
  conversion?: { rate: number; text: string; how: string };
}

interface DeckSpec extends Omit<DeckDraft, "budget" | "pricing" | "killCriteria" | "hints" | "plan"> {
  lines: LineSpec[];
  plan: PlanSpec;
  pricing: Omit<PitchDeck["pricing"], "claimId"> & { claimId?: string };
  kill: { key: string; condition: string; by: string; killReason: KillReason }[];
  hints?: Partial<Record<RosterRoleKey, Partial<RoleHint> & { label: string }>>;
}

const money = (n: number) => `$${n.toLocaleString("en-US")}`;

function lineClaim(l: LineSpec, months: number): Claim {
  const usd = l.monthly !== undefined ? l.monthly * months : (l.usd ?? 0);
  const amount = l.monthly !== undefined ? `${money(l.monthly)} a month × ${months} months = ${money(usd)}` : money(usd);
  return est(`c-budget-${l.key}`, `${l.label}: ${amount}${l.stretch ? ", only if seats past the minimum sell" : ""}.`, l.method, [], val(usd, "usd"));
}

function planClaims(p: PlanSpec, pricing: DeckSpec["pricing"]): { claims: Claim[]; input: PlanInput } {
  const perUse = pricing.cadence === "per-use";
  const claims: Claim[] = [];
  if (perUse && p.uses) claims.push(asm("c-plan-uses", `About ${p.uses.n} ${pricing.unit}s per customer a month.`, p.uses.how, val(p.uses.n, `${pricing.unit}s/month`)));
  claims.push(est("c-plan-variable", `About ${money(p.variable.usd)} per ${p.variable.per} to serve, before card fees.`, p.variable.method, [], val(p.variable.usd, "usd")));
  const from = p.leads.from ?? 1;
  claims.push(
    asm(
      "c-plan-leads",
      `${p.leads.n} ${p.leads.what} a month from month ${from}, growing ${p.leads.growthPct}% a month.`,
      p.leads.how,
      val(p.leads.n, "leads/month"),
      p.leads.rfeId,
    ),
  );
  claims.push(
    p.churn.basis
      ? est("c-plan-churn", p.churn.basis.text, p.churn.basis.method, [], val(p.churn.pct, "%/month"))
      : asm("c-plan-churn", `${p.churn.pct}% of paying customers leave each month.`, p.churn.how, val(p.churn.pct, "%/month")),
  );
  if (p.conversion) claims.push(asm("c-plan-conversion", p.conversion.text, p.conversion.how, val(p.conversion.rate, "share")));
  return {
    claims,
    input: {
      proofMonths: p.proofMonths,
      horizonMonths: PARAMS.PLAN_HORIZON_MONTHS.value,
      usesPerCustomerMonth: perUse ? (p.uses?.n ?? 1) : 1,
      variableUsdPerUse: p.variable.usd,
      firstLeadMonth: from,
      leadsPerMonth: p.leads.n,
      leadGrowthPct: p.leads.growthPct,
      leadToPaid: p.conversion?.rate,
      churnPct: p.churn.pct,
      claims: { uses: perUse && p.uses ? "c-plan-uses" : (pricing.claimId ?? "c-price"), variable: "c-plan-variable", leads: "c-plan-leads", churn: "c-plan-churn", conversion: p.conversion ? "c-plan-conversion" : undefined },
    },
  };
}

/**
 * Budget lines become claims on the proof budget slide and the plan inputs claims on the
 * business plan slide, so every dollar and every guess has a stated basis.
 */
function compose(spec: DeckSpec): DeckDraft {
  const months = spec.plan.proofMonths;
  const budgetClaims = spec.lines.map((l) => lineClaim(l, months));
  const plan = planClaims(spec.plan, spec.pricing);
  const planSlide = slide("plan", `${PARAMS.PLAN_HORIZON_MONTHS.value} months, computed from these inputs and the lines above.`, ...plan.claims);
  let slides = spec.slides.map((s) => (s.key === "budget" ? { ...s, headline: `What ${months} months of proof cost, line by line.`, claims: [...s.claims, ...budgetClaims] } : s));
  if (!slides.some((s) => s.key === "budget")) slides.push(slide("budget", `What ${months} months of proof cost.`, ...budgetClaims));
  slides = slides.flatMap((s) => (s.key === "budget" ? [s, planSlide] : [s]));
  const hints: DeckDraft["hints"] = {};
  for (const [k, h] of Object.entries(spec.hints ?? {})) {
    hints[k as RosterRoleKey] = { label: h.label, qualifications: h.qualifications ?? [], clusters: h.clusters ?? [], keywords: h.keywords ?? [] };
  }
  const { lines, kill, hints: _h, plan: _p, ...rest } = spec;
  return {
    ...rest,
    slides,
    pricing: { ...spec.pricing, claimId: spec.pricing.claimId ?? "c-price" },
    budget: lines.map((l) => ({
      ...proofLine({ key: l.key, label: l.label, category: l.category, usd: l.usd, monthlyUsd: l.monthly, claimId: `c-budget-${l.key}`, stretch: l.stretch }, months),
    })),
    plan: plan.input,
    killCriteria: kill.map((k) => ({ ...k, by: date(k.by) })),
    hints,
  };
}

/* ---------- standard lines, at 2026 list prices ---------- */

/** The operating agent's own loop: reading the record, drafting, deciding. */
const COMPUTE = (runsPerDay: number): LineSpec => {
  const perRun = (40_000 * 3 + 3_000 * 15) / 1_000_000;
  return {
    key: "compute",
    label: "Agent compute",
    category: "api",
    monthly: Math.round(runsPerDay * 30 * perRun),
    method: `${runsPerDay} agent runs a day × 30 days, each about 40k input and 3k output tokens at $3 and $15 per million (the operator model's list price): $${perRun.toFixed(3)} a run`,
  };
};
const DOMAIN: LineSpec = { key: "domain", label: "Domain", category: "domain", usd: 15, method: "One .com for a year at registrar list price" };
/** The back office every venture shares, at the catalogue's at-cost rates (see services.ts). */
const BACK_OFFICE = sharedServicesCharge(defaultParams());
const SHARED_SETUP: LineSpec = {
  key: "series",
  label: "Shared services: opening its series",
  category: "shared-services",
  usd: BACK_OFFICE.setupUsd,
  method: "The at-cost filing to add this venture as a series under the umbrella entity, instead of forming its own company; the legal form is still an open request for counsel",
};
const SHARED: LineSpec = {
  key: "shared-services",
  label: "Shared services: legal, finance and operations",
  category: "shared-services",
  monthly: BACK_OFFICE.monthlyUsd,
  method: `The flat charge from the shared back office, at cost: legal $${BACK_OFFICE.byArea.legal}, finance $${BACK_OFFICE.byArea.finance} and operations $${BACK_OFFICE.byArea.operations} a month. It covers the umbrella entity, templates, bank and payments, books, contractor payments, the master insurance policy, email, shared tools and hosting, with the pooled costs split across ${BACK_OFFICE.sharedBy} ventures`,
};
const INSURANCE_TOPUP = (monthly: number, what: string): LineSpec => ({
  key: "insurance",
  label: "Insurance top-up",
  category: "insurance",
  monthly,
  method: `${what}, which the master policy doesn't cover: about $${monthly * 12} a year quoted online, paid monthly`,
});
const COUNSEL = (hours: number, about: string): LineSpec => ({
  key: "counsel",
  label: `Counsel review: ${about}`,
  category: "legal",
  usd: hours * 350,
  method: `${hours} hours at about $350 an hour, the going rate for a small-firm lawyer in the area`,
});
/** Domain plus the shared back office; a top-up only where the venture carries a risk the master policy doesn't. */
const standard = (insuranceTopUp = 0, what = ""): LineSpec[] => [DOMAIN, SHARED_SETUP, SHARED, ...(insuranceTopUp ? [INSURANCE_TOPUP(insuranceTopUp, what)] : [])];

const FUNNEL_HOW = "The roster's introducers and buyer-side members; counted on the weekly update";

/* ---------- the seeded ventures ---------- */

const dockside = (): DeckDraft =>
  compose({
    purpose: "Dockside Notes writes detention and lumper dispute letters for small freight brokers, so charges they would write off get paid.",
    slides: [
      slide(
        "problem",
        "Brokers write off detention charges because a dispute letter takes an hour.",
        asm("c-status-quo", "Today an ops lead either writes the letter by hand from the rate confirmation and ELD timestamps, or lets the charge go.", "Knowledge request to brokerage operators on which clauses decide a dispute", undefined, "rfe-dockside-clauses"),
        asm("c-named-buyer", "The buyer is the ops lead at a 5–40 person brokerage; a written-off charge comes out of their desk's margin.", "Intro request to an ops lead at a 20-person brokerage", undefined, "rfe-dockside-intro-ops"),
        asm("c-job-story", "When a carrier bills detention I didn't plan for, I want the dispute letter drafted from the documents I already have, so I can send it before the payment window closes.", "Design-partner calls before the first invoice"),
      ),
      slide("demand", "Nothing committed yet: this deck was written before the first customer.", asm("c-demand", "No broker has paid, given time or set up a workflow yet.", "The first paid month is the test; the kill rule fires if it doesn't come")),
      slide(
        "solution",
        "The agent drafts the letter; a person at the brokerage sends it.",
        est("c-wedge", "The smallest paid thing is one month of letters for one desk, from the first week after formation.", "One desk's monthly volume at the planned flat price"),
        asm("c-cannot-do", "The agent can't sign or send for the broker, and can't judge whether a customer relationship is worth a dispute; the ops lead does both.", "Design-partner calls"),
      ),
      slide("customer", "Ops leads at small brokerages.", asm("c-icp", "Not for: brokers over 40 staff with a claims team, or carriers.", "Who answers the first intros")),
      slide(
        "market",
        "Bottom-up: broker authorities × the small-office share × the flat price.",
        est("c-market-accounts", "About 28,000 active broker authorities in the US.", "Count of active property-broker authorities", [pub("fmcsa-licensing", "FMCSA licensing and insurance data")], val(28000, "accounts")),
        asm("c-market-share", "About a quarter of them have 5–40 staff.", "Answers from brokerage operators on office sizes", val(0.25, "share")),
        est("c-market-sam", "7,000 accounts × $2,388 a year ≈ $16.7M a year.", "Accounts × share × annual price", [], val(16_700_000, "usd/yr")),
        est("c-market-tam", "Every active broker at the same price ≈ $67M a year.", "28,000 × $2,388", [], val(67_000_000, "usd/yr")),
        est("c-market-som", "200 brokerages in 24 months ≈ $0.48M a year.", "200 × $2,388", [], val(480_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "Letters can be written from documents brokers already keep.",
        asm("c-prior-attempts", "TMS claims modules exist but are priced and built for larger brokers with claims staff.", "Knowledge request to freight-software members"),
        asm("c-what-changed", "ELD timestamps are now exported in a standard file, so detention time can be shown, not argued.", "The builder role confirms the export format"),
      ),
      slide(
        "alternatives",
        "The real competitor is writing the charge off.",
        asm("c-alt-nothing", "Doing nothing: the charge is written off.", "Design-partner calls"),
        asm("c-alt-tms", "TMS claims modules, priced for larger brokers.", "Freight-software members"),
        asm("c-alt-hand", "A dispatcher writes the letter by hand.", "Design-partner calls"),
      ),
      slide("model", "One flat monthly price per brokerage.", asm("c-price", "$199 a month, flat, rather than $15 a letter.", "Judgment request on pricing to holders", val(199, "usd/month"), "rfe-dockside-pricing")),
      slide("gtm", "Member intros first; a TMS partner second.", asm("c-gtm", "Members who run or know brokerages introduce ops leads; a TMS partner lists it later.", "Intro request results")),
      slide("howItRuns", "Agent only.", est("c-who-works", "The agent drafts every letter; no contractors are paid.", "The product is documents in, a letter out")),
      slide(
        "unitEconomics",
        "Variable cost is small; tooling is the main cost.",
        est("c-unit-cost", "About $6 a month per customer in model calls (40 letters × $0.15).", "Letters per desk × model cost per letter", [], val(6, "usd/month")),
        est("c-cac", "Cash cost to reach a customer is near $0; member intros are paid in units.", "Planned intro requests at 6–8 units each", [rec("lesson", "L-001", "Batch 001 lesson on pricing intro requests")]),
      ),
      slide("milestones", "First paid month by week 6."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-letters", "Brokers won't send a letter an agent drafted.", "Design-partner calls"),
        asm("c-risk-cold", "Cold outbound is enough to reach ops leads, so intros aren't needed.", "Two outbound tests before formation money is spent"),
      ),
    ],
    market: { method: "bottom-up", formula: "accounts × small-office share × $2,388 a year", steps: ["c-market-accounts", "c-market-share", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Write it off", kind: "do-nothing", claimId: "c-alt-nothing" },
      { name: "TMS claims modules", kind: "incumbent", claimId: "c-alt-tms" },
      { name: "Dispatcher by hand", kind: "workaround", claimId: "c-alt-hand" },
    ],
    pricing: { price: 199, unit: "brokerage", cadence: "month" },
    lines: [
      COMPUTE(30),
      { key: "api", label: "Letter drafting while tuning", category: "api", usd: 60, method: "About 600 test letters at 20k input and 1.5k output tokens each: about $0.08 a letter, rounded up" },
      { key: "tools", label: "Email sending and document parsing", category: "tools", monthly: 55, method: "A transactional email plan at about $15 a month and a document-parsing API at about $40" },
      ...standard(),
      { key: "ads", label: "One outbound channel test", category: "ads-test", usd: 300, method: "A small sponsored post in a freight-broker newsletter, written down as an experiment first" },
    ],
    plan: {
      proofMonths: 4,
      variable: { usd: 4, per: "brokerage a month", method: "About 40 letters a month at $0.08 in model calls, plus storage" },
      leads: { n: 10, growthPct: 15, what: "intros to ops leads", how: FUNNEL_HOW, rfeId: "rfe-dockside-intro-ops" },
      churn: { pct: 3, how: "Renewals each quarter" },
    },
    contractors: [],
    requestPlan: [
      { key: "pricing", title: "Flat monthly price or per letter?", type: "judgment", stakes: "medium", audience: "any-holder" },
      { key: "clauses", title: "Which rate-confirmation clauses decide a detention dispute?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
      { key: "intro", title: "Intro to an ops lead at a 20-person brokerage", type: "access", stakes: "medium", audience: "introducer" },
    ],
    milestones: [
      { key: "partners", label: "Design partners", metric: "brokerages using drafts", target: 3, dueDays: 35 },
      { key: "first-paid", label: "First paid month", metric: "paying brokerages", target: 1, dueDays: 42 },
    ],
    kill: [{ key: "first-broker", condition: "no paying broker", by: "2026-03-31", killReason: "no demand" }],
    premortem: [
      { way: "Brokers don't trust a drafted letter enough to send it.", killReason: "poor product" },
      { way: "Ops leads can't be reached without intros the members don't have.", killReason: "could not reach buyer" },
      { way: "Recovered charges are too small to pay $199 a month.", killReason: "price" },
    ],
    primaryMetric: { name: "Paying brokerages", unit: "brokerages", target: 1, by: "first-paid" },
    motions: ["Partner or channel", "Sales-led"],
    needsIntegration: true,
    hints: {
      "icp-operator": { label: "Brokerage operators", qualifications: ["Runs a desk or ops at a freight brokerage"], clusters: ["freight-ops"] },
      introducer: { label: "Introducers to brokerage owners", qualifications: ["Can introduce a brokerage owner or ops lead"], keywords: ["retired", "executive", "owner"] },
      "domain-expert": { label: "Claims or freight-software experts", qualifications: ["Has handled freight claims or built freight software"], clusters: ["freight-ops", "saas-gtm"], keywords: ["claims"] },
      builder: { label: "ELD-export builder", qualifications: ["Has parsed ELD or TMS exports"], clusters: ["data-eng"] },
      channel: { label: "TMS channel partner", qualifications: ["Works at a TMS or load-board vendor"], clusters: ["saas-gtm", "freight-ops"], keywords: ["tms"] },
    },
  });

const chairside = (): DeckDraft =>
  compose({
    purpose: "Chairside Shifts books vetted hygienists into same-week sick-day cover for dental practices in the Denver metro.",
    slides: [
      slide(
        "problem",
        "A hygienist's sick day costs a practice a full day of cleanings.",
        asm("c-status-quo", "Today the practice manager phones former staff or a temp agency, or cancels the day's cleanings.", "Judgment request to holders on how practices fill a sick day", undefined, "rfe-chairside-sickday"),
        asm("c-named-buyer", "The buyer is the practice manager at a 1–4 chair practice; a cancelled day lands on their schedule and their numbers.", "Calls with practice managers"),
        asm("c-job-story", "When a hygienist calls in sick, I want a vetted replacement booked for today or tomorrow, so I can keep the day's patients.", "Calls with practice managers"),
      ),
      slide("demand", "Nothing committed yet: this deck was written before the first booking.", asm("c-demand", "No practice has paid or booked a shift yet.", "The first paid booking is the test")),
      slide(
        "solution",
        "The agent finds and books cover; a licensed hygienist works the shift.",
        est("c-wedge", "The smallest paid thing is one booked cover shift, at a $45 booking fee.", "One shift at the planned booking fee"),
        asm("c-cannot-do", "The agent can't check a licence by itself or work a shift; a person confirms the licence and the hygienist does the work.", "Steward sign-off on the contractor plan"),
      ),
      slide("customer", "Practice managers in the Denver metro.", asm("c-icp", "Not for: dental groups with their own float pool.", "Who answers the first calls")),
      slide(
        "market",
        "Bottom-up: practices × cover shifts a year × the booking fee.",
        est("c-market-accounts", "About 130,000 US dental practices; about 1,500 in the Denver metro.", "Practice counts by metro", [pub("ada-hpi", "ADA Health Policy Institute practice counts")], val(1500, "accounts")),
        asm("c-market-shifts", "About 8 cover shifts per practice a year, so $360 a year in fees.", "Judgment request on how often practices need cover", val(360, "usd/yr")),
        est("c-market-sam", "Denver: 1,500 × $360 ≈ $0.54M a year.", "Accounts × fees a year", [], val(540_000, "usd/yr")),
        est("c-market-tam", "Every US practice at the same rate ≈ $47M a year.", "130,000 × $360", [], val(47_000_000, "usd/yr")),
        est("c-market-som", "60 practices ≈ $22k a year.", "60 × $360", [], val(22_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "Hygienists already pick up shifts by text.",
        asm("c-prior-attempts", "Temp agencies cover this today at agency rates, with a day or more of notice.", "Calls with practice managers"),
        asm("c-what-changed", "Shift booking by text is normal for hygienists, so an agent can run the booking end to end.", "Knowledge request to hygienists"),
      ),
      slide(
        "alternatives",
        "The real competitor is cancelling the day.",
        asm("c-alt-nothing", "Cancel the day's cleanings.", "Calls with practice managers"),
        asm("c-alt-agency", "A temp agency, at agency rates.", "Calls with practice managers"),
        asm("c-alt-phone", "The manager phones former staff.", "Calls with practice managers"),
      ),
      slide("model", "A booking fee per shift; the hygienist's pay passes straight through.", asm("c-price", "$45 per booked shift, paid by the practice on top of the hygienist's rate.", "Demand from the first bookings", val(45, "usd/shift"))),
      slide("gtm", "Sales-led: calls to practice managers.", asm("c-gtm", "Member intros to practice managers, then calls.", "Intro request results")),
      slide(
        "howItRuns",
        "Agent plus contractors: hygienists are paid in cash per shift and never earn units.",
        est("c-who-works", "Two trial shifts at $240 each, paid out of the practice's payment, not seat money.", "A day's rate for a Denver hygienist", [], val(240, "usd/shift")),
      ),
      slide(
        "unitEconomics",
        "Small fees against a sales-led cost to reach each practice.",
        est("c-unit-fee", "$360 a year per practice in fees.", "8 shifts × $45", [], val(360, "usd/yr")),
        est("c-payback", "Reaching each practice by calls takes longer than a year of fees to pay back.", "Fees a year against hours of calls per practice"),
      ),
      slide("milestones", "First booked shift by week 6."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-stranger", "Practices won't let a stranger work on their patients.", "Judgment request to practice managers"),
        asm("c-risk-counsel", "Counsel checks licensure and whether booking shifts is staffing under Colorado rules before the first shift.", "Legal role on the roster"),
      ),
    ],
    market: { method: "bottom-up", formula: "practices × cover shifts a year × $45", steps: ["c-market-accounts", "c-market-shifts", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Cancel the day", kind: "do-nothing", claimId: "c-alt-nothing" },
      { name: "Temp agency", kind: "incumbent", claimId: "c-alt-agency" },
      { name: "Phone former staff", kind: "workaround", claimId: "c-alt-phone" },
    ],
    pricing: { price: 45, unit: "shift", cadence: "per-use" },
    lines: [
      COMPUTE(25),
      { key: "sms", label: "Text messaging and scheduling", category: "tools", monthly: 40, method: "A business texting number and about 2,000 messages a month at list rates, plus a scheduling tool" },
      ...standard(105, "Professional liability for a healthcare staffing service"),
      COUNSEL(3, "Colorado licensure and staffing rules"),
      { key: "checks", label: "Licence and background checks", category: "tools", usd: 150, method: "Five hygienist background checks at about $30 each; licences checked free on the state lookup" },
    ],
    plan: {
      proofMonths: 4,
      uses: { n: 0.7, how: "Booked shifts per practice, from the first three months" },
      variable: { usd: 1, per: "booked shift", method: "Texts and model calls for one booking; the hygienist's pay passes straight through" },
      leads: { n: 10, growthPct: 10, what: "calls to practice managers", how: "Member intros, then calls; counted weekly" },
      churn: { pct: 4, how: "Practices that book once and never again" },
    },
    contractors: [{ job: "Trial cover shift", rateUsd: 240, per: "shift", count: 2, paidFrom: "job fee", claimId: "c-who-works" }],
    requestPlan: [
      { key: "sickday", title: "How does a practice fill a hygienist sick day today?", type: "judgment", stakes: "medium", audience: "any-holder" },
      { key: "licence", title: "What does a cover hygienist need to work a shift in Colorado?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "first-shift", label: "First booked shift", metric: "paid shifts", target: 1, dueDays: 42 },
      { key: "repeat", label: "Repeat practices", metric: "practices booking twice", target: 3, dueDays: 120 },
    ],
    kill: [{ key: "first-practice", condition: "no paying practice", by: "2026-06-30", killReason: "no demand" }],
    premortem: [
      { way: "Practices won't trust a hygienist they haven't met.", killReason: "no demand" },
      { way: "Fees are too small to pay for the calls it takes to reach practices.", killReason: "flawed business model" },
      { way: "Licensure or staffing rules block booking cover this way.", killReason: "legal" },
    ],
    primaryMetric: { name: "Paid cover shifts", unit: "shifts", target: 1, by: "first-shift" },
    motions: ["Sales-led"],
    needsIntegration: false,
    hints: {
      "icp-operator": { label: "Practice managers", qualifications: ["Manages a dental practice"], clusters: ["dental-ops"] },
      introducer: { label: "Introducers to practice owners", qualifications: ["Can introduce a dental practice owner or manager"], keywords: ["dental"] },
      "domain-expert": { label: "Hygienists", qualifications: ["Licensed hygienist, or schedules hygienists"], clusters: ["dental-ops", "generalist"], keywords: ["hygienist"] },
      legal: { label: "Healthcare-staffing counsel", qualifications: ["Practising lawyer who knows healthcare staffing"], clusters: ["legal-counsel"], keywords: ["counsel", "lawyer"] },
    },
  });

const permitPulse = (): DeckDraft =>
  compose({
    purpose: "Permit Pulse sends roofing and HVAC sales teams the new commercial permits in their territory every Monday.",
    slides: [
      slide(
        "problem",
        "Contractors hear about new commercial permits weeks after they're filed.",
        asm("c-status-quo", "Today reps check county portals by hand, or pay for a construction-data suite to get one thing: new permits.", "Judgment request on trade to contractor sales leads", undefined, "rfe-permit-pulse-trade"),
        asm("c-named-buyer", "The buyer is the sales-ops lead at a roofing or HVAC contractor with an outside sales team; a late lead is a missed quarter for their reps.", "Intro request to a sales-ops lead", undefined, "rfe-permit-pulse-intro"),
        asm("c-job-story", "When a commercial permit is filed in my territory, I want it on my reps' Monday list, so they can call before the sub is picked.", "Design-partner calls"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "No contractor has paid or set up a workflow yet; the public demand check is open.", "Demand check, then the first paid Monday list", undefined, "rfe-permit-pulse-demand")),
      slide(
        "solution",
        "Weekly permits matched to trade and territory.",
        est("c-wedge", "The smallest paid thing is one trade in one metro, one Monday email a week, from week five.", "One territory at the planned price"),
        asm("c-cannot-do", "The agent can't judge whether a job fits a contractor's crew or bid strategy; a person at the contractor decides.", "Design-partner calls"),
      ),
      slide("customer", "Sales-ops leads at roofing and HVAC contractors.", asm("c-icp", "Eight Sun Belt metros. Not for: residential-only shops.", "Who answers the first intros")),
      slide(
        "market",
        "Bottom-up: contractor establishments × the share with outside sales × the price.",
        est("c-market-accounts", "About 12,000 roofing and HVAC contractor establishments in the eight metros.", "NAICS 238160 and 238220 establishment counts for the eight metros", [pub("census-cbp", "Census County Business Patterns")], val(12000, "accounts")),
        asm("c-market-share", "About 20% run outside sales teams that chase commercial work.", "Answers from contractor sales leads", val(0.2, "share")),
        est("c-market-sam", "2,400 accounts × $1,788 a year ≈ $4.3M a year.", "Accounts × share × annual price", [], val(4_300_000, "usd/yr")),
        est("c-market-tam", "About 15,000 such accounts nationally ≈ $26.8M a year.", "National equivalent × $1,788", [], val(26_800_000, "usd/yr")),
        est("c-market-som", "60 accounts in 24 months ≈ $107k a year.", "60 × $1,788", [], val(107_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "Counties now publish permits as open data.",
        asm("c-prior-attempts", "Construction-data suites already collect permits, bundled with far more than a sales team needs and priced for it.", "Contractor sales leads confirm what they pay"),
        est("c-what-changed", "Maricopa, Travis and Harris publish permits weekly or better.", "County open-data portals", [pub("county-open-data", "Maricopa, Travis and Harris county open-data portals")]),
      ),
      slide(
        "alternatives",
        "The real competitor is a rep reading county sites.",
        asm("c-alt-suite", "Construction-data suites; the over-served segment is teams that need only new permits.", "Contractor sales leads"),
        asm("c-alt-manual", "Checking county sites by hand.", "Design-partner calls"),
        asm("c-alt-nothing", "Waiting for bid invites.", "Design-partner calls"),
      ),
      slide("model", "One monthly price per trade and territory.", asm("c-price", "$149 a month per trade-territory.", "The public demand check, then the first paid list", val(149, "usd/month"), "rfe-permit-pulse-demand")),
      slide("gtm", "Member intros first; a supply distributor second.", asm("c-gtm", "Construction-sales members introduce sales-ops leads; a roofing supply distributor or trade association lists it later.", "Intro request results")),
      slide("howItRuns", "Agent only.", est("c-who-works", "The agent maintains the scrapers and the matching; no contractors are paid.", "The product is data in, an email out")),
      slide(
        "unitEconomics",
        "Variable cost is small once the scrapers run.",
        est("c-unit-cost", "About $8 a month per subscriber at 10 subscribers.", "$3 in model calls plus $50 of shared proxies ÷ 10", [], val(8, "usd/month")),
        est("c-cac", "Cash cost to reach a customer is near $0; intros are paid in units.", "Planned intro requests at about 6 units", [rec("lesson", "L-001", "Batch 001 lesson on pricing intro requests")]),
      ),
      slide("milestones", "Three design partners by day 35; the first paid Monday list by week five."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-late", "Permits name the winning firm too late to matter.", "Knowledge request to permit-data experts"),
        asm("c-risk-portals", "Portals change often enough that upkeep eats the margin.", "Knowledge request on which metros publish usable data", undefined, "rfe-permit-pulse-metros"),
      ),
    ],
    market: { method: "bottom-up", formula: "establishments × share with outside sales × $1,788 a year", steps: ["c-market-accounts", "c-market-share", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Construction-data suites", kind: "incumbent", claimId: "c-alt-suite" },
      { name: "County sites by hand", kind: "workaround", claimId: "c-alt-manual" },
      { name: "Wait for bid invites", kind: "do-nothing", claimId: "c-alt-nothing" },
    ],
    pricing: { price: 149, unit: "trade-territory", cadence: "month" },
    lines: [
      COMPUTE(30),
      { key: "api", label: "Parsing and matching model calls", category: "api", monthly: 25, method: "About 3,000 permits a week across eight metros at about 2k tokens each on the extraction model" },
      { key: "hosting", label: "Scraper hosting", category: "hosting", monthly: 40, method: "A small scheduled worker and database at list price" },
      { key: "portals", label: "County portal access and proxies", category: "data", monthly: 50, method: "A shared proxy plan for portals that rate-limit" },
      { key: "email", label: "Email sending", category: "tools", monthly: 15, method: "A transactional email plan for the Monday lists" },
      ...standard(),
      { key: "ads", label: "One paid-post test", category: "ads-test", usd: 300, method: "A sponsored post in a roofing trade newsletter, written down as an experiment first" },
      { key: "metro", label: "A fourth metro's portal access", category: "data", usd: 60, method: "One more county's proxy and access", stretch: true },
    ],
    plan: {
      proofMonths: 4,
      variable: { usd: 3, per: "subscriber a month", method: "Matching and email for one territory; the scrapers are fixed costs" },
      leads: { n: 10, growthPct: 15, what: "intros to sales-ops leads", how: FUNNEL_HOW, rfeId: "rfe-permit-pulse-intro" },
      churn: { pct: 4, how: "Cancellations each month" },
    },
    contractors: [],
    requestPlan: [
      { key: "launch-price", title: "Is $149 a month per territory the right launch price?", type: "judgment", stakes: "high", audience: "any-holder" },
      { key: "trade", title: "Lead with roofing or HVAC contractors?", type: "judgment", stakes: "medium", audience: "icp-operator" },
      { key: "metros", title: "Which Sun Belt metros publish permits weekly in usable form?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "partners", label: "Design partners", metric: "contractors on the list", target: 3, dueDays: 35 },
      { key: "first-paid", label: "First paid Monday list", metric: "paying contractors", target: 1, dueDays: 35 },
    ],
    kill: [{ key: "first-contractor", condition: "no paying contractor", by: "2027-03-31", killReason: "no demand" }],
    premortem: [
      { way: "Permits arrive too late for reps to act on.", killReason: "poor product" },
      { way: "Portal upkeep costs more than subscribers pay.", killReason: "flawed business model" },
      { way: "Sales-ops leads can't be reached without intros.", killReason: "could not reach buyer" },
    ],
    primaryMetric: { name: "Paying contractors", unit: "contractors", target: 1, by: "first-paid" },
    motions: ["Partner or channel", "Sales-led"],
    needsIntegration: true,
    hints: {
      "icp-operator": { label: "Contractor sales leads", qualifications: ["Leads sales at a roofing or HVAC contractor"], clusters: ["construction-sales"] },
      introducer: { label: "Introducers to contractor owners", qualifications: ["Can introduce a contractor owner or sales lead"], keywords: ["owner", "business development"] },
      "domain-expert": { label: "Permit or county-data experts", qualifications: ["Works with permit or county data"], clusters: ["data-eng", "construction-sales"], keywords: ["gis", "permit"] },
      builder: { label: "Scraper builder", qualifications: ["Has built and maintained scrapers"], clusters: ["data-eng"] },
      channel: { label: "Supply distributor or trade association", qualifications: ["Works at a roofing supply distributor or trade association"], keywords: ["distributor", "association"] },
    },
  });

const lienClock = (): DeckDraft =>
  compose({
    purpose: "Lien Clock tracks mechanics' lien deadlines for subcontractors in Texas and Arizona and prepares the notices for them to sign.",
    slides: [
      slide(
        "problem",
        "Subcontractors lose lien rights because the clock starts at the first invoice.",
        asm("c-status-quo", "Today the office manager tracks dates in a spreadsheet, or the sub pays a collections lawyer after the deadline has passed.", "Judgment request to holders on how subs track notice dates"),
        asm("c-named-buyer", "The buyer is the owner or office manager at a roofing, HVAC or electrical sub with 5–50 staff; a missed notice is unpaid work they can't recover.", "Intro requests to subcontractor owners"),
        asm("c-job-story", "When I send a first invoice on a project, I want the notice and filing dates worked out for me, so I can send the notice before the window closes.", "Design-partner calls"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "No subcontractor has paid or set up a workflow yet; the public demand check is open.", "Demand check, then the first paid month", undefined, "rfe-lien-clock-demand")),
      slide(
        "solution",
        "Dates from invoices; notices for a person to sign.",
        est("c-wedge", "The smallest paid thing is one month of date tracking for one sub's open projects.", "One subscriber at the planned price"),
        asm("c-cannot-do", "The agent gives no legal advice and never signs or files; a person at the sub signs every notice, and a lawyer reviews the date rules before launch.", "Counsel role on the roster"),
      ),
      slide("customer", "Specialty subs in Texas and Arizona.", asm("c-icp", "Not for: general contractors, or subs outside the two states.", "Who answers the first intros")),
      slide(
        "market",
        "Bottom-up: specialty subs in two states × a small share × the price.",
        est("c-market-accounts", "About 60,000 specialty subcontractors in Texas and Arizona.", "Specialty trade contractor establishment counts for the two states", [pub("census-cbp", "Census County Business Patterns")], val(60000, "accounts")),
        asm("c-market-share", "About 10% have 5–50 staff and unpaid invoices often enough to pay for tracking.", "Answers from subcontractor owners", val(0.1, "share")),
        est("c-market-sam", "6,000 accounts × $588 a year ≈ $3.5M a year.", "Accounts × share × annual price", [], val(3_500_000, "usd/yr")),
        est("c-market-tam", "All 60,000 at the same price ≈ $35M a year.", "60,000 × $588", [], val(35_000_000, "usd/yr")),
        est("c-market-som", "150 subs in 24 months ≈ $88k a year.", "150 × $588", [], val(88_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "The dates are now computable.",
        asm("c-prior-attempts", "Lien-service firms do this for larger subs, priced per project.", "Subcontractor owners confirm what they pay"),
        est("c-what-changed", "Texas shortened its notice windows in 2022 and county filings are searchable online.", "Statute changes and county search portals", [pub("tx-property-code-53", "Texas Property Code chapter 53")]),
      ),
      slide(
        "alternatives",
        "The real competitor is a spreadsheet and hope.",
        asm("c-alt-firm", "Lien-service firms, priced for larger subs.", "Subcontractor owners"),
        asm("c-alt-sheet", "A spreadsheet of dates kept by the office manager.", "Design-partner calls"),
        asm("c-alt-nothing", "Doing nothing until a payment is late.", "Design-partner calls"),
      ),
      slide("model", "One monthly price per subcontractor.", asm("c-price", "$49 a month per subscriber.", "The public demand check, then the first paid month", val(49, "usd/month"), "rfe-lien-clock-demand")),
      slide("gtm", "Sales-led, through member intros.", asm("c-gtm", "Construction-sales members introduce subcontractor owners.", "Intro request results")),
      slide("howItRuns", "Agent only.", est("c-who-works", "The agent reads invoices and prepares notices; no contractors are paid.", "Documents in, dated notices out")),
      slide(
        "unitEconomics",
        "Cheap to serve once the date rules are checked.",
        est("c-unit-cost", "About $4 a month per subscriber in model calls and postage.", "Invoices per month × parsing cost, plus certified mail", [], val(4, "usd/month")),
        est("c-cac", "Cash cost to reach a customer is near $0; intros are paid in units.", "Planned intro requests"),
      ),
      slide("milestones", "First paid month by week eight."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-counsel", "Counsel confirms the date rules and the notice templates, and that sending notices for a sub to sign isn't legal advice, before launch.", "Legal role on the roster"),
        asm("c-risk-ownership", "Office managers won't hand over invoices.", "Design-partner calls"),
      ),
    ],
    market: { method: "bottom-up", formula: "subcontractors × share × $588 a year", steps: ["c-market-accounts", "c-market-share", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Lien-service firms", kind: "incumbent", claimId: "c-alt-firm" },
      { name: "Spreadsheet of dates", kind: "workaround", claimId: "c-alt-sheet" },
      { name: "Wait until paid late", kind: "do-nothing", claimId: "c-alt-nothing" },
    ],
    pricing: { price: 49, unit: "subcontractor", cadence: "month" },
    lines: [
      COMPUTE(25),
      { key: "api", label: "Invoice parsing while tuning", category: "api", usd: 60, method: "About 500 test invoices at about $0.12 each" },
      { key: "hosting", label: "Hosting", category: "hosting", monthly: 30, method: "A small app server and database at list price" },
      { key: "mail", label: "Certified mail and email", category: "tools", monthly: 35, method: "About four certified notices a month at about $8 each, plus a sending plan" },
      ...standard(25, "Errors and omissions for a document-preparation service"),
      COUNSEL(4, "Texas and Arizona date rules and notice templates"),
    ],
    plan: {
      proofMonths: 4,
      variable: { usd: 4, per: "subscriber a month", method: "Parsing a sub's invoices plus a share of certified postage" },
      leads: { n: 12, growthPct: 15, what: "intros to subcontractor owners", how: FUNNEL_HOW },
      churn: { pct: 3, how: "Cancellations each month" },
    },
    contractors: [],
    requestPlan: [
      { key: "tracking", title: "How do subs track lien notice dates today?", type: "judgment", stakes: "medium", audience: "any-holder" },
      { key: "rules", title: "Which Texas and Arizona notice rules trip subs up most?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "partners", label: "Design partners", metric: "subs with projects tracked", target: 3, dueDays: 40 },
      { key: "first-paid", label: "First paid month", metric: "paying subcontractors", target: 1, dueDays: 56 },
    ],
    kill: [{ key: "first-sub", condition: "no paying subcontractor", by: "2027-04-30", killReason: "no demand" }],
    premortem: [
      { way: "Subs won't hand invoices to an agent.", killReason: "no demand" },
      { way: "The date rules need a lawyer per project, so it can't be automated.", killReason: "legal" },
      { way: "Office managers can't be reached without intros.", killReason: "could not reach buyer" },
    ],
    primaryMetric: { name: "Paying subcontractors", unit: "subcontractors", target: 1, by: "first-paid" },
    motions: ["Sales-led"],
    needsIntegration: true,
    hints: {
      "icp-operator": { label: "Subcontractor owners or office managers", qualifications: ["Runs or manages a specialty subcontractor"], clusters: ["construction-sales"] },
      introducer: { label: "Introducers to subcontractor networks", qualifications: ["Can introduce subcontractor owners"], keywords: ["business development", "sales director"] },
      "domain-expert": { label: "Construction lien or collections experts", qualifications: ["Knows lien rules or construction collections"], clusters: ["legal-counsel", "finance-ops"], keywords: ["lien", "collections"] },
      builder: { label: "Accounting-export builder", qualifications: ["Has parsed invoices from accounting software"], clusters: ["data-eng", "finance-ops"] },
      legal: { label: "Construction lien counsel", qualifications: ["Practising lawyer who knows Texas or Arizona lien law"], clusters: ["legal-counsel"], keywords: ["counsel", "lawyer"] },
    },
  });

const wetInk = (): DeckDraft =>
  compose({
    purpose: "Wet Ink books a nearby member to do the in-person steps an agent-run business can't: wet signatures, notarisations and county filings.",
    slides: [
      slide(
        "problem",
        "Agent-run ventures stall on steps that need a person in a room.",
        asm("c-status-quo", "Today the venture's operator drives to the notary or the county desk themselves, or posts a member request.", "Judgment request to holders on how ventures handle in-person steps"),
        asm("c-named-buyer", "The buyer is the operator or founder running an agent-run venture; a stalled filing holds up their launch.", "The first paid job"),
        asm("c-job-story", "When my agent hits a form that needs ink or a notary, I want a person booked nearby by API, so I can get a scan back the same week.", "The first paid jobs"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "No venture has paid for a job yet; the public demand check is open.", "Demand check, then the first paid job", undefined, "rfe-wet-ink-demand")),
      slide(
        "solution",
        "Request by API; a member nearby does it; a scan comes back.",
        est("c-wedge", "The smallest paid thing is one notarised form, returned as a scan with a chain of custody.", "One job at the planned price"),
        asm("c-cannot-do", "The agent can't sign, notarise or stand at a counter; a paid member does each job, and every request says an agent sent it.", "The first paid jobs"),
      ),
      slide("customer", "Agent-run ventures and the people building them.", asm("c-icp", "Not for: people who need legal documents drafted.", "Who sends the first jobs")),
      slide(
        "market",
        "Small and early: jobs a month from agent-run ventures.",
        asm("c-market-accounts", "A few hundred US jobs a month from agent-run ventures and early builders.", "Knowledge request on how often ventures hit in-person steps", val(300, "jobs/month")),
        est("c-market-sam", "300 jobs × $45 × 12 ≈ $162k a year.", "Jobs × price × months", [], val(162_000, "usd/yr")),
        asm("c-market-tam", "If agent-run ventures grow tenfold, about $1.6M a year.", "Track the number of agent-run ventures", val(1_620_000, "usd/yr")),
        est("c-market-som", "20 jobs a month in the first year ≈ $11k a year.", "20 × $45 × 12", [], val(10_800, "usd/yr")),
      ),
      slide(
        "whyNow",
        "The same request now repeats weekly.",
        asm("c-prior-attempts", "Mobile notaries and couriers do this, booked by hand by a person.", "Steward checks booking options"),
        asm("c-what-changed", "There are now enough agent-run ventures, including the Protocol's own, that the same in-person request repeats.", "Count requests across ventures"),
      ),
      slide(
        "alternatives",
        "The real competitor is a member request.",
        asm("c-alt-request", "A member Action request on the Protocol.", "Compare prices against a member request"),
        asm("c-alt-notary", "Mobile notaries booked by hand.", "Steward checks booking options"),
        asm("c-alt-self", "The operator does it themselves.", "The first paid jobs"),
      ),
      slide("model", "A fee per job; the member is paid out of it.", asm("c-price", "$45 per job.", "The public demand check, then the first paid jobs", val(45, "usd/job"), "rfe-wet-ink-demand")),
      slide("gtm", "Self-serve: an API other ventures call.", asm("c-gtm", "Ventures on the Protocol call it first; agent builders find it through their docs.", "The first ten jobs")),
      slide(
        "howItRuns",
        "Agent plus contractors: members are paid in cash per job and never earn units for it.",
        est("c-who-works", "The member who does each job is paid $30 out of the $45 fee.", "A local notary's going rate", [], val(30, "usd/job")),
      ),
      slide(
        "unitEconomics",
        "Thin per job, so volume decides it.",
        est("c-unit-margin", "About $13 a job after the member and $2 of compute and storage.", "$45 − $30 − $2", [], val(13, "usd/job")),
        est("c-cac", "Ventures on the Protocol find it without paid outreach.", "Requests posted by ventures"),
      ),
      slide("milestones", "Ten paid jobs by day 60."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-request", "A member request does the job for less, so ventures never pay for the tool.", "Compare against member requests"),
        asm("c-risk-one-buyer", "Only one venture needs it.", "Count ventures sending jobs"),
      ),
    ],
    market: { method: "bottom-up", formula: "jobs a month × $45 × 12", steps: ["c-market-accounts", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 12 },
    alternatives: [
      { name: "Member Action request", kind: "workaround", claimId: "c-alt-request" },
      { name: "Mobile notaries", kind: "incumbent", claimId: "c-alt-notary" },
      { name: "Do it yourself", kind: "do-nothing", claimId: "c-alt-self" },
    ],
    pricing: { price: 45, unit: "job", cadence: "per-use" },
    lines: [
      COMPUTE(20),
      { key: "tools", label: "Scan storage and signing tools", category: "tools", monthly: 45, method: "Storage and an e-signature plan with audit trails at list price" },
      ...standard(30, "Notary errors and omissions"),
      { key: "trial", label: "Three trial jobs", category: "contractors", usd: 90, method: "Three jobs at the $30 member rate before any venture pays" },
    ],
    contractors: [
      { job: "Trial in-person job", rateUsd: 30, per: "job", count: 3, paidFrom: "seat money", claimId: "c-who-works" },
      { job: "In-person job", rateUsd: 30, per: "job", count: 20, paidFrom: "job fee", claimId: "c-who-works" },
    ],
    plan: {
      proofMonths: 4,
      uses: { n: 2, how: "Jobs per venture a month, from the first ten jobs" },
      variable: { usd: 32, per: "job", method: "$30 to the member who does it, plus about $2 of compute and storage" },
      leads: { n: 4, growthPct: 10, what: "ventures trying the API", how: "API sign-ups, counted weekly" },
      churn: { pct: 5, how: "Ventures that stop sending jobs" },
      conversion: { rate: 0.25, text: "About one in four ventures that try the API pays for a job.", how: "Sign-ups against paid jobs in the first two months" },
    },
    requestPlan: [
      { key: "steps", title: "How do ventures handle in-person steps today?", type: "judgment", stakes: "low", audience: "any-holder" },
      { key: "notary", title: "What does a remote venture need for a notarised form to count?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "first-job", label: "First paid job", metric: "paid jobs", target: 1, dueDays: 30 },
      { key: "ten-jobs", label: "Ten paid jobs", metric: "paid jobs", target: 10, dueDays: 60 },
    ],
    kill: [{ key: "jobs", condition: "fewer than 20 paid jobs", by: "2027-03-31", killReason: "no demand" }],
    premortem: [
      { way: "A member request is cheaper than the tool.", killReason: "outcompeted" },
      { way: "Only the venture it names as job one needs it.", killReason: "no demand" },
      { way: "Too few members near the offices that need jobs done.", killReason: "execution" },
    ],
    primaryMetric: { name: "Paid jobs", unit: "jobs", target: 10, by: "ten-jobs" },
    motions: ["Self-serve"],
    needsIntegration: true,
    hints: {
      "icp-operator": { label: "Operators of agent-run ventures", qualifications: ["Runs or builds an agent-run venture"], clusters: ["data-eng", "generalist"] },
      introducer: { label: "Introducers to agent builders", qualifications: ["Can introduce people building agent-run businesses"], keywords: ["founder", "engineer"] },
      "domain-expert": { label: "Paralegals or notaries", qualifications: ["Works as a paralegal or notary"], clusters: ["legal-counsel", "generalist"], keywords: ["notary", "paralegal"] },
      builder: { label: "Agent-tools builder", qualifications: ["Has built tools agents call"], clusters: ["data-eng"] },
    },
  });

const bidDesk = (): DeckDraft =>
  compose({
    purpose: "Bid Desk assembles county and city bid packages for small contractors, by hand first and automated once the steps are written down.",
    slides: [
      slide(
        "problem",
        "Small contractors skip public bids because the package takes days.",
        asm("c-status-quo", "Today the owner fills the package in at night, pays a bid consultant priced for larger firms, or doesn't bid.", "Judgment request to holders on why small firms skip public bids"),
        asm("c-named-buyer", "The buyer is the owner of a contractor with under 20 staff; a skipped bid is work they were qualified for and never saw.", "Intro requests to contractor owners"),
        asm("c-job-story", "When a county posts a tender I qualify for, I want the package assembled from my documents, so I can bid without losing three evenings.", "The first paid package"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "No contractor has paid for a package yet.", "The first paid package is the test")),
      slide(
        "solution",
        "Members who've won tenders build the first packages; the agent writes down every step.",
        est("c-wedge", "The smallest paid thing is one hand-built package for one tender.", "One package at the planned price"),
        asm("c-cannot-do", "The agent can't sign a bid or vouch for a firm's qualifications; the owner signs, and a paid member checks the package.", "The first packages"),
      ),
      slide("customer", "Owners of contractors with under 20 staff.", asm("c-icp", "County and city work. Not for: federal contracts.", "Who answers the first intros")),
      slide(
        "market",
        "Bottom-up: small contractors who could bid × packages a year × the price.",
        est("c-market-accounts", "About 400,000 US contractor establishments with under 20 staff.", "Construction establishment counts by size", [pub("census-susb", "Census Statistics of US Businesses")], val(400000, "accounts")),
        asm("c-market-share", "About 2% would buy two packages a year.", "Answers from contractor owners", val(0.02, "share")),
        est("c-market-sam", "8,000 accounts × 2 × $350 ≈ $5.6M a year.", "Accounts × share × packages × price", [], val(5_600_000, "usd/yr")),
        est("c-market-tam", "Every small contractor at two packages a year ≈ $280M a year.", "400,000 × 2 × $350", [], val(280_000_000, "usd/yr")),
        est("c-market-som", "40 contractors at two packages a year ≈ $28k a year.", "40 × 2 × $350", [], val(28_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "Tenders now come with structured fields.",
        asm("c-prior-attempts", "Bid-writing consultants serve this, priced for firms that bid every week.", "Contractor owners confirm what they pay"),
        asm("c-what-changed", "Counties post tenders on portals with structured fields, so the repeatable parts can be captured.", "Knowledge request to members who've won tenders"),
      ),
      slide(
        "alternatives",
        "The real competitor is not bidding.",
        asm("c-alt-nothing", "Not bidding.", "Contractor owners"),
        asm("c-alt-evenings", "The owner's own evenings.", "Contractor owners"),
        asm("c-alt-consultant", "Bid-writing consultants.", "Contractor owners"),
      ),
      slide("model", "A fee per package.", asm("c-price", "$350 per package.", "The first paid package", val(350, "usd/package"))),
      slide("gtm", "Sales-led, through member intros.", asm("c-gtm", "Construction-sales members introduce owners who already bid on county work.", "Intro request results")),
      slide(
        "howItRuns",
        "Agent plus contractors: members who've won tenders are paid in cash per package and never earn units for it.",
        est("c-who-works", "One pilot package at $200 from seat money, then $200 a package out of the $350 fee.", "A day of a bid writer's time", [], val(200, "usd/package")),
      ),
      slide(
        "unitEconomics",
        "Thin until the repeatable parts are automated.",
        est("c-unit-margin", "About $140 a package after the member and $10 of compute.", "$350 − $200 − $10", [], val(140, "usd/package")),
        est("c-cac", "Cash cost to reach a customer is near $0; intros are paid in units.", "Planned intro requests"),
      ),
      slide("milestones", "First paid package by week six; ten packages before automating."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-counsel", "Counsel checks what a third party may prepare for a public bid in each county before the first paid package.", "Legal role on the roster"),
        asm("c-risk-win", "Packages go out but don't win, so owners stop paying.", "Win rate on the first ten packages"),
      ),
    ],
    market: { method: "bottom-up", formula: "contractors × share × 2 packages × $350", steps: ["c-market-accounts", "c-market-share", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Not bidding", kind: "do-nothing", claimId: "c-alt-nothing" },
      { name: "The owner's evenings", kind: "workaround", claimId: "c-alt-evenings" },
      { name: "Bid-writing consultants", kind: "incumbent", claimId: "c-alt-consultant" },
    ],
    pricing: { price: 350, unit: "package", cadence: "per-use" },
    lines: [
      COMPUTE(20),
      { key: "tools", label: "Document tools", category: "tools", monthly: 30, method: "Form-filling and storage plans at list price" },
      ...standard(),
      COUNSEL(3, "who may prepare a public bid for a contractor"),
      { key: "pilot", label: "Two pilot packages, built by members", category: "contractors", usd: 400, method: "Two packages at the $200 member rate, before any customer pays" },
    ],
    contractors: [
      { job: "Pilot bid package", rateUsd: 200, per: "package", count: 2, paidFrom: "seat money", claimId: "c-who-works" },
      { job: "Bid package", rateUsd: 200, per: "package", count: 8, paidFrom: "job fee", claimId: "c-who-works" },
    ],
    plan: {
      proofMonths: 4,
      uses: { n: 0.5, how: "Packages per contractor a month, from the first ten" },
      variable: { usd: 210, per: "package", method: "$200 to the member who builds it plus about $10 of compute" },
      leads: { n: 10, growthPct: 15, what: "intros to contractor owners", how: FUNNEL_HOW },
      churn: { pct: 5, how: "Contractors who stop bidding" },
    },
    requestPlan: [
      { key: "skip", title: "Why do small firms skip public bids they qualify for?", type: "judgment", stakes: "medium", audience: "any-holder" },
      { key: "steps", title: "Which parts of a county bid package repeat across tenders?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "first-paid", label: "First paid package", metric: "paid packages", target: 1, dueDays: 42 },
      { key: "ten", label: "Ten packages out", metric: "packages submitted", target: 10, dueDays: 120 },
    ],
    kill: [{ key: "first-package", condition: "no contractor pays for a hand-built package", by: "2027-02-28", killReason: "no demand" }],
    premortem: [
      { way: "Owners won't pay before they've won a bid.", killReason: "price" },
      { way: "Packages differ too much by county to automate.", killReason: "flawed business model" },
      { way: "Rules on who may prepare a bid block a third party.", killReason: "legal" },
    ],
    primaryMetric: { name: "Paid packages", unit: "packages", target: 1, by: "first-paid" },
    motions: ["Sales-led"],
    needsIntegration: false,
    hints: {
      "icp-operator": { label: "Contractor owners", qualifications: ["Owns or runs a contractor with under 20 staff"], clusters: ["construction-sales"] },
      introducer: { label: "Introducers to contractor owners", qualifications: ["Can introduce contractor owners who bid public work"], keywords: ["business development", "owner"] },
      "domain-expert": { label: "People who've won public tenders", qualifications: ["Has prepared or won county or city tenders"], clusters: ["construction-sales", "data-eng"], keywords: ["county", "procurement", "gis"] },
      legal: { label: "Public-procurement counsel", qualifications: ["Practising lawyer who knows public procurement"], clusters: ["legal-counsel"], keywords: ["counsel", "lawyer"] },
    },
  });

const siteRecord = (): DeckDraft =>
  compose({
    purpose: "Site Record turns job-site photos and check-ins into a dated, tamper-evident timeline that settles subcontractor payment disputes.",
    slides: [
      slide(
        "problem",
        "When payment is held back, the sub's proof is a camera roll.",
        asm("c-status-quo", "Today the sub sends photos from a group chat, then pays a collections firm 20–30% to chase what's owed.", "Judgment request to holders on how subs prove work was done"),
        asm("c-named-buyer", "The buyer is the owner of a subcontractor that invoices general contractors; a disputed invoice is cash they've already spent on the job.", "Intro requests to subcontractor owners"),
        asm("c-job-story", "When a GC says the work wasn't finished, I want a dated record their accounts team accepts, so I can get paid without a collections firm.", "Two test disputes"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "No subcontractor has paid or used a timeline in a dispute yet.", "Two test disputes, then the first paid record")),
      slide(
        "solution",
        "A signed timeline per job, built from the phone.",
        est("c-wedge", "The smallest paid thing is one job record a GC's accounts team accepts.", "One record at the planned price"),
        asm("c-cannot-do", "The agent can't argue a dispute or vouch for the work; the sub's owner sends the record and decides what to claim.", "Two test disputes"),
      ),
      slide("customer", "Subs who invoice general contractors.", asm("c-icp", "Not for: homeowners or residential-only crews.", "Who answers the first intros")),
      slide(
        "market",
        "Bottom-up: subcontractors × jobs recorded a year × the price.",
        est("c-market-accounts", "About 700,000 US specialty trade contractor establishments.", "Specialty trade establishment counts", [pub("census-cbp", "Census County Business Patterns")], val(700000, "accounts")),
        asm("c-market-share", "About 3% would record 20 jobs a year.", "Answers from subcontractor owners", val(0.03, "share")),
        est("c-market-sam", "21,000 accounts × 20 × $15 ≈ $6.3M a year.", "Accounts × share × jobs × price", [], val(6_300_000, "usd/yr")),
        est("c-market-tam", "Every specialty sub at 20 jobs a year ≈ $210M a year.", "700,000 × 20 × $15", [], val(210_000_000, "usd/yr")),
        est("c-market-som", "100 subs in 24 months ≈ $30k a year.", "100 × 20 × $15", [], val(30_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "Phones already record what a timeline needs.",
        asm("c-prior-attempts", "Job-site photo apps store photos, but no GC's accounts team treats them as evidence.", "Knowledge request to GC project managers"),
        asm("c-what-changed", "Phone photos include reliable GPS and timestamps, and signed timestamps are now cheap.", "The first test records"),
      ),
      slide(
        "alternatives",
        "The real competitor is a camera roll and a collections firm.",
        asm("c-alt-roll", "Camera roll and group chat.", "Subcontractor owners"),
        asm("c-alt-apps", "Job-site photo apps.", "Subcontractor owners"),
        asm("c-alt-nothing", "Write off the disputed amount.", "Subcontractor owners"),
      ),
      slide("model", "A fee per job record.", asm("c-price", "$15 per job record.", "The first paid records", val(15, "usd/job"))),
      slide("gtm", "Sales-led, through member intros.", asm("c-gtm", "Construction-sales members introduce subcontractor owners with a live dispute.", "Intro request results")),
      slide("howItRuns", "Agent only.", est("c-who-works", "The agent builds every record; no contractors are paid.", "Photos in, a signed timeline out")),
      slide(
        "unitEconomics",
        "Under $1 a job to serve.",
        est("c-unit-cost", "Under $1 per job in compute and signed timestamps.", "Photos per job × processing, plus one timestamp", [], val(1, "usd/job")),
        est("c-cac", "Cash cost to reach a customer is near $0; intros are paid in units.", "Planned intro requests"),
      ),
      slide("milestones", "Two test disputes by day 45; the first paid record by week eight."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-accepted", "GCs' accounts teams won't accept the timeline as evidence.", "Two test disputes"),
        asm("c-risk-habit", "Crews won't check in from the site.", "The first test records"),
      ),
    ],
    market: { method: "bottom-up", formula: "subcontractors × share × 20 jobs × $15", steps: ["c-market-accounts", "c-market-share", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Camera roll and group chat", kind: "workaround", claimId: "c-alt-roll" },
      { name: "Job-site photo apps", kind: "adjacent", claimId: "c-alt-apps" },
      { name: "Write it off", kind: "do-nothing", claimId: "c-alt-nothing" },
    ],
    pricing: { price: 15, unit: "job record", cadence: "per-use" },
    lines: [
      COMPUTE(20),
      { key: "hosting", label: "Hosting and signed timestamps", category: "hosting", monthly: 30, method: "Photo storage and a timestamping service at list price" },
      { key: "tools", label: "Mobile upload tools", category: "tools", monthly: 20, method: "A photo-upload plan at list price" },
      ...standard(),
      { key: "ads", label: "One paid-post test", category: "ads-test", usd: 250, method: "A sponsored post in a subcontractor trade group, written down as an experiment first" },
    ],
    plan: {
      proofMonths: 4,
      uses: { n: 2, how: "Job records per sub a month, from the first paid records" },
      variable: { usd: 1, per: "job record", method: "Photo processing and one signed timestamp" },
      leads: { n: 12, growthPct: 15, what: "intros to subcontractor owners", how: FUNNEL_HOW },
      churn: { pct: 4, how: "Subs who stop recording jobs" },
    },
    contractors: [],
    requestPlan: [
      { key: "accept", title: "Would a GC's accounts team accept this timeline in a dispute?", type: "judgment", stakes: "high", audience: "any-holder" },
      { key: "evidence", title: "What do GC accounts teams accept as proof that work was done?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "tests", label: "Test disputes", metric: "disputes with a record", target: 2, dueDays: 45 },
      { key: "first-paid", label: "First paid record", metric: "paying subcontractors", target: 1, dueDays: 56 },
    ],
    kill: [
      { key: "accepted", condition: "GCs' accounts teams reject the timeline in both test disputes", by: "2027-01-31", killReason: "poor product" },
      { key: "first-sub", condition: "no paying subcontractor", by: "2027-05-31", killReason: "no demand" },
    ],
    premortem: [
      { way: "GCs don't treat the record as evidence.", killReason: "poor product" },
      { way: "Crews won't change how they take photos.", killReason: "execution" },
      { way: "Subs can't be reached without intros.", killReason: "could not reach buyer" },
    ],
    primaryMetric: { name: "Paying subcontractors", unit: "subcontractors", target: 1, by: "first-paid" },
    motions: ["Sales-led"],
    needsIntegration: false,
    hints: {
      "icp-operator": { label: "Subcontractor owners", qualifications: ["Owns a subcontractor that invoices GCs"], clusters: ["construction-sales"] },
      introducer: { label: "Introducers to subcontractor networks", qualifications: ["Can introduce subcontractor owners"], keywords: ["business development"] },
      "domain-expert": { label: "GC project managers or accounts leads", qualifications: ["Has approved or disputed sub invoices at a GC"], clusters: ["construction-sales", "finance-ops"], keywords: ["general contracting", "project manager"] },
    },
  });

const lumperLine = (): DeckDraft =>
  compose({
    purpose: "Lumper Line publishes what each warehouse really charges to unload a truck, from receipts freight members already have.",
    slides: [
      slide(
        "problem",
        "Brokers quote loads without knowing the unloading fee.",
        asm("c-status-quo", "Today brokers guess from their own spreadsheets and carrier word of mouth, and eat the difference.", "Judgment request to holders on how brokers price lumper fees"),
        asm("c-named-buyer", "The buyer is the pricing or ops lead at a freight brokerage; a wrong guess comes out of the load's margin.", "Intros to broker owners"),
        asm("c-job-story", "When I quote a dry-van load to a warehouse, I want its real lumper fee, so I can price the load without eating the difference.", "The first paid lookups"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "No brokerage has paid for lookups yet.", "The first paid month")),
      slide(
        "solution",
        "Verified receipts, by warehouse, as a lookup.",
        est("c-wedge", "The smallest paid thing is a month of lookups for one brokerage, once 300 receipts are verified.", "One brokerage at the planned price"),
        asm("c-cannot-do", "The agent can't confirm a receipt is real on its own; a freight member checks the ones it flags.", "Knowledge request to freight members"),
      ),
      slide("customer", "Freight brokers quoting dry-van loads.", asm("c-icp", "Not for: carriers or shippers, for now.", "Who answers the first intros")),
      slide(
        "market",
        "Bottom-up: brokerages × the share that buy data × the price.",
        est("c-market-accounts", "About 20,000 US freight brokerages.", "Active property-broker authorities with recent filings", [pub("fmcsa-licensing", "FMCSA licensing and insurance data")], val(20000, "accounts")),
        asm("c-market-share", "About 10% would pay for lumper data.", "Answers from brokers", val(0.1, "share")),
        est("c-market-sam", "2,000 accounts × $1,188 a year ≈ $2.4M a year.", "Accounts × share × annual price", [], val(2_400_000, "usd/yr")),
        est("c-market-tam", "Every brokerage at the same price ≈ $24M a year.", "20,000 × $1,188", [], val(24_000_000, "usd/yr")),
        est("c-market-som", "50 brokerages in 24 months ≈ $59k a year.", "50 × $1,188", [], val(59_000, "usd/yr")),
      ),
      slide(
        "whyNow",
        "The receipts are already arriving.",
        asm("c-prior-attempts", "Load boards don't publish lumper fees; brokers' own spreadsheets never leave the office.", "Knowledge request to freight members"),
        asm("c-what-changed", "Dockside's customers already upload receipts with their disputes, so collection starts from a working stream.", "Count receipts in the first month"),
      ),
      slide(
        "alternatives",
        "The real competitor is a guess.",
        asm("c-alt-sheet", "Brokers' own spreadsheets.", "Brokers"),
        asm("c-alt-word", "Carrier word of mouth.", "Brokers"),
        asm("c-alt-nothing", "Quote and eat the difference.", "Brokers"),
      ),
      slide("model", "One monthly price per brokerage.", asm("c-price", "$99 a month per brokerage for unlimited lookups.", "The first paid month", val(99, "usd/month"))),
      slide("gtm", "Through Dockside and freight members.", asm("c-gtm", "Dockside's brokers see it first; freight members introduce broker owners.", "Intro request results")),
      slide("howItRuns", "Agent only.", est("c-who-works", "The agent verifies and publishes receipts; no contractors are paid.", "Receipts in, a lookup out")),
      slide(
        "unitEconomics",
        "Each receipt costs about $1 to verify.",
        est("c-unit-cost", "About $1 per verified receipt in compute and member checks.", "Parsing cost plus a share of check requests", [], val(1, "usd/receipt")),
        est("c-cac", "Cash cost to reach a customer is near $0 through Dockside.", "Dockside's broker list"),
      ),
      slide("milestones", "300 verified receipts, then the first paid month."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-receipts", "Members don't upload enough receipts to cover the warehouses brokers quote.", "Receipt count by day 60"),
        asm("c-risk-free", "Brokers share fees for free in groups, so nobody pays.", "The first paid month"),
      ),
    ],
    market: { method: "bottom-up", formula: "brokerages × share × $1,188 a year", steps: ["c-market-accounts", "c-market-share", "c-market-sam"], tam: "c-market-tam", sam: "c-market-sam", som: "c-market-som", somHorizonMonths: 24 },
    alternatives: [
      { name: "Brokers' spreadsheets", kind: "workaround", claimId: "c-alt-sheet" },
      { name: "Carrier word of mouth", kind: "adjacent", claimId: "c-alt-word" },
      { name: "Quote and eat it", kind: "do-nothing", claimId: "c-alt-nothing" },
    ],
    pricing: { price: 99, unit: "brokerage", cadence: "month" },
    lines: [
      COMPUTE(20),
      { key: "api", label: "Receipt parsing", category: "api", usd: 60, method: "About 600 receipts at about $0.10 each on the extraction model" },
      { key: "tools", label: "Lookup hosting", category: "hosting", monthly: 20, method: "A small database and API at list price" },
      ...standard(),
    ],
    plan: {
      proofMonths: 4,
      variable: { usd: 3, per: "brokerage a month", method: "Lookups and a share of new receipts verified" },
      leads: { n: 8, growthPct: 10, what: "brokers reached through Dockside and freight members", how: "Dockside's broker list and member intros, counted weekly" },
      churn: { pct: 4, how: "Cancellations each month" },
    },
    contractors: [],
    requestPlan: [
      { key: "pricing", title: "How do brokers price lumper fees today?", type: "judgment", stakes: "low", audience: "any-holder" },
      { key: "receipts", title: "Which warehouses' lumper fees vary most?", type: "knowledge", stakes: "medium", audience: "domain-expert" },
    ],
    milestones: [
      { key: "receipts", label: "Verified receipts", metric: "receipts", target: 300, dueDays: 60 },
      { key: "first-paid", label: "First paid month", metric: "paying brokerages", target: 1, dueDays: 75 },
    ],
    kill: [{ key: "receipts", condition: "fewer than 300 verified receipts", by: "2027-02-28", killReason: "execution" }],
    premortem: [
      { way: "Too few receipts to cover the warehouses brokers quote.", killReason: "execution" },
      { way: "Brokers trade fees for free.", killReason: "price" },
      { way: "Receipts can't be verified cheaply.", killReason: "flawed business model" },
    ],
    primaryMetric: { name: "Verified receipts", unit: "receipts", target: 300, by: "receipts" },
    motions: ["Partner or channel"],
    needsIntegration: true,
    hints: {
      "icp-operator": { label: "Brokers or carriers who pay lumper fees", qualifications: ["Pays or prices lumper fees"], clusters: ["freight-ops"] },
      introducer: { label: "Introducers to broker owners", qualifications: ["Can introduce brokerage owners"], keywords: ["executive", "owner"] },
      "domain-expert": { label: "Warehouse or freight-pricing experts", qualifications: ["Knows warehouse fees or freight pricing"], clusters: ["freight-ops", "finance-ops"], keywords: ["warehouse", "pricing"] },
      builder: { label: "Receipt-pipeline builder", qualifications: ["Has built document parsing pipelines"], clusters: ["data-eng"] },
      channel: { label: "Dockside or a load board", qualifications: ["Works at a load board or a venture with broker customers"], clusters: ["freight-ops", "saas-gtm"] },
    },
  });

/** Hand-written drafts for the seeded ventures, by slug. */
export const DECK_DRAFTS: Record<string, () => DeckDraft> = {
  dockside,
  chairside,
  "permit-pulse": permitPulse,
  "lien-clock": lienClock,
  "wet-ink": wetInk,
  "bid-desk": bidDesk,
  "site-record": siteRecord,
  "lumper-line": lumperLine,
};

/**
 * A library idea without a written deck: its memo becomes assumptions, each with a test.
 * The market is "not sized yet", and the first request asks members to size it. Never invents a number.
 */
export function memoDraft(idea: IdeaTemplate): DeckDraft {
  const m = idea.memo;
  const kill = idea.killRules.flatMap((r) => {
    const hit = r.match(/^(.*) by (\d{4}-\d{2}-\d{2})$/);
    return hit ? [{ key: `kill-${hit[2]}`, condition: hit[1].replace(/^./, (c) => c.toLowerCase()), by: hit[2], killReason: "no demand" as const }] : [];
  });
  const price = Number(m.unitEconomics.match(/\$(\d+)/)?.[1] ?? 0);
  const cadence: PitchDeck["pricing"]["cadence"] = /\/month|a month/.test(m.unitEconomics) ? "month" : "per-use";
  const level2 = idea.classification.workDelivery === "Agent plus contractors";
  const contractors: ContractorLine[] = level2 ? [{ job: "Paid job", rateUsd: Math.round(price * 0.6), per: "job", count: 10, paidFrom: "job fee", claimId: "c-who-works" }] : [];
  return compose({
    purpose: idea.tagline,
    slides: [
      slide(
        "problem",
        m.problem,
        asm("c-status-quo", m.competition, "Judgment request to holders on what buyers do today"),
        asm("c-named-buyer", `${m.customer} The person who signs is the owner or operations lead.`, "Intro requests to buyers"),
        asm("c-job-story", `When this comes up, I want it handled for me, so I can get back to running the business. (${idea.segment})`, "Design-partner calls"),
      ),
      slide("demand", "Nothing committed yet.", asm("c-demand", "Nobody has paid, given time or set up a workflow yet.", "The first paid month")),
      slide(
        "solution",
        idea.pitch.split(". ")[0] + ".",
        asm("c-wedge", "The smallest paid thing is one customer's first month.", "The first paid month"),
        asm("c-cannot-do", "The agent doesn't sign, decide for the customer, or act in person; a person at the customer does.", "Design-partner calls"),
      ),
      slide("customer", idea.segment, asm("c-icp", m.customer, "Who answers the first intros")),
      slide("market", "Not sized yet.", asm("c-market-unsized", m.marketSize, "Knowledge request: how many of these buyers are there, and where?")),
      slide("whyNow", m.whyNow, asm("c-prior-attempts", m.competition, "Knowledge request to members in the trade"), asm("c-what-changed", m.whyNow, "Knowledge request to members in the trade")),
      slide("alternatives", "What buyers do instead.", asm("c-alt-incumbent", m.competition, "Buyers confirm what they use"), asm("c-alt-nothing", "Doing nothing and living with it.", "Design-partner calls")),
      slide("model", "Price.", asm("c-price", m.unitEconomics, "The first paid month", price ? val(price, cadence === "month" ? "usd/month" : "usd/job") : undefined)),
      slide("howItRuns", level2 ? "Agent plus contractors, paid in cash per job." : "Agent only.", asm("c-who-works", level2 ? "People who do the in-person work are paid per job out of the fee." : "The agent does the work; no contractors are paid.", "The first paid jobs")),
      slide("milestones", "First paid month."),
      slide("budget", "Use of seat money"),
      slide(
        "risks",
        "The top three ways this dies.",
        asm("c-risk-demand", m.killMetric, "The kill rule"),
        asm("c-risk-reach", "Buyers can't be reached without intros the members don't have.", "Intro request results"),
      ),
    ],
    alternatives: [
      { name: "What they use today", kind: "incumbent", claimId: "c-alt-incumbent" },
      { name: "Do nothing", kind: "do-nothing", claimId: "c-alt-nothing" },
    ],
    pricing: { price, unit: "customer", cadence },
    lines: [
      COMPUTE(20),
      { key: "tools", label: "Tools and subscriptions", category: "tools", monthly: 50, method: "The library's standard tool plans for this kind of venture at list price; replaced once the agent prices it" },
      ...standard(),
    ],
    plan: {
      proofMonths: 4,
      uses: cadence === "per-use" ? { n: 1, how: "Uses per customer a month, from the first paid month" } : undefined,
      variable: { usd: level2 ? Math.round(price * 0.6) + 2 : 3, per: cadence === "per-use" ? "use" : "customer a month", method: level2 ? "The contractor's share of the fee plus about $2 of compute" : "Model calls and storage for one customer, a library default" },
      leads: { n: 8, growthPct: 10, what: "intros to buyers", how: FUNNEL_HOW },
      churn: { pct: 5, how: "Cancellations each month; a library default until there are customers" },
    },
    contractors,
    requestPlan: [
      { key: "size", title: "How many of these buyers are there, and where?", type: "knowledge", stakes: "low", audience: "domain-expert" },
      { key: "today", title: "What do buyers do about this today?", type: "judgment", stakes: "medium", audience: "any-holder" },
    ],
    milestones: [{ key: "first-paid", label: "First paid month", metric: "paying customers", target: 1, dueDays: 60 }],
    kill,
    premortem: [
      { way: "Nobody pays.", killReason: "no demand" },
      { way: "Buyers can't be reached.", killReason: "could not reach buyer" },
      { way: "It costs more to serve than it charges.", killReason: "flawed business model" },
    ],
    primaryMetric: { name: "Paying customers", unit: "customers", target: 1, by: "first-paid" },
    motions: [idea.classification.goToMarket],
    needsIntegration: false,
    hints: {},
  });
}

/** The draft for a venture: its written deck if there is one, otherwise the library memo's. */
export function deckDraftFor(slug: string, idea?: IdeaTemplate): DeckDraft | undefined {
  const written = DECK_DRAFTS[slug];
  const draft = written ? written() : idea ? memoDraft(idea) : undefined;
  return draft && { ...draft, proof: draft.proof ?? idea?.proof };
}
