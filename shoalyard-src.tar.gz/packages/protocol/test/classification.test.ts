import assert from "node:assert/strict";
import { test } from "node:test";
import { CLASSIFICATION_AXES, Classification, customerModel } from "@av/schema";
import { IDEA_LIBRARY } from "../src/ideas";
import { appliesToLine, learningStats, lessonsFor, templateLessons } from "../src/learning";
import { vestedByHandle } from "../src/economics";
import { closeGovernance, protocolVenture, respond, rfeById, ventureBySlug } from "../src/ops";
import { buildSeed } from "../src/seed";
import { classificationOf, confirmTag, vocabFor } from "../src/tags";

test("every library idea and seeded venture is classified on every axis", () => {
  for (const idea of IDEA_LIBRARY) {
    for (const axis of CLASSIFICATION_AXES) assert.ok(idea.classification[axis], `${idea.slug} lacks ${axis}`);
  }
  const s = buildSeed();
  for (const v of s.ventures.filter((x) => !x.isProtocol)) {
    const c = classificationOf(v);
    for (const axis of CLASSIFICATION_AXES) assert.ok(c[axis], `${v.slug} lacks ${axis}`);
    assert.ok(v.memo, `${v.slug} has a memo`);
  }
});

test("B2B, B2C and B2B2C derive from the customer", () => {
  assert.equal(customerModel({ customer: "Consumer", endMarket: "Healthcare" }), "B2C");
  assert.equal(customerModel({ customer: "Small business", endMarket: "Healthcare" }), "B2B");
  assert.equal(customerModel({ customer: "Government", endMarket: "Public sector" }), "B2B");
  assert.equal(customerModel({ customer: "Mid-market", endMarket: "Commerce and retail" }), "B2B2C");
  assert.equal(customerModel({}), undefined);
});

test("outcomes and lessons are cut by business model, customer and end market", () => {
  const s = buildSeed();
  const cuts = learningStats(s).cuts;
  const dock = cuts.find((c) => c.label === "Subscription software · Small business · Industrials and logistics")!;
  assert.deepEqual([dock.funded, dock.tried], [1, 1]);
  const drafts = templateLessons(s, learningStats(s));
  const lesson = drafts.find((d) => d.key === `cut:${dock.key}`)!;
  assert.equal(lesson.headline, "Subscription software · Small business · Industrials and logistics: 1 of 1 reached its minimum.");
  assert.equal(lesson.topic, "which-ideas");
  assert.equal(appliesToLine(lesson), "Industrials and logistics · Small business · Subscription software · Choosing ideas");
  assert.deepEqual(
    lesson.tags.map((t) => t.axis),
    ["businessModel", "customer", "endMarket"],
  );
});

test("lessons scoped to a classification apply only to matching ventures", () => {
  const s = buildSeed();
  const lien = ventureBySlug(s, "lien-clock")!;
  assert.ok(lessonsFor(s, lien).some((l) => l.id === "L-005"), "small-business lesson reaches a small-business venture");
  const enterprise = { ...lien, tags: lien.tags.map((t) => (t.axis === "customer" ? { ...t, value: "Enterprise" } : t)) };
  assert.ok(!lessonsFor(s, enterprise).some((l) => l.id === "L-005"), "but not an enterprise one");
  assert.ok(!lessonsFor(s, lien).some((l) => l.id === "L-002"), "the healthcare marketplace lesson stays with healthcare marketplaces");
});

test("a classification value joins only by a Protocol vote", () => {
  const s = buildSeed();
  const rfe = rfeById(s, "rfe-v0-class-agriculture")!;
  assert.equal(rfe.governance?.matter, "add-classification-value");
  assert.ok(!vocabFor(s).endMarket.includes("Agriculture and food"));
  const pp = ventureBySlug(s, "permit-pulse")!;
  const tryIt = () => confirmTag(s, { kind: "venture", id: pp.id, axis: "endMarket", value: "Real estate and construction", newValue: "Agriculture and food", by: "mp" });
  assert.throws(tryIt, /Protocol request/);

  const voted = new Set(s.responses.filter((r) => r.rfeId === rfe.id).map((r) => r.handle));
  for (const h of Object.keys(vestedByHandle(s, protocolVenture(s).id)).filter((x) => !voted.has(x))) {
    respond(s, { rfeId: rfe.id, handle: h, via: "structured", choice: "Add it" });
  }
  closeGovernance(s, rfe);
  assert.match(rfe.resolution ?? "", /^Passed/, rfe.resolution);
  assert.ok(vocabFor(s).endMarket.includes("Agriculture and food"));
  assert.equal(s.tagLog.at(-1)!.by, rfe.id);
  tryIt();
  assert.equal(classificationOf(ventureBySlug(s, "permit-pulse")!).endMarket, "Agriculture and food");
});

test("every lesson is a plain-language card", () => {
  const s = buildSeed();
  const jargon = [/\bliftoff\b/i, /\bcleared\b/i, /\bkill signal\b/i, /\bphenotypes?\b/i, /\bcluster\b/i, /\bbin\b/i, /\b0\.\d+\b/, /\bcould batch\b/i];
  const drafts = templateLessons(s, learningStats(s));
  for (const l of [...s.lessons, ...drafts]) {
    for (const field of [l.headline, l.whatHappened, l.whatWeDoDifferently, l.howSure.reason]) {
      assert.ok(field.length > 5, `${l.topic} has every field`);
      for (const re of jargon) assert.ok(!re.test(field), `${field} avoids ${re}`);
    }
    assert.ok(/[.!?]$/.test(l.headline), `headline is a sentence: ${l.headline}`);
    assert.ok(["Strong", "Moderate", "Early signal"].includes(l.howSure.level));
  }
  const l002 = s.lessons.find((l) => l.id === "L-002")!;
  assert.equal(l002.howSure.level, "Moderate");
  assert.equal(appliesToLine(l002), "Healthcare · Small business · Marketplace · Before the first customer");
});

test("ideas accept classification values added by vote", () => {
  const parsed = Classification.parse({ ...IDEA_LIBRARY[0].classification, endMarket: "Agriculture and food" });
  assert.equal(parsed.endMarket, "Agriculture and food");
});
