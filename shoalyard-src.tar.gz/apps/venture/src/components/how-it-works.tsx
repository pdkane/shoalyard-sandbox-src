import Link from "next/link";
import { CONTRIBUTE_PATH_LINE, JOIN_REASON, LEGACY_SEAT_NOTE, SEED_PATH_LINE } from "@av/protocol";
import type { ParamValues } from "@av/schema";
import { TermServer } from "@/lib/terms";

export function HowItWorks({ params: _params }: { params: ParamValues }) {
  const steps = [
    {
      title: "An agent proposes a small business.",
      body: (
        <>
          Each <TermServer id="venture">venture</TermServer> is an attempt: a plan, a proof budget, and the people it needs. New ones ship in{" "}
          <TermServer id="batch">batches</TermServer>.
        </>
      ),
    },
    {
      title: "Capital starts the attempt — or it ends.",
      body: <>{SEED_PATH_LINE}</>,
    },
    {
      title: "People steer and teach for cash.",
      body: (
        <>
          {CONTRIBUTE_PATH_LINE} Verification is a short chat plus a LinkedIn or X link the <TermServer id="steward">steward</TermServer>{" "}
          checks.
        </>
      ),
    },
    {
      title: "The yard keeps the record. A person can stop it.",
      body: (
        <>
          Every decision is on the public <TermServer id="ledger">ledger</TermServer>. The steward can shut it down. Hand-off and wind-down
          are meant to be as clear as the start.
        </>
      ),
    },
  ];
  return (
    <div className="space-y-4">
      <ol className="grid gap-3 sm:grid-cols-2">
        {steps.map((s, i) => (
          <li key={s.title} className="rounded-xl border border-line bg-white p-4">
            <p className="flex items-center gap-2 font-medium text-ink">
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-ink text-xs font-semibold text-white">
                {i + 1}
              </span>
              {s.title}
            </p>
            <p className="mt-2 text-sm text-pretty text-metal">{s.body}</p>
          </li>
        ))}
      </ol>
      <p className="max-w-3xl text-sm text-pretty text-metal">{JOIN_REASON}</p>
      <p className="max-w-3xl text-xs text-pretty text-metal">
        {LEGACY_SEAT_NOTE}{" "}
        <Link href="/invest" className="font-medium text-seaglass hover:text-seaglass-deep">
          Capital path
        </Link>
        {" · "}
        <Link href="/contribute" className="font-medium text-seaglass hover:text-seaglass-deep">
          Contribute
        </Link>
      </p>
    </div>
  );
}
