import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Download, ShieldCheck } from "lucide-react";
import { buildReport, matterLabel, ventureAttribution } from "@av/protocol";
import { OBJECTIVE_LABELS, RFE_TYPE_LABELS } from "@av/schema";
import { StatusBadge } from "@/components/badges";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData } from "@/lib/data";
import { resolveVenture } from "@/lib/venture";
import { formatDate, formatNumber, formatPct, formatUsd } from "@/lib/format";

const capitalize = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

export const metadata: Metadata = { title: "Quarterly report" };

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-zinc-200 bg-white p-4">
      <p className="text-xs text-zinc-500">{label}</p>
      <p className="mt-1 text-xl font-semibold tabular-nums">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-zinc-500">{hint}</p>}
    </div>
  );
}

export default async function ReportPage(props: PageProps<"/v/[slug]/report">) {
  const { slug } = await props.params;
  const { store, params } = await getData();
  const venture = resolveVenture(store, slug, "/report");
  const r = buildReport(store, venture, params);
  const f = r.financials;
  const attr = ventureAttribution(store, venture, params);

  return (
    <div className="space-y-8" style={{ "--accent-color": venture.accent } as React.CSSProperties}>
      <div className="space-y-3">
        <Link href={`/v/${venture.slug}`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> {venture.name}
        </Link>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">
              {venture.name} · {r.quarter}
            </h1>
            <p className="text-sm text-zinc-500">
              {[...attr.lines, `generated ${formatDate(r.generatedAt)}`, `settings v${r.venture.protocolVersion}`]
                .filter(Boolean)
                .join(" · ")}
            </p>
          </div>
          <a href={`/v/${venture.slug}/report.json`} className={buttonVariants({ variant: "outline" })} download>
            <Download /> Download JSON
          </a>
        </div>
        <p className="text-sm text-zinc-600">Every number on this page is calculated from the public record. The venture can&apos;t edit it.</p>
        <p className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-emerald-50/60 p-3 text-sm text-emerald-900">
          <ShieldCheck className="mt-0.5 size-4 shrink-0" /> {r.attestation.statement}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Revenue" value={formatUsd(f.revenueUsd)} />
        <Stat label="Costs" value={formatUsd(f.costsUsd)} hint={`plus ${formatUsd(f.passThroughUsd)} fixed costs (payment fees, bookkeeping)`} />
        <Stat label="Profit" value={formatUsd(f.profitUsd)} />
        <Stat label="Paid out" value={formatUsd(f.distributedUsd)} />
        <Stat label="Runway" value={formatUsd(r.runwayUsd)} />
        <Stat label="Customers" value={String(r.customers.count)} hint={r.customers.segment} />
        <Stat label="Unit holders" value={String(r.capTable.holderCount)} hint={`${formatNumber(r.capTable.grantedUnits)} units earned`} />
        <Stat label="Largest single holder" value={formatPct(r.capTable.topHolderPctOfPool)} hint="of the units for contributors" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Requests answered</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Posted</TableHead>
                  <TableHead className="text-right">Answered</TableHead>
                  <TableHead className="text-right">Median answers</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {r.rfeFillRates
                  .filter((x) => x.posted > 0)
                  .map((x) => (
                    <TableRow key={x.type}>
                      <TableCell>{RFE_TYPE_LABELS[x.type].label}</TableCell>
                      <TableCell className="text-right tabular-nums">{x.posted}</TableCell>
                      <TableCell className="text-right tabular-nums">{x.resolved}</TableCell>
                      <TableCell className="text-right tabular-nums">{x.medianResponses}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Decisions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div className="grid grid-cols-4 gap-2 text-center">
              {(
                [
                  ["auto", "Agent decided"],
                  ["advisory", "Asked members"],
                  ["gated", "Needed sign-off"],
                  ["embargoed", "Published later"],
                ] as const
              ).map(([k, label]) => (
                <div key={k} className="rounded-lg bg-zinc-50 p-2">
                  <p className="text-lg font-semibold tabular-nums">{r.decisions[k]}</p>
                  <p className="text-xs text-zinc-500">{label}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={venture.status} />
              <span className="text-zinc-600">Goal: {OBJECTIVE_LABELS[r.objective.objective].label}</span>
            </div>
            <div>
              <p className="mb-1 font-medium">Unit-holder votes</p>
              {r.reservedMatterChanges.length === 0 ? (
                <p className="text-zinc-500">None this period.</p>
              ) : (
                <ul className="space-y-1 text-zinc-600">
                  {r.reservedMatterChanges.map((c) => (
                    <li key={c.at + c.matter}>
                      {formatDate(c.at)}: {capitalize(matterLabel(c.matter))}. {c.result}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <p className="text-zinc-500">
              Protocol {formatPct(r.capTable.protocolPct, 0)} · contributors {formatPct(r.capTable.contributorPct, 0)} ·{" "}
              {formatNumber(r.capTable.treasuryUnits)} units not yet earned by anyone
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quarter history</CardTitle>
        </CardHeader>
        <CardContent>
          {venture.quarters.length === 0 ? (
            <p className="text-sm text-zinc-500">No quarters reported yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Quarter</TableHead>
                  <TableHead className="text-right">Revenue</TableHead>
                  <TableHead className="text-right">Costs</TableHead>
                  <TableHead className="text-right">Fixed costs</TableHead>
                  <TableHead className="text-right">Runway</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {venture.quarters.map((q) => (
                  <TableRow key={q.quarter}>
                    <TableCell>{q.quarter}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatUsd(q.revenueUsd)}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatUsd(q.costsUsd)}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatUsd(q.passThroughUsd)}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatUsd(q.runwayUsd)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
