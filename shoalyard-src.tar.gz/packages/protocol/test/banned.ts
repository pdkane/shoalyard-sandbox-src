/** A protocol, not a fund: these words stay out of copy and seeded text. */
export const BANNED: RegExp[] = [
  /\bfunds?\b/i,
  /\bcarry\b/i,
  /\binvestors?\b/i,
  /\bportfolios?\b/i,
  /\binvestment committee\b/i,
  /\bSPVs?\b/i,
  /\bLPA?s?\b/,
  /\bGPs?\b/,
  /\binvestments?\b/i,
  /\bfundrais/i,
];

/** Cohorts are shown as batches. Only the redirect from the old `/drops` routes may say "drop". */
export const OLD_NAME = /\bdrops?\b/i;
