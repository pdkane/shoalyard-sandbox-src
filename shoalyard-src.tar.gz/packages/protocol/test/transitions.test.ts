import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import {
  canTransition,
  GRANT_TRANSITIONS,
  defaultParams,
  PARAMS,
  RFE_TRANSITIONS,
  Store,
  VENTURE_TRANSITIONS,
} from "@av/schema";
import { tick } from "../agent/index";
import { renderConstitution } from "../src/constitution";
import {
  buySeat,
  closeGovernance,
  completeOnboarding,
  decideVerification,
  linkAccount,
  memberByHandle,
  inboxFor,
  killVenture,
  respond,
  rfeById,
  stewardDecide,
  transitionVenture,
  ventureBySlug,
} from "../src/ops";
import { resolveParams } from "../src/params";
import { buildSeed } from "../src/seed";

test("state machines allow the main path and forbid skipping", () => {
  assert.ok(canTransition(VENTURE_TRANSITIONS, "pitched", "funded"));
  assert.ok(!canTransition(VENTURE_TRANSITIONS, "pitched", "operating"));
  assert.ok(!canTransition(VENTURE_TRANSITIONS, "killed", "operating"));
  assert.ok(canTransition(RFE_TRANSITIONS, "quorum", "posted"), "an extension reopens a request");
  assert.ok(canTransition(GRANT_TRANSITIONS, "accepted", "forfeited"));
  assert.ok(!canTransition(GRANT_TRANSITIONS, "forfeited", "vested"));
});

test("illegal venture transitions throw", () => {
  const store = buildSeed();
  const pp = ventureBySlug(store, "permit-pulse")!;
  assert.throws(() => transitionVenture(store, pp, "distributing"));
});

test("the seed validates against the Store schema and has the promised shape", () => {
  const store = buildSeed();
  Store.parse(store);
  assert.equal(store.ventures.length, 9);
  assert.ok(store.members.length >= 25);
  const v0 = ventureBySlug(store, "protocol")!;
  const questions = store.rfes.filter(
    (r) => r.ventureId === v0.id && r.kind === "request" && !r.gtm && r.id.startsWith("rfe-v0-") &&
      !["rfe-v0-steward", "rfe-v0-articles-review", "rfe-v0-params-check"].includes(r.id),
  );
  assert.equal(questions.length, 34);
  assert.equal(questions.filter((r) => r.status === "resolved").length, 2, "the founding role, and proof budgets once seats were priced per venture");
  assert.equal(rfeById(store, "rfe-v0-role")!.resolution, "founding steward and largest contributor");
  const firstV0 = store.decisions.filter((d) => d.ventureId === v0.id).sort((a, b) => a.at.localeCompare(b.at))[0];
  assert.equal(firstV0.id, "dec-v0-role");
  assert.equal(ventureBySlug(store, "chairside")!.status, "killed");
  assert.equal(ventureBySlug(store, "permit-pulse")!.status, "pitched");
  assert.equal(ventureBySlug(store, "dockside")!.status, "distributing");
  assert.ok(store.decisions.some((d) => d.embargo && d.embargo.until > store.meta.clock));
  assert.equal(store.distributions.length, 1);
});

test("definition of done: seat → onboarding → answer → grant → agent decides → the Protocol asks", async () => {
  const store = buildSeed();
  buySeat(store, { slug: "dockside", handle: "new_reader" });
  const steward = ventureBySlug(store, "protocol")!.stewardHandle;
  const link = linkAccount(store, "new_reader", "linkedin", "https://www.linkedin.com/in/new-reader");
  assert.equal(memberByHandle(store, "new_reader")!.qualification, "pending");
  assert.throws(() => respond(store, { rfeId: "rfe-dockside-3pl-intro", handle: "new_reader", via: "text", text: "Too early." }));
  decideVerification(store, { by: steward, handle: "new_reader", verificationId: link.id, approve: true });
  const { firstRfe, qualified } = completeOnboarding(store, "new_reader", {
    role: "Dispatcher",
    industry: "Freight brokerage",
    seniority: "mid",
    companies: [],
    buyingAuthority: "None",
    tools: [],
    verticals: ["freight"],
    canReach: [],
    cluster: "brand-new-cluster",
  });
  assert.equal(store.grants.filter((g) => g.handle === "new_reader").length, 0, "qualifying earns no units by itself");
  assert.ok(qualified, "a confirmed LinkedIn link qualifies the member");
  assert.ok(firstRfe, "an RFE is waiting");
  const inbox = inboxFor(store, "new_reader");
  assert.ok(inbox.some((r) => r.ventureId === "protocol"), "The Protocol asks the same member");
  const access = rfeById(store, "rfe-dockside-3pl-intro")!;
  const res = respond(store, { rfeId: access.id, handle: "new_reader", via: "text", text: "Introduced you to our claims lead." });
  assert.ok(res.resolved);
  const g = store.grants.find((x) => x.handle === "new_reader" && x.rfeId === access.id);
  assert.ok(g && g.units === 1, "each accepted answer earns one equal share");
  assert.ok(store.ledger.some((l) => l.kind === "grant" && l.handle === "new_reader"));
  const before = store.decisions.length;
  await tick(store, { venture: "dockside", mode: "script" });
  assert.ok(store.decisions.length > before, "the agent logged a new decision");
});

test("buying the last seat funds a pitching venture", () => {
  const store = buildSeed();
  const pp = ventureBySlug(store, "permit-pulse")!;
  for (let i = 0; i < 13; i++) buySeat(store, { slug: "permit-pulse", handle: `buyer_${i}` });
  assert.equal(pp.status, "funded");
  assert.equal(rfeById(store, "rfe-permit-pulse-raise")!.status, "resolved");
});

test("steward approval applies a gated decision; only the steward can sign", () => {
  const store = buildSeed();
  assert.throws(() => stewardDecide(store, "dec-dockside-price-249", true, "", "someone_else"));
  stewardDecide(store, "dec-dockside-price-249", true, "ok", PARAMS.FOUNDING_STEWARD_HANDLE.value);
  assert.equal(store.decisions.find((d) => d.id === "dec-dockside-price-249")!.status, "taken");
});

test("kill switch closes open requests and writes a post-mortem", () => {
  const store = buildSeed();
  killVenture(store, "permit-pulse", PARAMS.FOUNDING_STEWARD_HANDLE.value, "Testing the switch");
  const pp = ventureBySlug(store, "permit-pulse")!;
  assert.equal(pp.status, "killed");
  assert.ok(pp.postMortem);
  assert.ok(store.rfes.filter((r) => r.ventureId === pp.id).every((r) => r.status === "resolved"));
});

test("a passed governance vote amends the parameter", () => {
  const store = buildSeed();
  const rfe = rfeById(store, "rfe-v0-amend-embargo")!;
  assert.equal(resolveParams(store).DEFAULT_EMBARGO_DAYS, 60);
  closeGovernance(store, rfe);
  assert.match(rfe.resolution!, /^Passed/);
  assert.equal(resolveParams(store).DEFAULT_EMBARGO_DAYS, 30);
  assert.equal(store.amendments.length, 1);
  assert.equal(store.meta.protocolVersion, "1.1");
});

test("CONSTITUTION.md matches the articles in code", () => {
  const md = readFileSync(join(import.meta.dirname, "..", "CONSTITUTION.md"), "utf8");
  assert.equal(md, renderConstitution(defaultParams()));
});

test("ticks are deterministic in script mode", async () => {
  const a = buildSeed();
  const b = buildSeed();
  const la = await tick(a, { mode: "script" });
  const lb = await tick(b, { mode: "script" });
  assert.deepEqual(la.map((l) => l.text), lb.map((l) => l.text));
});
