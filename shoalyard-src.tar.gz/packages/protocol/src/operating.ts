import type { Experiment, MemberUpdate, ParamValues, StewardReview, Store, Venture } from "@av/schema";
import { allClaims, latestDeck, settleClaim } from "./deck";
import { isOpen, logDecision, ProtocolError, responsesFor, type RfeDraft } from "./ops";
import { resolveParams } from "./params";
import { onRoutedResolved } from "./qa";
import { addDays, newId, round } from "./util";

const OPERATING = new Set(["formed", "operating", "distributing"]);
const DAY = 86_400_000;
const daysBetween = (a: string, b: string) => (Date.parse(b) - Date.parse(a)) / DAY;

function formedAt(venture: Venture): string | undefined {
  return venture.statusHistory.find((h) => h.status === "formed")?.at;
}

export function updatesFor(store: Store, ventureId: string): MemberUpdate[] {
  return store.updates.filter((u) => u.ventureId === ventureId).sort((a, b) => a.at.localeCompare(b.at));
}

export function reviewsFor(store: Store, ventureId: string): StewardReview[] {
  return store.reviews.filter((r) => r.ventureId === ventureId).sort((a, b) => a.at.localeCompare(b.at));
}

/* ---------- the one number ---------- */

/** The deck's primary metric, read from the record: revenue for a dollar metric, paying customers otherwise. */
export function primaryMetricNow(store: Store, venture: Venture): { name: string; unit: string; value: number } {
  const deck = latestDeck(store, venture.id);
  const name = deck?.primaryMetric.name ?? "Paying customers";
  const unit = deck?.primaryMetric.unit ?? "customers";
  const value = /usd|\$|revenue/i.test(unit) ? (venture.quarters.at(-1)?.revenueUsd ?? 0) : venture.customers.count;
  return { name, unit, value };
}

/* ---------- default alive ---------- */

/**
 * Graham's question: with costs flat and revenue growing as it has, does the venture reach
 * break-even before the cash runs out? Before there's revenue to grow, it's too early to say.
 */
export function defaultAlive(venture: Venture): MemberUpdate["defaultAlive"] {
  const q = venture.quarters;
  const last = q.at(-1);
  if (!last || !OPERATING.has(venture.status) || last.revenueUsd <= 0) {
    return { status: "too early", detail: "No revenue yet, so there's no growth rate to project." };
  }
  if (last.revenueUsd >= last.costsUsd) return { status: "alive", detail: `Revenue ($${last.revenueUsd}) covered costs ($${last.costsUsd}) last quarter.` };
  const prev = q.at(-2);
  const growth = prev && prev.revenueUsd > 0 ? last.revenueUsd / prev.revenueUsd - 1 : 0;
  if (growth <= 0) return { status: "dead", detail: `Costs ($${last.costsUsd}) exceed revenue ($${last.revenueUsd}) and revenue isn't growing.` };
  let cash = last.runwayUsd;
  let rev = last.revenueUsd;
  for (let i = 1; i <= 12; i++) {
    rev *= 1 + growth;
    if (rev >= last.costsUsd) return { status: "alive", detail: `At ${Math.round(growth * 100)}% a quarter, revenue covers costs in ${i} ${i === 1 ? "quarter" : "quarters"} with cash to spare.` };
    cash -= last.costsUsd - rev;
    if (cash < 0) return { status: "dead", detail: `At ${Math.round(growth * 100)}% a quarter, cash runs out in ${i} ${i === 1 ? "quarter" : "quarters"}, before revenue covers costs.` };
  }
  return { status: "dead", detail: "Revenue growth doesn't reach break-even within three years." };
}

/* ---------- the weekly update ---------- */

export function updateDue(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): boolean {
  if (!OPERATING.has(venture.status) || !latestDeck(store, venture.id)) return false;
  const last = updatesFor(store, venture.id).at(-1)?.at ?? formedAt(venture);
  return !!last && daysBetween(last, store.meta.clock) >= params.UPDATE_CADENCE_DAYS;
}

export interface UpdateInput {
  highlights: string[];
  lowlights: string[];
  asks: RfeDraft[];
  metricNote?: string;
  model?: string;
}

/**
 * One number, an honest default-alive check, at least one lowlight, and at most a few asks,
 * each posted as a request in the same pass. Credits name the members whose work counted.
 */
export function publishUpdate(store: Store, venture: Venture, input: UpdateInput): MemberUpdate {
  const params = resolveParams(store);
  if (!input.lowlights.filter((l) => l.trim()).length) throw new ProtocolError("An update needs at least one lowlight.");
  if (input.asks.length > params.UPDATE_MAX_ASKS) throw new ProtocolError(`An update has at most ${params.UPDATE_MAX_ASKS} asks.`);
  const prior = updatesFor(store, venture.id).at(-1);
  const since = prior?.at ?? formedAt(venture) ?? venture.createdAt;
  const m = primaryMetricNow(store, venture);
  const previous = prior?.metric.value;
  const changePct = previous !== undefined && previous >= params.GROWTH_MIN_BASE ? round(((m.value - previous) / previous) * 100, 1) : undefined;
  const growthNote =
    previous === undefined
      ? "First update."
      : changePct === undefined
        ? `${previous} → ${m.value}. Below a base of ${params.GROWTH_MIN_BASE}, only the count is shown.`
        : `${changePct >= 0 ? "+" : ""}${changePct}% on last week; the target is ${params.GROWTH_TARGET_WEEKLY_PCT}% and the floor ${params.GROWTH_FLOOR_WEEKLY_PCT}%.`;
  const asks = input.asks.map((draft) => {
    const { rfe } = logDecision(store, {
      ventureId: venture.id,
      title: `Ask in the weekly update: ${draft.title}`,
      reasoning: `Every ask in the weekly update becomes a request members can answer. ${draft.question}`,
      summary: "An ask from the weekly update, posted as a request.",
      confidence: 0.85,
      model: input.model ?? "script",
      rfe: draft,
    });
    if (!rfe) throw new ProtocolError(`The ask “${draft.title}” couldn't be posted.`);
    return { text: draft.title, rfeId: rfe.id };
  });
  const credits = new Map<string, number>();
  for (const g of store.grants.filter((x) => x.ventureId === venture.id && x.slice === "rfe" && x.at > since && x.at <= store.meta.clock)) {
    credits.set(g.handle, round((credits.get(g.handle) ?? 0) + g.units, 2));
  }
  const decisions = store.decisions.filter((d) => d.ventureId === venture.id);
  const update: MemberUpdate = {
    id: newId(store, "upd"),
    ventureId: venture.id,
    at: store.meta.clock,
    week: Math.max(1, Math.round(daysBetween(formedAt(venture) ?? venture.createdAt, store.meta.clock) / 7)),
    metric: { name: m.name, unit: m.unit, value: m.value, previous, changePct, note: [input.metricNote, growthNote].filter(Boolean).join(" ") },
    defaultAlive: defaultAlive(venture),
    highlights: input.highlights,
    lowlights: input.lowlights,
    decisions: {
      taken: decisions.filter((d) => d.status === "taken" && (d.takenAt ?? d.at) > since).length,
      pending: decisions.filter((d) => d.status === "awaiting_steward").length,
    },
    asks,
    credits: [...credits].map(([handle, units]) => ({ handle, units })).sort((a, b) => b.units - a.units),
  };
  store.updates.push(update);
  return update;
}

/** The scripted update: highlights from the log, lowlights from what's stuck or slipping. */
export function scriptedUpdate(store: Store, venture: Venture): UpdateInput {
  const params = resolveParams(store);
  const prior = updatesFor(store, venture.id).at(-1);
  const since = prior?.at ?? formedAt(venture) ?? venture.createdAt;
  const highlights = store.decisions
    .filter((d) => d.ventureId === venture.id && d.status === "taken" && (d.takenAt ?? d.at) > since && d.model !== "rule" && !(d.embargo && d.embargo.until > store.meta.clock))
    .slice(-3)
    .map((d) => d.title);
  const lowlights: string[] = [];
  for (const r of store.rfes.filter((x) => x.ventureId === venture.id && isOpen(x) && !x.gtm && x.type !== "capital")) {
    const days = Math.floor(daysBetween(r.postedAt, store.meta.clock));
    if (days >= 7 && !responsesFor(store, r.id).length) lowlights.push(`“${r.title}” has had no answers in ${days} days.`);
  }
  const m = primaryMetricNow(store, venture);
  if (prior && m.value <= prior.metric.value) lowlights.push(`${m.name} didn't grow this week (${prior.metric.value} → ${m.value}).`);
  const alive = defaultAlive(venture);
  if (alive.status === "dead") lowlights.push(`Default dead: ${alive.detail}`);
  const deck = latestDeck(store, venture.id);
  for (const k of deck?.killCriteria ?? []) {
    const left = daysBetween(store.meta.clock, k.by);
    if (left > 0 && left <= 30 && !killRuleMet(venture, k.condition)) lowlights.push(`Kill rule due in ${Math.ceil(left)} days: ${k.condition}.`);
  }
  if (!lowlights.length) lowlights.push(`Nothing on the record slipped this week. The agent checked open requests, ${m.name.toLowerCase()} and the kill rules.`);
  return { highlights, lowlights: lowlights.slice(0, params.UPDATE_MAX_ASKS + 2), asks: [] };
}

/* ---------- the monthly steward review ---------- */

function killRuleMet(venture: Venture, condition: string): boolean {
  if (/^no paying/i.test(condition)) return venture.customers.count > 0;
  return false;
}

export function killRuleStatus(store: Store, venture: Venture): StewardReview["killRules"] {
  const deck = latestDeck(store, venture.id);
  return (deck?.killCriteria ?? []).map((k) => {
    const met = killRuleMet(venture, k.condition);
    const left = daysBetween(store.meta.clock, k.by);
    return { key: k.key, condition: k.condition, by: k.by, status: met ? "met" : left < 0 ? "fired" : left <= 30 ? "at risk" : "on track" };
  });
}

/** Consecutive weekly updates at or below the growth floor. */
export function flatWeeks(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): number {
  let n = 0;
  for (const u of [...updatesFor(store, venture.id)].reverse()) {
    if (u.metric.previous === undefined) break;
    const pct = u.metric.previous > 0 ? ((u.metric.value - u.metric.previous) / u.metric.previous) * 100 : u.metric.value > 0 ? 100 : 0;
    if (pct >= params.GROWTH_FLOOR_WEEKLY_PCT) break;
    n++;
  }
  return n;
}

export function reviewDue(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): boolean {
  if (!OPERATING.has(venture.status) || !latestDeck(store, venture.id)) return false;
  const reviews = reviewsFor(store, venture.id);
  const pending = reviews.some((r) => store.decisions.find((d) => d.id === r.decisionId)?.status === "awaiting_steward");
  if (pending) return false;
  const last = reviews.at(-1)?.at ?? formedAt(venture);
  if (!last) return false;
  return daysBetween(last, store.meta.clock) >= params.STEWARD_REVIEW_DAYS || flatWeeks(store, venture, params) >= params.FLAT_WEEKS_TO_REVIEW;
}

/** The agent recommends persevere, pivot or propose shutdown; the steward signs. */
export function runReview(store: Store, venture: Venture, model = "script"): StewardReview {
  const params = resolveParams(store);
  const updates = updatesFor(store, venture.id);
  const m = primaryMetricNow(store, venture);
  const first = updates.at(-5)?.metric.value ?? updates[0]?.metric.value;
  const trend = first === undefined ? `${m.name}: ${m.value} (no weekly updates yet)` : `${m.name}: ${first} → ${m.value} ${updates.length === 1 ? "in the first update" : `over the last ${Math.min(updates.length, 5)} updates`}`;
  const rules = killRuleStatus(store, venture);
  const alive = defaultAlive(venture);
  const flat = flatWeeks(store, venture, params);
  const prior = reviewsFor(store, venture.id);
  const flatPersevered = prior.slice(-(params.FLAT_REVIEWS_TO_KILL_PROPOSAL - 1)).filter((r) => r.call === "persevere" && /flat/.test(r.reason)).length;
  const fired = rules.filter((r) => r.status === "fired");
  let call: StewardReview["call"] = "persevere";
  let reason = `${trend}; default ${alive.status}. No kill rule has fired.`;
  if (fired.length) {
    call = "propose shutdown";
    reason = `A kill rule fired: ${fired.map((r) => `${r.condition} by ${r.by.slice(0, 10)}`).join("; ")}. The rule was set at pitch and isn't moved quietly.`;
  } else if (flat >= params.FLAT_WEEKS_TO_REVIEW && flatPersevered >= params.FLAT_REVIEWS_TO_KILL_PROPOSAL - 1 && params.FLAT_REVIEWS_TO_KILL_PROPOSAL > 1) {
    call = "propose shutdown";
    reason = `${flat} flat weeks, and the last review chose to persevere while flat. Two flat reviews in a row send a shutdown proposal to the steward.`;
  } else if (flat >= params.FLAT_WEEKS_TO_REVIEW) {
    call = alive.status === "dead" ? "pivot" : "persevere";
    reason = `${flat} weeks below the ${params.GROWTH_FLOOR_WEEKLY_PCT}% floor (flat); default ${alive.status}. ${call === "pivot" ? "Change the wedge or the buyer, as a deck amendment." : "Hold for one more review with a named change."}`;
  } else if (alive.status === "dead") {
    call = "pivot";
    reason = `${trend}. Default dead: ${alive.detail} Write down the change of plan before the cash runs out.`;
  }
  const experiments = store.experiments.filter((e) => e.ventureId === venture.id && e.status === "running").map((e) => e.id);
  const { decision } = logDecision(store, {
    ventureId: venture.id,
    title: `Monthly review: ${call}`,
    reasoning: `${reason} Kill rules: ${rules.map((r) => `${r.condition} (${r.status})`).join("; ") || "none"}. Open experiments: ${experiments.join(", ") || "none"}.`,
    summary: `Monthly review: the agent recommends ${call}.`,
    confidence: 0.8,
    model,
    facts: { review: call },
  });
  const review: StewardReview = {
    id: newId(store, "rev"),
    ventureId: venture.id,
    at: store.meta.clock,
    metricTrend: trend,
    defaultAlive: alive.status,
    killRules: rules,
    experiments,
    call,
    reason,
    decisionId: decision.id,
  };
  store.reviews.push(review);
  return review;
}

/* ---------- experiments, written down before any spend ---------- */

const premiseKey = (p: string) => p.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, "").replace(/\s+/g, " ").trim();

export function failedOnPremise(store: Store, ventureId: string, premise: string): Experiment[] {
  return store.experiments.filter((e) => e.ventureId === ventureId && e.status === "failed" && premiseKey(e.premise) === premiseKey(premise));
}

export type ExperimentInput = Pick<Experiment, "premise" | "hypothesis" | "metric" | "successBar" | "stopRule" | "budgetUsd"> & { days: number };

/** Two failures that share a premise are evidence about the premise: test it before a third attempt. */
export function startExperiment(store: Store, venture: Venture, input: ExperimentInput, model = "script"): Experiment {
  const params = resolveParams(store);
  for (const k of ["premise", "hypothesis", "metric", "successBar", "stopRule"] as const) {
    if (!input[k]?.trim()) throw new ProtocolError(`An experiment is written down before it runs; it needs a ${k.replace(/[A-Z]/g, (c) => ` ${c.toLowerCase()}`)}.`);
  }
  if (!(input.days > 0)) throw new ProtocolError("An experiment needs an end date.");
  const failed = failedOnPremise(store, venture.id, input.premise);
  if (failed.length >= params.PREMISE_FAILURES_BEFORE_TEST) {
    const testId = failed.map((e) => e.premiseTestRfeId).find(Boolean);
    const test = testId ? store.rfes.find((r) => r.id === testId) : undefined;
    if (!test || isOpen(test)) {
      throw new ProtocolError(`${failed.length} tests that rest on “${input.premise}” failed. Test the premise first${test ? `: ${test.title}` : ""}.`);
    }
  }
  const exp: Experiment = {
    id: newId(store, "exp"),
    ventureId: venture.id,
    at: store.meta.clock,
    premise: input.premise.trim(),
    hypothesis: input.hypothesis.trim(),
    metric: input.metric.trim(),
    successBar: input.successBar.trim(),
    stopRule: input.stopRule.trim(),
    budgetUsd: input.budgetUsd,
    endsAt: addDays(store.meta.clock, input.days),
    status: "running",
  };
  store.experiments.push(exp);
  logDecision(store, {
    ventureId: venture.id,
    title: `Write down an experiment: ${exp.hypothesis}`,
    reasoning: `Premise: ${exp.premise} Success: ${exp.successBar}. Stop: ${exp.stopRule}. Budget $${exp.budgetUsd}, ends ${exp.endsAt.slice(0, 10)}. Scored against this bar, never re-described.`,
    summary: "An experiment written down before any money is spent.",
    confidence: 0.85,
    model,
  });
  return exp;
}

/** Scored once against the bar set in advance. A second failure on the same premise posts a premise test. */
export function scoreExperiment(store: Store, input: { id: string; passed: boolean; result: string; stopped?: boolean }, model = "script"): Experiment {
  const params = resolveParams(store);
  const exp = store.experiments.find((e) => e.id === input.id);
  if (!exp) throw new ProtocolError("No such experiment.");
  if (exp.status !== "running") throw new ProtocolError(`${exp.id} was scored on ${exp.scoredAt?.slice(0, 10)}; a result is never re-described.`);
  exp.status = input.stopped ? "stopped" : input.passed ? "passed" : "failed";
  exp.result = input.result.trim();
  exp.scoredAt = store.meta.clock;
  const venture = store.ventures.find((v) => v.id === exp.ventureId)!;
  logDecision(store, {
    ventureId: venture.id,
    title: `Score the experiment: ${exp.status}`,
    reasoning: `${exp.hypothesis}. Bar: ${exp.successBar}. Result: ${exp.result}`,
    summary: `Experiment ${exp.status} against the bar set before it ran.`,
    confidence: 0.9,
    model,
  });
  if (exp.status === "failed" && failedOnPremise(store, venture.id, exp.premise).length >= params.PREMISE_FAILURES_BEFORE_TEST) {
    const { rfe } = logDecision(store, {
      ventureId: venture.id,
      title: `Test the premise before a third attempt: ${exp.premise}`,
      reasoning: `Two failed tests rest on the same premise, which is evidence about the premise. The cheapest test of it comes before any third attempt.`,
      summary: "Two tests failed on one premise; members are asked whether the premise holds.",
      confidence: 0.85,
      model,
      rfe: {
        type: "judgment",
        title: `Is this premise wrong? ${exp.premise}`,
        question: `Two tests that rested on “${exp.premise}” failed: ${failedOnPremise(store, venture.id, exp.premise).map((e) => `${e.hypothesis} (${e.result})`).join("; ")}. Does the premise hold?`,
        recommendation: "The premise is wrong; change the approach",
        stakes: "medium",
        format: "choice",
        options: ["The premise is wrong; change the approach", "The premise holds; the tests were run badly", "Not sure"],
        offerUnits: 1,
        audience: "Members who know these buyers",
      },
    });
    exp.premiseTestRfeId = rfe?.id;
  }
  return exp;
}

/* ---------- requests that resolve ---------- */

/**
 * When a request resolves: its resolution goes back on the questions routed to it, and a claim
 * the request was testing becomes evidence if members agreed with the claim's recommendation.
 */
export function applyResolvedRequests(store: Store, venture: Venture): string[] {
  const out: string[] = [];
  const resolved = store.rfes.filter((r) => r.ventureId === venture.id && r.status === "resolved" && r.resolution);
  for (const r of resolved) {
    if (store.questions.some((q) => q.answer?.routed?.rfeId === r.id && !q.answer.updates.some((u) => u.ref === r.id))) {
      onRoutedResolved(store, r.id, { text: `Members answered: ${r.resolution}` });
      out.push(`Added the answer to “${r.title}” to the questions it came from`);
    }
    const deck = latestDeck(store, venture.id);
    for (const c of deck ? allClaims(deck).filter((x) => x.test?.rfeId === r.id && x.basis !== "evidence" && !x.disproved) : []) {
      if (!r.recommendation || !r.resolution!.toLowerCase().includes(r.recommendation.toLowerCase())) continue;
      settleClaim(store, venture, { claimId: c.id, rfeId: r.id, result: "supported", label: r.title });
      out.push(`Claim ${c.id} is now evidence, from “${r.title}”`);
    }
  }
  return out;
}
