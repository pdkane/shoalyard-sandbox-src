import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Check } from "lucide-react";
import { EARNED_NOT_BOUGHT, hasSeat, isLive, latestDeck, raiseProgress, seatPriceOf, seatSummary, seatWindow, ventureAttribution } from "@av/protocol";
import { StatusBadge } from "@/components/badges";
import { REFUND_GUARANTEE, SeatDisclaimer } from "@/components/protocol-ui";
import { VentureAttribution } from "@/components/venture-attribution";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { resolveVenture } from "@/lib/venture";
import { formatDateTime, formatUsd } from "@/lib/format";
import { SeatForm } from "./seat-form";

export const metadata: Metadata = { title: "Take a seat" };

export default async function SeatPage(props: PageProps<"/v/[slug]/seat">) {
  const { slug } = await props.params;
  const sp = await props.searchParams;
  const { store, params, viewer, member } = await getData();
  const venture = resolveVenture(store, slug, "/seat");
  const raise = raiseProgress(store, venture, params);
  const refId = typeof sp.ref === "string" && store.rfes.some((r) => r.id === sp.ref && r.gtm) ? sp.ref : undefined;
  const seated = member && hasSeat(store, venture.id, viewer);
  const w = seatWindow(store, venture, params);
  const pitched = venture.status === "pitched";
  const closed = !isLive(venture) || venture.isProtocol || (pitched && w.state === "ended");
  const earlyLocked = pitched && w.state === "early" && member?.qualification !== "qualified";
  const style = { "--accent-color": venture.accent } as React.CSSProperties;
  const attr = ventureAttribution(store, venture, params);
  const verified = member?.qualification === "qualified";
  const deck = latestDeck(store, venture.id);

  return (
    <div style={style} className="mx-auto max-w-4xl space-y-6">
      <Link href={`/v/${venture.slug}`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
        <ArrowLeft className="size-4" /> {venture.name}
      </Link>
      <div className="grid gap-6 md:grid-cols-[1fr_1.1fr]">
        <div className="space-y-4">
          <div className="h-1.5 w-12 rounded-full bg-[var(--accent-color)]" />
          <h1 className="text-2xl font-semibold tracking-tight">Take a seat in {venture.name}</h1>
          <VentureAttribution mark={attr.mark} />
          <StatusBadge status={venture.status} />
          <ul className="space-y-3 pt-2 text-sm text-zinc-700">
            {[
              <>
                {formatUsd(seatPriceOf(venture, params))}, paid once. The agent will send you this venture&apos;s{" "}
                <TermServer id="request">requests</TermServer>.
              </>,
              verified ? (
                <>You&apos;re already verified, so you can answer them straight away.</>
              ) : (
                <>
                  Next, get <TermServer id="verified">verified</TermServer>: a 2-minute interview and a LinkedIn or X link the steward checks.
                  Until then you can see requests but not answer them.
                </>
              ),
              <>
                Pilot/legacy path: answering requests is how demo units are earned (up to {params.MAX_UNITS_PER_RFE} per request). The seat
                itself earns none. {EARNED_NOT_BOUGHT}
              </>,
              <>
                Units become fully yours {params.VESTING_DAYS} days after you earn them (<TermServer id="vesting">vesting</TermServer>).
              </>,
              <>
                Your {formatUsd(seatPriceOf(venture, params))} is held, unspent, until the {formatUsd(venture.minRaiseUsd)}{" "}
                <TermServer id="minimum">minimum</TermServer> is met. If it isn&apos;t, the venture ends and every seat is refunded in full.
              </>,
              <>You can also answer questions about how these rules should work.</>,
            ].map((t, i) => (
              <li key={i} className="flex gap-2">
                <Check className="mt-0.5 size-4 shrink-0 text-[var(--accent-color)]" />
                <span>{t}</span>
              </li>
            ))}
          </ul>
          <p className="text-sm text-zinc-500">
            {raise.sold} of {raise.needed} seats taken.
          </p>
          {deck && (
            <p className="rounded-lg border border-zinc-200 bg-white p-3 text-sm text-zinc-700">
              You&apos;re taking a seat under deck v{deck.version}: {seatSummary(deck.seatPlan)} (
              <Link href={`/v/${venture.slug}/deck#ask`} className="underline underline-offset-2">
                see the math
              </Link>
              ). Read{" "}
              <Link href={`/v/${venture.slug}/deck`} className="underline underline-offset-2">
                the deck
              </Link>{" "}
              and{" "}
              <Link href={`/v/${venture.slug}/qa`} className="underline underline-offset-2">
                members&apos; questions
              </Link>{" "}
              first.
            </p>
          )}
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Checkout</CardTitle>
            <CardDescription>One seat · {formatUsd(seatPriceOf(venture, params))}</CardDescription>
          </CardHeader>
          <CardContent>
            {closed ? (
              <div className="space-y-3 text-sm text-zinc-600">
                <p>
                  {venture.isProtocol
                    ? "The Protocol doesn't sell seats. Any verified member can answer its questions."
                    : `${venture.name} is not selling seats.`}
                </p>
                <Link href="/" className={buttonVariants({ variant: "outline" })}>
                  See ventures selling seats
                </Link>
              </div>
            ) : earlyLocked ? (
              <div className="space-y-3 text-sm text-zinc-600">
                <p>
                  Verified members only until {formatDateTime(w.opensAt!)} UTC
                  {member && member.qualification === "pending" ? ". Finish getting verified to get in now." : ". Everyone else can take a seat after that."}
                </p>
                {member?.qualification === "pending" && (
                  <Link href="/onboarding?step=qualify" className={buttonVariants({ variant: "outline" })}>
                    Finish getting verified
                  </Link>
                )}
              </div>
            ) : seated ? (
              <div className="space-y-3 text-sm text-zinc-600">
                <p>@{viewer} already holds a seat in {venture.name}.</p>
                <Link href="/inbox" className={buttonVariants()}>
                  Go to your requests
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                <SeatForm slug={venture.slug} price={formatUsd(seatPriceOf(venture, params))} refId={refId} />
                <SeatDisclaimer className="text-center" />
                <p className="text-center text-xs text-zinc-500">{REFUND_GUARANTEE}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
