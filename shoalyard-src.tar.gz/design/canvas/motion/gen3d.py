import math
END=0.72; STEPS=40; R=22; SC=0.75
S=[(6,44,22),(26,70,36),(16,52,50),(40,88,64)]
def smooth(a,b,t):
    if t<=a: return 0.0
    if t>=b: return 1.0
    x=(t-a)/(b-a); return x*x*(3-2*x)
def ease(t):  # chase speed: steady, then slows into place
    return 1-(1-t)**2.2
kf=[];divs=[]
for k,(x1,x2,y) in enumerate(S):
    start=-90*k-720
    fr=[]
    for i in range(STEPS+1):
        t=i/STEPS
        s=smooth(0.40,END,t)
        a=start+(0-start)*ease(min(t,END)/END)
        r=R*(1-s)
        z=math.cos(math.radians(a))
        op=0.3+0.7*(z+1)/2; op=op+(1-op)*s
        if t>0.96: op*=1-(t-0.96)/0.04
        if t<0.04: op*=t/0.04
        fr.append(f"{t*100:.1f}%{{transform:rotateY({a:.1f}deg) translateZ({r:.1f}px);opacity:{op:.3f}}}")
    kf.append(f"@keyframes syTurn{k+1}{{"+"".join(fr)+"}")
    L=(x1-4.5)*SC; T=(y-4.5)*SC; Wd=(x2-x1+9)*SC; H=9*SC
    divs.append(f'<div style="position: absolute; left: {L:.1f}px; top: {T:.1f}px; width: {Wd:.1f}px; height: {H:.1f}px; perspective: 150px"><div class="sy-t{k+1}" style="width: 100%; height: 100%; border-radius: {H/2:.1f}px; background: #2F6F6A"></div></div>')
open('kf3d.css','w').write("\n".join(kf)+"\n"+"".join(f".sy-t{k+1}{{animation:syTurn{k+1} 5s linear infinite}}" for k in range(4))+"\n")
open('divs3d.html','w').write("".join(divs))
