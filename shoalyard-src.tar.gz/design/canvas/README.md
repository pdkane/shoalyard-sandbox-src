# Shoalyard brand canvas (source)

Source files for the Shoalyard Brand design canvas, the board where the brand was worked out: wordmark, seal, color, type, motion, sample pages, don'ts, and the explorations behind each decision.

- `project/canvas.json` is the board index; each `*.dc.html` file is one artboard.
- `motion/gen3d.py` generates the stroke-chase keyframes (`kf3d.css`) used on the Motion board.

What ships to the site is in `brand/`, not here.
