import { cn } from "@/lib/utils";

/** The venture's mark line, when it has one (Article 7). */
export function VentureAttribution({ mark, className }: { mark?: string; className?: string }) {
  if (!mark) return null;
  return (
    <div className={cn("text-sm text-zinc-500", className)}>
      <p>{mark}</p>
    </div>
  );
}
