import assert from "node:assert/strict";
import { test } from "node:test";
import { closeGovernance, contractorLabel, EMPLOYMENT_BLOCKED, logDecision, payContractor, pitchAwaitingSignOff, pitchVenture, respond, stewardDecide, buySeat, ventureBySlug } from "../src/ops";
import { resolveParams } from "../src/params";
import { buildSeed } from "../src/seed";
import { addClassificationValue, TagError, workDeliveryOf } from "../src/tags";

test("the seed says who does each venture's work", () => {
  const s = buildSeed();
  const level = (slug: string) => workDeliveryOf(ventureBySlug(s, slug)!);
  for (const slug of ["chairside", "wet-ink", "bid-desk"]) assert.equal(level(slug), "Agent plus contractors", slug);
  for (const slug of ["dockside", "permit-pulse", "lien-clock", "site-record", "lumper-line"]) assert.equal(level(slug), "Agent only", slug);
  assert.equal(workDeliveryOf(ventureBySlug(s, "protocol")!), "Agent only");
  assert.ok(ventureBySlug(s, "chairside")!.tags.some((t) => t.axis === "workDelivery" && t.status === "confirmed"), "the steward confirms it like the other fields");
});

test("employment is off by default, and a vote alone can't turn it on", () => {
  const s = buildSeed();
  assert.equal(resolveParams(s).EMPLOYMENT_ALLOWED, false);
  assert.ok(s.rfes.some((r) => r.id === "rfe-v0-employment" && /employer of record/.test(r.question) && /payroll/.test(r.question) && /insurance/.test(r.question)));
  const v0 = ventureBySlug(s, "protocol")!;
  const { rfe } = logDecision(s, {
    ventureId: v0.id,
    title: "Allow ventures to employ people",
    reasoning: "Proposed by a member.",
    confidence: 0.5,
    model: "script",
    rfe: {
      type: "judgment",
      kind: "governance",
      title: "Amend EMPLOYMENT_ALLOWED",
      question: "Turn employment on?",
      recommendation: "No",
      stakes: "high",
      format: "choice",
      options: ["Yes", "No"],
      offerUnits: 0,
      audience: "Holders",
      governance: { matter: "parameter-amendment", threshold: "simple", windowEndsAt: "2026-11-06T12:00:00.000Z", paramKey: "EMPLOYMENT_ALLOWED", currentValue: false, proposedValue: true, effect: "Ventures could employ people." },
    },
  });
  for (const h of ["policy_pia", "counsel_kemi", "cfo_ines", "ux_uma", "llc_lena", "MP"]) {
    try {
      respond(s, { rfeId: rfe!.id, handle: h, via: "structured", choice: "Yes" });
    } catch {
      /* not every holder has vested units */
    }
  }
  s.meta.clock = "2026-11-07T00:00:00.000Z";
  closeGovernance(s, rfe!);
  assert.match(rfe!.resolution ?? "", /not applied/);
  assert.equal(resolveParams(s).EMPLOYMENT_ALLOWED, false);
});

test("a venture that needs employees can't pitch, with a clear message", () => {
  const s = buildSeed();
  const v = ventureBySlug(s, "site-record")!;
  v.tags = v.tags.map((t) => (t.axis === "workDelivery" ? { ...t, value: "Employees" } : t));
  assert.throws(() => pitchVenture(s, v), (err: Error) => err.message.includes(EMPLOYMENT_BLOCKED));
  assert.equal(v.status, "generated");
});

test("a level-2 pitch waits for the steward; seats open on sign-off", () => {
  const s = buildSeed();
  const v = ventureBySlug(s, "bid-desk")!;
  assert.equal(v.status, "generated");
  const d = pitchVenture(s, v);
  assert.equal(d.status, "awaiting_steward");
  assert.match(d.binReasons.join(" "), /pays contractors/);
  assert.equal(d.rfeId, undefined, "no seat request before sign-off");
  assert.ok(pitchAwaitingSignOff(s, v));
  assert.throws(() => buySeat(s, { slug: "bid-desk", handle: "gis_greta" }), /signs off on the pitch first/);
  stewardDecide(s, d.id, true, "Contractor plan checked.", v.stewardHandle);
  assert.equal(v.status, "pitched");
  assert.ok(d.rfeId && s.rfes.some((r) => r.id === d.rfeId && r.type === "capital"));
  assert.ok(!pitchAwaitingSignOff(s, v));
});

test("an agent-only pitch needs no sign-off", () => {
  const s = buildSeed();
  const v = ventureBySlug(s, "site-record")!;
  const d = pitchVenture(s, v);
  assert.notEqual(d.status, "awaiting_steward");
  assert.ok(d.rfeId);
});

test("contractors are paid cash against a signed-off hire, never named and never given units", () => {
  const s = buildSeed();
  const chair = ventureBySlug(s, "chairside")!;
  const pay = s.ledger.filter((l) => l.ventureId === chair.id && l.kind === "contractor-pay");
  assert.equal(pay.length, 2);
  for (const l of pay) {
    assert.equal(l.handle, undefined, "no handle on contractor pay");
    assert.ok(l.usd && l.usd > 0);
    assert.match(l.note, /^Paid Contractor 1 for /);
    assert.match(l.note, /no units/);
  }
  const hire = s.decisions.find((d) => d.id === "dec-chairside-hire")!;
  assert.equal(hire.bin, "gated", "hiring needs sign-off");
  assert.equal(contractorLabel(s, hire), "Contractor 1");
  const grantsBefore = s.grants.length;
  payContractor(s, { hireDecisionId: hire.id, usd: 120, job: "a half shift" });
  assert.equal(s.grants.length, grantsBefore);
});

test("contractor pay needs a taken hire on a level-2 venture", () => {
  const s = buildSeed();
  const dock = ventureBySlug(s, "dockside")!;
  const { decision } = logDecision(s, { ventureId: dock.id, title: "Contract a designer", reasoning: "A one-off logo.", confidence: 0.9, model: "script", facts: { hiresPerson: true } });
  assert.equal(decision.status, "awaiting_steward");
  assert.throws(() => payContractor(s, { hireDecisionId: decision.id, usd: 50, job: "a logo" }), /hasn't signed off/);
  stewardDecide(s, decision.id, true, "", dock.stewardHandle);
  assert.throws(() => payContractor(s, { hireDecisionId: decision.id, usd: 50, job: "a logo" }), /agent only/);
});

test("the three levels of who does the work are fixed", () => {
  const s = buildSeed();
  assert.throws(() => addClassificationValue(s, { axis: "workDelivery", value: "Volunteers", by: "rfe-x" }), TagError);
});
