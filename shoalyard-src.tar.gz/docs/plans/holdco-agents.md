# Holdco agent map (stubs)

**Status:** Stub map for future specialized holdco agents. Operating model detail lives in [`economics-safe-seed.md`](economics-safe-seed.md) § Holdco / platform responsibilities. Plain-language About list: [`messaging.md`](messaging.md) — What the yard does.

Holdco runs like a VC firm’s platform: **specialized agents**, not one undifferentiated bot. Opco agents run day-to-day ventures. Humans supply capital, kill-switch judgment, and work agents cannot fake.

**Not legal advice.** Securities / entity / offering posture remain counsel TBD.

## Roles

| Role id | Name | Job |
| --- | --- | --- |
| `capital_formation` | Capital formation | Structure the attempt’s seed path; escrow / fill-or-kill rails; keep holdco rails capital separate from opco seed |
| `marketing` | Marketing | Yard brand, batch cadence, honest public story; channel for counsel-cleared CTAs |
| `sourcing` | Sourcing | Hunt and filter ideas / domains worth an attempt |
| `thesis_dd` | Thesis / diligence | Stress the idea before capital is at risk; publish what can be published |
| `value_creation` | Value creation | Platform playbooks, shared rails, cross-venture learning |
| `governance` | Governance | Packs, calendars, breach / mark hygiene, steward workflows |
| `exit` | Exit prep | Hand-off packs, buyer/partner narrative, wind-down paths per instrument riders |
| `back_office` | Back office | Ledger, infra, security, legal-ops coordination, protocol product |
| `ir` | IR | Seeder / stakeholder communications; counsel-gated disclosure; no silent solicitation |

## Schema stub

Light enum / type: `packages/schema/src/holdco-agents.ts` (`HoldcoAgentRole`). No runtime agents wired yet.

## STATUS pointer

See `docs/STATUS.md` → Holdco agents. Future work: one agent package or worker per role, shared tools, human approval gates on money and outbound claims.
