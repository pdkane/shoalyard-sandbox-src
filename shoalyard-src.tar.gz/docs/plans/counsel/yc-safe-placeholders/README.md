# YC SAFE forms — PLACEHOLDER MIRROR

**NOT LEGAL ADVICE. PLACEHOLDER. REPLACE WITH COUNSEL.**

Downloaded from Y Combinator’s public SAFE page ([ycombinator.com/documents](https://www.ycombinator.com/documents) / [ycombinator.com/safe](https://www.ycombinator.com/safe)) for counsel reference only. These are **not** Shoalyard-executed instruments. Prefer refreshing from YC’s site before any real use; hashes and filenames below are a snapshot.

YC publishes these under its own terms (including Creative Commons Attribution-No Derivatives on the standard forms). Do not treat this mirror as authorization to modify the forms without counsel.

## Mirrored files (US post-money)

| File | YC label |
| --- | --- |
| `Postmoney-SAFE-Valuation-Cap-Only.docx` | SAFE: Valuation Cap, no Discount (default / preferred starting point) |
| `Postmoney-SAFE-Discount-Only.docx` | SAFE: Discount, no Valuation Cap |
| `Postmoney-SAFE-MFN-Only.docx` | SAFE: Uncapped MFN |
| `Pro-Rata-Side-Letter.docx` | Optional pro rata side letter |
| `SAFE-User-Guide.pdf` | SAFE User Guide |
| `Primer-for-post-money-SAFE-v1.1.pdf` | Primer for post-money SAFE v1.1 |

## Shoalyard intent (from economics memo — not form text)

- **Default flavor:** post-money valuation-cap SAFE.
- Cap / discount / MFN: **TBD with counsel**.
- Must add (stock YC form does **not** cover): wind-down, hand-off, unused-capital riders — see [`../wind-down-handoff-riders-checklist.md`](../wind-down-handoff-riders-checklist.md).
- Accredited path only; fill-or-kill escrow; miss → refund, no SAFE.

**Do not claim these placeholders are executed, filled, or cleared for a public offering.**
