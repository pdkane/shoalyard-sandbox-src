import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams, PARAMS, type Store } from "@av/schema";
import { latestDeck } from "../src/deck";
import { protocolVenture, rfeById, transitionVenture, ventureBySlug } from "../src/ops";
import { buildSeed } from "../src/seed";
import {
  chargeSharedServices,
  runBackOffice,
  SERVICE_AREAS,
  SERVICE_CATALOGUE,
  serviceChargesFor,
  servicesAccount,
  protocolCoveringLine,
  sharedServicesCharge,
  STANDALONE_MONTHLY_USD,
  STANDALONE_ONCE_USD,
} from "../src/services";

const seed = buildSeed();
const fresh = () => structuredClone(seed) as Store;

test("the flat charge is computed from the catalogue's at-cost rates", () => {
  const p = defaultParams();
  const c = sharedServicesCharge(p);
  const pooled = SERVICE_CATALOGUE.filter((i) => i.basis === "shared").reduce((s, i) => s + (p[i.param] as number), 0);
  const each = SERVICE_CATALOGUE.filter((i) => i.basis === "each").reduce((s, i) => s + (p[i.param] as number), 0);
  assert.equal(c.pooledMonthlyUsd, pooled);
  assert.equal(c.monthlyUsd, SERVICE_AREAS.reduce((s, a) => s + c.byArea[a], 0));
  assert.ok(c.monthlyUsd >= pooled / p.SERVICES_SHARED_BY + each && c.monthlyUsd < pooled / p.SERVICES_SHARED_BY + each + SERVICE_AREAS.length);
  assert.equal(c.setupUsd, p.SVC_SERIES_SETUP_USD);
  const fewer = sharedServicesCharge({ ...p, SERVICES_SHARED_BY: 4 });
  assert.ok(fewer.monthlyUsd > c.monthlyUsd, "fewer ventures sharing means a bigger share each");
  for (const i of SERVICE_CATALOGUE) assert.equal(PARAMS[i.param].group, "services", `${i.key} is a setting in the back-office group`);
});

test("a four-month proof costs less on the shared back office than bought separately", () => {
  const c = sharedServicesCharge(defaultParams());
  const shared = c.setupUsd + 4 * c.monthlyUsd;
  const alone = STANDALONE_ONCE_USD.formation + STANDALONE_ONCE_USD.templates + 4 * (STANDALONE_MONTHLY_USD.books + STANDALONE_MONTHLY_USD.insurance + STANDALONE_MONTHLY_USD.mailboxes);
  assert.ok(shared < alone, `$${shared} vs $${alone}`);
});

test("every seeded deck carries the shared-services lines at the computed charge", () => {
  const c = sharedServicesCharge(defaultParams());
  for (const slug of ["dockside", "permit-pulse", "bid-desk", "lumper-line"]) {
    const d = latestDeck(seed, slug)!;
    const monthly = d.budget.find((b) => b.key === "shared-services")!;
    assert.equal(monthly.monthlyUsd, c.monthlyUsd, slug);
    assert.equal(d.budget.find((b) => b.key === "series")!.usd, c.setupUsd, slug);
    assert.ok(!d.budget.some((b) => ["formation", "bookkeeping", "templates", "mailboxes"].includes(b.key)), `${slug}: no venture buys its own back office`);
  }
});

test("charges post once a month per area, only for ventures that use the back office, and the Protocol books its costs", () => {
  const s = fresh();
  const dock = ventureBySlug(s, "dockside")!;
  const pp = ventureBySlug(s, "permit-pulse")!;
  const c = sharedServicesCharge(defaultParams());
  assert.equal(serviceChargesFor(s, dock.id).totalUsd, c.setupUsd + c.monthlyUsd, "the seed bills Dockside's setup and October");
  assert.deepEqual(chargeSharedServices(s, dock, "2026-10"), [], "a month is billed once");
  assert.deepEqual(chargeSharedServices(s, pp, "2026-10"), [], "a venture still selling seats doesn't pay");
  assert.deepEqual(chargeSharedServices(s, protocolVenture(s), "2026-10"), []);

  s.meta.clock = "2026-11-02T12:00:00.000Z";
  const rows = runBackOffice(s);
  const charged = rows.filter((r) => r.kind === "service-charge");
  assert.deepEqual(charged.map((r) => r.ventureId), ["dockside", "dockside", "dockside"]);
  assert.equal(charged.reduce((t, r) => t + (r.usd ?? 0), 0), c.monthlyUsd);
  const costs = rows.filter((r) => r.kind === "service-cost");
  assert.ok(costs.every((r) => r.ventureId === protocolVenture(s).id));
  assert.equal(Math.round(costs.reduce((t, r) => t + (r.usd ?? 0), 0) * 100) / 100, c.pooledMonthlyUsd + c.items.filter((i) => i.item.basis === "each").reduce((t, i) => t + i.usd, 0));
  assert.deepEqual(runBackOffice(s), [], "running it again in the same month posts nothing");
});

test("the Protocol publishes what the back office cost against what it charged", () => {
  const s = fresh();
  const before = servicesAccount(s);
  assert.equal(before.months.length, 1);
  assert.ok(before.costUsd > before.chargedUsd, "with one venture using it, charges don't cover the pooled bills yet");
  assert.equal(before.uncoveredUsd, Math.round((before.costUsd - before.chargedUsd) * 100) / 100);
  assert.equal(protocolCoveringLine(before), `Protocol covering $${Math.round(before.uncoveredUsd).toLocaleString("en-US")} until more ventures share it`);
  assert.equal(protocolCoveringLine({ uncoveredUsd: 0 }), undefined);
  const pp = ventureBySlug(s, "permit-pulse")!;
  pp.status = "funded";
  transitionVenture(s, pp, "formed");
  s.meta.clock = "2026-11-02T12:00:00.000Z";
  runBackOffice(s);
  const after = servicesAccount(s);
  assert.equal(after.months.length, 2);
  assert.deepEqual(after.ventures.map((v) => v.ventureId).sort(), ["dockside", "permit-pulse"]);
});

test("the legal form stays an open question for counsel", () => {
  const legal = rfeById(seed, "rfe-v0-legal-form")!;
  assert.ok(legal && legal.status !== "resolved");
  assert.equal(rfeById(seed, "rfe-v0-services-rates")?.status === "resolved", false);
  const text = [...SERVICE_CATALOGUE.map((i) => i.what), ...SERVICE_CATALOGUE.map((i) => PARAMS[i.param].reason)].join(" ");
  assert.doesNotMatch(text, /\bLLC\b|\bDelaware\b|\bWyoming\b|\bcorporation\b/i);
  assert.match(text, /open question for counsel|question for counsel/);
});
