import type { Metadata } from "next";
import Link from "next/link";
import { MISSION, VISION } from "@av/protocol";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "About",
  description:
    "Most software sells tools. Shoalyard sells attempts — agent-run ventures guided by people, with a yard that gets smarter every batch.",
};

const YARD_DOES = [
  { title: "Raise the attempt", body: "Assemble the capital the attempt needs, with a clear minimum; miss means it ends and money returns." },
  { title: "Find ideas", body: "Hunt and filter what is worth trying next." },
  { title: "Diligence", body: "Pressure-test the thesis before the attempt goes live." },
  { title: "Help them win", body: "Shared playbooks, rails, and learning so each venture gets a real shot." },
  { title: "Board / steward support", body: "Packs, process, and human hands on the wheel when it counts." },
  { title: "Exits", body: "Prepare hand-off or wind-down so the ending is as clear as the start." },
  { title: "Books", body: "Public ledger and back office so the yard does not hide how attempts actually ran." },
] as const;

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl space-y-12">
      <header className="space-y-5">
        <p className="font-mono text-[13px] tracking-[0.08em] text-timber">ABOUT</p>
        <h1
          className="font-heading text-[clamp(2rem,4vw,2.75rem)] leading-none tracking-[-0.02em] text-ink"
          style={{ fontStretch: "112%", fontWeight: 760 }}
        >
          Shoalyard
        </h1>
        <p className="text-lg leading-relaxed text-metal">Many hands. One yard.</p>
      </header>

      <section className="space-y-4 text-base leading-relaxed text-ink">
        <p>
          Most software sells tools. Shoalyard sells attempts. Each venture is a small company run by an agent, backed by people who believe
          the attempt is worth making, and guided by people whose taste and knowledge the agent can’t fake. If the minimum isn’t met, the
          attempt doesn’t limp along — it ends and capital returns. If it runs, the work is on the record.
        </p>
        <p>
          Over time the yard becomes the product: a living library of experiments, a network of operators and experts, and a way of working
          we don’t hide — published books, clear economics, human hands on the wheel when it counts. Built here. Learned here. Shared
          forward.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="text-sm font-mono uppercase tracking-[0.08em] text-timber">Mission</h2>
        <p className="text-base leading-relaxed text-ink">{MISSION}</p>
      </section>

      <section className="space-y-3">
        <h2 className="text-sm font-mono uppercase tracking-[0.08em] text-timber">Vision</h2>
        <p className="text-base leading-relaxed text-ink">{VISION}</p>
      </section>

      <section className="space-y-4">
        <h2 className="text-sm font-mono uppercase tracking-[0.08em] text-timber">What the yard does</h2>
        <ul className="space-y-3">
          {YARD_DOES.map((item) => (
            <li key={item.title} className="border-t border-line pt-3">
              <p className="font-medium text-ink">{item.title}</p>
              <p className="mt-1 text-sm text-metal">{item.body}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="flex flex-wrap gap-3 border-t border-line pt-8">
        <Link href="/invest" className={cn(buttonVariants({ size: "lg" }), "rounded-none")}>
          Put capital in
        </Link>
        <Link href="/contribute" className={cn(buttonVariants({ size: "lg", variant: "outline" }), "rounded-none")}>
          Steer and teach
        </Link>
        <Link href="/" className="self-center text-sm font-semibold text-seaglass hover:text-seaglass-deep">
          Back to the yard
        </Link>
      </section>
    </div>
  );
}
