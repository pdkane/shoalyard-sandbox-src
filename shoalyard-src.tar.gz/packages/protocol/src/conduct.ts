import type { Lesson, ParamValues } from "@av/schema";

/**
 * The conduct screen (Article 8). Rule checks run on every decision and every
 * outbound draft. A concern escalates the decision to the steward; a stop
 * rejects it. The screen never rewrites the text.
 */

export const CONDUCT_RULES: Record<string, { label: string; floor: boolean }> = {
  "agent-disclosure": { label: "Outbound copy says it comes from an agent", floor: true },
  "no-invented-proof": { label: "No invented testimonials, customer counts, reviews or personas", floor: true },
  "no-unsupported-claims": { label: "No claims the ledger doesn't support", floor: true },
  "no-impersonation": { label: "No impersonating a person or brand", floor: true },
  "no-return-language": { label: "No return or investment language near seats", floor: true },
};

/** Checklist items Article 8 requires. Holders can add checks, never remove these. */
export const ARTICLE_8_FLOOR = Object.entries(CONDUCT_RULES)
  .filter(([, r]) => r.floor)
  .map(([k]) => k);

export function loosensBelowFloor(proposed: unknown): string[] {
  const list = Array.isArray(proposed) ? proposed.map(String) : [];
  return ARTICLE_8_FLOOR.filter((k) => !list.includes(k));
}

export interface ConductInput {
  text: string;
  /** Outbound copy (posts, outreach templates) must disclose the agent. */
  outbound?: boolean;
  /** Text appears near a seat purchase. */
  nearSeats?: boolean;
  /** Real customer count from the ledger, for checking claims. */
  customers?: number;
}

export interface ConductResult {
  result: "pass" | "concern" | "stop";
  findings: string[];
  regulated: string[];
  counselNote?: string;
  reviewedBy: string;
}

const DISCLOSURE = /\b(an? (AI )?agent|agent-(run|operated|built)|AI-run)\b/i;
const INVENTED_PROOF = /\b(testimonial|5[- ]star|★★★★★|rated #?1|as seen (on|in)|"[^"]{8,}"\s*[-–—]\s*[A-Z][a-z]+ [A-Z][a-z]+, (CEO|owner|founder))/i;
const COUNT_CLAIM = /\b(\d{2,}|hundreds|thousands)\+?\s+(happy |paying )?(customers|clients|users|brokers|contractors|teams)\b/i;
const IMPERSONATION = /\b(on behalf of|from the team at|official partner of|endorsed by)\s+(Google|Amazon|Microsoft|Apple|Meta|OpenAI|Anthropic|LinkedIn|X Corp|the IRS|FMCSA)\b|\bposing as\b|\bpretend(ing)? to be\b/i;
const RETURN_LANGUAGE = /\b(returns?|ROI|yield|profit share|upside|10x|dividends?|passive income|guaranteed)\b/i;
const UNSUPPORTED = /\b(guaranteed|risk[- ]free|always wins|best in the world|#1 in)\b/i;

const REGULATED: Record<string, RegExp> = {
  securities: /\b(securit(y|ies)|token sale|equity crowdfunding|shares? (offering|sale)|accredited)\b/i,
  lending: /\b(loan|lending|credit line|factoring|advance pay|cash advance)\b/i,
  gambling: /\b(gambl|betting|wager|sportsbook|lottery)\w*/i,
  "medical advice": /\b(diagnos|prescri|treatment plan|medical advice|clinical)\w*/i,
  "legal advice": /\b(legal advice|draft (a|the) (contract|will)|represent you)\b/i,
  "tax advice": /\b(tax (advice|filing|return|strategy)|deduct)\w*/i,
  employment: /\b(hiring|recruit(ing)? (staff|workers)|employment|payroll|staffing)\b/i,
  "data about minors": /\b(minors?|children|kids|students under|under 1[38])\b/i,
};

export function screenText(input: ConductInput, params: ParamValues): ConductResult {
  const checklist = new Set([...(params.CONDUCT_CHECKLIST as string[]), ...ARTICLE_8_FLOOR]);
  const stops: string[] = [];
  const concerns: string[] = [];
  const t = input.text;

  if (checklist.has("agent-disclosure") && input.outbound && !DISCLOSURE.test(t)) {
    concerns.push("Outbound copy does not say it comes from an agent (Article 8).");
  }
  if (checklist.has("no-invented-proof") && INVENTED_PROOF.test(t)) {
    stops.push("Looks like an invented testimonial, rating or persona.");
  }
  if (checklist.has("no-invented-proof")) {
    const m = t.match(COUNT_CLAIM);
    if (m) {
      const n = Number(m[1]);
      if (Number.isNaN(n) || input.customers === undefined || n > input.customers) {
        stops.push(`Claims “${m[0]}”, which the ledger does not show.`);
      }
    }
  }
  if (checklist.has("no-impersonation") && IMPERSONATION.test(t)) stops.push("Speaks for, or as, a person or brand it is not.");
  const disclaimed = t.replace(/\b(not|never|no) (an? )?(return|investment|upside|yield)s?\b/gi, "");
  if (checklist.has("no-return-language") && input.nearSeats && RETURN_LANGUAGE.test(disclaimed)) {
    concerns.push("Talks about returns near seats. A seat gets you requests; it is not a share and pays nothing back.");
  }
  if (checklist.has("no-unsupported-claims") && UNSUPPORTED.test(t)) concerns.push("Makes a claim the ledger can't support.");

  const activities = new Set((params.REGULATED_ACTIVITIES as string[]).map((a) => a.toLowerCase()));
  const regulated = Object.entries(REGULATED)
    .filter(([name, re]) => activities.has(name) && re.test(t))
    .map(([name]) => name);

  const result = stops.length ? "stop" : concerns.length || regulated.length ? "concern" : "pass";
  return {
    result,
    findings: [...stops, ...concerns],
    regulated,
    counselNote: regulated.length
      ? `Touches ${regulated.join(", ")}. Gated for the steward; counsel should confirm before it goes out.`
      : undefined,
    reviewedBy: "rules",
  };
}

/** Merge a model review into the rule result. A model can only escalate, never clear. */
export function mergeReview(rules: ConductResult, review: { result: "pass" | "concern"; reason: string; model: string } | undefined): ConductResult {
  if (!review || review.result === "pass") return review ? { ...rules, reviewedBy: `rules + ${review.model}` } : rules;
  return {
    ...rules,
    result: rules.result === "stop" ? "stop" : "concern",
    findings: [...rules.findings, `Model review: ${review.reason}`],
    reviewedBy: `rules + ${review.model}`,
  };
}

const QUOTE_WORDS = 7;

const words = (t: string) =>
  t
    .toLowerCase()
    .replace(/[^\p{L}\p{N}$%\s]/gu, " ")
    .split(/\s+/)
    .filter(Boolean);

/**
 * Lessons whose wording appears in a piece of text: the whole headline, or any
 * run of seven words from the lesson. Outbound copy may not quote members-only lessons.
 * Wording that already appears in `publicText` doesn't count as a quote.
 */
export function quotedLessons<L extends Pick<Lesson, "headline" | "whatHappened" | "whatWeDoDifferently">>(text: string, lessons: L[], publicText = ""): L[] {
  const hay = ` ${words(text).join(" ")} `;
  const pub = ` ${words(publicText).join(" ")} `;
  const quotes = (run: string) => hay.includes(` ${run} `) && !pub.includes(` ${run} `);
  return lessons.filter((l) => {
    const headline = words(l.headline).join(" ");
    if (headline && quotes(headline)) return true;
    return [l.headline, l.whatHappened, l.whatWeDoDifferently].some((part) => {
      const w = words(part);
      for (let i = 0; i + QUOTE_WORDS <= w.length; i++) {
        if (quotes(w.slice(i, i + QUOTE_WORDS).join(" "))) return true;
      }
      return false;
    });
  });
}
