# Pitch deck, seat sizing, member Q&A and liftoff roster: spec

Status: design only. Nothing here is implemented. It assumes two pending changes land first: **Venture 0 → "the Protocol"** (copy only; identifiers such as `isVenture0` and `rfe-v0-*` stay) and **phenotypes → classification** (`Venture.classification`: sector + sub-vertical, customer, business model, go-to-market, market type, geography; the agent proposes and the steward confirms).

Read against: `packages/schema/src/{primitives,params}.ts`, `packages/protocol/src/{ops,n-engine,economics,network,spawn,ideas,seed,batches,conduct}.ts`, `packages/protocol/agent/claude.ts`, `apps/venture/src/app/v/[slug]/page.tsx`, `packages/protocol/test/copy.test.ts`, and the foundation plan.

---

## 0. Where things stand today (what this replaces)

| Concern | Today | Problem |
|---|---|---|
| Seat count | `spawn.ts`: `minRaiseUsd = sum(budget)`; `n-engine.seatsNeeded = ceil(minRaise / SEAT_PRICE_USD)`. Budget is four generic lines (compute, tooling, formation, **Buffer**). `pitchVenture` reasoning: "No seat count beyond that is needed". | Only the budget sets the count. It ignores whether the holders can meet the N engine's targets, and whether there are enough seats to hold the roster. The buffer is a hidden line that differs per idea. |
| Pitch | `Venture.pitch` (one paragraph) + `Thesis` card (6 strings: whyThis, whyNow, whyUs, whyAgent, pathToFirstCustomer, killSignal). | No market, customer, alternatives, pricing, unit economics or milestones. No claim says whether it rests on evidence. |
| Capital request | `nBounds` capital: minimum = target = seats needed. Seats keep selling after funding. `seatUnitsEach = 10 / seatsNeeded`, so seats sold past the minimum find the seat slice empty (`grantSeatSlice` returns early). | Holders past the minimum silently get no seat units. |
| Readiness | `network.readiness`: 4 disclosures (budget coverage with a hard-coded `0.25`, reach, demand check, contradicted lessons). Never a gate. | Says nothing about the roster or the seat math. |
| Roster | `RosterSlot {type,label,count,clusters,keywords}`; defaults per phenotype; Dockside 4, Chairside 3, Permit Pulse 5 slots. `rosterFill` assigns each qualified seat holder to at most one slot. Open slots become network gaps and gated recruiting drafts. | Counts are picked by hand. There is no funnel math and no link to requests. Three same-cluster members count as **one** effective response in the N engine. There is no gate, so an unfilled roster has no consequence. Phenotype defaults go away with reclassification. |

Banned-word gotchas for every string below (`copy.test.ts` regexes; app copy and the whole seed JSON are scanned): `funds?` (so never "use of funds"), `carry` ("carry over"), `investors?`, `portfolios?`, `investment committee`, `SPVs?`, `LPA?s?`, `GPs?`, and `drops?`, which also bans **"drop-off"** in funnel copy (say "fall-through" or "lost at this step"). "Investment" alone is allowed only inside the fixed disclaimer. Also avoid "returns" and "upside" (conduct check `no-return-language`).

---

## 1. Pitch deck primitive

### 1.1 Shape (zod, `packages/schema/src/primitives.ts`, new section "pitch deck")

```ts
export const CLAIM_BASES = ["evidence", "estimate", "assumption"] as const;

export const Source = z.object({
  kind: z.enum(["rfe", "response", "decision", "ledger", "lesson", "public-data", "member-answer"]),
  ref: z.string().describe("Store id, or a dataset name/URL for public-data"),
  label: z.string(),
  verified: z.boolean().describe("public-data starts false; true once a member confirms it in a Knowledge request"),
  verifiedBy: z.string().optional().describe("Handle, 'steward', or the confirming rfe id"),
});

export const Claim = z.object({
  id: z.string().describe("Stable within a venture across versions, e.g. c-market-accounts"),
  text: z.string(),
  basis: z.enum(CLAIM_BASES),
  sources: z.array(Source).default([]),
  method: z.string().optional().describe("Required for estimate: the arithmetic or reasoning"),
  test: z.object({                       // required for assumption
    how: z.string(),
    rfeType: z.enum(RFE_TYPES).optional(),
    rfeId: z.string().optional(),
    killCriterionKey: z.string().optional(),
  }).optional(),
  value: z.object({ n: z.number(), unit: z.string() }).optional(),
});

export const SLIDE_KEYS = ["problem","solution","customer","market","whyNow","alternatives",
  "model","gtm","unitEconomics","milestones","budget","risks","ask"] as const;

export const Slide = z.object({ key: z.enum(SLIDE_KEYS), headline: z.string(), claims: z.array(Claim) });

export const MarketSizing = z.object({
  method: z.enum(["bottom-up", "top-down"]),
  formula: z.string().describe("e.g. accounts × annual price"),
  steps: z.array(z.object({ label: z.string(), claimId: z.string() })),
  tam: z.string(), sam: z.string(), som: z.string(),   // claim ids; each claim has value {n, unit:"USD/yr"}
  somHorizonMonths: z.number(),
});

export const Alternative = z.object({
  name: z.string(),
  kind: z.enum(["incumbent", "workaround", "do-nothing", "adjacent"]),
  claimIds: z.array(z.string()),
});

export const BudgetLine = z.object({
  key: z.string(),
  label: z.string(),
  category: z.enum(["formation","domain","tools","api","data","hosting","ads-test","outreach","contingency"]),
  usd: z.number(),
  claimId: z.string().describe("Quote = evidence, otherwise estimate with method"),
  milestoneKey: z.string(),
  stretch: z.boolean().default(false).describe("Funded only by seats between the minimum and the maximum"),
});

export const RequestPlanItem = z.object({
  key: z.string(), title: z.string(),
  type: z.enum(RFE_TYPES), stakes: Stakes,
  audience: z.string().describe("'any-holder' or a roster role key"),
  milestoneKey: z.string(),
});

export const Milestone = z.object({
  key: z.string(), label: z.string(), metric: z.string(), target: z.number(),
  dueDays: z.number().describe("Days after the minimum is met"),
  gate: z.enum(["liftoff", "customer1"]).optional(),
});

export const KillCriterion = z.object({ key: z.string(), metric: z.string(), threshold: z.string(), dueDays: z.number() });

export const SeatPlan = z.object({ ... });      // §2.3
export const RosterRole = z.object({ ... });    // §4.2

export const PitchDeck = z.object({
  id: z.string().describe("deck-<slug>-v<n>"),
  ventureId: z.string(),
  version: z.number().int(),
  status: z.enum(["published", "superseded"]),
  publishedAt: Iso,
  author: z.string().describe("Model id, 'script', or 'reconstructed'"),
  protocolVersion: z.string(),
  slides: z.array(Slide),                      // ordered by DECK_SLIDES
  market: MarketSizing,
  alternatives: z.array(Alternative),
  pricing: z.object({ claimId: z.string(), price: z.number(), unit: z.string(), cadence: z.enum(["month","year","one-time","per-use"]) }),
  unitEconomics: z.object({ priceClaimId: z.string(), variableCostClaimId: z.string(),
    grossMarginClaimId: z.string(), cacClaimId: z.string(), paybackClaimId: z.string() }),
  milestones: z.array(Milestone),
  budget: z.array(BudgetLine),
  requestPlan: z.array(RequestPlanItem),
  killCriteria: z.array(KillCriterion),
  seatPlan: SeatPlan,                          // computed by code, never by the model
  roster: z.array(RosterRole),                 // computed by code from the plan
  changes: z.array(z.object({ path: z.string(), before: z.unknown(), after: z.unknown(), material: z.boolean() })),
  cause: z.object({ kind: z.enum(["pitch","qa","rfe","steward","lesson","migration"]), ref: z.string().optional() }),
  decisionId: z.string().optional(),
});
```

Store gains `decks: PitchDeck[]` and `questions: Question[]` (§3), both `.default([])`. `Venture` keeps `minRaiseUsd`, `roster`, `killRules` and `thesis`. They are written from the current deck when it is published, so existing readers (`raiseProgress`, `readiness`, gap drafts, batch cards) keep working. `Thesis` becomes a derived view: `thesisFromDeck(deck)` maps problem → whyThis, whyNow → whyNow, gtm "why this network" claim → whyUs, solution "why an agent" claim → whyAgent, milestones → pathToFirstCustomer, killCriteria[0] → killSignal.

Slides (12 plus the ask). DECK_SLIDES is a param, so the order can be amended. Required content per slide:

| # | Slide | Required content (validated) |
|---|---|---|
| 1 | Problem | Who hurts, how much (a value claim), what they do today |
| 2 | Solution | What it does; "why an agent" claim; "what the agent cannot do" claim (a human signs or sends) |
| 3 | Customer / ICP | ICP sentence (role, company size, trigger); who it is *not* for; classification shown as confirmed/proposed (read from `venture.classification`, not copied) |
| 4 | Market | TAM/SAM/SOM, all three value claims, `som ≤ sam ≤ tam`, bottom-up unless `method` says why not; each step a claim |
| 5 | Why now | At least one dated change (law, data, cost, tool) |
| 6 | Alternatives | Market type Existing needs ≥ 2 named incumbents. Resegmented must name the over-served segment. New must include a workaround and do-nothing |
| 7 | Model and pricing | Pricing claim; business model from classification; one rejected pricing option and why |
| 8 | Go-to-market | Motion from classification; channels, each tied to a roster role and lessons cited (e.g. L-005 rules out cold outbound for small business) |
| 9 | Unit economics | Price, variable cost, gross margin, cash CAC (plus units CAC from request offers), payback. Pre-revenue numbers are estimates or assumptions, never evidence |
| 10 | Milestones | Liftoff (gate) → design partners → customer 1, with due days |
| 11 | Use of seat money | Itemized `budget`; contingency line computed (§2); stretch lines separated |
| 12 | Risks and kill criteria | Each risk links to a claim; kill criteria become `venture.killRules` |
| 13 | The ask | Rendered from `seatPlan` + `roster` only (worked calculation, roster table, refund rules, disclaimer) |

### 1.2 Claim rules (`validateDeck`, deterministic, in `packages/protocol/src/deck.ts`)

1. `evidence` ⇒ ≥ 1 source and every source is `verified`. Internal sources (`rfe`, `response`, `decision`, `ledger`, `lesson`) must resolve to existing store ids, and they're verified by construction.
2. `estimate` ⇒ `method` present. Unverified `public-data` can only support an estimate. The UI shows it as "cited by the agent, not yet checked by a member".
3. `assumption` ⇒ `test` present: how it will be tested (a planned request type or a kill criterion).
4. Every number shown on slides 4, 9 and 11 is a claim with `value`. Budget lines sum to the itemized total. Market `som ≤ sam ≤ tam`.
5. No claim may say customers, testimonials or reviews exist unless the ledger shows them (`no-invented-proof`). Numbers in `ledger`-sourced claims are recomputed from the store, and a mismatch fails validation.
6. All text passes `screenText` (conduct checklist) and the banned-word list. Any `REGULATED_ACTIVITIES` hit adds a risk line and a legal roster role (§4).
7. Claim ids are stable across versions, so citations and diffs survive amendment.

The **honesty bar** at the top of the deck shows counts by basis (e.g. "6 evidence · 14 estimates · 11 assumptions"). Its numbers come from the claims, not from a score.

### 1.3 Generation

`buildDeck(store, venture, mode)` runs at spawn, before `pitchVenture`. The model writes prose and inputs. **Code computes everything that sets money or people:** `seatPlan`, `roster`, the contingency line and the ask slide.

**Claude path** (`agent/claude.ts → deckWithClaude`, `MODEL_OPERATOR`, `forcedTool` "write_pitch_deck", ~6k tokens). The schema is `DeckDraft` = PitchDeck minus `id/version/status/seatPlan/roster/changes/cause`.

- System: "You are the operating agent of an agent-operated venture. Write its pitch deck for members deciding whether to take a $10 seat. A seat is access to the venture's requests, not an investment; never promise or imply profit to seat holders. Article 8: never deceive. Tag every claim evidence, estimate or assumption. Evidence may cite only the store ids in `evidence`. Anything you know from training is an estimate with a method, or an assumption with a test. Size markets bottom-up: accounts × price, each step its own claim. Say what you don't know. Never invent customers, quotes or partners. Avoid these words: [banned list]. Do not compute seats or roster counts; list the budget lines and the requests you expect to post before the first customer."
- Prompt JSON: idea fields, proposed classification, budget categories, params the agent may read (seat price, `N_BASELINE`, `RESPONSE_RATE`, `FUNNEL_RATES`), member graph as **cluster counts only** (no handles), adopted lessons with ids, `evidence`: resolved requests, responses and decisions for this venture with ids.
- After the call: `validateDeck`. On failure, retry once with the error list, then fall back to the script. The fallback is logged as `author: "script"` with reason "Claude draft failed validation: …".

**Scripted fallback** (`deckFromTemplate`). `IdeaTemplate` gains a `deck` block per library idea: problem/solution/whyNow claims, `market {accounts, accountsSource, price, segmentShare, reachable}`, alternatives, pricing, unit-cost estimates, budget lines with categories, requestPlan, killCriteria. Templates write claims from these with fixed basis rules: counts from named datasets → estimate (unverified public-data); price → assumption tested by the demand check; budget → estimate with method. An idea without a `market` block gets a Market slide marked "Not sized yet". All its claims are assumptions, and the agent posts a Knowledge request ("How many X are in Y?", 1 unit) as the test. The script never fabricates a number.

### 1.4 Versioning and amendment

- Decks are immutable once published. `amendDeck(store, venture, patch, cause)` writes version n+1, marks n `superseded`, computes `changes` (claim-level and field-level diff) and logs a Decision whose title starts "Amend the deck: …" and links the diff.
- **Triggers:** a material Q&A answer (§3); an RFE resolution that settles a claim's `test` (auto-upgrades assumption → evidence, or marks it **disproved**: the claim is struck through with the request linked, never deleted); steward edit; a new adopted lesson that contradicts a claim.
- **Material** = any change to a path in `DECK_MATERIAL_FIELDS` (default: seatPlan.min, budget total, pricing, killCriteria, classification). A material amendment is a **gated** decision (steward signs, Article 4) and notifies every holder (`notify`). While the venture is still `pitched`, holders who bought under an earlier version may withdraw for a full refund (`DECK_AMEND_WITHDRAW`). Non-material amendments are `auto`, and all amendments go on the log (Article 3).
- The `seat` ledger row records `ref: deck id`, so each holder can see the version they bought under.
- Raising `seatPlan.min` during a live window is material. Lowering it is also material, because it changes when the venture funds.

### 1.5 Rendering

- **Venture page** (`v/[slug]/page.tsx`): the "The pitch" card plus `ThesisCard` are replaced by a **Deck summary** card. It shows the headlines of problem, solution and customer, the honesty bar, "v3 · amended 29 Oct after a member question", and an **Open the deck** button. The Seats card gains a compact **Why N seats** block (§2.4) linking to `/deck#ask`. Below it sit Readiness, Liftoff roster (§4) and Q&A (§3), with Requests and the Log after.
- **`/v/[slug]/deck`** (new route, server component): one page, slides as stacked `Card`s with `id={key}` anchors.
  - Mobile: a sticky, horizontally scrolling chip nav (13 chips) and full-width cards. Claims are a list: basis badge, text, then a small source line. Tapping the badge expands method/test.
  - `lg+`: a left rail nav and the slide column at max 720px.
  - Prev/next links at each card foot. Query params: `?v=2` for an older version, with a banner "Superseded by v3".
  - TAM/SAM/SOM appear as three nested horizontal bars with numbers and the formula underneath. Budget is a `Table`, Milestones an ordered timeline, and the Ask is the worked calculation (§2.4) plus the roster table (§4.4) plus `<SeatDisclaimer />` and the refund lines.
- **`/v/[slug]/deck/changes`**: versions newest first. Each shows its cause (linked question, request, steward or lesson), the material flag, and before/after per changed claim.
- Basis badges (`components/deck-ui.tsx`): Evidence = solid emerald, Estimate = amber with "method", Assumption = dashed outline with "how it gets tested", Disproved = rose with strikethrough. The colour isn't the only signal: each badge shows its word, so screen readers and colour-blind users get it too.
- Teaser (announced batch): no deck. "The deck is revealed when early access opens."
- Print: `@media print` hides nav and prints one slide per page.

---

## 2. Seat sizing logic

### 2.1 Rule

```
budgetUsd     = Σ budget lines (non-stretch, excluding contingency)
budgetSeats   = ceil(budgetUsd / SEAT_PRICE_USD)

coverageSeats = max over requestPlan items with audience "any-holder" and type in RESPONSE_RATE:
                  ceil( nBounds(item).target / RESPONSE_RATE[item.type] )

rosterSeats   = Σ roster role counts          // every roster member holds a seat

raw           = max(budgetSeats, coverageSeats, rosterSeats)        → "binding" = which one
min           = clamp( ceil(raw × (1 + SEAT_BUFFER_PCT/100)), SEAT_FLOOR, SEAT_CAP )
max           = min( SEAT_CAP, ceil(min × SEAT_MAX_MULTIPLE) )
minRaiseUsd   = min × SEAT_PRICE_USD
contingency   = minRaiseUsd − budgetUsd       // an explicit budget line, category "contingency"
seatUnitsEach = POOL_SEATS_UNITS / max
```

- `nBounds` is the existing N engine function (baseline × stakes multiplier, clipped to the type's range). Coverage reuses it, so amending `N_BASELINE` or `STAKES_MULTIPLIER` moves the seat count automatically.
- Access, credibility, action and stewardship requests are excluded from coverage. They need specific people, so the roster covers them (§4), not seat breadth.
- If `raw × buffer > SEAT_CAP`, the pitch decision is gated ("Budget exceeds the seat cap; cut scope or split the milestone"), and readiness shows "Over cap". The agent is expected to re-scope, and the steward may approve as is.
- Ideas no longer carry a "Buffer" budget line. The buffer is one param for every venture, so it isn't counted twice.

### 2.2 Params (`packages/schema/src/params.ts`, new group `"pitch"`)

All `governedBy: "rfe-v0-seat-sizing"` (new Protocol request) unless noted.

| Key | Default | Reason (one line, as shipped) |
|---|---|---|
| `SEAT_BUFFER_PCT` | 20 (%) | Both Batch 001 ventures spent 97–100% of their budget before first customer or kill; 20% covers one overrun. |
| `SEAT_MAX_MULTIPLE` | 1.5 | Seats past the minimum add reach and responses, but a venture shouldn't hold seat money it has no listed use for. |
| `SEAT_CAP` | 150 (seats) | $1,500 is the most a pilot venture should hold before its first customer. Above that, the plan is too big for a seat raise. |
| `SEAT_FLOOR` | 10 (seats) | Below 10 holders, a medium-stakes Judgment request can't reach its target across distinct clusters. |
| `RESPONSE_RATE` | `{ judgment: 0.2, knowledge: 0.2 }` | Share of holders whose answer counts as a distinct-cluster response. Dockside's pricing request got 3 of 20 (0.15) before closing early, so 0.2 is a pilot guess, not evidence. (`governedBy: rfe-v0-manipulation`) |
| `READINESS_PLAUSIBLE_SHARE` | 0.25 | Replaces the hard-coded 0.25 in `readiness()`: the share of non-reaching qualified members assumed to take a seat. |
| `DECK_SLIDES` | the 13 keys in order | Slide order and set, amendable. (`rfe-v0-pitch-deck`) |
| `DECK_MATERIAL_FIELDS` | `["seatPlan.min","budget","pricing","killCriteria","classification"]` | Changes holders relied on when they bought; these are gated and notified. (`rfe-v0-pitch-deck`) |
| `DECK_AMEND_WITHDRAW` | true | A holder who bought under an earlier deck may withdraw in full before the minimum is met after a material change. (`rfe-v0-seat-vs-subscription`) |

### 2.3 `SeatPlan` schema

```ts
export const SeatPlan = z.object({
  rule: z.enum(["derived", "legacy-budget"]),   // legacy = formed under the old rule (Article 6)
  priceUsd: z.number(),
  budgetUsd: z.number(), budgetSeats: z.number(),
  coverageSeats: z.number(),
  coverageBinding: z.object({ requestKey: z.string(), type: z.enum(RFE_TYPES), stakes: Stakes, target: z.number(), rate: z.number() }).optional(),
  rosterSeats: z.number(),
  binding: z.enum(["budget", "coverage", "roster"]),
  bufferPct: z.number(), floor: z.number(), cap: z.number(),
  min: z.number(), max: z.number(),
  minRaiseUsd: z.number(), contingencyUsd: z.number(), seatUnitsEach: z.number(),
  overCap: z.boolean(),
  paramsAt: z.string().describe("Protocol version whose params produced this"),
});
```

`seatPlanFor(deck, params)` lives in the new `packages/protocol/src/sizing.ts`. It is pure, and the worked lines (§2.4) are rendered from the object, never stored as prose.

### 2.4 Worked calculation (rendered on the ask slide; compact version in the Seats card)

Permit Pulse, as it would read:

```
Budget to first customer           $260 itemized (6 lines)    →  26 seats at $10
Responses: launch-price Judgment, high stakes
  needs 5 distinct answers ÷ 0.20 of holders answering      →  25 seats
Roster: 12 roles, each held by a seat holder                 →  12 seats
Largest: budget                                                  26 seats
+ 20% buffer  → 31.2, rounded up                                 32 seats minimum · $320
Maximum: 32 × 1.5                                                48 seats · cap 150
Contingency: $320 − $260 = $60. Seats past the minimum pay for the listed stretch lines only.
Below 32 seats when the window closes: every seat is refunded in full.
Roster not filled 21 days after the minimum: the venture ends before forming; every seat is refunded in full.
Seat slice: 10 units ÷ 48 = 0.21 units per qualified holder. Units not claimed by liftoff move to the request reserve.
A seat is access to requests, not an investment.
```

Each figure links to its param on `/protocol` (value, reason, change history).

### 2.5 Interaction with the N engine, the pool and refunds

- **Capital request.** `nBounds` for `capital` returns `{ minimum: seatPlan.min, target: seatPlan.max }`. `evaluateN` capital returns `close` at `sold ≥ minimum`, as now, so `buySeat` funds the venture at the minimum. `buySeat` throws "Seats are full at {max}" at the maximum. `n-engine.seatsNeeded` stays for the legacy rule.
- **Distinct clusters.** Coverage assumes holders span enough clusters. Readiness shows "Distinct clusters among holders: 7 (largest request needs 5)" as a disclosure.
- **Pool (100 units).** The seat slice stays at 10 units (`POOL_SEATS_UNITS`), divided by `max` instead of the minimum, so every qualifying holder gets the same share whatever order they bought in. `sweepSeatSlice(venture)` runs at liftoff (Funded → Formed). It moves unclaimed seat-slice units to the request reserve and writes a ledger row ("6.7 seat-slice units unclaimed at liftoff moved to the request reserve"). The 60/25/5 slices are unchanged. Q&A unit awards (§3) come from the request reserve under `MAX_UNITS_PER_RFE`.
- **Refunds (uses the refund work already landed: `refundSeats`, `REFUND_IN_FULL`).**
  1. Below `min` at window close: refund all (unchanged).
  2. Funded, but the liftoff gate fails (§4.5): the venture ends before forming, so refund all (the existing "ends before forming" path).
  3. Material amendment while pitched: a holder may withdraw, refunding that one seat (`DECK_AMEND_WITHDRAW`).
  4. After Formed: no refunds (Article 2 unchanged).
- **Grandfathering (Article 6).** Ventures pitched before this change keep `rule: "legacy-budget"` and their current minimum. The ask slide shows the legacy derivation and a line "Under the current rule this venture would need N seats". The derived rule applies from the next pitched venture (Batch 003).

---

## 3. Member-candidate Q&A

### 3.1 Who and limits

- **Read:** everyone, including logged-out visitors.
- **Ask and upvote:** any member handle not `declined`, including `pending` candidates who haven't bought a seat. Asking from a new handle creates a pending member, through an `ensureMember()` extracted from `buySeat`. Labels next to handles: "seat holder", "qualified", "candidate". Handles stay pseudonymous, and no linked-account data is shown.
- **Window:** opens at early access (qualified members), then publicly with the seat window, and stays open while the venture is live. It becomes read-only when the venture is killed or the batch closes. The Protocol venture has no deck or Q&A; its open questions stay governance requests.
- **Params** (group `"pitch"`, `governedBy: "rfe-v0-qa"`):

| Key | Default | Reason |
|---|---|---|
| `QA_DAILY_PER_HANDLE` | 3 per venture | Enough to probe an idea; stops one handle flooding a page. |
| `QA_PENDING_DAILY` | 1 per venture | Unverified new handles are cheap to make. |
| `QA_OPEN_PER_HANDLE` | 5 across ventures | Unanswered questions queue on the agent; caps one handle's share. |
| `QA_MAX_CHARS` | 500 | One question, not an essay. |
| `QA_PRIORITY_UPVOTES` | 5 | At this many upvotes a question is answered on the next tick and reviewed for amendment. |
| `QA_MATERIAL_UNITS` | 0.5 units | A question that changes the deck is useful work (Article 1). Paid only to qualified members, from the request reserve. |
| `QA_UNITS_CAP_PER_VENTURE` | 3 units | Keeps question-asking from becoming a way to farm units. |
| `QA_HIDE_REASONS` | `["personal data about a person","harassment","spam or ads","illegal content","impersonation"]` | The steward may hide a question only for a conduct reason on this list. |

### 3.2 Schema

```ts
export const Citation = z.object({ deckVersion: z.number(), slideKey: z.enum(SLIDE_KEYS), claimId: z.string() });

export const Answer = z.object({
  at: Iso,
  by: z.string().describe("Model id or 'script'; always the operating agent"),
  status: z.enum(["answered", "partial", "unknown"]),
  text: z.string(),
  citations: z.array(Citation),
  assumptions: z.array(z.string()).describe("Cited claim ids whose basis is assumption or estimate"),
  material: z.boolean(),
  materialReason: z.string().optional(),
  routed: z.object({ rfeId: z.string().optional(), deckVersion: z.number().optional() }).optional(),
  updates: z.array(z.object({ at: Iso, text: z.string(), ref: z.string() })).default([]),
  conduct: z.object({ result: z.enum(["pass", "concern", "stop"]), findings: z.array(z.string()) }),
});

export const Question = z.object({
  id: z.string(), ventureId: z.string(), handle: Handle, text: z.string(), at: Iso,
  deckVersion: z.number().describe("Version on screen when asked"),
  status: z.enum(["open", "answered", "routed", "held", "hidden"]),
  upvotes: z.array(Handle).default([]),
  answer: Answer.optional(),
  stewardNote: z.string().optional().describe("The steward may add a note; never edits the answer"),
  hidden: z.object({ by: z.string(), reason: z.string(), at: Iso }).optional(),
});
```

### 3.3 Flows (`packages/protocol/src/qa.ts`)

1. **Ask.** `askQuestion(store, {slug, handle, text})`: `ensureMember` → rate limits → `screenText` on the question. A `stop` or `concern` puts it in `held` for steward review, and the asker sees "Held for a conduct check". Otherwise it is `open` and public at once.
2. **Answer.** `answerQuestion(store, q, mode)`. It runs inline in the server action when it's scripted. With a key set it calls Claude in the action with a timeout, then falls back to the script. Any still-open question is answered on the next `tick`. Always headed "Answered by the operating agent ({model})" (Article 8).
3. **Ground check (deterministic).** Every citation must resolve in the cited deck version. A number in the answer that appears in neither a cited claim nor the ledger downgrades the answer to `partial` with "I couldn't support {n} from the deck". Assumption- and estimate-based citations are listed under "This rests on…" with their tests. An answer with no supporting claim must be `unknown` and start "I don't know."
4. **Materiality.** The answer is material if any of these hold:
   - (a) it is `unknown` and the question is about an ICP, market, pricing, budget, roster or kill claim;
   - (b) it exposes a claim that is wrong or unsupported;
   - (c) answering would change a `DECK_MATERIAL_FIELDS` path;
   - (d) the question has ≥ `QA_PRIORITY_UPVOTES` and cites an assumption.

   Where it goes:
   - **A fact members can supply** → post a Knowledge or Judgment request. The audience comes from the roster role that serves the type; the offer is priced per lessons. The question becomes `routed`. When the request resolves, its resolution is appended to `answer.updates`, and the claim test may upgrade.
   - **Something the agent can fix now** → `amendDeck` (cause `qa`): `auto` if not material-field, gated otherwise. The answer links to the version it created.
   - If either route changes the deck, the asker gets `QA_MATERIAL_UNITS` if qualified and under the cap. It's issued as an `rfe` grant with note "Question changed the deck".
5. **Upvote.** Toggle, one per handle, not self. Sort options: top (default), new, unanswered.
6. **Hide.** `hideQuestion(store, {by, id, reason})`. It's steward-only and `reason ∈ QA_HIDE_REASONS`, so it can't be used against a hard or unflattering question: no such reason exists. The question shows "Hidden by @MP on 30 Oct: personal data about a person." A `redaction` ledger row is written. Any member can flag the hide through the existing `Flag` flow, and the member vote can restore it. Held questions are approved (made public) or hidden under the same reasons.
7. **No X.** Q&A never posts anywhere off-site. Sharing a Q&A is an ordinary gated Action draft for a human to post (`GATE_PUBLIC_POSTS`).

### 3.4 Claude prompt outline (`answerWithClaude`, `MODEL_OPERATOR`, tool "answer_member_question")

- System: "You answer a member's question about a venture you operate, using only the deck, the venture's public log and the parameters given. Cite claim ids for every statement of fact. If the deck doesn't support an answer, say 'I don't know' and say what would find out. Name assumptions as assumptions. You are an AI agent; say so if asked. A seat is access to the venture's requests, not an investment: never suggest a seat pays anything back, never give legal, tax or medical advice (point to the Protocol's legal-structure request instead), and avoid [banned list]. Also return whether the question is material, why, and a request draft if members could answer it."
- Input: the current deck (claims with ids and basis), seat plan, roster fill, open and recently resolved requests, refund rules, and the question plus prior Q&A on the venture (to avoid duplicates).
- Output: `Answer` minus `at/by/conduct/updates`, plus an optional `rfeDraft` (RfeDraft) and `amendment` (a JSON patch on claims). Then the ground check, then `screenText` + `conductReviewWithClaude`. A conduct concern holds the answer for the steward. The rule is never broken silently.

### 3.5 Scripted fallback answers (`answerScripted`)

The script matches intent by regex, in order, and picks claims by keyword overlap over claim text (`QA_MIN_MATCH` = 2 shared content words, otherwise unknown).

| Intent (pattern) | Answer template (cites) |
|---|---|
| Money back, profit, payout (`return|profit|payout|make money|worth`) | "A seat is access to {name}'s requests, not an investment. Holders earn units only for work: qualifying, and answering requests. Seat money is held until {min} seats; if the minimum isn't met, every seat is refunded in full." (ask) |
| Seat count (`how many seats|why \d+ seats|minimum`) | The worked calculation lines from `seatPlan` (ask) |
| Refund (`refund|get my \$10`) | Refund rules 1–3 from §2.5 (ask) |
| Customer (`who.*(buy|customer|for)`) | ICP claim + not-for claim (customer) |
| Market size (`market|tam|how big`) | TAM/SAM/SOM with basis, plus "These are estimates from {source}, not yet checked by a member." (market) |
| Competition (`compet|already|instead|why not`) | Alternatives (alternatives) |
| Price (`price|cost|charge`) | Pricing claim + its test (model) |
| Failure (`fail|kill|what if`) | Kill criteria (risks) |
| Roster or help (`who do you need|roster|help`) | Open roles with counts (ask) |
| Legal (`legal|lawyer|securit|tax`) | "I can't give legal advice. {Legal risk claim if any}. The Protocol's legal-structure question is open for counsel: /rfe/rfe-v0-legal-structure" → `partial` |
| Agent (`are you (a )?(human|bot|ai)`) | "I'm an AI agent operating {name}; @{steward} is the human steward." |
| Otherwise, below the match threshold | "I don't know. The deck doesn't cover this. I've asked members in a Knowledge request: {link}." → `unknown`, routed, with a 1-unit Knowledge request draft (`auto` bin, within the reserve) |

### 3.6 UI

- **Venture page `#qa` section:** the top 3 questions by upvotes with answers, an "Ask the agent" form (`Textarea` + submit; `useActionState` like other forms; shows remaining daily questions), and "All N questions →" linking to `/v/[slug]/qa`.
- **`/v/[slug]/qa`:** sort tabs (`Tabs`: Top / New / Unanswered / Routed), a `QuestionCard` per question:
  - the handle with its holder/candidate label, the date, and the deck version asked against;
  - the upvote button (a form posting to a server action);
  - the answer with a status badge (Answered / Partly answered / "I don't know");
  - citations as chips linking to `/deck?v=n#slide`, and a "This rests on" assumption list;
  - routed request and deck-version links, and updates.
- **`/steward`:** a new "Q&A held for conduct" queue (approve, or hide with reason) and material deck amendments in the existing gated-decision queue.
- **Seat checkout (`v/[slug]/seat`):** one line, "You're taking a seat under deck v3: minimum 32 seats because the budget binds (see the math)", plus links to the deck and Q&A.
- Components: `components/qa-ui.tsx` (`QuestionCard`, `AnswerBody`, `CitationChip`, `AskForm`, `UpvoteButton`). Actions: `askQuestionAction`, `upvoteAction`, `hideQuestionAction`, `approveQuestionAction` in `app/actions.ts`.

---

## 4. Liftoff roster

### 4.1 Why it must be larger

1. **Funnel arithmetic.** One paying customer needs about 3 design partners, and 3 partners need about 15 warm intros (§4.3). One "introducer" slot can't carry 15 intros. L-005 says cold outbound produced no trials (200 emails, 4 replies), so warm intros are the only channel the evidence supports.
2. **Cluster collapse.** The N engine counts one answer per profile cluster. Two "buyer-side operator" slots from `freight-ops` are one effective Judgment answer. Roles that serve N-counted requests need a minimum number of distinct clusters, not just headcount.
3. **Buyer-side weight.** L-003 (buyer dissent proved right) needs at least 3 buyer-side members, so a 2-of-3 split can exist.
4. **Chairside.** Its roster had 3 slots, and only 2 practice-side members existed in the whole graph (L-006). A roster of 11 with a liftoff gate would have shown the gap before formation money was spent. Instead it ran 211 days to its kill signal.

Result: rosters move from 3–5 to roughly 10–14 roles for a small-business ICP. Readiness shows the size against the member graph, and open roles become network gaps (existing recruiting drafts, still gated).

### 4.2 `RosterRole` schema (replaces `RosterSlot`)

```ts
export const ROSTER_ROLE_KEYS = ["icp-operator","introducer","domain-expert","builder","channel","legal","credibility"] as const;

export const RosterRole = z.object({
  key: z.enum(ROSTER_ROLE_KEYS),
  label: z.string().describe("Venture-specific, e.g. 'Contractor sales lead'"),
  count: z.number().int(),
  critical: z.boolean(),
  qualifications: z.array(z.string()).describe("Plain-language criteria shown on the page"),
  match: z.object({
    clusters: z.array(z.string()),
    keywords: z.array(z.string()),
    verifiedAttributes: z.array(z.enum(MEMBER_ATTRIBUTES)).default([]).describe("Must be verified to count for a critical role"),
    minDistinctClusters: z.number().int().default(1),
  }),
  serves: z.array(z.object({ type: z.enum(RFE_TYPES), requestKey: z.string().optional() })),
  derivation: z.string().describe("Rendered from inputs by code"),
  inputs: z.record(z.string(), z.number()),
});
```

`rosterFill` returns `{ role, filled: Handle[], pending: Handle[], distinctClusters, status: "open"|"partial"|"filled"|"cluster-short" }`. `pending` = matching seat holders not yet qualified. As now, each member fills at most one role, the steward is excluded, and only qualified seat holders count. For critical roles, the matched attribute must also be verified when `LIFTOFF_CRITICAL_VERIFIED` is set.

### 4.3 Sizing rule (`rosterPlan(deck, classification, params)` in `sizing.ts`)

```
f = FUNNEL_RATES[classification.customer]
partners      = ceil( FIRST_CUSTOMERS_TARGET / f.partnerToPaid )
intros        = ceil( partners / (f.introToCall × f.callToPartner) )
icp-operator  = ROSTER_ICP_OPERATORS                                       critical
introducer    = max(1, ceil( (intros − icp × INTROS_PER_ICP_OPERATOR) / INTROS_PER_INTRODUCER ))
domain-expert = max(ROSTER_DOMAIN_MIN, highest Knowledge target in requestPlan),  minDistinctClusters 2
builder       = ROSTER_ROLE_RULES.builderIfIntegration if any plan item or solution claim needs an integration
channel       = ROSTER_ROLE_RULES.channelPerMotion × |gtm motions ∩ {Partner/channel, Community & content}|  (≤ 2)
legal         = 1 if sector ∈ ROSTER_ROLE_RULES.legalSectors or the deck's risks hit REGULATED_ACTIVITIES   critical
credibility   = 1 if requestPlan has a Credibility item
total ≤ ROSTER_MAX, otherwise readiness says "Roster over cap: this ICP is hard to reach through intros"
```

Consumer customers replace intros with test users: `partners = f.testUsers` and channel = `ceil(testUsers / USERS_PER_CHANNEL_MEMBER)`, with no introducer role.

Params (group `"pitch"`, `governedBy: "rfe-v0-roster-sizing"`):

| Key | Default | Reason |
|---|---|---|
| `FIRST_CUSTOMERS_TARGET` | 1 | The Customer1 state. |
| `FUNNEL_RATES` | Small business `{introToCall .5, callToPartner .4, partnerToPaid .34}`; Mid-market `{.4,.3,.3}`; Enterprise `{.3,.25,.25}`; Government `{.25,.2,.2}`; Consumer `{testUsers 20}` | Pilot guesses. Dockside's single intro converted (L-001, L-005), a sample of one, so the defaults are deliberately conservative. |
| `INTROS_PER_INTRODUCER` | 3 | A member can make about three warm intros in a liftoff window without spending their reputation. |
| `INTROS_PER_ICP_OPERATOR` | 1 | A buyer-side member can usually introduce one peer. |
| `ROSTER_ICP_OPERATORS` | 3 | L-003: buyer-side dissent was right; three allows a 2-of-3 buyer view. |
| `ROSTER_DOMAIN_MIN` | 2 | Two distinct clusters let the N engine see disagreement. |
| `ROSTER_ROLE_RULES` | `{ builderIfIntegration: 1, channelPerMotion: 1, legalSectors: ["Fintech","Healthcare","Education","Public sector"], credibilityIfPlanned: 1 }` | Roles the plan, not the phenotype, calls for. |
| `USERS_PER_CHANNEL_MEMBER` | 10 | Consumer ventures recruit test users through community members. |
| `ROSTER_MAX` | 25 | Larger than this, the venture is a recruiting project, not a liftoff. |
| `LIFTOFF_WINDOW_DAYS` | 21 | Time after the minimum is met to fill the roster before formation money is spent. |
| `LIFTOFF_EXTENSION_DAYS` | 14 | One extension, gated to the steward. |
| `LIFTOFF_ROSTER_FILL_PCT` | 75 | Most of the plan must be staffed; a few open roles can fill while operating. |
| `LIFTOFF_CRITICAL_ROLES` | `["icp-operator","legal"]` | Without buyers, nothing is learned; without legal where required, Article 8 is at risk. |
| `LIFTOFF_CRITICAL_VERIFIED` | true | Critical roles count only with the matching attribute verified (LinkedIn or steward). |

Small-business example: partners = ceil(1/0.34) = 3; intros = ceil(3/0.2) = 15; introducers = ceil((15 − 3)/3) = 4. For Enterprise the same rule gives 4 partners, 54 intros and 17 introducers. That pushes the roster past `ROSTER_MAX` and readiness says so: the arithmetic tells the agent to resegment.

### 4.4 Display (`RosterPanel` → `RosterTable`, on the venture page and the ask slide)

Columns: role (label + qualifications), count, filled/pending (handles), distinct clusters, serves (request type chips linking to the open requests of that type), status, and "why this many" (the derivation line, e.g. "15 intros for 3 design partners at 50% × 40%; 3 come from ICP operators; 12 ÷ 3 per introducer = 4"). Open roles show "Recruiting draft awaiting @MP" when one exists. Summary line: "8 of 12 roles filled · critical: 3 of 3 ICP operators, verified".

### 4.5 Gating

- **Before funding (crowd decides):** readiness stays disclosures only. It adds:
  - **Seat math:** the binding constraint, plausible holders versus the minimum, and over-cap.
  - **Roster projection:** qualified members in the whole graph matching each role, so shortfalls show before anyone pays, with cluster-short warnings.
  - **Evidence share:** the honesty bar.
  - **Unanswered questions:** a count of `unknown` and open Q&A.
- **Liftoff gate (Funded → Formed):** `checkLiftoff(store, venture)` runs on every tick and on each qualification or seat event. Formation spend (the series formation line) can't happen before it passes. Pass =
  - fill ≥ `LIFTOFF_ROSTER_FILL_PCT` of total roles, **and**
  - every critical role is filled to count, verified if required, with `minDistinctClusters` met.

  On pass: `transitionVenture(→ formed)`, `sweepSeatSlice`, and a decision log line "Liftoff: roster 10 of 12, critical roles filled".
- **On failure at `LIFTOFF_WINDOW_DAYS`:** a gated decision "Extend liftoff by 14 days, or end before forming" goes to the steward. Without an extension, or when the extension expires: `killVenture(reason "could not reach buyer", stage "funded")` → `refundSeats` (full, before forming) → post-mortem draft. Every number in the gate is a param, and the gate never judges the idea.
- Recruiting: open roles are already network gaps. The agent drafts X and LinkedIn posts as gated Action requests and never posts itself.

---

## 5. The three seeded ventures

All market numbers below are **estimates** whose dataset citations are unverified until a member confirms them. Prices without demand evidence are **assumptions**. Decks for Dockside and Chairside are `author: "reconstructed"` with the banner "Reconstructed at migration from the pitch decision and thesis; the original pitch had no deck." Both keep `rule: "legacy-budget"`.

### 5.1 Dockside Notes (operating; Small business, Software & IT / freight sub-vertical, Subscription software, Partner/channel + Sales-led, Existing market, US)

- **Deck v1 (reconstructed, 2025-10-15):**
  - Problem: brokers write off detention and lumper charges because a dispute letter takes an hour (assumption; tested by the clauses Knowledge request).
  - Solution: the agent reads the rate con and ELD timestamps and drafts the letter; a person at the brokerage sends it.
  - ICP: ops lead at a 5–40-staff broker.
  - Market (bottom-up): ~28,000 active broker authorities (estimate, FMCSA) × 25% in 5–40 staff (assumption) = 7,000 accounts. × $2,388/yr gives SAM ≈ $16.7M; TAM (all brokers) ≈ $67M; SOM over 24 months = 200 brokers ≈ $0.48M.
  - Alternatives: do-nothing (write-off), TMS claims modules, a dispatcher writing by hand.
  - Pricing: $199/mo flat, versus $15 per letter rejected.
  - Unit economics: variable cost about $6/mo (40 letters × $0.15 API, estimate); gross margin ≈ 97% before tooling; cash CAC ≈ $0 plus 6–8 units per intro (L-001).
  - Kill: no paying broker by 31 Mar 2026.
- **Deck v2 (migration, evidence upgrade):** pricing becomes evidence (rfe-dockside-pricing, 3 of 3). 14 customers with 13 renewed (ledger). Median recovery $2,100/mo per customer (decision). Gross margin restated from the ledger: Q3 2026 revenue $11,420, costs $5,260 → 54% all-in (evidence). The cold-outbound claim is marked disproved (L-005).
- **Seats.** Legacy: $200 → 20 seats, 20 sold. Shown: "Under the current rule: budget $170 (API $80, domain $15, email/tools $20, formation $55) → 17; pricing Judgment medium 4 ÷ 0.2 → 20; roster 12 → binding coverage 20 → +20% = 24 seats ($240), max 36."
- **Roster (12):** brokerage operators 3 (critical; freight-ops), introducers to brokerage owners 4, claims/freight-software experts 3 (≥ 2 clusters: freight-ops + saas-gtm), ELD-export builder 1 (data-eng), TMS channel 1. No legal (sector not listed, no regulated hit).
- **Q&A (historical seed, 2):** "Do you serve carriers too?" routes to the existing carriers Judgment request. "Why flat pricing?" is answered with the pricing evidence cited.

### 5.2 Chairside Shifts (killed; Small business, Healthcare / dental staffing, Marketplace, Sales-led, Existing, US-CO)

- **Deck v1 (reconstructed):**
  - Problem: a sick day costs eight cleanings (assumption).
  - Market: ~130,000 US dental practices (estimate, ADA HPI), of which ~1,500 in the Denver metro (estimate). Revenue = $45 booking fee × ~8 cover shifts per practice per year (assumption) = $360/yr. SAM (Denver) ≈ $0.54M; TAM ≈ $47M; SOM 60 practices ≈ $22k.
  - Unit economics: $360/yr against a sales-led CAC (estimate) means payback is longer than 12 months. The deck shows this plainly.
  - Risks: employment and licensure (REGULATED_ACTIVITIES: employment) → legal role; "practices won't use a stranger" (assumption; this became L-002).
- **Seats.** Legacy: $180 → 18, 18 sold. Current rule: budget $155 (API $70, domain $15, SMS $15, formation $55) → 16; sick-day Judgment medium 4 ÷ 0.2 → 20; roster 11 → binding coverage 20 → 24 seats ($240), max 36.
- **Roster (11):** practice managers 3 (critical; the graph had 2 dental-ops members), introducers 4, hygienists 3 (≥ 2 clusters; the graph had 1), legal 1 (critical; Healthcare; none in the graph with healthcare-staffing law).
- **Counterfactual note** (shown on the post-mortem, labelled as such): "Under the liftoff gate, Chairside would have been at 3 of 11 roles with the legal role open at day 21, and would have ended before forming with every seat refunded, instead of reaching its kill signal at day 211." This is an estimate, not a claim about what would have happened with customers.

### 5.3 Permit Pulse (live in Batch 002, 17 seats sold; Small business, Real estate & construction / commercial permits, Subscription software, Partner/channel + Sales-led, Resegmented, US Sun Belt)

- **Deck v1 (published at pitch, script):**
  - Problem: contractors hear about permits weeks late (assumption; tested by the trade Judgment request).
  - Solution: weekly permits matched to trade and territory; the agent maintains scrapers. "Cannot do": judge bid fit; a person at the contractor decides.
  - ICP: sales-ops lead at a roofing or HVAC contractor with an outside sales team, 8 Sun Belt metros. Not for: residential-only shops.
  - Market (bottom-up): roofing + HVAC contractor establishments in 8 metros ≈ 12,000 (estimate, Census County Business Patterns NAICS 238160/238220, unverified) × 20% with outside sales teams doing commercial work (assumption) = 2,400 accounts × $1,788/yr gives SAM ≈ $4.3M. National equivalent ≈ 15,000 accounts gives TAM ≈ $26.8M. SOM 24 months = 60 accounts ≈ $107k.
  - Why now: Maricopa, Travis and Harris publish weekly or better (estimate → evidence after the metros request).
  - Alternatives: construction-data suites (incumbent; the over-served segment is "teams that need only new permits"), manually checking county sites (workaround), waiting for bid invites (do-nothing).
  - Pricing: $149/mo per trade-territory (assumption; demand check 2 of 3 "yes at about the price", 1 "only cheaper" — evidence, small sample).
  - Unit economics: variable about $8/mo per subscriber at 10 subscribers (API $3 + proxies $50 shared, estimate); gross margin ≈ 95%; cash CAC $0 plus 6 units per intro; payback under 1 month (estimate).
  - Milestones: liftoff by day 21; 3 design partners by day 35; first paid Monday list by week 5 (customer1).
  - Kill: below minimum at batch close; no paying contractor by 31 Mar 2027.
- **Budget (itemized, no buffer line):** API parsing/matching $70, scraper hosting $40, county portal access and proxies $50, domain $15, email sending $25, formation $60 = **$260**. Stretch (seats 33–48, $160): LinkedIn ads test $100 (gated, public post), a fourth metro's portal access $60.
- **Seats.** Legacy, kept: $300 → 30 seats (17 sold). Ask slide line: "Under the current rule: budget 26, launch-price Judgment high 5 ÷ 0.2 = 25, roster 12 → +20% → 32 seats ($320), max 48. This venture keeps its 30-seat minimum, set when it was pitched." The minimum is not moved mid-window.
- **Roster (12):**

  | Role | Count | Serves |
  |---|---|---|
  | Contractor sales leads (critical; construction-sales, role verified) | 3 | Judgment, Access |
  | Introducers to contractor owners | 4 | Access |
  | Permit or county-data experts (≥ 2 clusters) | 3 | Knowledge |
  | Scraper builder (data-eng) | 1 | Action |
  | Channel (roofing supply distributor or trade association) | 1 | Access |

  On current holders: about 3/3 ICP, domain 3 filled but **1 distinct cluster** (all `data-eng`, so cluster-short), builder 1/1, introducers about 1/4, channel 0/1. That's ≈ 8/12 with a cluster gap, which produces a recruiting draft for a county permit clerk or plan reviewer.
- **Seeded Q&A (6), showing every path:**
  1. @roofer_rita, "Why monthly, when lead services charge per lead?" Answered: pricing assumption plus demand-check evidence cited, under "This rests on".
  2. A new pending candidate, "Why 30 seats?" Answered with the legacy derivation and the current-rule comparison.
  3. @bidboard, "Is Fulton County in?" Answered with evidence from gis_greta's metros answer (PDF-only, skip). Material (market changes) → **deck v2**: 8 metros → 7, SAM restated; non-material field, so `auto`. Asker gets 0.5 units.
  4. @hvac_hank, "Do permits name the winning GC early enough to matter?" → "I don't know" → routed to a Knowledge request (2 units, audience: permit or county-data experts).
  5. @coldcall_cass, "Are scrapers allowed under the portals' terms?" Partial: a new risk claim is added in v2, plus a routed Knowledge request. No legal role (not a listed sector); the risk claim is an assumption tested by that request.
  6. A hidden question: "Hidden by @MP on 30 Oct: personal data about a person", with a redaction ledger row.

Batch 002's spawned ventures (Lien Clock, Wet Ink) and Batch 003 spawns get scripted decks from their `IdeaTemplate.deck` blocks. Lien Clock's risks hit "legal advice", so it gets a critical legal role (counsel_kemi or llc_lena could fill it).

---

## 6. Implementation plan

### 6.1 Ordering

1. **Rename to the Protocol** lands first. It is copy only: new param `governedBy` ids keep the `rfe-v0-` prefix, and the copy says "the Protocol".
2. **Reclassification** lands second: `Venture.classification` replaces the phenotype; `PHENOTYPES` roster defaults are removed; `TAG_AXES` updated.
3. **This work**, in these phases (each phase is one commit with its tests):
   - **A. Schema and params:** the primitives in §1.1, §2.3, §3.2, §4.2; `Store.decks` and `Store.questions`; the params in §2.2, §3.1, §4.3; `ParamGroup` adds `"pitch"`; the `/protocol` group label.
   - **B. Sizing (pure):** `sizing.ts` with `seatPlanFor`, `rosterPlan`, `coverageSeats`. It reads `classification` through a narrow type, so it can be built while step 2 is in review.
   - **C. Deck:** `deck.ts` (`validateDeck`, `deckFromTemplate`, `publishDeck`, `amendDeck`, `latestDeck`, `deckDiff`, `thesisFromDeck`); `IdeaTemplate.deck` blocks for all 9 library ideas; budget "Buffer" lines removed.
   - **D. Economics, gate and refunds:** `nBounds` capital min/max; the `buySeat` cap and deck ref on the seat row; `seatUnitsEach` ÷ max; `sweepSeatSlice`; `checkLiftoff` + `batches.advanceBatches` / `tick` hook; deck-amend withdrawal → single-seat `refundSeats` variant. Builds on the refund work already merged (`7bb0423`, `383d0c4`).
   - **E. Q&A:** `qa.ts`; `ensureMember` extracted from `buySeat`.
   - **F. Claude:** `deckWithClaude` and `answerWithClaude` in `agent/claude.ts`; tick answers open questions and applies evidence upgrades when requests resolve.
   - **G. UI:** routes and components (§6.3).
   - **H. Seed migration** (§6.4) last, then regenerate `.data` with the existing seed script.

### 6.2 Files

| File | Change |
|---|---|
| `packages/schema/src/primitives.ts` | Add Claim, Source, Slide, MarketSizing, Alternative, BudgetLine, RequestPlanItem, Milestone, KillCriterion, SeatPlan, RosterRole, PitchDeck, Citation, Answer, Question; `Venture.roster: RosterRole[]`; `Store.decks`, `Store.questions`; `PRIMITIVES` += PitchDeck, Question; remove `RosterSlot` (alias during phase A) |
| `packages/schema/src/params.ts` | ~27 params in §2.2, §3.1, §4.3; group `"pitch"` |
| `packages/protocol/src/sizing.ts` (new) | seatPlanFor, rosterPlan, coverageSeats, renderSeatMath |
| `packages/protocol/src/deck.ts` (new) | validate, build (script), publish, amend, diff, thesisFromDeck, claim lookup |
| `packages/protocol/src/qa.ts` (new) | askQuestion, answerScripted, groundCheck, routeQuestion, upvote, hideQuestion, approveHeld, qaFor |
| `packages/protocol/src/n-engine.ts` | capital bounds from SeatPlan (legacy fallback to `seatsNeeded`) |
| `packages/protocol/src/economics.ts` | `seatUnitsEach` ÷ max; `sweepSeatSlice` |
| `packages/protocol/src/ops.ts` | `pitchVenture` reasoning = worked lines; `buySeat` max cap and deck ref; `ensureMember`; `checkLiftoff`; formation gate on Funded → Formed; single-seat withdrawal refund |
| `packages/protocol/src/network.ts` | `rosterFill` over RosterRole with pending, distinct clusters and verified checks; readiness adds seat-math, roster projection, evidence share, unanswered Q&A; `READINESS_PLAUSIBLE_SHARE` |
| `packages/protocol/src/spawn.ts`, `ideas.ts` | Build the deck at spawn; `minRaiseUsd`, roster and killRules come from the deck; `IdeaTemplate.deck` blocks |
| `packages/protocol/src/batches.ts` | Liftoff deadline events; teaser hides deck and Q&A |
| `packages/protocol/agent/claude.ts`, `agent/index.ts` | deckWithClaude, answerWithClaude; tick: answer questions, liftoff check, evidence upgrade |
| `packages/protocol/src/seed.ts` | §6.4 |
| `packages/protocol/src/index.ts` | export the new modules |
| `apps/venture/src/app/v/[slug]/page.tsx` | Deck summary, Why N seats, RosterTable, Q&A section; ThesisCard only when there's no deck |
| `apps/venture/src/app/v/[slug]/deck/page.tsx`, `deck/changes/page.tsx` (new) | Deck viewer and version diff |
| `apps/venture/src/app/v/[slug]/qa/page.tsx` (new) | Full Q&A |
| `apps/venture/src/app/v/[slug]/seat/page.tsx` | Deck version and seat-math line |
| `apps/venture/src/app/steward/page.tsx` | Held-questions queue |
| `apps/venture/src/app/actions.ts` | askQuestionAction, upvoteAction, hideQuestionAction, approveQuestionAction, extendLiftoffAction |
| `apps/venture/src/components/deck-ui.tsx` (new) | DeckNav, SlideCard, ClaimRow, BasisBadge, SourceLine, HonestyBar, MarketBars, BudgetTable, MilestoneList, SeatMath |
| `apps/venture/src/components/qa-ui.tsx` (new) | §3.6 |
| `apps/venture/src/components/protocol-ui.tsx` | RosterPanel → RosterTable; ReadinessPanel new item keys |

### 6.3 Routes

`/v/[slug]` (updated), `/v/[slug]/deck?v=n#slide`, `/v/[slug]/deck/changes`, `/v/[slug]/qa?sort=top|new|unanswered|routed`. Unknown version → 404 (match the existing per-route not-found pattern). Codename slugs resolve, and the deck and Q&A routes return the teaser while the batch is announced (reuse `isRevealed`).

### 6.4 Seed migration

- **Dockside:** deck v1 reconstructed (Oct 2025) + v2 evidence upgrade; `seatPlan.rule = "legacy-budget"` (min 20); roster rebuilt to 12 roles; existing holders mapped into roles; 2 historical Q&A.
- **Chairside:** deck v1 reconstructed; legacy 18; roster of 11 with the counterfactual note on the post-mortem; Q&A read-only, empty.
- **Permit Pulse:** deck v1 at pitch (2026-10-28) and v2 from question 3 (2026-10-29); legacy 30 seats kept; 6 questions (§5.3) and one new pending candidate member; routed Knowledge requests seeded.
- **Lien Clock, Wet Ink, Batch 003 spawns:** decks from template; Batch 003 ventures use `rule: "derived"`, so the new seat math is live on the next batch.
- Remove "Buffer" lines from every budget. For legacy ventures, keep their historical `minRaiseUsd` and show the buffer as contingency.
- Post three new Protocol requests, each listing its params with current values: `rfe-v0-seat-sizing`, `rfe-v0-roster-sizing`, `rfe-v0-qa`. Also `rfe-v0-pitch-deck`.

### 6.5 Tests (`node:test`, `packages/protocol/test/`)

- `sizing.test.ts`:
  - Permit Pulse inputs give budget 26, coverage 25, roster 12, binding budget, min 32, max 48, contingency $60, seatUnitsEach 0.2083.
  - Dockside gives 24 with binding coverage.
  - Floor and cap clamp; over-cap sets `overCap`.
  - Amending `N_BASELINE`, `RESPONSE_RATE` or `SEAT_BUFFER_PCT` moves the result.
  - Small-business funnel gives 3/15/4; Enterprise exceeds `ROSTER_MAX`.
  - A legal role appears for Healthcare and for a regulated risk.
- `deck.test.ts`:
  - Each basis rule rejects its violations; an unverified public-data source can't back evidence.
  - Rejects `som > sam`; rejects a budget mismatch; rejects a ledger-number mismatch.
  - Every seeded deck validates; the ask slide is code-derived (model output with seat numbers is ignored).
  - Amend: n+1, superseded n, diff, material path → gated decision + notify; claim ids stable.
- `qa.test.ts`:
  - Rate limits for pending vs qualified; held on conduct concern.
  - The scripted seat-money answer contains the disclaimer and no return language; an off-deck question → `unknown` + routed request.
  - The ground check downgrades unsupported numbers.
  - Upvotes: one per handle, none on own question.
  - Hide requires a listed reason and writes a redaction row; the placeholder renders; unit award capped per venture.
- `liftoff.test.ts`:
  - Funded, critical role unverified at day 21 → steward gated decision; no extension → killed, every seat refunded, no formation spend.
  - Filled → formed and the seat slice swept to the reserve.
  - Seats are refused at max; material amendment withdrawal refunds one seat only while pitched.
- Update `n-engine.test.ts` (capital min/max) and `economics.test.ts` (÷ max, sweep).
- `copy.test.ts`:
  - Already scans `apps/venture/src` and the full seed JSON, so decks and questions are covered automatically.
  - Add assertions that `deck-ui.tsx` renders `<SeatDisclaimer />` on the ask slide, and that no seeded string matches `/drop-off/i`. The existing `drops?` regex already catches it; this just gives a clearer failure.

### 6.6 Risks to watch

- **Claude token budget.** One deck is about 6k output tokens. Use the script on `--spawn` batches when no key is set.
- **Seat count rises.** Most derived decks bind on budget or coverage at 24–32 seats against a graph of about 25 members, so a funded venture now needs recruiting. That's intended (it makes gaps visible), but batch-level readiness should show it.
- **The gate is a new hard stop.** It uses only the venture's own declared roster and params, never a judgment of the idea. Say so on the page: "This venture's own plan needs these people before it spends formation money."

## User decisions (Oct 30, 2026)

1. Seat slice: FOLD the 10 seat units into the RFE reserve (pool becomes steward 5, cohort 25, RFE reserve 70). Paying never earns units. Drop the "slice divided by max seats" design and remove seat-slice grants/forfeiture code paths; refunds stay.
2. Roster gate: COMBINED rule. A venture may be pitched only when qualified members cover >= 60% of roster roles (param, "network fit"); after funding it must reach 75% filled + all critical roles filled and verified within 21 days (one steward extension), else it ends before forming and every seat is refunded.
3. Founding DNA (founding_dna_research.md): adopt the recommended set by default. Office-hours questions and the new pitch fields go into the deck; the weekly update / monthly steward review loop goes into the operating agent. "Seat money is spent only on the published plan" stays a protected param for now, pending the user.

### Revision to decision 2 (cold start)
User flagged the 60% pre-pitch gate as a cold-start problem. Replace with:
- No pre-pitch roster gate. The pitch shows open roles; the pitch itself recruits for them (agent drafts role-targeted recruiting posts; steward posts).
- Anyone qualified, or a candidate who qualifies, can claim a role during the raise, with or without buying a seat.
- The raise succeeds only when the seat minimum is met AND the venture's critical roles are claimed (param CRITICAL_ROLES_AT_RAISE, about 2-3: e.g. one buyer-side operator and one domain expert). Otherwise every seat is refunded.
- After funding: fill the remaining roles within 21 days at a pilot-friendly bar (param ROSTER_FILL_AT_FORMATION, default 50%, rising by Protocol vote as the network grows). One steward extension, then end and refund.
- Fill rates per role and classification feed the learning loop.
