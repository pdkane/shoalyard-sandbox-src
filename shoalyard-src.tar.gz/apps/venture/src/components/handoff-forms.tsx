"use client";

import { checkOfferAction, submitOfferAction, withdrawOfferAction } from "@/app/actions";
import { useToastAction } from "@/components/protocol-forms";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export function OfferForm({ slug, name }: { slug: string; name: string }) {
  const [state, action] = useToastAction(submitOfferAction);
  return (
    <form action={action} className="space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
      <input type="hidden" name="slug" value={slug} />
      <p className="text-sm font-medium">Offer to adopt {name}</p>
      <p className="text-xs text-pretty text-zinc-500">
        You run it with your own money. Your handle is all unit holders see. The agent summarises your offer, the steward checks it follows the rules, and
        unit holders vote.
      </p>
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="space-y-1.5">
          <Label htmlFor={`price-${slug}`}>Price (USD)</Label>
          <Input id={`price-${slug}`} name="price" inputMode="numeric" required placeholder="15000" className="h-9" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor={`cash-${slug}`}>Cash to contributors now</Label>
          <Input id={`cash-${slug}`} name="cash" inputMode="numeric" placeholder="12000" className="h-9" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor={`retained-${slug}`}>Profit share they keep (%)</Label>
          <Input id={`retained-${slug}`} name="retained" inputMode="numeric" placeholder="10" className="h-9" />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor={`plan-${slug}`}>What you&apos;ll do with it</Label>
        <Textarea id={`plan-${slug}`} name="plan" rows={3} required minLength={20} maxLength={800} placeholder="Who runs it, what you'll add, how contributors hear from you." />
      </div>
      <p className="text-xs text-zinc-500">Cash goes to people with earned units, by vested units. Seat holders without units get nothing.</p>
      <div className="flex flex-wrap items-center gap-2">
        <SubmitButton size="sm">Send the offer</SubmitButton>
        <FormMessage state={state} />
      </div>
    </form>
  );
}

export function CheckOfferForm({ offerId }: { offerId: string }) {
  const [state, action] = useToastAction(checkOfferAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="offerId" value={offerId} />
      <SubmitButton size="sm">Check it against the rules</SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function WithdrawOfferForm({ offerId }: { offerId: string }) {
  const [state, action] = useToastAction(withdrawOfferAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="offerId" value={offerId} />
      <SubmitButton size="sm" variant="outline">
        Withdraw my offer
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}
