"use client";

import { useActionState } from "react";
import { CreditCard, Lock } from "lucide-react";
import { buySeatAction, type ActionState } from "@/app/actions";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function SeatForm({
  slug,
  price,
  defaultHandle,
  refId,
}: {
  slug: string;
  price: string;
  defaultHandle?: string;
  refId?: string;
}) {
  const [state, action] = useActionState<ActionState, FormData>(buySeatAction, { ok: true });
  return (
    <form action={action} className="space-y-5">
      <input type="hidden" name="slug" value={slug} />
      {refId && <input type="hidden" name="ref" value={refId} />}
      <div className="space-y-2">
        <Label htmlFor="handle">Choose a handle</Label>
        <div className="flex items-center rounded-lg border border-input bg-white focus-within:ring-3 focus-within:ring-ring/50">
          <span className="pl-3 text-zinc-400">@</span>
          <Input
            id="handle"
            name="handle"
            required
            defaultValue={defaultHandle}
            autoComplete="off"
            pattern="[A-Za-z0-9_]{2,24}"
            placeholder="your_handle"
            className="border-0 shadow-none focus-visible:ring-0"
          />
        </div>
        <p className="text-xs text-zinc-500">This is your public name here. You never have to give your real name.</p>
      </div>

      <div className="space-y-2">
        <Label>Payment</Label>
        <div className="space-y-2 rounded-lg border border-dashed border-zinc-300 bg-zinc-50 p-3">
          <div className="flex items-center gap-2 text-sm text-zinc-500">
            <CreditCard className="size-4" />
            <span className="font-mono">4242 4242 4242 4242</span>
            <span className="ml-auto font-mono">12/30</span>
          </div>
          <p className="flex items-center gap-1.5 text-xs text-zinc-500">
            <Lock className="size-3" /> Demo checkout. No card is charged; the {price} is recorded on the ledger.
          </p>
        </div>
      </div>

      <label className="flex items-start gap-2 text-sm text-zinc-700">
        <input type="checkbox" name="agree" className="mt-0.5 size-4 accent-zinc-900" required />
        <span>
          I understand a seat gets me this venture&apos;s requests. It is not a share and pays nothing back. I can only earn units by
          answering requests, and I need to be verified first.
        </span>
      </label>

      <FormMessage state={state} />
      <SubmitButton size="lg" className="w-full" pendingText="Taking your seat…">
        Pay {price} and continue
      </SubmitButton>
    </form>
  );
}
