import { cookies } from "next/headers";
import { inboxFor, memberByHandle, resolveParams } from "@av/protocol";
import { loadStore } from "@av/protocol/store";

export const VIEWER_COOKIE = "av_viewer";
/** The view-as value for someone who isn't signed in: no member, the public view. */
export const VISITOR = "visitor";

/**
 * Per-request read of the local JSON store. Reading the cookie makes every
 * route that calls this render dynamically, so pages always show the latest
 * state after a Server Action writes the store.
 */
export async function getData() {
  const jar = await cookies();
  const store = loadStore();
  const params = resolveParams(store);
  const requested = jar.get(VIEWER_COOKIE)?.value;
  const visitor = requested === VISITOR;
  const member = visitor ? undefined : (requested && memberByHandle(store, requested)) || memberByHandle(store, params.FOUNDING_STEWARD_HANDLE);
  const viewer = visitor ? VISITOR : (member?.handle ?? params.FOUNDING_STEWARD_HANDLE);
  const isSteward = store.ventures.some((v) => v.stewardHandle === viewer);
  const inboxCount = member ? inboxFor(store, viewer).length : 0;
  /** The cookie names a real member. Without it the demo shows the founding steward, but nobody has signed in. */
  const signedIn = !visitor && !!requested && memberByHandle(store, requested) !== undefined;
  return { store, params, viewer, member, isSteward, inboxCount, signedIn };
}

export type Data = Awaited<ReturnType<typeof getData>>;
