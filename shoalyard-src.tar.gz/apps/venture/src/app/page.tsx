import Link from "next/link";
import { ArrowRight, Inbox } from "lucide-react";
import {
  batchLabel,
  capTable,
  currentBatch,
  earlyAccessAt,
  inboxFor,
  openRfes,
  raiseProgress,
  ventureAttribution,
} from "@av/protocol";
import type { Venture } from "@av/schema";
import { ObjectiveBadge, StatusBadge } from "@/components/badges";
import { BatchPanel } from "@/components/batch-ui";
import { HomeHero } from "@/components/home-hero";
import { HowItWorks } from "@/components/how-it-works";
import { VentureAttribution } from "@/components/venture-attribution";
import { buttonVariants } from "@/components/ui/button";
import { getData, type Data } from "@/lib/data";
import { formatDateTime, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

function VentureCard({ venture, data }: { venture: Venture; data: Data }) {
  const { store, params } = data;
  const raise = raiseProgress(store, venture, params);
  const open = openRfes(store, venture.id).filter((r) => r.kind === "request" && !r.gtm).length;
  const cap = capTable(store, venture, params);
  const q = venture.quarters.at(-1);
  const killed = venture.status === "killed";
  const attr = ventureAttribution(store, venture, params);
  return (
    <Link
      href={`/v/${venture.slug}`}
      style={{ "--accent-color": venture.accent } as React.CSSProperties}
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-xl border border-line bg-white p-5 shadow-xs transition hover:border-line hover:shadow-md",
        killed && "opacity-80",
      )}
    >
      <span className="absolute inset-x-0 top-0 h-1 bg-[var(--accent-color)]" />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-lg font-semibold tracking-tight">{venture.name}</h3>
          <VentureAttribution mark={attr.mark} className="text-xs" />
        </div>
        <StatusBadge status={venture.status} />
      </div>
      <p className="mt-3 line-clamp-2 text-sm text-metal">{venture.tagline}</p>
      <div className="mt-4 flex flex-wrap gap-1.5">
        <ObjectiveBadge objective={venture.objective} explain={false} />
      </div>
      <dl className="mt-5 grid grid-cols-3 gap-3 border-t border-line pt-4 text-sm">
        <div>
          <dt className="text-xs text-metal">Seats</dt>
          <dd className="font-medium tabular-nums">
            {raise.sold}/{raise.needed}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-metal">Open asks</dt>
          <dd className="font-medium tabular-nums">{killed ? "—" : open}</dd>
        </div>
        <div>
          <dt className="text-xs text-metal">{q ? `Revenue ${q.quarter}` : "Holders"}</dt>
          <dd className="font-medium tabular-nums">{q ? formatUsd(q.revenueUsd) : cap.holderCount}</dd>
        </div>
      </dl>
      {venture.status === "pitched" && (
        <div className="mt-4">
          <div className="h-1.5 overflow-hidden rounded-full bg-mist">
            <div className="h-full rounded-full bg-[var(--accent-color)]" style={{ width: `${raise.pct}%` }} />
          </div>
          <p className="mt-1.5 text-xs text-metal">
            {formatUsd(raise.raisedUsd)} of {formatUsd(venture.minRaiseUsd)} needed
          </p>
        </div>
      )}
      <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-ink">
        {killed ? "Read what went wrong" : "Open venture"}
        <ArrowRight className="size-4 transition group-hover:translate-x-0.5" />
      </span>
    </Link>
  );
}

export default async function Home() {
  const data = await getData();
  const { store, params, viewer, member } = data;
  const v0 = store.ventures.find((v) => v.isProtocol)!;
  const batch = currentBatch(store);
  const inBatch = new Set(batch?.status === "closed" ? [] : (batch?.ventureIds ?? []));
  const others = store.ventures.filter((v) => !v.isProtocol && v.status !== "generated" && !inBatch.has(v.id));
  const order = ["pitched", "operating", "customer1", "distributing", "funded", "formed", "dormant", "killed"];
  others.sort((a, b) => order.indexOf(a.status) - order.indexOf(b.status));
  const inbox = member ? inboxFor(store, viewer).length : 0;
  const v0Open = openRfes(store, v0.id).filter((r) => r.kind === "request" && !r.gtm).length;
  const announced = store.cohorts.filter((c) => c.status === "announced" && c.id !== batch?.id).sort((a, b) => a.number - b.number)[0];

  return (
    <>
      <HomeHero />

      <div className="space-y-10">
        <section id="how-it-works" className="scroll-mt-20 space-y-4">
          <h2 className="text-xl font-semibold tracking-tight">How it works</h2>
          <HowItWorks params={params} />
        </section>

        {batch && <BatchPanel cohort={batch} data={data} />}

        {announced && (
          <Link
            href={`/batches/${announced.number}`}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-dashed border-line bg-mist px-5 py-4 text-sm transition hover:border-metal"
          >
            <span>
              <strong>{batchLabel(announced.number)}</strong> is coming: {announced.ventureIds.length} new ventures,
              names hidden until {formatDateTime(announced.opensAt)}. Verified members get first look from{" "}
              {formatDateTime(earlyAccessAt(announced, params))}.
            </span>
            <span className="inline-flex items-center gap-1 font-medium">
              See teasers <ArrowRight className="size-4" />
            </span>
          </Link>
        )}

        <section id="ventures" className="scroll-mt-20 space-y-4">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-semibold tracking-tight">Ventures</h2>
              <p className="text-sm text-metal">Open a venture to see its asks, seats and progress.</p>
            </div>
            {member ? (
              <Link
                href="/inbox"
                className="inline-flex items-center gap-2 text-sm font-medium text-seaglass hover:text-seaglass-deep"
              >
                <Inbox className="size-4" />
                {inbox ? (
                  <span>
                    {inbox} ask{inbox === 1 ? "" : "s"} waiting
                  </span>
                ) : (
                  <span>Inbox</span>
                )}
              </Link>
            ) : null}
          </div>

          <section
            style={{ "--accent-color": v0.accent } as React.CSSProperties}
            className="rounded-2xl border border-line bg-white p-6 shadow-xs"
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-xl font-semibold tracking-tight">{v0.name}</h3>
                  <StatusBadge status={v0.status} />
                </div>
                <p className="max-w-2xl text-sm text-metal">{v0.tagline}</p>
                <p className="text-xs text-metal">
                  Run by @{v0.stewardHandle}. Any verified member can answer its questions — no seat needed.
                </p>
              </div>
              <Link href={`/v/${v0.slug}`} className={buttonVariants({ variant: "outline" })}>
                {v0Open} open question{v0Open === 1 ? "" : "s"} <ArrowRight />
              </Link>
            </div>
          </section>

          {others.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-base font-semibold tracking-tight text-ink">Past ventures</h3>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {others.map((v) => (
                  <VentureCard key={v.id} venture={v} data={data} />
                ))}
              </div>
            </div>
          )}
        </section>
      </div>
    </>
  );
}
