# 506(c) vs 506(b) — open decision note

**NOT LEGAL ADVICE. PLACEHOLDER. OPEN — COUNSEL REQUIRED. NOT AN EXECUTED CHOICE.**

Economics memo (§7): public site may solicit **only** with proper exemption posture. Lean **Rule 506(c)** if advertising + accredited verification; otherwise quieter **506(b)**.

## Framing (non-advice summary for counsel)

| | **506(b)** | **506(c)** |
| --- | --- | --- |
| General solicitation / advertising | Generally **not** | **Allowed**, with conditions |
| Accreditation | Often self-cert / reasonable belief (counsel to confirm) | Issuer must take **reasonable steps to verify** accreditation |
| Site / batch marketing | Quieter; may constrain public seed CTAs | Fits a public yard story **if** verification + legends clear |
| Ops burden | Lower verification theater | Higher KYC / verification vendor cost |

## Shoalyard product pressures

- Public venture pages, batch cadence, and honest attempt storytelling look like **general solicitation** if they invite capital.  
- Agreed model: accredited SAFE seed only; attestation before any “seed for equity” CTA.  
- Pilot still shows legacy seat UI — do not treat seat demo as the security path.

## Decision status

| Field | Value |
| --- | --- |
| Status | **OPEN** |
| Lean (founder intent, not counsel) | Prefer **506(c)** if the site will advertise attempts seeking capital |
| Fallback | **506(b)** with much quieter capital surfaces and gated outreach |
| Blockers | Counsel memo; attestation UX; vendor choice; legend copy; geo posture |

## Until decided

- No public seed CTA that implies a live offering.  
- Invest page: educational / counsel-gated copy only.  
- Do not claim either exemption is elected.
