---
name: Agent Ventures pilot
overview: "Build the Agent-Operated Ventures pilot from the uploaded zip around a short founding constitution, a handful of primitives, and amendable parameters, so the system starts with as few rules as possible. Claude-only operator agent, seeded Next.js demo, Quiver Supabase project untouched."
todos:
  - id: ingest-doc
    content: Copy CLAUDE.md, docs/working-model.md, and .gitignore from the zip. Do not copy the nested .git or run bootstrap.sh.
    status: pending
  - id: constitution
    content: Write the eight-article CONSTITUTION.md first, and a params registry where every other number is a versioned, amendable default.
    status: pending
  - id: primitives
    content: Create the pnpm workspace and packages/schema with the primitives, their states, and the Amendment type.
    status: pending
  - id: seed-public-page
    content: Seed three ventures, the Protocol with the doc's open questions as RFEs, and ~25 members; build /v/[slug].
    status: pending
  - id: member-flows
    content: Add fake seat checkout, inbox, onboarding, steward queue, ledger tables, report JSON, and the amendment vote.
    status: pending
  - id: protocol-agent
    content: Implement simulate with the default classifier and N policy read from params (scripted fallback, Claude Sonnet 5.5 when a key is set).
    status: pending
isProject: false
---

# Agent Ventures pilot

## Principle

Few rules, fixed. Everything else is a default the members can change.

Three layers, from hardest to change to easiest:

**Naming.** The Protocol is the body: members answer its questions, the protocol fee goes to it, its holders vote, and it keeps the registry and ledger. The Constitution is its founding document; Parameters are its amendable defaults. It was called Venture 0 until Constitution 1.3; the seeded venture's slug is `protocol` (the old `/v/venture-0` redirects), the flag is `isProtocol`, and request ids keep their `rfe-v0-*` prefix. /protocol labels the two versions separately: Constitution v1.3 and Parameters v1.x.

1. **Constitution** — eight short articles. Changed only by a Protocol supermajority with a notice period.
2. **Parameters** — every number and policy the brief and doc name (fees, pool split, N baselines, classifier gates, embargo length, vote thresholds). Each ships with the doc’s or brief’s pilot value, a one-line reason, and the RFE that can change it. Holders change them by simple vote.
3. **Open questions** — things nobody has decided. They are live RFEs on the Protocol, not rules.

The brief asked for a `PROTOCOL.md` with ten sections of numbered rules. This replaces it with `CONSTITUTION.md` plus a generated parameters page. Rules that the working model describes in detail (the reporting table, the reserved-matter list, the redaction reasons) ship as parameter defaults, not as articles.

## Framing: a protocol, with fund mechanics inside it

Agent Ventures is an open standard for agent-operated ventures, with a reference implementation and a public ledger. Some of its parts work like a fund's, and the build keeps them, but no fund vocabulary appears in the code, copy, or docs.

What we borrow, under our own names:

- The cohort vehicle works like a vintage. Its interests come only from work, never from cash; seat money never flows into it.
- Reserved matters with holder votes do the job of an advisory committee.
- The fixed-schema quarterly report does the job of investor reporting.
- One series per venture under a management entity is the likely legal shape. Counsel decides; the build doesn't.
- The founder's grant plus the steward seat stay exactly as described: no extra economics, no extra powers.

Banned words in UI copy, the README, `CONSTITUTION.md`, and seeded text: fund, LP, LPA, GP, carry, SPV, investor, portfolio, investment committee. Allowed exceptions: the Protocol legal-structure question may name structures for counsel, and the working model in `docs/` is kept unchanged. A test greps the app copy and seed for the banned list.

Copy by audience, all describing the same thing:

- Members (home page, venture pages, onboarding): "Answer requests from agent-run ventures. Get paid in a share of their profits."
- Counsel (README legal note, the legal-structure RFE): "Compensatory profits interests in series LLCs, with a protocol fee to the management entity."
- X and press (`/protocol` header, GTM drafts): "An open standard for agent-operated ventures, with a reference implementation and a public ledger."

The legal-structure RFE recommendation reads: "Compensatory profits interests in one series LLC per venture, with a protocol fee to the management entity; counsel to confirm."

The schema stays neutral (`Venture`). Nothing is built for capital accounts or fund-style commitments.

## What a venture is: a zero-to-one experiment

Each venture is an experiment to prove that a named buyer will pay. It is priced honestly: every pitch carries a computed 12-month business plan (`plan.ts`) and a proof budget that covers the whole proof period, including its share of the shared back office. Pivoting stays a monthly-review outcome, not an ending. A venture ends one of three ways:

1. **Shut down.** The kill rule fires or the steward stops it. The post-mortem and its lessons stay public.
2. **Keep running.** The agent keeps operating it, and profit goes to the people with vested units.
3. **Hand off.** An entrepreneur adopts it and takes it forward with their own money. The venture must meet the hand-off checklist (governed parameters `HANDOFF_*`). The entrepreneur submits an offer, the agent summarises it, the steward checks that it follows the rules, and unit holders decide by the reserved-matter vote Article 5 calls "selling it". The cash for contributors is paid by vested units, with ledger rows; seats never share in a hand-off. The status becomes "handed off", and the page notes that its mark likely ends. Whether the price is fixed by formula or set by bids is an open request (`rfe-v0-handoff-price`). Seeded example: an offer to adopt Dockside.

Every venture runs on one shared back office (`services.ts`): one legal umbrella, one bank and payments setup, shared books, insurance, mailboxes and tools, billed to each venture at cost and published on `/protocol/services`.

The legal-structure RFE also carries a "Considered and set aside" note for counsel: "Making the $10 seat an option to acquire a profits interest at formation. Set aside because an option on a possible security is likely a security itself, the sale happens at payment rather than at formation, a paid-for interest is not compensatory, and it would contradict Articles 1 and 2. If members are ever to buy upside for cash, do it as a registered offering (Regulation Crowdfunding or Regulation A) at the Protocol level."

## Seat price, sharing, scarcity and the proof (built Oct 31, 2026)

Decision notes: `docs/plans/seat-price-per-venture.md`.

- **Per-venture seat price** (`seat-price.ts`). Code computes the band: the top is the proof budget divided by the people the venture runs on (its roster, or the seats needed to cover its requests), never above the Protocol maximum. The agent proposes a price inside the band, backed by tagged claims about the roster, the TAM and the ICP. If the proposal falls outside the band or comes without claims, code's own pricing rule sets the price. The steward signs off, and seats stay closed until then. Seats needed = proof budget ÷ price, rounded up, and never below the headcount. The learning page tracks seats sold against seats needed by price and customer type. Nothing caps the seat count: the market decides, and a miss means a full refund. The deck's seat maximum (the minimum × `SEAT_MAX_MULTIPLE` 1.5; 150 for legacy decks) is a real limit, enforced by `buySeat`.
- **Sharing for everyone** (`sharing.ts`). Every public venture, batch, deck and Q&A page has a share action: copy link, native share, X and LinkedIn posts, and an Open Graph card for each venture and batch. The embeddable badge is not built yet. Visitors get an anonymous ref code in a cookie, which is linked to a member when they join. Attribution runs from visit to candidate, qualified, seat and role. A referral earns `REFERRAL_UNITS` (0.5) once, only when the referred person fills a roster role, is verified and does the work. Seat sales never earn anything. Referrers see their own funnel.
- **Real scarcity** (`scarcity.ts`, `waitlist.ts`). Everything shown is derived from the store (Article 8): "N of M seats left", a countdown to the close or the public opening, "Members got first look Nh ago" (`EARLY_ACCESS_HOURS` 24), "Roles: X of Y claimed", and code-name teasers for announced ventures. When a venture is full, a waitlist replaces "Take a seat"; freed seats notify the first in line. A waitlist for the next batch is notified, by code name only, at announcement and again when the batch goes live. Each share landing has a CTA: get notified, claim a role, or get verified. The learning page shows the funnel by channel and by venture.
- **Constrain the proof, not the idea** (`proof.ts`, `proof-plans.ts`). Every idea and deck has a proof plan, and each task is marked agent, member request or contractor. Code rejects a proof that needs an employee (while `EMPLOYMENT_ALLOWED` is off), a licence the Protocol doesn't hold (it holds none), or someone in person when the task is the agent's. The agent then reshapes the proof:
  - a hire becomes contractor work with a price and an end;
  - a licensed step stops at signed letters of intent, and the plan becomes "hand-off expected";
  - a visit goes to a paid local contractor.

  Each reshape stays on the plan, and a decision logs it under the code name while the batch is announced. The deck's "Who does the work" slide shows "Proof run by", "Long-term operator: agents / hand-off expected" and "What an entrepreneur would need to build". Seeded examples:
  - Bid Desk's "hire a bid coordinator" becomes contractor work;
  - the library idea Cert Chase's quoting step needs an insurance producer licence, so it stops at commitments.

## The constitution

Draft text for [`packages/protocol/CONSTITUTION.md`](packages/protocol/CONSTITUTION.md). Each article is one or two sentences in the file.

1. **Agents operate, people contribute.** An agent founds and runs each venture. People earn profits interests for work they do, never for money they pay.
2. **Seats are access, not investment.** A seat buys the right to receive a venture’s requests. A venture that misses its minimum raise ends and owes nothing.
3. **Everything is logged.** Every decision, with the agent’s reasoning, goes on the public log. Anything withheld is logged with the reason and a release date.
4. **A human can stop it.** Each venture has a steward who can kill it and must approve any action the parameters mark irreversible.
5. **Owners decide what the agent cannot.** A short list of matters goes to holders, weighted by vested interest. The agent proposes and never votes.
6. **Amendment.** Parameters change by a holder vote. These articles change only by Protocol supermajority after notice. A venture keeps the version it was formed under unless its holders opt in.
7. **The mark follows the rules.** A venture carries “[Name], an Agent Ventures venture” only while it follows these articles.
8. **Honest and lawful.** The agent never breaks the law, never deceives anyone, always says it is an agent, and stops and asks a human when it is unsure.

The brand is **Agent Ventures**. Code still keeps it out of identifiers (`protocol`, `isProtocol`) and reads it from one parameter, `BRAND_NAME = "Agent Ventures"`, so a rename is an amendment, not a refactor. The mark wording is also a parameter. The Protocol name question stays open with its recommendation changed to “Agent Ventures (working name)”, so members can still weigh in and counsel can check the mark.

## Primitives

Kept small, in [`packages/schema`](packages/schema). Each is a type, a JSON Schema, and a state enum with allowed transitions.

- `Venture` — `Generated → Pitched → Funded → Formed → Operating → Customer1 → Distributing`, or `Dormant`, or `Killed`
- `Member` — handle, public attributes, a profile graph, a public reputation tier stub
- `RFE` — the one request shape for everything, including governance. Types: Judgment, Knowledge, Access, Credibility, Action, Capital, Stewardship. `Drafted → Posted → Quorum → Resolved → Scored`
- `Response`
- `Grant` — `Offered → Accepted → Vested → Distributing`, or `Forfeited`
- `Decision` — bin `auto | advisory | gated`, reasoning, embargo flag, outcome
- `LedgerEntry` — seats, grants, distributions, redactions, as append-only rows
- `Amendment` — a parameter change: old value, new value, the RFE that passed it, effective version
- `Cohort` and `Lesson` — the learning loop (see below)
- `Classification` — the standard classification (end market, sub-vertical, customer, business model, go-to-market, market type, geography); a venture carries it as steward-confirmed tags, and gains a `memo`

`Report` is a generated view of the ledger, not a stored primitive.

Governance is not a separate system. A reserved matter or an amendment is an RFE with `kind: "governance"`, a voting window, and votes weighted by vested interest.

## Parameters

One file, [`packages/schema/params.ts`](packages/schema/params.ts), holds every number. Components import from it. Each entry looks like:

```ts
protocolFeePct: {
  value: 10,
  reason: "Founding steward's pilot choice; brief said 8%, working model ~5%.",
  governedBy: "rfe-v0-cohort-and-fee",
}
```

Pilot defaults, all amendable:

- Protocol fee 10% of profits interests, non-voting, pari passu. Pass-through costs off the top.
- Contributor pool of 100 units: steward 5, cohort vehicle 25, request reserve 70; at most 15 on one request. There is no seat slice: buying a seat never earns units, so paying is never a condition of earning an interest.
- Seat price per venture, inside a code-set band: `SEAT_PRICE_MIN_USD` $10 to `SEAT_PRICE_MAX_USD` $100 (protected; raising it waits for counsel). Ventures pitched before per-venture pricing keep $10 (Article 6).
- Classifier gates: spend above `GATE_SPEND_USD`, any contract, any pricing change, outbound to a new domain. `ADVISORY_CONFIDENCE` threshold.
- N baselines by type from the doc, stakes multiplier, agreement and divergence thresholds.
- Reserved-matter list and its thresholds from the doc (simple majority, supermajority for objective change and sale).
- Embargo days, vote window, quorum, daily push cap.
- Model ids: `claude-sonnet-5-5` for the operator loop and drafts, `claude-haiku-5-5` for extraction and cluster checks. No xAI or Grok client in the repo.

The fee stays visible as a choice: the default is 10%, the parameters page shows the brief’s 8% and the working model’s ~5% as context, and the Protocol fee and cohort-ratio RFE stays open so holders can amend it.

## You, the founding steward

Your handle is **@MP** and your display title is **Founding Steward**. "Managing Partner" was dropped because it is fund vocabulary; the title is a parameter (`FOUNDING_STEWARD_TITLE`) if you want it back. You are the steward of every seeded venture and of the Protocol by default. Your legal name does not appear anywhere in the repo or the UI.

The title adds no powers. The constitution gives the steward a kill switch and sign-off on irreversible actions, and nothing else; the agent still operates and holders still decide reserved matters.

- One parameter, `FOUNDING_STEWARD_HANDLE = "MP"` (shown as @MP), overridable by an environment variable of the same name. It sets the handle shown on every steward line, the steward console, and the Protocol cap table.
- You hold the 5-unit steward slice in each venture and a founder’s grant in the Protocol, as the working model describes: the steward seat and that grant, nothing more.
- The Protocol question “Your role: founding steward and largest contributor, or operator” is seeded as **Resolved: founding steward and largest contributor**, with you as the one respondent. It is the first entry in the Protocol decision log.
- The “view as” switcher opens on your handle, so `/steward` works on first load. Switching to a member handle shows the member view.
- Replacing the steward stays a reserved matter in the parameters, so the default can be voted out later.

## The three things that decide whether this works

### 1. Viable first ideas

#### Classification: one standard vocabulary, one shared memo

Ideas are classified the way any operator would describe a company, not by founder archetype. (This replaced the earlier "phenotypes" design.) Every idea and venture carries the same standard classification, defined as zod enums in `packages/schema/src/primitives.ts` with the vocabulary in the `TAG_VOCAB` parameter:

- **End market:** Fintech, Healthcare, Commerce and retail, Software and IT, Media and entertainment, Education, Industrials and logistics, Real estate and construction, Energy and climate, Consumer services, Professional services, Public sector. A free-text **sub-vertical** narrows it (e.g. "dental practices").
- **Customer:** Consumer, Small business, Mid-market, Enterprise, Government. B2B, B2C and B2B2C are derived from it (a business customer in a consumer end market is B2B2C).
- **Business model:** Subscription software, Marketplace, Transactional or payments, Usage-based, E-commerce or direct-to-consumer, Advertising, Tech-enabled services, Data or licensing.
- **Go-to-market:** Self-serve, Sales-led, Partner or channel, Community and content.
- **Market type:** Existing market, Resegmented, New market. (The old "new category" archetype maps to New market; "commodity executed to perfection" maps to Existing market.)
- **Geography.**

The agent proposes the classification when it writes an idea; the steward confirms or corrects it in the tagging queue (see below). Sub-verticals are free text. A new standard value joins only by a Protocol vote ("add a classification value"); the seed has one open, end market "Agriculture and food". Nobody screens ideas for taste: the classification describes an idea, it doesn't rank it.

Every idea fills the same light memo, which is the logic that governs it:

- **Problem:** the pain, and what the buyer does today.
- **Customer:** who pays, and who in the network reaches them.
- **Market size:** a rough, honest count of buyers and spend.
- **Why now:** what changed that makes it possible or necessary.
- **Competition:** what the buyer uses instead, including doing nothing.
- **Unit economics:** price against the cost to serve one customer.
- **Kill metric:** what evidence, by what date, ends it.

The memo is shown at the top of each venture page, next to its classification and readiness panel.

Batches spread across end markets and business models rather than betting on one. The learning loop tracks outcomes by classification (cleared liftoff, meaning the minimum raise was met; time to first customer; survival) and shifts the next batch's slots toward what has worked, while always keeping a floor for every end market and business model with an idea ready and a share for the least-tried pairs (`BATCH_MIN_SLOTS_PER_SEGMENT`, `BATCH_EXPLORATION_SHARE`). That is how the system learns which kinds of idea hit without anyone deciding in advance.

#### The crowd decides, the agent discloses

No one screens ideas, including you and the agent. The crowd is the filter: members vote with seats, and the market votes with a first purchase. The agent's job is to make that vote informed, not to pre-empt it.

Before a batch, every idea publishes a readiness panel next to its memo. These are disclosures, not gates:

- whether a plausible seat count covers the budget to first customer
- how many qualified members can reach the named buyer segment
- the result of a public demand check: a Knowledge request any qualified member can answer ("would your team pay for this, and roughly what?")
- any adopted lessons the idea contradicts, with the agent's reason it thinks this case is different

An idea with weak readings still goes into a batch if the agent proposes it; members see the readings and decide. The only hard stops are the constitutional ones: Article 8 (lawful, honest) and the conduct screen. Members can flag any idea or post, and flags are resolved by a member vote on the flag rather than by the steward, with the steward only certifying that the result follows the constitution.

### 2. Sourcing the right members (the liftoff)

Every pitched venture declares a liftoff roster: the member types it needs before it can reach first customer (for example, two buyer-side operators, one domain expert, one introducer). It is shown on the venture page with filled and open slots.

- Open slots, and any request that fails to reach quorum, become network gaps.
- Each gap produces recruiting drafts for X and LinkedIn aimed at that segment, gated for a human to send.
- Attribution records which draft brought which qualified member, and whether that member's answers were later followed and proved right.
- The learning loop reports time to fill a roster, gap fill rate by segment and channel, and which member types mattered at which stage. Those become lessons that shape the next roster.

### 3. Not repeating mistakes

Lessons are checked before actions, not only read afterwards. Before the agent spawns, prices, sets kill rules, or takes a decision, it runs a repeat-mistake check against adopted lessons with matching tags. If the planned action contradicts one, the classifier moves the decision up a bin (auto to advisory, advisory to gated) and logs "contradicts L-014" with the lesson linked. Every killed venture must publish a structured post-mortem before its batch closes, so every failure produces lessons.

Operational sign-off stays with you for the pilot: spend above the gate, contracts, pricing changes, new outbound domains, public posts, and decisions escalated by the repeat-mistake check. Article 4 is unchanged. Spreading sign-off to a holder panel is a later amendment, not part of this build.

## Classification and tagging (your job)

You don't police ideas; you classify them, so the learning loop can tell what works where. The classification axes are what every statistic and lesson is cut on.

- **Axes:** the standard classification above (end market, sub-vertical, customer, business model, go-to-market, market type, geography). For outcomes: stage reached and kill reason (no demand, could not reach buyer, price, execution, legal, ran out of time).
- **Who tags:** the agent proposes a classification for every idea and venture as it writes it, and end market and customer tags for requests (Claude Haiku when a key is set, rules otherwise). You confirm or correct them in the tagging queue on `/steward`, picking from the standard lists. Confirmed values are marked as yours; unconfirmed ones show as agent-proposed. Tagging never blocks anything.
- **Vocabulary:** each axis is a list in params. Sub-verticals are free text. You can merge one standard value into another; renaming one, or adding a new end market, customer, business model, go-to-market or market type, needs a Protocol vote. Every change is logged, so history stays comparable.
- **Where it shows up:** `/learning` cuts the public index by any axis and by the standard cut, business model · customer · end market (for example, "Subscription software · Small business · Healthcare: 2 of 3 reached their minimum"). Lessons carry the classification of the evidence they came from, and the repeat-mistake check matches on it, so a lesson about enterprise sales only fires for enterprise ventures.
- **Seed:** every seeded venture, request and lesson ships with confirmed tags, plus a few agent-proposed ones waiting in your queue.

## Conduct

Article 8 is the hard line. It is constitutional, so it changes only by Protocol supermajority after notice, not by an ordinary parameter vote. The working detail is a conduct checklist in params that holders can tighten, but not loosen below the article.

Every outbound draft and every decision passes a conduct screen before it is taken:

- **Rule checks:** agent disclosure present in outbound copy; no invented testimonials, customer counts, reviews or personas; no claims unsupported by the ledger; no impersonating a person or brand; no return or investment language near seats.
- **Regulated-activity flags:** securities, lending, gambling, medical, legal and tax advice, employment, and data about minors. A flag makes the decision gated and adds a note for counsel.
- **Model check:** with a key set, Claude Haiku reviews the text against the checklist and returns pass or concern with a reason. Concerns escalate the decision; they never silently rewrite it.

Members can flag any public decision or post as a conduct concern. Flags go to `/steward`, and a confirmed breach is logged publicly. Repeated breaches withdraw the mark (Article 7). The agent's own refusals are not the safety mechanism; the screen, the gate, and the public log are.

## Member qualification

The onboarding interview is a required qualification step, not a welcome screen. A member gets no requests until it is done.

- `Member.qualification`: `pending → qualified`, or `declined`. Seat holders start at `pending`.
- The agent runs the interview: role, company, buying authority, tools, verticals, and who they can reach. Free-text answers are structured with Claude Haiku when a key is set, and by a heuristic otherwise.
- Each attribute is tagged `self-reported` or `verified`, with the source that verified it. Only verified attributes count toward the profile-diversity check.
- Two linked accounts, weighted, plus the steward:
  - **LinkedIn** verifies the professional attributes: role, company, seniority, industry. It carries the heavier weight for those, because they are what Judgment, Knowledge, and Access requests route on.
  - **X** verifies the handle and the public reach that matters for recruiting and Credibility requests.
  - **Steward review** can verify any single attribute from `/steward`.
- Weights live in params (`VERIFICATION_WEIGHTS`, for example LinkedIn 0.5, X 0.3, steward 0.2 per attribute, and `QUALIFY_MIN_SCORE`), so members can amend them. A member's public profile shows a verification badge per source and a verified-share bar, never the linked account or the legal name. The LinkedIn name stays private unless the member opts in on a Credibility request.
- Linking is a mock flow in the pilot ("Connect LinkedIn" and "Connect X" buttons that ask for a profile URL and handle and mark them pending until a steward confirms them). It sits behind a `VerificationProvider` interface so real OAuth can replace it. One constraint for later: LinkedIn's standard sign-in only returns name, email and photo. Verifying employer and title needs LinkedIn's Verified on LinkedIn partner program, or steward review of the profile URL. The README says this.
- Qualifying assigns the member a profile cluster and opens requests to them. It earns no units by itself; units come only from answering requests and stewardship.
- The interview answers feed routing: the first request a new member sees is picked by matching their profile to open requests.

## Learning loop

Every cohort learns from the ones before it. The protocol owns that learning as a commons: it is written to the Protocol's registry, every new venture inherits it, and it is public like everything else.

Two new primitives:

- `Cohort` — the ventures launched in one period. Open while ventures are being spawned, closed when the period ends.
- `Lesson` — a plain-language card a member can read in ten seconds. Its fields: a topic in plain words (Pricing requests, How many answers to wait for, Why ventures end, Whose advice to weight, Finding members, Reaching buyers, Which ideas work, When the agent asks first); a one-sentence headline with the takeaway; what happened, in two or three sentences naming the venture, the event and the number; what we do differently, the concrete change later ventures inherit; how sure we are (Strong, Moderate or Early signal, with a plain reason such as "one venture, 2 answers"); what it applies to (its classification tags plus a stage such as "Before the first customer"); evidence links; the cohort it came from; and a status of `proposed`, `adopted`, or `retired`. The metric and numeric confidence stay internal: they refresh the lesson and set the how-sure level, and are never shown.

How lessons are made:

- A learning pass runs whenever a venture is killed, reaches first customer, or a cohort closes. It aggregates decisions, inputs, and outcomes into plain statistics: clearing units by request type (accepted offers and counters), time to fill, responses needed versus agreement, which clusters' answers were followed and proved right, how long ventures took to hit kill signals, and seats and responses by recruiting draft.
- With a key set, Claude Sonnet rewrites the template cards in plain words, keeping every number, the topic, the stage and the how-sure level. Without a key, the templated cards come from the same statistics in the same shape.

How lessons are used:

- When the agent spawns a venture, prices a request, sets N, writes kill rules, or drafts recruiting copy, it reads the adopted lessons as priors. It cites the lesson ids it used in the decision's reasoning, so the public log shows "Follows L-001: An introduction to a buyer is worth about 7 units".
- Lessons act only inside the parameters. If a lesson implies changing a parameter (for example, the advisory threshold), the loop posts a parameter-amendment vote instead of changing it. Learning proposes, holders decide. No new constitutional rule is needed: Article 3 gains one clause, "and the log is a commons every later venture learns from."
- `pnpm simulate -- --spawn` generates a new venture in the open cohort, conditioned on adopted lessons and on what the member graph can uniquely reach.

What you can see:

- [`/learning`](apps/venture): cohorts, lessons with evidence links and status, and the public index (survival rate by cohort, median time to first customer, request clearing prices by type, distribution yield).
- Every venture page has a "Lessons it starts with" panel listing the headlines of the lessons it was spawned or run with. `/learning` groups lessons by topic and filters them by classification and stage.
- Seed: cohort 1 holds the killed venture plus one older closed venture, and has produced a handful of adopted lessons. Cohort 2 holds the live ventures, and their seeded decisions cite those lessons.

## Batches

Each cohort ships as a numbered batch. The name is from Y Combinator; the mechanics keep the MSCHF-style build-up, short window and public record. Unlike a YC batch, nobody selects the ventures: the crowd does, with seats.

- A cohort is presented as **Batch 001, 002, ...** The stored primitive is still `Cohort`; "batch" is how it looks.
- Batch states: `announced → live → closed`.
  - **Announced:** a countdown, the number of ventures, and one-line teasers with codenames. Pitches and budgets stay hidden until it goes live.
  - **Live:** every venture's seat window opens at once and runs for a fixed time. A venture that misses its minimum raise in the window dies at zero cost, which is already the rule.
  - **Closed:** the batch page becomes the record: which ventures funded, which died, and the batch's lessons, published as batch notes from the learning loop.
- Exclusivity comes from timing, not gatekeeping. Qualified members get an early-access window before the public one. That rewards finishing qualification and keeps membership open.
- The agent drafts a teaser sequence for X for each batch, as steward-gated Action requests like every other post.
- Every number is a parameter: `BATCH_WINDOW_HOURS`, `EARLY_ACCESS_HOURS`, `VENTURES_PER_BATCH`, `BATCH_ANNOUNCE_LEAD_DAYS`.
- Routes: `/batches` lists every batch, and `/batches/[n]` is one batch's countdown, live board, or record. The home page leads with the current batch.
- Seed: Batch 001 closed (cohort 1, with its killed venture and lessons), Batch 002 live (the current ventures), Batch 003 announced with a countdown.
- Copy guardrail: hype is about the ventures and the window, never about returns. Every live batch repeats "A seat is access to requests, not an investment" next to the buy button.

## What gets built

pnpm workspaces:

- [`packages/schema`](packages/schema) — primitives, schemas, `params.ts`
- [`packages/protocol`](packages/protocol) — `CONSTITUTION.md`, the classifier and N engine as default policies that read params, and [`agent`](packages/protocol/agent) with `simulate`
- [`apps/venture`](apps/venture) — Next.js (App Router), TypeScript, Tailwind, shadcn/ui
- [`docs`](docs) — `working-model.md` and `CLAUDE.md` from the zip, unchanged

```mermaid
flowchart TB
  constitution[Constitution: 7 articles] --> params[Parameters: amendable defaults]
  params --> agent[Claude operator]
  agent --> decision[Decision on public log]
  agent --> rfe[RFE]
  rfe --> grant[Grant]
  rfe -->|governance kind| amendment[Amendment]
  amendment --> params
```

Data stays seeded JSON behind a small repository, with SQL migrations as the later Supabase seam (RLS on, no `user_metadata` in policies). The existing **Quiver** project (`vzftkfkktnqcfpahndnn`) is not touched. Demo login is a “view as @handle” switcher.

Seed: a pitching venture, an operating venture with open RFEs and grants, a killed venture with its post-mortem, the Protocol with 16 of the doc’s open questions as live RFEs and the steward-role question resolved, about 25 members, and you as the steward of all four.

Screens:

1. [`/v/[slug]`](apps/venture) — pitch, objective, seats versus minimum raise, lifecycle status, open RFEs, decision log with reasoning, cap table, latest report. Built first.
2. Fake $10 seat checkout, then the qualification interview (below), then an RFE waiting in the inbox.
3. [`/inbox`](apps/venture) — structured, short-text, and voice answers; accept or counter the unit offer; N progress.
4. [`/steward`](apps/venture) — approve or reject gated decisions, kill switch, recruiting drafts as Action RFEs for a human to post.
5. Ledger tables per venture and per member.
6. [`/v/[slug]/report`](apps/venture) — generated quarterly report, on screen and as JSON.
7. [`/protocol`](apps/venture) — the eight articles, the parameters table with each value’s reason and change history, and one amendment vote in progress. This replaces the separate governance screen.

`pnpm simulate` advances one seeded venture on a fake clock and writes new decisions and RFEs into the store the public page reads. It replays a script with no `ANTHROPIC_API_KEY`, and calls Claude when the key is set.

Not built: mobile app, real payments, series-LLC automation, push. Calibration is a simple stub that feeds the learning loop. Email is a logged “would notify” row.

## Done when

Someone opens a demo venture and understands it in a couple of minutes, takes a seat, answers an RFE, sees the grant on the ledger, sees the agent’s next decision on the public log, then opens `/protocol` and finds eight articles, a parameters table, and the Protocol asking them whether those defaults are right. On `/learning` they can see which lessons from earlier cohorts shaped the venture they just joined. The dev server stays running on an uncommon port, with a README.

This planning session runs on Grok. To have Claude write the code, switch this agent’s model to Claude in Cursor before telling it to build.
