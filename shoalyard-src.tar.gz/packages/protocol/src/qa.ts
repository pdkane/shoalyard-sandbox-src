import type { Answer, Citation, Claim, Member, ParamValues, PitchDeck, Question, SlideKey, Store, Venture } from "@av/schema";
import { seatWindow } from "./batches";
import { quotedLessons, screenText } from "./conduct";
import { allClaims, amendDeck, claimById, deckVersion, latestDeck, slideOf, type AmendInput } from "./deck";
import { hasSeat, issueGrant, ensureMember, ledger, logDecision, memberByHandle, ProtocolError, ventureBySlug, type RfeDraft } from "./ops";
import { resolveParams } from "./params";
import { rosterFill } from "./roster";
import { businessPlanFor, planSummary } from "./plan";
import { currentRuleLine, seatMath } from "./sizing";
import { classificationOf } from "./tags";
import { newId } from "./util";

/** Shared content words a claim needs with a question before the script cites it. */
export const QA_MIN_MATCH = 2;

/** Ask-slide facts computed by code; they resolve without a claim in the deck. */
export const ASK_REFS = ["ask-seats", "ask-refunds", "ask-roster", "ask-seat-money"] as const;

const LEGAL_REQUEST = "rfe-v0-legal-structure";

/* ---------- who may ask, and when ---------- */

export type QaWindow = { state: "none" | "early" | "open" | "read-only"; reason: string };

/** Opens with early access, publicly with the seat window, and stays open while the venture is live. */
export function qaWindow(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): QaWindow {
  if (venture.isProtocol) return { state: "none", reason: "The Protocol's open questions are requests, not Q&A." };
  if (venture.status === "killed") return { state: "read-only", reason: `${venture.name} has ended; its Q&A is kept as a record.` };
  if (!latestDeck(store, venture.id)) return { state: "none", reason: `${venture.name} has no deck to ask about yet.` };
  const w = seatWindow(store, venture, params);
  if (w.cohort?.status === "closed") return { state: "read-only", reason: "The batch has closed; its Q&A is kept as a record." };
  if (venture.status === "generated" || w.state === "announced") return { state: "none", reason: "Q&A opens with early access." };
  if (venture.status === "pitched" && w.state === "early") return { state: "early", reason: "Verified members can ask now; everyone else when seats open to the public." };
  if (venture.status === "pitched" && w.state === "ended") return { state: "read-only", reason: "The seat window has closed." };
  return { state: "open", reason: "Anyone with a handle can ask. The operating agent answers." };
}

export type AskerLabel = "seat holder" | "qualified" | "candidate";

export function askerLabel(store: Store, venture: Venture, handle: string): AskerLabel {
  if (hasSeat(store, venture.id, handle)) return "seat holder";
  return memberByHandle(store, handle)?.qualification === "qualified" ? "qualified" : "candidate";
}

function sameDay(a: string, b: string) {
  return a.slice(0, 10) === b.slice(0, 10);
}

/** How many more questions a handle may ask in this venture today. */
export function questionsLeft(store: Store, venture: Venture, member: Pick<Member, "handle" | "qualification"> | undefined, params: ParamValues = resolveParams(store)): number {
  const daily = member?.qualification === "qualified" ? params.QA_DAILY_PER_HANDLE : params.QA_PENDING_DAILY;
  if (!member) return daily;
  const today = store.questions.filter((q) => q.ventureId === venture.id && q.handle === member.handle && sameDay(q.at, store.meta.clock)).length;
  const open = store.questions.filter((q) => q.handle === member.handle && (q.status === "open" || (q.status === "held" && !q.answer))).length;
  return Math.max(0, Math.min(daily - today, params.QA_OPEN_PER_HANDLE - open));
}

/* ---------- asking ---------- */

export function askQuestion(store: Store, input: { slug: string; handle: string; text: string; source?: string; referredBy?: string }): Question {
  const params = resolveParams(store);
  const venture = ventureBySlug(store, input.slug);
  if (!venture) throw new ProtocolError("That venture does not exist.");
  const w = qaWindow(store, venture, params);
  if (w.state === "none" || w.state === "read-only") throw new ProtocolError(w.reason);
  const text = input.text.trim().replace(/\s+/g, " ");
  if (text.length < 8) throw new ProtocolError("Ask a full question.");
  if (text.length > params.QA_MAX_CHARS) throw new ProtocolError(`Questions are at most ${params.QA_MAX_CHARS} characters.`);
  const member = ensureMember(store, input.handle, input.source, input.referredBy, venture.id);
  if (member.qualification === "declined") throw new ProtocolError("Verification didn't go through for this handle, so it can't ask questions.");
  if (w.state === "early" && member.qualification !== "qualified") throw new ProtocolError(w.reason);
  if (questionsLeft(store, venture, member, params) <= 0) {
    throw new ProtocolError(
      member.qualification === "qualified"
        ? `You've asked as many as you can for now: ${params.QA_DAILY_PER_HANDLE} a day per venture, and at most ${params.QA_OPEN_PER_HANDLE} waiting for an answer.`
        : `Before you're verified you can ask ${params.QA_PENDING_DAILY} question a day per venture.`,
    );
  }
  const deck = latestDeck(store, venture.id)!;
  const screen = screenText({ text, customers: venture.customers.count }, params);
  const q: Question = {
    id: newId(store, "q"),
    ventureId: venture.id,
    handle: member.handle,
    text,
    at: store.meta.clock,
    deckVersion: deck.version,
    status: screen.result === "pass" ? "open" : "held",
    upvotes: [],
    stewardNote: screen.result === "pass" ? undefined : `Held for a conduct check: ${screen.findings.join(" ") || screen.counselNote}`,
  };
  store.questions.push(q);
  return q;
}

/* ---------- scripted answers ---------- */

export interface AnswerDraft {
  status: Answer["status"];
  text: string;
  citations: Citation[];
  /** Exposes a claim that is wrong or unsupported. */
  exposes?: string;
  /** A request members could answer, when the deck can't. */
  rfeDraft?: RfeDraft;
  /** A fix the agent can make now. */
  amendment?: Pick<AmendInput, "claims" | "patch" | "title" | "reason">;
  /** Extra numbers the answer may use: computed by code, so supported by construction. */
  support?: string[];
  by: string;
}

const STOP = new Set(
  "a an and are as at be but by can do does for from has have how i if in is it its of on or so that the their them then there these they this to was we what when where which who why will with would you your about into than any our not just more most much only also been were being very should could".split(
    " ",
  ),
);

export function contentWords(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s-]/gu, " ")
      .split(/\s+/)
      .map((w) => w.replace(/^-+|-+$/g, "").replace(/(ies)$/, "y").replace(/(?<=[a-z]{3})s$/, ""))
      .filter((w) => w.length > 2 && !STOP.has(w)),
  );
}

function overlap(a: Set<string>, b: Set<string>) {
  let n = 0;
  for (const w of a) if (b.has(w)) n++;
  return n;
}

const cite = (deck: PitchDeck, claimId: string): Citation => ({ deckVersion: deck.version, slideKey: claimId.startsWith("ask-") ? "ask" : (slideOf(deck, claimId) ?? "ask"), claimId });
const slideClaims = (deck: PitchDeck, key: SlideKey) => (deck.slides.find((s) => s.key === key)?.claims ?? []).filter((c) => !c.disproved);
const live = (claims: (Claim | undefined)[]) => claims.filter((c): c is Claim => !!c && !c.disproved);
const sentence = (t: string) => (/[.!?]$/.test(t.trim()) ? t.trim() : `${t.trim()}.`);

function fromClaims(deck: PitchDeck, claims: Claim[], lead = ""): Pick<AnswerDraft, "text" | "citations"> {
  return { text: `${lead}${claims.map((c) => sentence(c.text)).join(" ")}`.trim(), citations: claims.map((c) => cite(deck, c.id)) };
}

type Intent = { key: string; re: RegExp; answer: (ctx: { store: Store; venture: Venture; deck: PitchDeck; params: ParamValues }) => Omit<AnswerDraft, "by"> };

const INTENTS: Intent[] = [
  {
    key: "refund",
    re: /\brefund|money back|get my \$?\d+|withdraw/i,
    answer: ({ venture, deck }) => ({
      status: "answered",
      text: `Three rules. If ${venture.name} doesn't sell ${deck.seatPlan.min} seats before its window closes, every seat is refunded in full. If the minimum is met but the people its plan needs aren't in place in time, it ends before forming and every seat is refunded in full. If the deck changes materially while seats are selling, anyone who took a seat under the earlier version can take it back.`,
      citations: [cite(deck, "ask-refunds")],
      support: [String(deck.seatPlan.min)],
    }),
  },
  {
    key: "seat-money",
    re: /\b(returns?|profit|payout|pays? (me )?back|make money|worth it|earn|dividend|share of)\b/i,
    answer: ({ venture, deck }) => ({
      status: "answered",
      text: `A seat is access to ${venture.name}'s requests. It is not a share and pays nothing back. Holders earn units only for work: getting verified, and answering requests. Seat money is held until ${deck.seatPlan.min} seats are sold; if the minimum isn't met, every seat is refunded in full.`,
      citations: [cite(deck, "ask-seat-money")],
      support: [String(deck.seatPlan.min)],
    }),
  },
  {
    key: "seats",
    re: /how many seats|why \d+ seats|\bminimum\b|seat count|\bmaximum\b/i,
    answer: ({ deck }) => {
      const lines = seatMath(deck.seatPlan, deck.roster);
      const text = [...lines.map((l) => `${l.label}: ${l.value}${l.detail ? ` (${l.detail})` : ""}.`), currentRuleLine(deck.seatPlan, deck.currentRule)].filter(Boolean).join(" ");
      return { status: "answered", text, citations: [cite(deck, "ask-seats")], support: [text] };
    },
  },
  {
    key: "plan",
    re: /break.?even|business plan|\bburn\b|how much (does|will) (it|this) cost|proof budget|cost to run|pay for itself|after the proof/i,
    answer: ({ venture, deck, params }) => {
      const plan = businessPlanFor(deck, classificationOf(venture).customer, params);
      if (!plan) return { status: "unknown", text: "This deck was written before the business plan, so there's no plan to answer from yet.", citations: [] };
      const text = planSummary(plan).join(" ");
      const ids = ["c-plan-leads", "c-plan-variable", "c-plan-churn"].filter((id) => claimById(deck, id));
      return { status: "answered", text: `${text} The ramp is an assumption; the plan slide shows each input and how it gets tested.`, citations: ids.map((id) => cite(deck, id)), support: [text] };
    },
  },
  {
    key: "agent",
    re: /are you (a |an )?(human|bot|ai|person|real|agent)|who (is|am i) (talking|writing)/i,
    answer: ({ venture, deck }) => ({
      status: "answered",
      text: `I'm an AI agent operating ${venture.name}; @${venture.stewardHandle} is the human steward who signs off on risky actions and can shut it down.`,
      citations: [cite(deck, "ask-roster")],
    }),
  },
  {
    key: "legal",
    re: /\b(legal|lawyer|attorney|securit|tax|licen[cs]e|regulat|compliance)/i,
    answer: ({ deck }) => {
      const risk = live(slideClaims(deck, "risks").filter((c) => /counsel|lawyer|legal|licen|regulat/i.test(c.text)));
      const base = risk.length ? fromClaims(deck, risk.slice(0, 1)) : { text: "", citations: [] };
      return {
        status: "partial",
        text: `I can't give legal advice. ${base.text} The Protocol's legal-structure question is open for counsel: /rfe/${LEGAL_REQUEST}`.replace(/\s+/g, " ").trim(),
        citations: base.citations,
      };
    },
  },
  {
    key: "customer",
    re: /\bwho\b.*\b(buy|buyers?|customers?|for|pays?|uses?)\b|\bicp\b|ideal customer|not for/i,
    answer: ({ deck }) => {
      const claims = live([claimById(deck, "c-named-buyer"), ...slideClaims(deck, "customer")]).filter((c, i, a) => a.findIndex((x) => x.id === c.id) === i);
      return { status: claims.length ? "answered" : "unknown", ...fromClaims(deck, claims.slice(0, 3)) };
    },
  },
  {
    key: "market",
    re: /\bmarket\b|\btam\b|how big|how many (customers|buyers|accounts|businesses)/i,
    answer: ({ deck }) => {
      const claims = slideClaims(deck, "market");
      if (!deck.market || !claims.length) return { status: "unknown", text: "", citations: [] };
      const unchecked = claims.some((c) => c.basis !== "evidence" && c.sources.some((s) => s.kind === "public-data" && !s.verified));
      const sources = [...new Set(claims.flatMap((c) => c.sources.filter((s) => s.kind === "public-data").map((s) => s.label)))];
      const tail = unchecked ? ` These are estimates from ${sources.join(" and ") || "public data"}, not yet checked by a member.` : "";
      const out = fromClaims(deck, claims.slice(0, 4));
      return { status: "answered", text: `${out.text}${tail}`, citations: out.citations };
    },
  },
  {
    key: "competition",
    re: /compet|already (do|use|exist)|instead|why not|alternative|incumbent/i,
    answer: ({ deck }) => {
      const claims = live(deck.alternatives.map((a) => claimById(deck, a.claimId)));
      return { status: claims.length ? "answered" : "unknown", ...fromClaims(deck, claims.slice(0, 3)) };
    },
  },
  {
    key: "price",
    re: /\bprice|pricing|\bcharge|how much (does|will|is)|per month|subscription/i,
    answer: ({ deck }) => {
      const c = live([claimById(deck, deck.pricing.claimId)]);
      const out = fromClaims(deck, c);
      const test = c[0]?.basis === "assumption" && c[0].test ? ` This is an assumption; it gets tested by: ${sentence(c[0].test.how)}` : "";
      return { status: c.length ? "answered" : "unknown", text: `${out.text}${test}`, citations: out.citations };
    },
  },
  {
    key: "failure",
    re: /\bfail|\bkill|what if|shut (it )?down|what happens if|give up/i,
    answer: ({ deck }) => {
      const rules = deck.killCriteria.map((k) => `${sentence(`${k.condition[0].toUpperCase()}${k.condition.slice(1)} by ${k.by.slice(0, 10)}`)}`);
      const risks = slideClaims(deck, "risks").slice(0, 2);
      const out = fromClaims(deck, risks);
      return {
        status: "answered",
        text: `It ends if any of these happens: ${rules.join(" ")} ${out.text}`.trim(),
        citations: out.citations.length ? out.citations : [cite(deck, "ask-roster")],
        support: rules,
      };
    },
  },
  {
    key: "roster",
    re: /who do you need|\broster\b|\broles?\b|can i help|how (can|do) i help|\bclaim\b/i,
    answer: ({ store, venture, deck }) => {
      const open = rosterFill(store, venture).filter((r) => r.open > 0);
      const lines = open.map((r) => `${r.role.label}: ${r.open} open${r.role.critical ? " (needed before the raise succeeds)" : ""}`);
      return {
        status: "answered",
        text: open.length
          ? `Open roles: ${lines.join("; ")}. Anyone verified can claim one, with or without a seat.`
          : `Every role on ${venture.name}'s roster is filled.`,
        citations: [cite(deck, "ask-roster")],
        support: lines,
      };
    },
  },
];

const TOPICS = /\b(customer|buyer|who.*for|market|tam|price|pricing|charge|budget|spend|seat money|roster|roles?|people|kill|fail|deadline)\b/i;

/** The script: intents first, then claims that share enough words with the question, otherwise "I don't know". */
export function answerScripted(store: Store, venture: Venture, q: Pick<Question, "text">): AnswerDraft {
  const params = resolveParams(store);
  const deck = latestDeck(store, venture.id)!;
  for (const intent of INTENTS) {
    if (!intent.re.test(q.text)) continue;
    const a = intent.answer({ store, venture, deck, params });
    if (a.status !== "unknown" && a.text) return { ...a, by: "script" };
    break;
  }
  const words = contentWords(q.text);
  const scored = allClaims(deck)
    .filter((c) => !c.disproved)
    .map((c) => ({ c, n: overlap(words, contentWords(c.text)) }))
    .filter((x) => x.n >= QA_MIN_MATCH)
    .sort((a, b) => b.n - a.n)
    .slice(0, 2);
  if (scored.length) return { status: "answered", ...fromClaims(deck, scored.map((x) => x.c)), by: "script" };
  return {
    status: "unknown",
    text: "I don't know. The deck doesn't cover this. I've asked members in a Knowledge request.",
    citations: [],
    rfeDraft: knowledgeDraft(store, venture, q.text),
    by: "script",
  };
}

function knowledgeDraft(store: Store, venture: Venture, question: string): RfeDraft {
  const role = latestDeck(store, venture.id)?.roster.find((r) => r.serves.includes("knowledge"));
  const short = question.length > 80 ? `${question.slice(0, 77).replace(/\s+\S*$/, "")}…` : question;
  return {
    type: "knowledge",
    title: `A member asked: ${short}`,
    question: `A member asked this on ${venture.name}'s Q&A and the deck doesn't cover it: “${question}” What do you know?`,
    recommendation: "No answer yet; the deck doesn't cover this",
    stakes: "low",
    format: "text",
    offerUnits: 1,
    audience: role ? `${role.label}, or any verified holder` : "Any verified holder",
  };
}

/* ---------- the ground check ---------- */

const NUMBER = /\d[\d,]*(?:\.\d+)?/g;
/** Paths and ids such as /rfe/rfe-v0-legal-structure carry digits that aren't claims. */
const LINKS = /https?:\/\/\S+|\/[a-z][\w\-./#?=&]*|\b[a-z]+(?:-[a-z0-9]+)*-v?\d[\w-]*/gi;
const numbersIn = (t: string) => (t.replace(LINKS, " ").match(NUMBER) ?? []).map((n) => n.replace(/,/g, "")).filter((n) => n.length);

export interface GroundResult {
  status: Answer["status"];
  citations: Citation[];
  unsupported: string[];
  dropped: Citation[];
  restsOn: string[];
}

/**
 * Deterministic. Every citation must resolve in the version it names; every number must
 * appear in a cited claim, in code-computed support or in the venture's ledger; an answer
 * with nothing behind it is "I don't know".
 */
export function groundCheck(store: Store, venture: Venture, draft: Pick<AnswerDraft, "status" | "text" | "citations" | "support">): GroundResult {
  const dropped: Citation[] = [];
  const kept: Citation[] = [];
  const cited: Claim[] = [];
  for (const c of draft.citations) {
    if (c.claimId.startsWith("ask-") && (ASK_REFS as readonly string[]).includes(c.claimId)) {
      kept.push({ ...c, slideKey: "ask" });
      continue;
    }
    const deck = deckVersion(store, venture.id, c.deckVersion);
    const claim = deck && claimById(deck, c.claimId);
    if (!deck || !claim || slideOf(deck, c.claimId) !== c.slideKey) dropped.push(c);
    else {
      kept.push(c);
      cited.push(claim);
    }
  }
  const supported = new Set([
    ...cited.flatMap((c) => [...numbersIn(c.text), ...(c.value ? [String(c.value.n)] : [])]),
    ...(draft.support ?? []).flatMap(numbersIn),
    ...store.ledger.filter((l) => l.ventureId === venture.id && l.usd !== undefined).map((l) => String(Math.abs(l.usd!))),
  ]);
  const unsupported = draft.status === "unknown" ? [] : [...new Set(numbersIn(draft.text).filter((n) => !supported.has(n)))];
  let status = draft.status;
  if (status !== "unknown" && !kept.length) status = "unknown";
  else if (status === "answered" && (unsupported.length || dropped.length)) status = "partial";
  return { status, citations: kept, unsupported, dropped, restsOn: cited.filter((c) => c.basis !== "evidence").map((c) => c.id) };
}

/* ---------- answering ---------- */

/** Decisions whose reasoning the text quotes, unless the same words are public in the deck or its computed seat math. */
function decisionQuotes(store: Store, venture: Venture, text: string, deck: PitchDeck, support: string[] = []): string[] {
  const reasons = store.decisions.filter((d) => d.ventureId === venture.id).map((d) => ({ id: d.id, headline: "", whatHappened: d.reasoning, whatWeDoDifferently: "" }));
  const publicText = [
    ...allClaims(deck).map((c) => c.text),
    ...seatMath(deck.seatPlan, deck.roster).map((l) => `${l.label}: ${l.value} (${l.detail}).`),
    currentRuleLine(deck.seatPlan, deck.currentRule) ?? "",
    ...support,
  ].join(" \n ");
  return quotedLessons(text, reasons, publicText).map((h) => h.id);
}

/**
 * Answer a question: ground-check the draft, screen it, decide whether it's material, and
 * route it. Answers are always from the operating agent (Article 8). A conduct concern, or
 * text that quotes a members-only lesson or a decision's reasoning, holds it for the steward.
 */
export function answerQuestion(store: Store, q: Question, draft?: AnswerDraft): Question {
  if (q.status !== "open" && !(q.status === "held" && !q.answer)) return q;
  const params = resolveParams(store);
  const venture = store.ventures.find((v) => v.id === q.ventureId)!;
  const deck = latestDeck(store, venture.id)!;
  const d = draft ?? answerScripted(store, venture, q);
  const g = groundCheck(store, venture, d);
  let text = d.text.trim();
  if (g.status === "unknown" && !/^I don't know\b/.test(text)) text = `I don't know. ${text.replace(/^I don't know\.?\s*/i, "")}`.trim();
  if (g.unsupported.length) text = `${text} I couldn't support ${g.unsupported.join(", ")} from the deck.`;
  const restsOn = g.restsOn.filter((id) => !id.startsWith("ask-"));
  const asksTopic = TOPICS.test(q.text);
  const priority = q.upvotes.length >= params.QA_PRIORITY_UPVOTES && restsOn.some((id) => claimById(deck, id)?.basis === "assumption");
  const reasons = [
    g.status === "unknown" && asksTopic ? "The deck can't answer a question about its customer, market, price, budget, roster or kill rules" : "",
    d.exposes ? `It exposes a claim that is wrong or unsupported: ${d.exposes}` : "",
    d.amendment ? "Answering it changes the deck" : "",
    priority ? `${q.upvotes.length} members upvoted a question that rests on an assumption` : "",
  ].filter(Boolean);
  const answer: Answer = {
    at: store.meta.clock,
    by: d.by,
    status: g.status,
    text,
    citations: g.citations,
    restsOn,
    material: reasons.length > 0,
    materialReason: reasons.join("; ") || undefined,
    updates: [],
  };
  q.answer = answer;

  const lessons = params.LESSONS_VISIBLE_TO === "public" ? [] : quotedLessons(text, store.lessons).map((l) => l.id);
  const decisions = decisionQuotes(store, venture, text, deck, d.support);
  const screen = screenText({ text, customers: venture.customers.count, nearSeats: true }, params);
  if (screen.result !== "pass" || lessons.length || decisions.length) {
    q.status = "held";
    q.stewardNote = [
      screen.findings.length ? `Conduct: ${screen.findings.join(" ")}` : "",
      screen.counselNote ?? "",
      lessons.length ? `Quotes ${lessons.join(", ")}; lessons are for members.` : "",
      decisions.length ? "Quotes a decision's reasoning, which only unit holders see." : "",
    ]
      .filter(Boolean)
      .join(" ");
    return q;
  }
  q.status = "answered";
  routeQuestion(store, venture, q, d);
  return q;
}

/** Material answers go somewhere: a request members can answer, or a deck change the agent can make now. */
function routeQuestion(store: Store, venture: Venture, q: Question, d: AnswerDraft) {
  const a = q.answer!;
  const rfeDraft = d.rfeDraft ?? (a.material && a.status === "unknown" ? knowledgeDraft(store, venture, q.text) : undefined);
  if (rfeDraft) {
    const { rfe } = logDecision(store, {
      ventureId: venture.id,
      title: `Ask members what the deck can't answer`,
      reasoning: `A member's question on the Q&A isn't covered by deck v${q.deckVersion}. Members who know can answer it, and the answer goes back on the question.`,
      summary: "A member question the deck doesn't cover became a request.",
      confidence: 0.85,
      model: d.by,
      rfe: { ...rfeDraft, id: rfeDraft.id ?? `rfe-${venture.slug}-${q.id}` },
    });
    if (rfe) {
      a.routed = { ...a.routed, rfeId: rfe.id };
      q.status = "routed";
    }
  }
  if (d.amendment) {
    const { deck, decision } = amendDeck(store, venture, { ...d.amendment, cause: { kind: "qa", ref: q.id }, model: d.by });
    a.routed = { ...a.routed, deckVersion: deck.version };
    if (!rfeDraft) q.status = "routed";
    if (decision.status === "taken") awardQuestion(store, venture, q);
  }
}

/** A question that changed the deck is useful work (Article 1), paid only to verified members and capped per venture. */
export function awardQuestion(store: Store, venture: Venture, q: Question): number {
  const params = resolveParams(store);
  const member = memberByHandle(store, q.handle);
  if (member?.qualification !== "qualified" || member.handle === venture.stewardHandle) return 0;
  const note = `Question changed the deck (${q.id})`;
  if (store.grants.some((g) => g.ventureId === venture.id && g.note === note)) return 0;
  const paid = store.grants.filter((g) => g.ventureId === venture.id && g.note?.startsWith("Question changed the deck")).reduce((s, g) => s + g.units, 0);
  const units = Math.min(params.QA_MATERIAL_UNITS, params.QA_UNITS_CAP_PER_VENTURE - paid);
  if (units <= 0) return 0;
  issueGrant(store, { venture, handle: member.handle, slice: "rfe", units, rfeId: q.answer?.routed?.rfeId, note });
  return units;
}

/** When a routed request resolves, its resolution goes back on the question. */
export function onRoutedResolved(store: Store, rfeId: string, opts: { text: string; deckChanged?: boolean }) {
  for (const q of store.questions.filter((x) => x.answer?.routed?.rfeId === rfeId)) {
    q.answer!.updates.push({ at: store.meta.clock, text: opts.text, ref: rfeId });
    const venture = store.ventures.find((v) => v.id === q.ventureId)!;
    if (opts.deckChanged) awardQuestion(store, venture, q);
  }
}

/** Answer every open question, priority ones first: the agent's step does this. */
export function answerOpenQuestions(store: Store, answer: (q: Question) => AnswerDraft | undefined = () => undefined): Question[] {
  const params = resolveParams(store);
  const open = store.questions
    .filter((q) => q.status === "open")
    .sort((a, b) => Number(b.upvotes.length >= params.QA_PRIORITY_UPVOTES) - Number(a.upvotes.length >= params.QA_PRIORITY_UPVOTES) || a.at.localeCompare(b.at));
  return open.map((q) => answerQuestion(store, q, answer(q)));
}

/* ---------- upvotes ---------- */

export function toggleUpvote(store: Store, input: { id: string; handle: string }): { upvoted: boolean; count: number } {
  const q = store.questions.find((x) => x.id === input.id);
  if (!q || q.status === "hidden" || q.status === "held") throw new ProtocolError("That question isn't public.");
  const venture = store.ventures.find((v) => v.id === q.ventureId)!;
  const w = qaWindow(store, venture);
  if (w.state !== "open" && w.state !== "early") throw new ProtocolError(w.reason);
  const member = ensureMember(store, input.handle);
  if (member.qualification === "declined") throw new ProtocolError("Verification didn't go through for this handle.");
  if (member.handle === q.handle) throw new ProtocolError("You can't upvote your own question.");
  const i = q.upvotes.indexOf(member.handle);
  if (i >= 0) q.upvotes.splice(i, 1);
  else q.upvotes.push(member.handle);
  const params = resolveParams(store);
  if (i < 0 && q.upvotes.length === params.QA_PRIORITY_UPVOTES && q.status === "answered" && q.answer) reviewPriority(store, venture, q);
  return { upvoted: i < 0, count: q.upvotes.length };
}

/** At the priority bar, an answer that rests on an assumption is reviewed: members are asked to test it. */
function reviewPriority(store: Store, venture: Venture, q: Question) {
  const deck = latestDeck(store, venture.id)!;
  const assumption = q.answer!.restsOn.map((id) => claimById(deck, id)).find((c) => c?.basis === "assumption");
  if (!assumption || q.answer!.routed?.rfeId) return;
  q.answer!.material = true;
  q.answer!.materialReason = `${q.upvotes.length} members upvoted a question that rests on an assumption`;
  routeQuestion(store, venture, q, {
    status: q.answer!.status,
    text: q.answer!.text,
    citations: q.answer!.citations,
    by: "script",
    rfeDraft: {
      ...knowledgeDraft(store, venture, q.text),
      title: `Test an assumption members asked about: ${assumption.text.slice(0, 70)}`,
      question: `Members asked “${q.text}” and the answer rests on an assumption: “${assumption.text}” ${assumption.test ? `The plan was to test it this way: ${assumption.test.how}` : ""} What do you know?`.trim(),
    },
  });
}

/* ---------- the steward: held and hidden ---------- */

function assertSteward(venture: Venture, by: string) {
  if (by !== venture.stewardHandle) throw new ProtocolError(`Only @${venture.stewardHandle} can do this for ${venture.name}.`);
}

/** Hide a question only for a listed conduct reason; a hard or unflattering question isn't one. */
export function hideQuestion(store: Store, input: { by: string; id: string; reason: string }): Question {
  const params = resolveParams(store);
  const q = store.questions.find((x) => x.id === input.id);
  if (!q) throw new ProtocolError("No such question.");
  const venture = store.ventures.find((v) => v.id === q.ventureId)!;
  assertSteward(venture, input.by);
  const reasons = params.QA_HIDE_REASONS as string[];
  if (!reasons.includes(input.reason)) throw new ProtocolError(`A question can be hidden only for: ${reasons.join(", ")}.`);
  if (q.status === "hidden") throw new ProtocolError("Already hidden.");
  q.status = "hidden";
  q.hidden = { by: input.by, reason: input.reason, at: store.meta.clock };
  ledger(store, { ventureId: venture.id, kind: "redaction", ref: q.id, note: `Question ${q.id} hidden by @${input.by}: ${input.reason}. Any member can flag the hide.` });
  return q;
}

/** A held question (or answer) passes review and goes public; an unanswered one is answered now. */
export function approveHeld(store: Store, input: { by: string; id: string; note?: string }): Question {
  const q = store.questions.find((x) => x.id === input.id);
  if (!q || q.status !== "held") throw new ProtocolError("That question isn't waiting for review.");
  const venture = store.ventures.find((v) => v.id === q.ventureId)!;
  assertSteward(venture, input.by);
  q.stewardNote = input.note?.trim() || undefined;
  if (!q.answer) {
    q.status = "open";
    return answerQuestion(store, q);
  }
  q.status = q.answer.routed?.rfeId ? "routed" : "answered";
  return q;
}

export function hiddenPlaceholder(q: Pick<Question, "hidden">): string | undefined {
  if (!q.hidden) return undefined;
  const day = new Date(q.hidden.at).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });
  return `Hidden by @${q.hidden.by} on ${day}: ${q.hidden.reason}.`;
}

/* ---------- reading ---------- */

export type QaSort = "top" | "new" | "unanswered" | "routed";

/**
 * Questions as a viewer sees them. Held questions show only to the asker and the steward;
 * hidden ones keep their place with the placeholder and lose their text.
 */
export function qaFor(store: Store, venture: Venture, opts: { viewer?: string; sort?: QaSort } = {}): Question[] {
  const steward = opts.viewer === venture.stewardHandle;
  const qs = store.questions
    .filter((q) => q.ventureId === venture.id)
    .filter((q) => q.status !== "held" || steward || q.handle === opts.viewer)
    .map((q) => (q.status === "hidden" && !steward ? { ...q, text: "", answer: undefined } : q));
  const sort = opts.sort ?? "top";
  const byNew = (a: Question, b: Question) => b.at.localeCompare(a.at);
  if (sort === "new") return qs.sort(byNew);
  if (sort === "unanswered") return qs.filter((q) => q.status === "open" || q.answer?.status === "unknown").sort(byNew);
  if (sort === "routed") return qs.filter((q) => !!q.answer?.routed).sort(byNew);
  return qs.sort((a, b) => Number(a.status === "hidden") - Number(b.status === "hidden") || b.upvotes.length - a.upvotes.length || byNew(a, b));
}

export function heldQuestions(store: Store, steward: string): Question[] {
  const mine = new Set(store.ventures.filter((v) => v.stewardHandle === steward).map((v) => v.id));
  return store.questions.filter((q) => q.status === "held" && mine.has(q.ventureId)).sort((a, b) => a.at.localeCompare(b.at));
}
