# Wind-down / hand-off / unused-capital riders — counsel checklist

**NOT LEGAL ADVICE. PLACEHOLDER. REPLACE WITH COUNSEL.**

Stock YC post-money SAFEs cover liquidity and dissolution events in generic form. Shoalyard’s agreed model needs **explicit riders** (or side letters) so fill-or-kill, steward kill, hand-off, and unused proof/seed capital behave as product promises. Open until counsel drafts.

## Must address

- [ ] **Missed minimum:** escrow refund timing, fees, who pays processor costs, no SAFE issued  
- [ ] **Steward kill / early stop:** interaction with SAFE purchase amount, dissolution vs company election, notice to seeders  
- [ ] **Unused capital after stop:** return vs spend-down rules; proof-budget remainder vs seed remainder  
- [ ] **Hand-off to entrepreneur:** mark ends (Article 7); SAFE/equity follows opco — confirm assignee, consent, information rights  
- [ ] **Wind-down pack:** ledger freeze, final report, answerer cash owed, vig accrued, token costs  
- [ ] **Priority:** SAFE vs debt vs answerer payables vs platform vig claims  
- [ ] **Escrow agent / release conditions:** who certifies minimum met; false-minimum remediation  
- [ ] **Multi-opco / series:** whether each attempt is a separate issuer for SAFEs  
- [ ] **Public ledger disclosure** during wind-down without selective-disclosure issues  
- [ ] **Geo / non-US seeders:** enforceability of riders  

## Product promises to preserve in counsel language

From economics memo: fill-or-kill minimum; miss → full refund; hit → SAFE; answers = cash only; holdco capital never mixed into opco seed escrow.

## Non-claims

This checklist is **not** a rider draft and **not** an executed amendment to any YC form.
