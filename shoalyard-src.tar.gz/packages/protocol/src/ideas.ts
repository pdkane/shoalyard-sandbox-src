import type { Classification, Memo, Objective, ProofPlan } from "@av/schema";
import { PROOF_PLANS } from "./proof-plans";

/**
 * The scripted idea library, each idea with its proposed classification. With
 * an API key the operator writes ideas instead; without one, `spawn` picks
 * from here, conditioned on adopted lessons and on who our members can reach.
 */
export interface IdeaTemplate {
  classification: Classification;
  slug: string;
  name: string;
  codename: string;
  teaser: string;
  tagline: string;
  pitch: string;
  objective: Objective;
  distributionPolicy: string;
  /** Fallback lines for an idea without a written deck. */
  budget: { label: string; usd: number }[];
  killRules: string[];
  voice: string;
  accent: string;
  segment: string;
  memo: Memo;
  /** Clusters whose qualified members make this idea sellable; used to rank ideas by graph reach. */
  reachClusters: string[];
  /** How it gets proved, task by task, as the agent first wrote it. The operability check runs on it at spawn. */
  proof: ProofPlan;
  /** If an adopted lesson guards against this, the agent's reason it thinks this case differs ({lesson} is replaced by the id). */
  differs?: { keyword: string; reason: string };
}

/** Itemized lines only: contingency is what the seat rule adds on top. */
const budget = (compute: number, tooling: number, formation = 55) => [
  { label: "Agent compute to customer 1", usd: compute },
  { label: "Domain and tooling", usd: tooling },
  { label: "Series formation", usd: formation },
];

export const IDEA_LIBRARY: readonly IdeaTemplate[] = [
  {
    classification: {
      endMarket: "Real estate and construction",
      subVertical: "Mechanics' lien compliance for specialty subcontractors",
      customer: "Small business",
      businessModel: "Subscription software",
      goToMarket: "Sales-led",
      marketType: "Existing market",
      geography: "US",
      workDelivery: "Agent only",
    },
    slug: "lien-clock",
    proof: PROOF_PLANS["lien-clock"],
    name: "Lien Clock",
    codename: "FERRULE",
    teaser: "Every subcontractor has a lien deadline. Most find out after it passed.",
    tagline: "Mechanics' lien deadlines for subcontractors in Texas and Arizona, tracked from the first invoice.",
    pitch:
      "A subcontractor who isn't paid has a fixed number of days to send a lien notice, and the clock starts at the first invoice, not the last. Lien Clock reads the sub's invoices, works out each project's notice and filing dates under Texas and Arizona rules, and sends the notice letters for a person at the sub to sign. It never gives legal advice; a lawyer reviews the date rules before launch.",
    objective: "profitability",
    distributionPolicy: "Pay out 70% of quarterly profit after fixed costs; retain 30% for a third state.",
    budget: budget(90, 40, 60),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "No paying subcontractor by 2027-04-30", "The steward shuts it down"],
    voice: "Calm and exact. Dates first, then what to do.",
    accent: "#a16207",
    segment: "Roofing, HVAC and electrical subcontractors with 5–50 staff",
    memo: {
      problem: "Subcontractors lose lien rights on unpaid work because the notice deadline runs from the first invoice; they pay collections lawyers to recover what a letter would have protected.",
      customer: "Owners and office managers at roofing, HVAC and electrical subcontractors with 5–50 staff in Texas and Arizona.",
      marketSize: "Roughly 60,000 specialty subcontractors in the two states; 1% of them at $49/month is about $350,000 a year.",
      whyNow: "Texas shortened its notice windows in 2022 and county filings are now searchable online, so the dates are computable.",
      competition: "Lien-service firms priced for larger subs, and collections lawyers hired after the deadline has passed.",
      unitEconomics: "$49/month per subscriber against about $4/month in compute and postage; paid back in the first month.",
      killMetric: "No subcontractor pays $49/month within 90 days of launch.",
    },
    reachClusters: ["construction-sales", "legal-counsel"],
    differs: {
      keyword: "cold email",
      reason:
        "{lesson} says member intros beat cold outbound with small-business buyers. Here the first email is a dated deadline warning built from a public filing, not a pitch, so the agent expects it to read as a service; it will still lead with member intros.",
    },
  },
  {
    classification: {
      endMarket: "Software and IT",
      subVertical: "In-person signatures and filings for agent-run businesses",
      customer: "Small business",
      businessModel: "Tech-enabled services",
      goToMarket: "Self-serve",
      marketType: "New market",
      geography: "US",
      workDelivery: "Agent plus contractors",
    },
    slug: "wet-ink",
    proof: PROOF_PLANS["wet-ink"],
    name: "Wet Ink",
    codename: "QUILL",
    teaser: "Agents can run a business. They still can't sign in ink.",
    tagline: "Wet signatures, notarisations and in-person filings, booked by an agent and done by a member nearby.",
    pitch:
      "Agent-run ventures stall on the few steps that need a person in a room: a notarised form, a wet signature, a filing at a county desk. Wet Ink takes the request by API, books a member near the office, and returns a scan with a chain of custody. Dockside needed this in its first year. Every request says up front that an agent sent it.",
    objective: "scale",
    distributionPolicy: "Reinvest until 200 completed jobs a month; then pay out 60% of quarterly profit.",
    budget: budget(70, 45, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "Fewer than 20 paid jobs by 2027-03-31", "The steward shuts it down"],
    voice: "Brief and procedural, like a good courier receipt.",
    accent: "#334155",
    segment: "Agent-run ventures and agent builders who need a person on site",
    memo: {
      problem: "Agents running businesses hit steps that need a human in a room; today their operators drive to the notary themselves.",
      customer: "Agent-run ventures and agent builders who need a wet signature, notarisation or county filing done in person.",
      marketSize: "Small and early: the ventures in this registry plus early agent builders, a few hundred US jobs a month.",
      whyNow: "There are now enough agent-run ventures, including this protocol's, that the same request repeats weekly.",
      competition: "Mobile notaries and couriers booked by hand, and member Action requests on this protocol.",
      unitEconomics: "$45 per job; the member who does it is paid $30 and compute and storage cost under $2.",
      killMetric: "Fewer than 20 paid jobs by 31 March 2027.",
    },
    reachClusters: ["data-eng", "generalist", "legal-counsel"],
  },
  {
    classification: {
      endMarket: "Real estate and construction",
      subVertical: "Payment-dispute evidence for subcontractors",
      customer: "Small business",
      businessModel: "Usage-based",
      goToMarket: "Sales-led",
      marketType: "New market",
      geography: "US",
      workDelivery: "Agent only",
    },
    slug: "site-record",
    proof: PROOF_PLANS["site-record"],
    name: "Site Record",
    codename: "KESTREL",
    teaser: "Signed photo proof that a job was finished, for contractors who get paid late.",
    tagline: "Tamper-evident job-site photo timelines that settle subcontractor payment disputes.",
    pitch:
      "When a general contractor holds back payment, the subcontractor's proof is a camera roll and a group chat. Site Record turns photos and check-ins into a dated, tamper-evident timeline per job that a GC's accounts team accepts. Nobody sells this as a product yet; subs pay lawyers and collections firms to work around not having it.",
    objective: "profitability",
    distributionPolicy: "Pay out 70% of quarterly profit after fixed costs.",
    budget: budget(120, 50, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "No paying subcontractor by 2027-05-31", "The steward shuts it down"],
    voice: "Matter-of-fact. Talks about invoices and dates, not technology.",
    accent: "#0369a1",
    segment: "Subcontractors who invoice general contractors",
    memo: {
      problem: "Subs lose disputed payments for lack of a dated record; today they pay collections firms 20–30% to chase them.",
      customer: "Owners of subcontractors who invoice general contractors and have had payment held back.",
      marketSize: "Several hundred thousand US subcontractors; most have at least one disputed invoice a year.",
      whyNow: "Phone photos include reliable GPS and timestamps, and signed timestamps are now cheap.",
      competition: "Camera rolls, group chats and general job-site photo apps, none of which a GC's accounts team treats as evidence.",
      unitEconomics: "$15 per job record against under $1 per job in compute and signed timestamps.",
      killMetric: "GCs' accounts teams won't accept the timeline as evidence in two test disputes.",
    },
    reachClusters: ["construction-sales"],
  },
  {
    classification: {
      endMarket: "Public sector",
      subVertical: "Tender packages for small contractors",
      customer: "Small business",
      businessModel: "Tech-enabled services",
      goToMarket: "Sales-led",
      marketType: "Resegmented",
      geography: "US",
      workDelivery: "Agent plus contractors",
    },
    slug: "bid-desk",
    proof: PROOF_PLANS["bid-desk"],
    name: "Bid Desk",
    codename: "BASALT",
    teaser: "Help small firms fill out government bids, with members who've won them.",
    tagline: "Public-sector bid packages for small contractors, assembled by members first and automated once it works.",
    pitch:
      "Small contractors skip public tenders because the paperwork takes days. Bid Desk has members who have won tenders assemble the first packages by hand, paid per package, while the agent writes down every step. Once ten packages have gone out, the agent automates the repeatable parts.",
    objective: "profitability",
    distributionPolicy: "Pay out 60% of quarterly profit; retain 40% to pay for the automation.",
    budget: budget(60, 30, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "No contractor pays for a hand-built package by 2027-02-28", "The steward shuts it down"],
    voice: "Practical and encouraging, written for owners who hate paperwork.",
    accent: "#15803d",
    segment: "Contractors with under 20 staff bidding on county and city work",
    memo: {
      problem: "Small contractors lose public work they could win because the bid package takes days they don't have.",
      customer: "Owners of contractors with under 20 staff bidding on county and city work.",
      marketSize: "US counties and cities post hundreds of thousands of tenders a year; small contractors bid on a fraction of those they qualify for.",
      whyNow: "Counties now post tenders on portals with structured fields, so the repeatable parts can be captured.",
      competition: "Bid-writing consultants priced for larger firms, and the owner's own evenings.",
      unitEconomics: "$350 per package; members are paid $200 per hand-built package until the agent automates the repeatable parts.",
      killMetric: "No contractor pays for a hand-built package by 28 February 2027.",
    },
    reachClusters: ["construction-sales", "data-eng"],
  },
  {
    classification: {
      endMarket: "Industrials and logistics",
      subVertical: "Lumper fees for dry-van freight",
      customer: "Small business",
      businessModel: "Data or licensing",
      goToMarket: "Partner or channel",
      marketType: "New market",
      geography: "US",
      workDelivery: "Agent only",
    },
    slug: "lumper-line",
    proof: PROOF_PLANS["lumper-line"],
    name: "Lumper Line",
    codename: "MERIDIAN",
    teaser: "What every warehouse really charges to unload a truck, from people who pay it.",
    tagline: "Verified lumper fees by warehouse, sourced from the brokers and carriers who pay them.",
    pitch:
      "Lumper fees vary by hundreds of dollars between warehouses and nobody publishes them. Lumper Line collects receipts from freight members, verifies them, and sells brokers a lookup before they quote. Only a network that already has brokers and carriers in it can collect this.",
    objective: "profitability",
    distributionPolicy: "Pay out 80% of quarterly profit after fixed costs.",
    budget: budget(60, 30, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "Fewer than 300 verified receipts by 2027-02-28", "The steward shuts it down"],
    voice: "Dispatcher-direct, like Dockside.",
    accent: "#7c3aed",
    segment: "Freight brokers quoting dry-van loads",
    memo: {
      problem: "Brokers quote loads without knowing the unloading fee, and eat the difference.",
      customer: "Freight brokers quoting dry-van loads, starting with Dockside's 14 brokers.",
      marketSize: "About 20,000 US freight brokerages; lumper fees run $100–$600 a stop and vary widely by warehouse.",
      whyNow: "Dockside's customers already upload receipts with their disputes.",
      competition: "Brokers' own spreadsheets and carrier word of mouth; load boards don't publish lumper fees.",
      unitEconomics: "$99/month per brokerage for unlimited lookups; each verified receipt costs about $1 in compute and member requests.",
      killMetric: "Fewer than 300 verified receipts by 28 February 2027.",
    },
    reachClusters: ["freight-ops"],
  },
  {
    classification: {
      endMarket: "Real estate and construction",
      subVertical: "Subcontractor insurance certificates",
      customer: "Small business",
      businessModel: "Subscription software",
      goToMarket: "Sales-led",
      marketType: "Existing market",
      geography: "US",
      workDelivery: "Agent only",
    },
    slug: "cert-chase",
    proof: PROOF_PLANS["cert-chase"],
    name: "Cert Chase",
    codename: "COBALT",
    teaser: "The most boring email in construction, sent on time, every time.",
    tagline: "Certificates of insurance collected from every subcontractor before they're on site, for small general contractors.",
    pitch:
      "General contractors must hold a current insurance certificate for every sub, and chasing them is someone's least favourite job. Cert Chase does it faster and cheaper than the compliance vendors: it requests, reads and tracks expiry dates, and only bothers a person when a certificate is wrong.",
    objective: "profitability",
    distributionPolicy: "Pay out 70% of quarterly profit after fixed costs.",
    budget: budget(60, 35, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "No paying GC by 2027-03-31", "The steward shuts it down"],
    voice: "Polite and persistent.",
    accent: "#0e7490",
    segment: "General contractors with 10–60 subcontractors a year",
    memo: {
      problem: "Small GCs track subcontractor insurance in spreadsheets and get caught by expired certificates.",
      customer: "Office managers at general contractors with 10–60 subcontractors a year.",
      marketSize: "Tens of thousands of US general contractors in that size band, each chasing dozens of certificates a year.",
      whyNow: "Certificate PDFs follow a standard form, so an agent reads them reliably.",
      competition: "Spreadsheets, and compliance vendors priced for larger GCs.",
      unitEconomics: "$79/month per GC against under $5/month in compute.",
      killMetric: "No paying GC by 31 March 2027, or GCs won't switch from the spreadsheet for under $99/month.",
    },
    reachClusters: ["construction-sales"],
  },
  {
    classification: {
      endMarket: "Real estate and construction",
      subVertical: "Closeout punch lists for small GCs",
      customer: "Small business",
      businessModel: "Subscription software",
      goToMarket: "Self-serve",
      marketType: "Resegmented",
      geography: "US",
      workDelivery: "Agent only",
    },
    slug: "punch-list",
    proof: PROOF_PLANS["punch-list"],
    name: "Punch List",
    codename: "TERRACE",
    teaser: "One screen from a $10,000 suite, for the crews who only ever used that screen.",
    tagline: "Just the punch list, for small GCs paying for a whole construction suite.",
    pitch:
      "Small GCs pay for construction-management suites and use one feature: the punch list at closeout. Punch List is that feature alone, with photos and sign-off, priced for a five-person crew.",
    objective: "profitability",
    distributionPolicy: "Pay out 70% of quarterly profit after fixed costs.",
    budget: budget(100, 40, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "No paying GC by 2027-04-30", "The steward shuts it down"],
    voice: "Plain and short.",
    accent: "#9333ea",
    segment: "General contractors with under 10 staff",
    memo: {
      problem: "Small GCs pay suite prices for the one feature they use.",
      customer: "Owners of general contractors with under 10 staff.",
      marketSize: "Most of the small US GCs who pay for a construction-management suite today.",
      whyNow: "Suite vendors raised prices this year and small customers are shopping.",
      competition: "Construction-management suites, and paper lists at closeout.",
      unitEconomics: "$29/month per crew against under $2/month in hosting and compute.",
      killMetric: "No paying GC by 30 April 2027.",
    },
    reachClusters: ["construction-sales"],
  },
  {
    classification: {
      endMarket: "Software and IT",
      subVertical: "Phone answering for agent-run businesses",
      customer: "Small business",
      businessModel: "Tech-enabled services",
      goToMarket: "Self-serve",
      marketType: "New market",
      geography: "US",
      workDelivery: "Agent plus contractors",
    },
    slug: "relay-line",
    proof: PROOF_PLANS["relay-line"],
    name: "Relay Line",
    codename: "HALYARD",
    teaser: "A phone number an agent can hand out, answered by a person who knows it's an agent's line.",
    tagline: "Phone numbers for agent-run ventures, answered by members on shift, logged back to the agent.",
    pitch:
      "Some buyers only pick up the phone. Relay Line gives an agent-run venture a number answered by a member on shift, who says up front that the business is agent-run and logs the call back to the agent.",
    objective: "scale",
    distributionPolicy: "Reinvest until 30 ventures use it; then pay out 60% of quarterly profit.",
    budget: budget(70, 60, 55),
    killRules: ["Minimum not met when the batch window closes: venture ends, every seat refunded in full", "Fewer than 5 ventures paying by 2027-03-31", "The steward shuts it down"],
    voice: "Friendly and clear about who is speaking.",
    accent: "#475569",
    segment: "Agent-run ventures selling to buyers who phone",
    memo: {
      problem: "Agent-run ventures lose buyers who want to talk to a person.",
      customer: "Agent-run ventures selling to buyers who phone, starting with Dockside.",
      marketSize: "Small and early: ventures in this registry, then agent builders selling to phone-first trades.",
      whyNow: "Ventures in this registry now have buyers who call.",
      competition: "Answering services that don't know the business is agent-run and can't log back to the agent.",
      unitEconomics: "$149/month per venture for up to 100 calls; members are paid per shift, about $90 of it.",
      killMetric: "Fewer than 5 ventures paying by 31 March 2027.",
    },
    reachClusters: ["data-eng", "generalist"],
  },
];
