import type { NStatus } from "@av/protocol";
import { cn } from "@/lib/utils";

export function NProgress({ n, compact = false, className }: { n: NStatus; compact?: boolean; className?: string }) {
  const max = Math.max(n.target, n.effective, 1);
  const pct = Math.min(100, (n.effective / max) * 100);
  const minPct = Math.min(100, (n.minimum / max) * 100);
  return (
    <div className={cn("space-y-1.5", className)}>
      <div className="flex items-baseline justify-between gap-2 text-xs">
        <span className="font-medium text-zinc-800">
          {n.effective}/{n.target} answers counted
          {n.raw > n.effective && (
            <span className="font-normal text-zinc-500"> ({n.raw} people answered; similar profiles count once)</span>
          )}
        </span>
        {n.effective > 0 && n.agreement < 1.01 && (
          <span className="text-zinc-500">{Math.round(n.agreement * 100)}% agree</span>
        )}
      </div>
      <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-zinc-100">
        <div className="h-full rounded-full bg-[var(--accent-color,#18181b)] transition-all" style={{ width: `${pct}%` }} />
        {n.minimum < n.target && (
          <span className="absolute top-0 h-full w-px bg-zinc-400" style={{ left: `${minPct}%` }} title={`Minimum ${n.minimum}`} />
        )}
      </div>
      {!compact && <p className="text-xs text-zinc-500">{n.reason}</p>}
    </div>
  );
}
