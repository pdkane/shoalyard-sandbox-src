import type { HandOffOffer, ParamKey, ParamValues, Rfe, Store, Venture } from "@av/schema";
import { protocolPctFor, totalVestedUnits, vestedByHandle } from "./economics";
import { breachCount } from "./flags";
import { updatesFor } from "./operating";
import { isOpen, ledger, memberByHandle, notify, postRfe, ProtocolError, rejectDecision, seatHolders, setRfeStatus, transitionVenture, ventureById, ventureBySlug } from "./ops";
import { resolveParams } from "./params";
import { rosterProgress } from "./roster";
import { monthOf } from "./services";
import { addDays, newId, round } from "./util";

/**
 * Handing a venture off: once the experiment has proved a named buyer pays, an
 * entrepreneur can adopt it and run it with their own money. Seats never share in a
 * hand-off; only earned units are paid, by vested units.
 */
export const HAND_OFF_STAGES: readonly Venture["status"][] = ["customer1", "distributing"];
export const HAND_OFF_OPTIONS = ["Hand it off", "Keep it in the Protocol"] as const;
export const MARK_ENDS_NOTE = "The mark ends: once an entrepreneur runs it, the Protocol no longer builds it (Article 7).";

export interface ChecklistItem {
  key: "customers" | "growth" | "books" | "roster" | "conduct";
  label: string;
  met: boolean;
  detail: string;
  param: ParamKey;
}

const WEEKS_PER_QUARTER = 13;
const pct = (n: number) => `${Math.round(n * 10) / 10}%`;

/**
 * Consecutive weeks at or above the weekly growth floor, newest first. Weekly updates count
 * first; before they began, each quarter of the revenue record counts as 13 weeks if its
 * weekly rate cleared the floor.
 */
export function growthWeeksAtFloor(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): { weeks: number; fromUpdates: number; fromQuarters: number; weeklyPct?: number } {
  const floor = params.GROWTH_FLOOR_WEEKLY_PCT;
  const updates = updatesFor(store, venture.id);
  let fromUpdates = 0;
  for (const u of [...updates].reverse()) {
    if (u.metric.previous === undefined) break;
    const g = u.metric.previous > 0 ? ((u.metric.value - u.metric.previous) / u.metric.previous) * 100 : u.metric.value > 0 ? 100 : 0;
    if (g < floor) return { weeks: fromUpdates, fromUpdates, fromQuarters: 0 };
    fromUpdates++;
  }
  const firstUpdate = updates[0]?.at;
  const quarters = venture.quarters.filter((q) => !firstUpdate || quarterEnd(q.quarter) <= firstUpdate);
  let fromQuarters = 0;
  let weeklyPct: number | undefined;
  for (let i = quarters.length - 1; i >= 1; i--) {
    const prev = quarters[i - 1].revenueUsd;
    const now = quarters[i].revenueUsd;
    if (!(prev > 0)) break;
    const weekly = (Math.pow(now / prev, 1 / WEEKS_PER_QUARTER) - 1) * 100;
    if (weeklyPct === undefined) weeklyPct = round(weekly, 1);
    if (weekly < floor) break;
    fromQuarters += WEEKS_PER_QUARTER;
  }
  return { weeks: fromUpdates + fromQuarters, fromUpdates, fromQuarters, weeklyPct };
}

function quarterEnd(q: string): string {
  const [y, n] = q.split("-Q").map(Number);
  const month = n * 3;
  return new Date(Date.UTC(month === 12 ? y + 1 : y, month === 12 ? 0 : month, 1)).toISOString();
}

function booksClosed(store: Store, venture: Venture): string | undefined {
  const now = monthOf(store.meta.clock);
  const d = new Date(`${now}-01T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() - 1);
  const last = monthOf(d.toISOString());
  return [now, last].find((m) => store.ledger.some((l) => l.ventureId === venture.id && l.kind === "service-charge" && l.ref === `svc:${m}:finance`));
}

/** The "ready to hand off" checklist. Every item is a setting, so members can change the bar. */
export function handOffChecklist(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): { ready: boolean; stageOk: boolean; items: ChecklistItem[] } {
  const items: ChecklistItem[] = [];
  const n = params.HANDOFF_MIN_CUSTOMERS;
  items.push({
    key: "customers",
    label: `At least ${n} paying customers`,
    met: venture.customers.count >= n,
    detail: `${venture.customers.count} paying ${venture.customers.count === 1 ? "customer" : "customers"} on the record.`,
    param: "HANDOFF_MIN_CUSTOMERS",
  });
  const g = growthWeeksAtFloor(store, venture, params);
  const m = params.HANDOFF_GROWTH_WEEKS;
  items.push({
    key: "growth",
    label: `The weekly growth floor (${pct(params.GROWTH_FLOOR_WEEKLY_PCT)}) met for ${m} weeks`,
    met: g.weeks >= m,
    detail:
      g.fromQuarters > 0
        ? `${g.weeks} weeks: ${g.fromUpdates} from weekly updates, ${g.fromQuarters} from quarterly revenue (the last quarter ran at about ${pct(g.weeklyPct ?? 0)} a week).`
        : `${g.weeks} ${g.weeks === 1 ? "week" : "weeks"} in a row from the weekly updates.`,
    param: "HANDOFF_GROWTH_WEEKS",
  });
  const closed = booksClosed(store, venture);
  items.push({
    key: "books",
    label: "Books closed by the shared bookkeeper",
    met: !params.HANDOFF_BOOKS_RECONCILED || !!closed,
    detail: closed ? `Its class was reconciled for ${new Date(`${closed}-01T00:00:00Z`).toLocaleString("en-US", { month: "long", year: "numeric", timeZone: "UTC" })}.` : "No month closed this month or last.",
    param: "HANDOFF_BOOKS_RECONCILED",
  });
  const roster = rosterProgress(store, venture);
  items.push({
    key: "roster",
    label: `Roster at the formation bar (${params.ROSTER_FILL_AT_FORMATION}%)`,
    met: !params.HANDOFF_ROSTER_AT_FORMATION || (roster.pct >= params.ROSTER_FILL_AT_FORMATION && !roster.criticalOpen.length),
    detail: `${roster.filled} of ${roster.total} roles filled (${roster.pct}%)${roster.criticalOpen.length ? `; ${roster.criticalOpen.map((r) => r.label.toLowerCase()).join(", ")} open` : ""}.`,
    param: "HANDOFF_ROSTER_AT_FORMATION",
  });
  const breaches = breachCount(store, venture.id);
  const openFlags = pendingConductVotes(store, venture.id);
  items.push({
    key: "conduct",
    label: "A clean conduct record",
    met: breaches <= params.HANDOFF_MAX_BREACHES && openFlags === 0,
    detail: `${breaches} confirmed ${breaches === 1 ? "breach" : "breaches"}${openFlags ? `; ${openFlags} reported ${openFlags === 1 ? "concern is" : "concerns are"} still being voted on, which blocks a hand-off until it's resolved` : ""}.`,
    param: "HANDOFF_MAX_BREACHES",
  });
  const stageOk = HAND_OFF_STAGES.includes(venture.status);
  return { ready: stageOk && items.every((i) => i.met), stageOk, items };
}

/** Reported concerns still being voted on. Any one of them blocks a hand-off until it's resolved. */
export function pendingConductVotes(store: Pick<Store, "flags">, ventureId: string): number {
  return store.flags.filter((f) => f.ventureId === ventureId && f.status === "voting").length;
}

export function offersFor(store: Pick<Store, "offers">, ventureId: string): HandOffOffer[] {
  return store.offers.filter((o) => o.ventureId === ventureId).sort((a, b) => b.at.localeCompare(a.at));
}

export const conductHoldNote = (n: number) =>
  `${n} reported ${n === 1 ? "concern is" : "concerns are"} still being voted on. The hand-off waits until ${n === 1 ? "it's" : "they're"} resolved; check the offer then.`;

export const openOffer = (o: Pick<HandOffOffer, "status">) => o.status === "submitted" || o.status === "voting";

export interface PayoutPreview {
  cashUsd: number;
  protocolUsd: number;
  contributorUsd: number;
  perUnitUsd: number;
  payouts: { handle: string; units: number; usd: number }[];
  /** Seat holders with no vested units: they get nothing from a hand-off. */
  seatOnly: number;
}

/** How the contributors' cash splits: the Protocol fee first, then the rest by vested units. Seats get nothing. */
export function payoutPreview(store: Store, venture: Venture, cashUsd: number, params: ParamValues = resolveParams(store)): PayoutPreview {
  const vested = vestedByHandle(store, venture.id);
  const total = totalVestedUnits(store, venture.id);
  const protocolUsd = round(cashUsd * (protocolPctFor(venture, params) / 100));
  const contributorUsd = round(cashUsd - protocolUsd);
  const perUnitUsd = total > 0 ? contributorUsd / total : 0;
  const payouts = Object.entries(vested)
    .filter(([, u]) => u > 0)
    .map(([handle, units]) => ({ handle, units, usd: round(units * perUnitUsd) }))
    .sort((a, b) => b.units - a.units || a.handle.localeCompare(b.handle));
  const seatOnly = seatHolders(store, venture.id).filter((h) => !(vested[h] > 0)).length;
  return { cashUsd, protocolUsd, contributorUsd, perUnitUsd: round(perUnitUsd, 4), payouts, seatOnly };
}

const usd = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 2 })}`;

/** The agent's plain summary for unit holders. Written by rule, so it never says more than the offer does. */
export function summariseOffer(store: Store, venture: Venture, o: Pick<HandOffOffer, "entrepreneur" | "priceUsd" | "plan" | "contributors">, params: ParamValues = resolveParams(store)): string {
  const p = payoutPreview(store, venture, o.contributors.cashUsd, params);
  const parts = [`@${o.entrepreneur} offers ${usd(o.priceUsd)} to adopt ${venture.name} and run it with their own money.`];
  if (o.contributors.cashUsd > 0) {
    parts.push(
      `${usd(o.contributors.cashUsd)} of it is paid to contributors now: ${usd(p.protocolUsd)} Protocol fee, then ${usd(p.contributorUsd)} across ${p.payouts.length} people by vested units, about ${usd(round(p.perUnitUsd, 2))} a unit.`,
    );
  }
  if (o.contributors.retainedSharePct > 0) parts.push(`Contributors keep ${o.contributors.retainedSharePct}% of the profit after the hand-off.`);
  if (o.priceUsd > o.contributors.cashUsd) parts.push(`The other ${usd(o.priceUsd - o.contributors.cashUsd)} stays in the venture as working capital.`);
  parts.push(`Seat holders without units get nothing${p.seatOnly ? ` (${p.seatOnly} of them)` : ""}. Their plan: “${o.plan.trim()}”`);
  return parts.join(" ");
}

export interface OfferInput {
  slug: string;
  handle: string;
  priceUsd: number;
  plan: string;
  cashUsd: number;
  retainedSharePct: number;
  note?: string;
}

/** A verified member offers to adopt a venture that is ready to hand off. */
export function submitOffer(store: Store, input: OfferInput): HandOffOffer {
  const params = resolveParams(store);
  const venture = ventureBySlug(store, input.slug);
  if (!venture || venture.isProtocol) throw new ProtocolError("That venture doesn't exist.");
  const member = memberByHandle(store, input.handle);
  if (member?.qualification !== "qualified") throw new ProtocolError("Only a verified member can offer to adopt a venture. A pseudonymous handle is fine.");
  if (input.handle === venture.stewardHandle) throw new ProtocolError("The steward checks offers, so the steward can't make one.");
  const list = handOffChecklist(store, venture, params);
  if (!list.stageOk) throw new ProtocolError(`${venture.name} can be handed off once it has paying customers.`);
  if (!list.ready) throw new ProtocolError(`${venture.name} isn't ready to hand off yet: ${list.items.filter((i) => !i.met).map((i) => i.label.toLowerCase()).join("; ")}.`);
  if (store.offers.some((o) => o.ventureId === venture.id && o.entrepreneur === input.handle && openOffer(o))) throw new ProtocolError("You already have an open offer for this venture.");
  const plan = input.plan.trim();
  if (plan.length < 20) throw new ProtocolError("Say what you'll do with it: a sentence or two at least.");
  if (!(input.priceUsd > 0)) throw new ProtocolError("Give a price.");
  if (!(input.cashUsd >= 0 && input.cashUsd <= input.priceUsd)) throw new ProtocolError("The cash to contributors comes out of the price, so it can't be more than the price.");
  if (!(input.retainedSharePct >= 0 && input.retainedSharePct < 100)) throw new ProtocolError("A retained share is between 0% and 99%.");
  if (!(input.cashUsd > 0 || input.retainedSharePct > 0)) throw new ProtocolError("Say what contributors get: cash now, a retained share of profit, or both.");
  const draft = {
    entrepreneur: input.handle,
    priceUsd: round(input.priceUsd),
    plan,
    contributors: { cashUsd: round(input.cashUsd), retainedSharePct: input.retainedSharePct, note: input.note?.trim() || undefined },
  };
  const offer: HandOffOffer = {
    id: newId(store, "off"),
    ventureId: venture.id,
    at: store.meta.clock,
    ...draft,
    summary: summariseOffer(store, venture, draft, params),
    status: "submitted",
  };
  store.offers.push(offer);
  ledger(store, { ventureId: venture.id, kind: "handoff", handle: input.handle, usd: offer.priceUsd, ref: offer.id, note: `@${input.handle} offered ${usd(offer.priceUsd)} to adopt ${venture.name}. The steward checks it, then unit holders vote.` });
  notify(store, venture.id, venture.stewardHandle, `@${input.handle} made an offer to adopt ${venture.name}; check it on /steward`);
  return offer;
}

/** The steward's check that the offer follows the rules. It never judges the price; holders do. */
export function conformanceCheck(store: Store, offer: HandOffOffer, params: ParamValues = resolveParams(store)): NonNullable<HandOffOffer["check"]> & { by: string } {
  const venture = ventureById(store, offer.ventureId);
  const list = handOffChecklist(store, venture, params);
  const p = payoutPreview(store, venture, offer.contributors.cashUsd, params);
  const member = memberByHandle(store, offer.entrepreneur);
  const otherVote = store.offers.some((o) => o.id !== offer.id && o.ventureId === venture.id && o.status === "voting");
  const items = [
    { label: "The venture is still ready to hand off", ok: list.ready, detail: list.ready ? "Every item on the checklist is met." : list.items.filter((i) => !i.met).map((i) => i.label).join("; ") },
    { label: "The entrepreneur is verified and isn't the steward", ok: member?.qualification === "qualified" && offer.entrepreneur !== venture.stewardHandle, detail: `@${offer.entrepreneur}` },
    { label: "Cash to contributors comes out of the price", ok: offer.contributors.cashUsd <= offer.priceUsd, detail: `${usd(offer.contributors.cashUsd)} of ${usd(offer.priceUsd)}` },
    { label: "Contributors get something", ok: offer.contributors.cashUsd > 0 || offer.contributors.retainedSharePct > 0, detail: [offer.contributors.cashUsd > 0 && `${usd(offer.contributors.cashUsd)} now`, offer.contributors.retainedSharePct > 0 && `${offer.contributors.retainedSharePct}% of profit after`].filter(Boolean).join(" and ") || "nothing" },
    { label: "Only earned units are paid", ok: p.payouts.length > 0, detail: `${p.payouts.length} people with vested units; ${p.seatOnly} seat holders without units get nothing` },
    { label: "No other offer is being voted on", ok: !otherVote, detail: otherVote ? "One offer goes to a vote at a time." : "None." },
  ];
  const warnings: string[] = [];
  warnings.push("The price isn't checked against a formula: whether it should be is an open request.");
  return { by: venture.stewardHandle, at: store.meta.clock, passed: items.every((i) => i.ok), items, warnings };
}

/** The steward runs the check. If it passes, unit holders vote; the steward can't approve a hand-off alone. */
export function stewardCheckOffer(store: Store, input: { offerId: string; by: string }): HandOffOffer {
  const params = resolveParams(store);
  const offer = store.offers.find((o) => o.id === input.offerId);
  if (!offer) throw new ProtocolError("No such offer.");
  const venture = ventureById(store, offer.ventureId);
  if (input.by !== venture.stewardHandle) throw new ProtocolError(`Only @${venture.stewardHandle} checks offers for ${venture.name}.`);
  if (offer.status !== "submitted") throw new ProtocolError(`This offer is ${offer.status}.`);
  const pending = pendingConductVotes(store, venture.id);
  if (pending) throw new ProtocolError(conductHoldNote(pending));
  const check = conformanceCheck(store, offer, params);
  offer.check = check;
  if (!check.passed) {
    offer.status = "declined";
    offer.decidedAt = store.meta.clock;
    offer.outcome = `Didn't pass the steward's check: ${check.items.filter((i) => !i.ok).map((i) => i.label.toLowerCase()).join("; ")}.`;
    ledger(store, { ventureId: venture.id, kind: "handoff", ref: offer.id, note: `@${offer.entrepreneur}'s offer didn't pass the steward's check, so it doesn't go to a vote.` });
    notify(store, venture.id, offer.entrepreneur, `your offer for ${venture.name} didn't pass the steward's check`);
    return offer;
  }
  const threshold = (params.RESERVED_MATTERS as Record<string, "simple" | "super">).sale ?? "super";
  const rfe = postRfe(store, venture.id, {
    type: "judgment",
    kind: "governance",
    title: `Hand ${venture.name} off to @${offer.entrepreneur}?`,
    question: `${offer.summary} The steward checked it against the rules. Should ${venture.name} be handed off on these terms?`,
    recommendation: "Unit holders decide; the agent doesn't recommend on a hand-off",
    confidence: 0.5,
    stakes: "high",
    format: "choice",
    options: [...HAND_OFF_OPTIONS],
    offerUnits: 0,
    audience: `${venture.name} unit holders`,
    governance: {
      matter: "sale",
      threshold,
      windowEndsAt: addDays(store.meta.clock, params.VOTE_WINDOW_DAYS),
      proposedValue: { offerId: offer.id },
      effect: `If it passes, ${usd(offer.contributors.cashUsd)} is paid to people with earned units by vested units, and ${venture.name} leaves the Protocol. ${MARK_ENDS_NOTE}`,
    },
  });
  offer.voteRfeId = rfe.id;
  offer.status = "voting";
  ledger(store, { ventureId: venture.id, kind: "handoff", ref: offer.id, note: `@${offer.entrepreneur}'s offer passed the steward's check; unit holders are voting.` });
  for (const p of payoutPreview(store, venture, offer.contributors.cashUsd, params).payouts) {
    notify(store, venture.id, p.handle, `vote on handing ${venture.name} off to @${offer.entrepreneur}`);
  }
  return offer;
}

export function withdrawOffer(store: Store, input: { offerId: string; by: string }): HandOffOffer {
  const offer = store.offers.find((o) => o.id === input.offerId);
  if (!offer) throw new ProtocolError("No such offer.");
  if (offer.entrepreneur !== input.by) throw new ProtocolError("Only the person who made the offer can withdraw it.");
  if (!openOffer(offer)) throw new ProtocolError(`This offer is ${offer.status}.`);
  offer.status = "withdrawn";
  offer.decidedAt = store.meta.clock;
  offer.outcome = "Withdrawn by the entrepreneur.";
  const rfe = offer.voteRfeId ? store.rfes.find((r) => r.id === offer.voteRfeId) : undefined;
  if (rfe && isOpen(rfe)) {
    if (rfe.status === "posted") setRfeStatus(rfe, "quorum");
    setRfeStatus(rfe, "resolved");
    rfe.resolvedAt = store.meta.clock;
    rfe.resolution = "Closed: the offer was withdrawn.";
  }
  ledger(store, { ventureId: offer.ventureId, kind: "handoff", ref: offer.id, note: `@${offer.entrepreneur} withdrew their offer.` });
  return offer;
}

/** Called when the hand-off vote closes. Only a passed vote hands the venture off. */
export function settleHandOffVote(store: Store, rfe: Rfe, passes: boolean, summary: string) {
  const offerId = (rfe.governance?.proposedValue as { offerId?: string } | undefined)?.offerId;
  const offer = store.offers.find((o) => o.id === offerId);
  if (!offer || offer.status !== "voting") return;
  const venture = ventureById(store, offer.ventureId);
  if (!passes) {
    offer.status = "declined";
    offer.decidedAt = store.meta.clock;
    offer.outcome = `Unit holders voted to keep it in the Protocol. ${summary}`;
    rfe.resolution = `Did not pass: ${venture.name} stays in the Protocol. ${summary}`;
    ledger(store, { ventureId: venture.id, kind: "handoff", ref: offer.id, note: `Unit holders didn't approve @${offer.entrepreneur}'s offer. ${venture.name} keeps running.` });
    notify(store, venture.id, offer.entrepreneur, `unit holders didn't approve your offer for ${venture.name}`);
    return;
  }
  const breaches = breachCount(store, venture.id);
  const pending = pendingConductVotes(store, venture.id);
  const params = resolveParams(store);
  if (breaches > params.HANDOFF_MAX_BREACHES || pending > 0 || !HAND_OFF_STAGES.includes(venture.status)) {
    offer.status = "declined";
    offer.decidedAt = store.meta.clock;
    const why =
      breaches > params.HANDOFF_MAX_BREACHES
        ? "a breach was confirmed during the vote"
        : pending > 0
          ? "a reported concern was still being voted on; the entrepreneur can offer again once it's resolved"
          : `${venture.name} is no longer at a stage that can be handed off`;
    offer.outcome = `Passed, but not applied: ${why}. ${summary}`;
    rfe.resolution = offer.outcome;
    return;
  }
  rfe.resolution = `Passed: ${venture.name} is handed off to @${offer.entrepreneur}. ${summary}`;
  executeHandOff(store, offer, rfe);
}

function executeHandOff(store: Store, offer: HandOffOffer, rfe: Rfe) {
  if (rfe.status !== "resolved" || !rfe.resolution?.startsWith("Passed")) throw new ProtocolError("A hand-off needs a passed unit-holder vote.");
  const params = resolveParams(store);
  const venture = ventureById(store, offer.ventureId);
  const p = payoutPreview(store, venture, offer.contributors.cashUsd, params);
  if (p.protocolUsd > 0) {
    ledger(store, { ventureId: venture.id, kind: "handoff-payout", usd: p.protocolUsd, ref: offer.id, note: "Hand-off: Protocol fee to the Protocol" });
  }
  for (const x of p.payouts) {
    ledger(store, { ventureId: venture.id, kind: "handoff-payout", handle: x.handle, usd: x.usd, units: x.units, ref: offer.id, note: `Hand-off: ${x.units} vested units × $${p.perUnitUsd}` });
  }
  offer.status = "approved";
  offer.decidedAt = store.meta.clock;
  offer.outcome = `Approved by unit holders. ${usd(offer.contributors.cashUsd)} paid by vested units.`;
  venture.handOff = {
    offerId: offer.id,
    at: store.meta.clock,
    entrepreneur: offer.entrepreneur,
    priceUsd: offer.priceUsd,
    payoutUsd: offer.contributors.cashUsd,
    retainedSharePct: offer.contributors.retainedSharePct,
  };
  for (const o of store.offers.filter((x) => x.ventureId === venture.id && x.id !== offer.id && openOffer(x))) {
    o.status = "declined";
    o.decidedAt = store.meta.clock;
    o.outcome = `Closed: ${venture.name} was handed off to @${offer.entrepreneur}.`;
  }
  for (const r of store.rfes.filter((x) => x.ventureId === venture.id && isOpen(x) && x.id !== rfe.id)) {
    if (r.status === "posted") setRfeStatus(r, "quorum");
    setRfeStatus(r, "resolved");
    r.resolvedAt = store.meta.clock;
    r.resolution = "Closed: the venture was handed off.";
  }
  for (const d of store.decisions.filter((x) => x.ventureId === venture.id && x.status.startsWith("awaiting"))) {
    rejectDecision(store, d, "Closed: the venture was handed off.");
  }
  transitionVenture(store, venture, "handed-off", `adopted by @${offer.entrepreneur}`);
  for (const x of p.payouts) notify(store, venture.id, x.handle, `${venture.name} was handed off; you were paid $${x.usd} for ${x.units} vested units`);
}
