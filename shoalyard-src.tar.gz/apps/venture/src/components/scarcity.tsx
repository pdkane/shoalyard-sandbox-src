import Link from "next/link";
import { Eye, Ticket, UserRoundCheck, Users } from "lucide-react";
import { lessonsArePublic, nextAnnouncedBatch, onWaitlist, type Scarcity } from "@av/protocol";
import type { Cohort, Venture } from "@av/schema";
import { buttonVariants } from "@/components/ui/button";
import { WaitlistForm } from "@/components/waitlist-form";
import type { Data } from "@/lib/data";
import { cn } from "@/lib/utils";

const ICONS = [
  [/seats? (left|taken)/, Ticket],
  [/^Roles:/, Users],
  [/first look/, Eye],
] as const;

/** The true numbers: seats left of the deck's maximum, roles claimed, how long members have had first look. */
export function ScarcityStrip({ sc, className }: { sc: Scarcity; className?: string }) {
  if (!sc.lines.length) return null;
  return (
    <ul className={cn("flex flex-wrap gap-1.5", className)} aria-label="Seats and roles right now">
      {sc.lines.map((line) => {
        const Icon = ICONS.find(([re]) => re.test(line))?.[1] ?? Ticket;
        const urgent = sc.seats?.full && /seats taken/.test(line);
        return (
          <li
            key={line}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium tabular-nums",
              urgent ? "border-amber-200 bg-amber-50 text-amber-900" : "border-zinc-200 bg-white text-zinc-700",
            )}
          >
            <Icon className="size-3.5 text-zinc-500" /> {line}
          </li>
        );
      })}
      {sc.waiting > 0 && (
        <li className="inline-flex items-center rounded-full border border-zinc-200 bg-white px-2.5 py-1 text-xs text-zinc-600 tabular-nums">
          {sc.waiting} waiting
        </li>
      )}
    </ul>
  );
}

/** What "get notified" means on this page, so the form never promises something that can't happen. */
function notifyTarget(data: Data, venture?: Venture, cohort?: Cohort, full?: boolean) {
  if (venture && full) return { slug: venture.slug, label: "Join the waitlist", target: { ventureId: venture.id } };
  const c = cohort?.status === "announced" ? cohort : nextAnnouncedBatch(data.store);
  return { batch: c?.number, label: c ? "Tell me when it opens" : "Tell me about the next batch", target: { cohortId: c?.id } };
}

/**
 * Shown to someone who arrived through a share link and isn't verified yet: what members get,
 * and the three ways in. Nothing here is a countdown trick; the hours are the real early-access window.
 */
export function ShareLanding({ data, venture, cohort, full, signedIn }: { data: Data; venture?: Venture; cohort?: Cohort; full?: boolean; signedIn: boolean }) {
  const { params, member, store } = data;
  const n = notifyTarget(data, venture, cohort, full);
  const handle = signedIn ? member?.handle : undefined;
  const joined = handle ? !!onWaitlist(store, handle, n.target) : false;
  const claimable = venture && ["pitched", "funded", "formed", "operating"].includes(venture.status) && !venture.isProtocol;
  return (
    <aside className="space-y-4 rounded-xl border border-sky-200 bg-sky-50/60 p-5" aria-labelledby="share-landing">
      <div className="space-y-1.5">
        <h2 id="share-landing" className="text-base font-semibold tracking-tight text-zinc-900">
          Someone shared this with you
        </h2>
        <p className="max-w-2xl text-sm text-pretty text-zinc-700">
          Verified members see more and go first: {lessonsArePublic(params) ? "" : "the lessons from earlier ventures, "}what went well
          and wrong each week, each experiment&apos;s result, and seats {params.EARLY_ACCESS_HOURS} hours before everyone else. Getting verified costs nothing.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="space-y-2 rounded-lg border border-zinc-200 bg-white p-3">
          <p className="text-sm font-medium">Get notified</p>
          <p className="text-xs text-zinc-500">
            {venture && full ? "Every seat is taken. If one frees up, the first person waiting hears first." : n.batch ? `Hear when Batch ${String(n.batch).padStart(3, "0")} opens.` : "Hear when the next batch is announced."}
          </p>
          <WaitlistForm slug={n.slug} batch={n.batch} handle={handle} joined={joined} label={n.label} />
        </div>
        <div className="space-y-2 rounded-lg border border-zinc-200 bg-white p-3">
          <p className="text-sm font-medium">Claim a role</p>
          <p className="text-xs text-zinc-500">Ventures need people who know the customer. A role needs no seat; accepted work earns an equal share.</p>
          {claimable ? (
            <Link href={`/v/${venture.slug}#people`} className={buttonVariants({ variant: "outline", size: "sm" })}>
              <Users /> See the roles
            </Link>
          ) : (
            <p className="text-xs text-zinc-500">Roles open with the plan.</p>
          )}
        </div>
        <div className="space-y-2 rounded-lg border border-zinc-200 bg-white p-3">
          <p className="text-sm font-medium">Get verified</p>
          <p className="text-xs text-zinc-500">Link LinkedIn or X; the steward checks it matches what you say you do.</p>
          <Link href={handle ? "/onboarding?step=qualify" : "/onboarding"} className={buttonVariants({ variant: "outline", size: "sm" })}>
            <UserRoundCheck /> Get verified
          </Link>
        </div>
      </div>
    </aside>
  );
}
