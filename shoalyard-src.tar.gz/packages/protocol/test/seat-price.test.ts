import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams, type Store } from "@av/schema";
import { buildDeck, latestDeck, logSeatPriceDecision, seatPriceHold, seatPriceOf, seatPriceStatus, type DeckDraft } from "../src/deck";
import { DECK_DRAFTS } from "../src/deck-content";
import { checkPriceProposal } from "../src/seat-price";
import { closeGovernance, logDecision, respond, stewardDecide, ventureBySlug } from "../src/ops";
import { buildSeed } from "../src/seed";
import { priceBand } from "../src/sizing";
import { learningStats } from "../src/learning";
import { resolveParams } from "../src/params";

const seed = buildSeed();
const fresh = () => structuredClone(seed) as Store;
const params = defaultParams();

test("every generated venture's price sits in its band, with tagged claims and a pricing decision", () => {
  for (const slug of ["bid-desk", "site-record", "lumper-line"]) {
    const v = ventureBySlug(seed, slug)!;
    const plan = latestDeck(seed, v.id)!.seatPlan;
    assert.equal(plan.rule, "derived");
    assert.ok(plan.priceUsd >= params.SEAT_PRICE_MIN_USD && plan.priceUsd <= plan.price!.upperUsd, slug);
    assert.ok(plan.price!.upperUsd <= Math.floor(plan.proofBudgetUsd / plan.headcount) || plan.price!.upperUsd === params.SEAT_PRICE_MIN_USD, `${slug}: proof ÷ people bounds the price`);
    assert.equal(plan.min, Math.max(plan.headcount, Math.ceil(plan.proofBudgetUsd / plan.priceUsd), params.SEAT_FLOOR), `${slug}: seats = proof ÷ price, never below the headcount`);
    assert.equal(seatPriceOf(v, params), plan.priceUsd);
    assert.deepEqual(checkPriceProposal({ priceUsd: plan.priceUsd, claims: plan.price!.claims }, priceBand({ budget: latestDeck(seed, v.id)!.budget, requestPlan: latestDeck(seed, v.id)!.requestPlan, roster: latestDeck(seed, v.id)!.roster }, params)), []);
    const d = seed.decisions.find((x) => x.id === plan.price!.decisionId)!;
    assert.ok(d.facts.pricingChange && d.bin === "gated");
  }
  assert.equal(seatPriceStatus(seed, latestDeck(seed, "lumper-line")), "signed");
  assert.equal(seatPriceStatus(seed, latestDeck(seed, "bid-desk")), "awaiting");
});

test("ventures already pitched keep their $10 price and minimum (Article 6)", () => {
  for (const slug of ["dockside", "permit-pulse", "lien-clock"]) {
    const v = ventureBySlug(seed, slug)!;
    const deck = latestDeck(seed, v.id)!;
    assert.equal(v.seatPriceUsd, undefined);
    assert.equal(seatPriceOf(v, params), 10);
    assert.equal(deck.seatPlan.priceUsd, 10);
    assert.equal(seatPriceStatus(seed, deck), "kept");
    assert.equal(seatPriceHold(seed, v), undefined);
  }
});

test("the agent's price is used when it's in the band and justified; otherwise the pricing rule is", () => {
  const s = fresh();
  const v = ventureBySlug(s, "bid-desk")!;
  const draft = DECK_DRAFTS["bid-desk"]();
  const claims = latestDeck(s, v.id)!.seatPlan.price!.claims;
  const good = buildDeck(s, v, { ...draft, seatPrice: { priceUsd: 40, claims } } as DeckDraft, { author: "test", cause: { kind: "pitch" } });
  assert.equal(good.seatPlan.priceUsd, 40);
  assert.equal(good.seatPlan.price!.proposedBy, "agent");
  const over = buildDeck(s, v, { ...draft, seatPrice: { priceUsd: 400, claims } } as DeckDraft, { author: "test", cause: { kind: "pitch" } });
  assert.equal(over.seatPlan.price!.proposedBy, "script", "outside the band, code uses its own rule");
  assert.ok(over.seatPlan.priceUsd <= over.seatPlan.price!.upperUsd);
  const bare = buildDeck(s, v, { ...draft, seatPrice: { priceUsd: 40, claims: [] } } as DeckDraft, { author: "test", cause: { kind: "pitch" } });
  assert.equal(bare.seatPlan.price!.proposedBy, "script", "a price without claims isn't accepted");
});

test("a declined price keeps seats closed until a new one is signed", () => {
  const s = fresh();
  const v = ventureBySlug(s, "site-record")!;
  const deck = latestDeck(s, v.id)!;
  stewardDecide(s, deck.seatPlan.price!.decisionId!, false, "Too high for site supers.", v.stewardHandle);
  assert.equal(seatPriceStatus(s, deck), "declined");
  assert.match(seatPriceHold(s, v) ?? "", /declined/);
  const again = logSeatPriceDecision(s, v, deck)!;
  assert.equal(again.status, "awaiting_steward");
  assert.equal(seatPriceStatus(s, deck), "awaiting");
});

test("the seat price maximum is protected: a vote can lower it, but raising it waits for counsel", () => {
  const vote = (s: Store, value: number) => {
    const v0 = ventureBySlug(s, "protocol")!;
    const { rfe } = logDecision(s, {
      ventureId: v0.id,
      title: `Set the highest seat price to $${value}`,
      reasoning: "Proposed by a member.",
      confidence: 0.5,
      model: "script",
      rfe: {
        type: "judgment",
        kind: "governance",
        title: "Amend SEAT_PRICE_MAX_USD",
        question: `Set it to $${value}?`,
        recommendation: "No",
        stakes: "high",
        format: "choice",
        options: ["Yes", "No"],
        offerUnits: 0,
        audience: "Holders",
        governance: { matter: "Parameter amendment", threshold: "simple", windowEndsAt: "2026-11-06T12:00:00.000Z", paramKey: "SEAT_PRICE_MAX_USD", currentValue: 100, proposedValue: value, effect: "Moves the highest seat price." },
      },
    });
    for (const h of ["policy_pia", "counsel_kemi", "cfo_ines", "ux_uma"]) respond(s, { rfeId: rfe!.id, handle: h, via: "structured", choice: "Yes" });
    s.meta.clock = "2026-11-07T00:00:00.000Z";
    closeGovernance(s, rfe!);
    return rfe!;
  };
  const up = fresh();
  assert.match(vote(up, 250).resolution ?? "", /not applied: the highest seat price can rise only once counsel answers/);
  assert.equal(up.amendments.filter((a) => a.paramKey === "SEAT_PRICE_MAX_USD").length, 0);
  const down = fresh();
  vote(down, 50);
  assert.equal(down.amendments.filter((a) => a.paramKey === "SEAT_PRICE_MAX_USD").length, 1);
});

test("the learning loop tracks seats sold against seats needed, by price and customer", () => {
  const rows = learningStats(seed).sellThrough;
  assert.ok(rows.length > 0);
  for (let i = 1; i < rows.length; i++) assert.ok(rows[i - 1].priceUsd <= rows[i].priceUsd, "cheapest first");
  for (const r of rows) {
    const v = seed.ventures.find((x) => x.id === r.ventureId)!;
    assert.ok(v.statusHistory.some((h) => h.status === "pitched"), `${v.slug} has sold seats`);
    assert.equal(r.priceUsd, seatPriceOf(v, resolveParams(seed)));
    assert.ok(r.customer);
  }
  assert.ok(!rows.some((r) => r.ventureId === "bid-desk"), "a venture still announced hasn't sold seats");
});
