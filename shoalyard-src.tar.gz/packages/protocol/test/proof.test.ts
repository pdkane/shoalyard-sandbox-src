import assert from "node:assert/strict";
import { test } from "node:test";
import type { ProofPlan, Store } from "@av/schema";
import { latestDeck, validateDeck } from "../src/deck";
import { DECK_DRAFTS } from "../src/deck-content";
import { IDEA_LIBRARY } from "../src/ideas";
import { ventureBySlug } from "../src/ops";
import { resolveParams } from "../src/params";
import { checkOperability, operableProof, proofRosterErrors, proofRunBy } from "../src/proof";
import { PROOF_PLANS } from "../src/proof-plans";
import { buildSeed } from "../src/seed";
import { spawnVenture } from "../src/spawn";

const seed = buildSeed();
const params = resolveParams(seed);
const fresh = () => structuredClone(seed) as Store;

test("every written plan and library idea can be run after the agent reshapes it", () => {
  for (const [slug, plan] of Object.entries(PROOF_PLANS)) {
    const { plan: ok } = operableProof(plan, params);
    assert.deepEqual(checkOperability(ok, params), [], slug);
  }
  for (const idea of IDEA_LIBRARY) assert.deepEqual(checkOperability(operableProof(idea.proof, params).plan, params), [], idea.slug);
});

test("every seeded venture's deck carries a proof the Protocol can run, and each member request has a role", () => {
  for (const v of seed.ventures.filter((v) => !v.isProtocol)) {
    const deck = latestDeck(seed, v.id)!;
    assert.ok(deck.proof, `${v.slug} has a proof plan`);
    assert.deepEqual(checkOperability(deck.proof, params), [], v.slug);
    assert.deepEqual(proofRosterErrors(deck.proof, deck.roster), [], v.slug);
    assert.ok(deck.proof.entrepreneurBuilds && deck.proof.operatorReason, v.slug);
  }
});

test("a hire is rejected and reshaped into contractor work, and the seed logs it under the code name", () => {
  const raw = PROOF_PLANS["bid-desk"];
  assert.deepEqual(checkOperability(raw, params).map((i) => i.need), ["employee"]);
  const { plan, rejected } = operableProof(raw, params);
  assert.equal(rejected.length, 1);
  const task = plan.tasks.find((t) => t.key === "assemble")!;
  assert.equal(task.runBy, "contractor");
  assert.doesNotMatch(task.task, /hire/i);
  assert.equal(plan.reshaped[0].need, "employee");
  assert.equal(latestDeck(seed, "bid-desk")!.proof!.reshaped.length, 1);
  const v = ventureBySlug(seed, "bid-desk")!;
  const d = seed.decisions.find((d) => d.ventureId === v.id && d.title.startsWith("Reshape"))!;
  assert.equal(d.title, `Reshape ${v.codename}'s proof: one task the Protocol can't run`);
  assert.ok(!d.title.includes(v.name));
  assert.match(d.reasoning, /Proof run by: The agent, with 1 member request and 1 contractor/);
  assert.ok(!checkOperability(raw, { EMPLOYMENT_ALLOWED: true }).length, "once employment is allowed, the hire stands");
});

test("a licence the Protocol doesn't hold stops the proof at commitments and expects a hand-off", () => {
  const s = fresh();
  const idea = IDEA_LIBRARY.find((i) => i.slug === "cert-chase")!;
  assert.equal(checkOperability(idea.proof, params)[0].need, "licence");
  const batch = s.cohorts.find((c) => c.status === "announced")!;
  const v = spawnVenture(s, batch, idea.classification, { idea });
  const proof = latestDeck(s, v.id)!.proof!;
  assert.equal(proof.longTermOperator, "hand-off expected");
  assert.match(proof.entrepreneurBuilds, /an insurance producer licence/);
  assert.match(proof.tasks.find((t) => t.key === "quote")!.task, /letters of intent/);
  assert.ok(s.decisions.some((d) => d.ventureId === v.id && d.title === `Reshape ${v.codename}'s proof: one task the Protocol can't run`));
});

test("a visit nobody covers goes to a paid local contractor; a member or contractor may go in person", () => {
  const plan: ProofPlan = {
    tasks: [
      { key: "walk", task: "Walk the site with the foreman before each pour.", runBy: "agent", needs: [], place: "the job site" },
      { key: "visit", task: "Members visit three yards in person.", runBy: "member request", roleKey: "icp-operator", needs: [] },
    ],
    longTermOperator: "agents",
    operatorReason: "Software.",
    entrepreneurBuilds: "Nothing.",
    reshaped: [],
  };
  assert.deepEqual(checkOperability(plan, params).map((i) => [i.taskKey, i.need]), [["walk", "in-person"]]);
  const { plan: ok } = operableProof(plan, params);
  assert.equal(ok.tasks[0].runBy, "contractor");
  assert.match(ok.tasks[0].task, /local contractor, paid per visit, goes in person to the job site/);
  assert.equal(proofRunBy(ok), "1 member request and 1 contractor");
});

test("a deck needs a proof plan, and the operability check is a deck rule", () => {
  const v = ventureBySlug(seed, "site-record")!;
  const unknown = { ...v, id: "no-plan", slug: "no-plan" };
  assert.match(validateDeck(seed, unknown, DECK_DRAFTS["site-record"]()).join(" "), /needs a proof plan/);
  const errs = validateDeck(seed, v, { ...DECK_DRAFTS["site-record"](), proof: PROOF_PLANS["bid-desk"] }).join(" ");
  assert.match(errs, /needs an employee.*Reshape the proof/);
});

test("the 'Proof run by' line counts who runs the tasks", () => {
  const t = (runBy: ProofPlan["tasks"][number]["runBy"]) => ({ key: runBy, task: "x", runBy, needs: [] });
  const plan = (...r: ProofPlan["tasks"][number]["runBy"][]): ProofPlan => ({ tasks: r.map(t), longTermOperator: "agents", operatorReason: "", entrepreneurBuilds: "", reshaped: [] });
  assert.equal(proofRunBy(plan("agent")), "The agent alone");
  assert.equal(proofRunBy(plan("agent", "member request", "member request")), "The agent, with 2 member requests");
  assert.equal(proofRunBy(plan("agent", "member request", "contractor")), "The agent, with 1 member request and 1 contractor");
});
