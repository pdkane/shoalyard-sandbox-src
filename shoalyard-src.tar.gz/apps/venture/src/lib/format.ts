const usd0 = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
const usd2 = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function formatUsd(n: number, cents = false): string {
  return (cents ? usd2 : usd0).format(n);
}

export function formatUnits(n: number): string {
  const v = Math.round(n * 100) / 100;
  return `${v.toLocaleString("en-US", { maximumFractionDigits: 2 })} ${v === 1 ? "unit" : "units"}`;
}

export function formatNumber(n: number, dp = 2): string {
  return n.toLocaleString("en-US", { maximumFractionDigits: dp });
}

export function formatPct(n: number, dp = 1): string {
  return `${n.toLocaleString("en-US", { maximumFractionDigits: dp })}%`;
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
}

export function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "UTC",
  });
}

/** Relative to the simulated clock, not the wall clock. */
export function formatAgo(iso: string, clock: string): string {
  const diff = Date.parse(clock) - Date.parse(iso);
  const future = diff < 0;
  const mins = Math.abs(diff) / 60000;
  const unit = (n: number, s: string) => `${Math.round(n)} ${s}${Math.round(n) === 1 ? "" : "s"}`;
  let text: string;
  if (mins < 60) text = mins < 2 ? "just now" : unit(mins, "minute");
  else if (mins < 60 * 24) text = unit(mins / 60, "hour");
  else if (mins < 60 * 24 * 45) text = unit(mins / 1440, "day");
  else if (mins < 60 * 24 * 365) text = unit(mins / 43200, "month");
  else text = unit(mins / 525600, "year");
  if (text === "just now") return text;
  return future ? `in ${text}` : `${text} ago`;
}
