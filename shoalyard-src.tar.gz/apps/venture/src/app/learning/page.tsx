import type { Metadata } from "next";
import Link from "next/link";
import {
  appliesToLine,
  batchLabel,
  canReadLessons,
  codenameSlug,
  isRevealed,
  SHARE_CHANNEL_LABELS,
  type ShareFunnelRow,
  clusterLabel,
  LESSON_AXES,
  learningStats,
  lessonTeaser,
  median,
  vocabFor,
  type LessonTeaser,
} from "@av/protocol";
import {
  LESSON_STAGES,
  LESSON_TOPICS,
  LESSON_TOPIC_LABELS,
  RFE_TYPE_LABELS,
  TAG_AXES,
  TAG_AXIS_LABELS,
  type Lesson,
  type TagAxis,
  type Venture,
} from "@av/schema";
import { Pill } from "@/components/badges";
import { BatchStatusPill } from "@/components/batch-ui";
import { MembersOnlyLessons } from "@/components/lessons-gate";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData } from "@/lib/data";
import { formatDate, formatPct, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

export const metadata: Metadata = { title: "Lessons" };

const reached = (v: Venture, s: Venture["status"]) => v.status === s || v.statusHistory.some((h) => h.status === s);

const LESSON_STATUS: Record<Lesson["status"], { label: string; className: string }> = {
  adopted: { label: "Kept", className: "border-emerald-200 bg-emerald-50 text-emerald-800" },
  proposed: { label: "Proposed", className: "border-amber-200 bg-amber-50 text-amber-800" },
  retired: { label: "Replaced", className: "border-zinc-200 bg-zinc-100 text-zinc-500" },
};

const SURE_STYLE: Record<Lesson["howSure"]["level"], string> = {
  Strong: "border-emerald-200 bg-emerald-50 text-emerald-800",
  Moderate: "border-sky-200 bg-sky-50 text-sky-800",
  "Early signal": "border-zinc-200 bg-zinc-50 text-zinc-600",
};

type LessonAxis = (typeof LESSON_AXES)[number];

/** A lesson with no value on an axis applies to every value of it, as in lessonsFor. */
const appliesOn = (l: Lesson, axis: LessonAxis, value: string) => {
  const wanted = l.tags.filter((t) => t.axis === axis).map((t) => t.value);
  return !wanted.length || wanted.includes(value);
};

function Num({ children }: { children: React.ReactNode }) {
  return <TableCell className="text-right tabular-nums">{children}</TableCell>;
}

function FunnelTable({ rows, label, waiting }: { rows: (ShareFunnelRow & { waiting?: number })[]; label: (key: string) => string; waiting?: boolean }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead />
          <TableHead className="text-right">Visits</TableHead>
          <TableHead className="text-right">Signed up</TableHead>
          <TableHead className="text-right">Verified</TableHead>
          <TableHead className="text-right">Seats</TableHead>
          <TableHead className="text-right">Roles</TableHead>
          {waiting && <TableHead className="text-right">Waiting</TableHead>}
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((r) => (
          <TableRow key={r.key}>
            <TableCell className="max-w-40 truncate font-medium">{label(r.key)}</TableCell>
            <Num>{r.stages.visit}</Num>
            <Num>{r.stages.candidate}</Num>
            <Num>{r.stages.qualified}</Num>
            <Num>{r.stages.seat}</Num>
            <Num>{r.stages.role}</Num>
            {waiting && <Num>{r.waiting ?? 0}</Num>}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

/** For visitors: how the lessons work, and that they exist. The lessons themselves are for members (Article 3). */
function PublicLearning({ teaser }: { teaser: LessonTeaser }) {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">Lessons</h1>
        <p className="text-sm text-pretty text-zinc-600">
          When a venture ends, gets its first customer, or finishes a batch, the agent writes down what it learned. New ventures start with the
          lessons that match them, and if the agent wants to do something a lesson warns against, a person has to approve it first.
        </p>
        <p className="text-sm text-pretty text-zinc-600">
          Every decision stays public, including which ones followed a lesson. The lessons themselves are for members: they come from the
          judgement members brought and the calls they made, good and bad.
        </p>
      </div>
      <MembersOnlyLessons teaser={teaser} />
    </div>
  );
}

export default async function LearningPage(props: PageProps<"/learning">) {
  const sp = await props.searchParams;
  const axis: TagAxis = TAG_AXES.includes(sp.axis as TagAxis) ? (sp.axis as TagAxis) : "endMarket";
  const str = (k: string) => (typeof sp[k] === "string" && sp[k] ? (sp[k] as string) : undefined);
  const filters = LESSON_AXES.flatMap((a) => (str(a) ? [{ axis: a, value: str(a)! }] : []));
  const stage = LESSON_STAGES.find((x) => x === str("stage"));
  const { store, params, member } = await getData();
  if (!canReadLessons(member, params)) return <PublicLearning teaser={lessonTeaser(store)} />;
  const stats = learningStats(store);
  const vocab = vocabFor(store);
  const ventures = store.ventures.filter((v) => !v.isProtocol && v.status !== "generated");

  const valueOf = (v: Venture) => v.tags.filter((t) => t.axis === axis).map((t) => t.value);
  const values = [...new Set([...vocab[axis], ...ventures.flatMap(valueOf)])];
  const slices = values
    .map((value) => {
      const vs = ventures.filter((v) => valueOf(v).includes(value));
      const s = learningStats(store, { ventureIds: vs.map((v) => v.id) });
      const units = store.grants.filter((g) => g.rfeId && vs.some((v) => v.id === g.ventureId)).map((g) => g.units);
      return {
        value,
        label: value,
        ventures: vs.length,
        funded: vs.filter((v) => reached(v, "funded")).length,
        customer1: vs.filter((v) => reached(v, "customer1")).length,
        killed: vs.filter((v) => v.status === "killed").length,
        requests: s.byType.reduce((n, t) => n + t.samples, 0),
        medianUnits: units.length ? median(units) : undefined,
        lessons: store.lessons.filter((l) => l.status !== "retired" && l.tags.some((t) => t.axis === axis && t.value === value)).length,
      };
    })
    .filter((s) => s.ventures > 0 || s.lessons > 0);

  const lessons = [...store.lessons]
    .filter((l) => l.status !== "retired")
    .filter((l) => filters.every((f) => appliesOn(l, f.axis, f.value)))
    .filter((l) => !stage || l.appliesTo.stage === stage || l.appliesTo.stage === "Any stage")
    .sort((a, b) => a.id.localeCompare(b.id));
  const byTopic = LESSON_TOPICS.map((topic) => ({ topic, lessons: lessons.filter((l) => l.topic === topic) })).filter((g) => g.lessons.length);
  const retired = store.lessons.filter((l) => l.status === "retired").length;
  const lessonAxisValues = (a: LessonAxis) => [...new Set([...vocab[a], ...store.lessons.flatMap((l) => l.tags.filter((t) => t.axis === a).map((t) => t.value))])];
  const filterHref = (a: string, value: string) => `/learning?${new URLSearchParams({ [a]: value }).toString()}#lessons`;
  const cohorts = [...store.cohorts].sort((a, b) => b.number - a.number);
  const channel = (c: string) => (c === "x_post" ? "X post" : c === "linkedin" ? "LinkedIn" : "Outreach");

  return (
    <div className="space-y-10">
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">Lessons</h1>
        <p className="max-w-2xl text-sm text-zinc-600">
          When a venture ends, gets its first customer, or finishes a batch, the agent writes down what it learned. A lesson is kept once the
          evidence is strong enough; one that would change a setting goes to a holder vote first. New ventures start with the kept lessons that
          match them. If the agent wants to do something a lesson warns against, a person has to approve it first.
        </p>
      </div>

      <section id="lessons" className="scroll-mt-20 space-y-5">
        <form action="/learning#lessons" className="flex flex-wrap items-end gap-2 rounded-xl border border-zinc-200 bg-white p-3 text-sm">
          {LESSON_AXES.map((a) => (
            <label key={a} className="flex flex-col gap-1 text-xs text-zinc-500">
              {TAG_AXIS_LABELS[a]}
              <select
                name={a}
                defaultValue={str(a) ?? ""}
                className="h-8 max-w-48 rounded-md border border-zinc-200 bg-white px-2 text-sm text-zinc-900"
              >
                <option value="">Any</option>
                {lessonAxisValues(a).map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </label>
          ))}
          <label className="flex flex-col gap-1 text-xs text-zinc-500">
            Stage
            <select name="stage" defaultValue={stage ?? ""} className="h-8 rounded-md border border-zinc-200 bg-white px-2 text-sm text-zinc-900">
              <option value="">Any</option>
              {LESSON_STAGES.filter((x) => x !== "Any stage").map((x) => (
                <option key={x} value={x}>
                  {x}
                </option>
              ))}
            </select>
          </label>
          <button type="submit" className="h-8 rounded-md bg-zinc-900 px-3 text-sm font-medium text-white hover:bg-zinc-800">
            Show lessons
          </button>
          {(filters.length > 0 || stage) && (
            <Link href="/learning#lessons" scroll={false} className="h-8 px-1 leading-8 text-zinc-500 underline underline-offset-2">
              Clear
            </Link>
          )}
        </form>
        <p className="text-sm text-zinc-500">
          {filters.length || stage
            ? `Lessons that apply to ${[...filters.map((f) => f.value), ...(stage ? [stage.toLowerCase()] : [])].join(" · ")}: ${lessons.length}.`
            : `${lessons.length} lessons${retired ? `, plus ${retired} replaced by newer evidence` : ""}.`}
        </p>
        {byTopic.length === 0 && <p className="text-sm text-zinc-500">No lesson applies to this kind of venture yet.</p>}
        {byTopic.map((g) => (
          <div key={g.topic} className="space-y-3">
            <h2 className="text-lg font-semibold tracking-tight">{LESSON_TOPIC_LABELS[g.topic]}</h2>
            <ol className="space-y-3">
              {g.lessons.map((l) => {
                const cohort = store.cohorts.find((c) => c.id === l.cohortId);
                return (
                  <li key={l.id} id={l.id} className="scroll-mt-20 rounded-xl border border-zinc-200 bg-white p-4 target:ring-2 target:ring-sky-300">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono font-semibold text-zinc-900">{l.id}</span>
                      <Pill className={LESSON_STATUS[l.status].className}>{LESSON_STATUS[l.status].label}</Pill>
                      <Pill className={SURE_STYLE[l.howSure.level]}>{l.howSure.level}</Pill>
                      <span className="text-zinc-500">Applies to: {appliesToLine(l)}</span>
                    </div>
                    <p className="mt-2 font-medium text-zinc-900">{l.headline}</p>
                    <p className="mt-1 text-sm text-zinc-600">{l.whatHappened}</p>
                    <p className="mt-2 text-sm text-zinc-800">
                      <span className="font-medium">What we do differently:</span> {l.whatWeDoDifferently}
                    </p>
                    <p className="mt-1 text-sm text-zinc-600">
                      <span className="font-medium text-zinc-800">How sure:</span> {l.howSure.level}: {l.howSure.reason}.
                    </p>
                    {l.evidence.length > 0 && (
                      <p className="mt-2 text-xs text-zinc-500">
                        Evidence:{" "}
                        {l.evidence.map((e, i) => (
                          <span key={`${e.kind}-${e.id}`}>
                            {i > 0 && " · "}
                            {e.kind === "rfe" || e.kind === "draft" ? (
                              <Link href={`/rfe/${e.id}`} className="underline underline-offset-2">
                                {e.label}
                              </Link>
                            ) : e.kind === "venture" && store.ventures.some((v) => v.id === e.id) ? (
                              <Link href={`/v/${store.ventures.find((v) => v.id === e.id)!.slug}`} className="underline underline-offset-2">
                                {e.label}
                              </Link>
                            ) : (
                              e.label
                            )}
                          </span>
                        ))}
                      </p>
                    )}
                    {l.amendmentRfeId && (
                      <Link href={`/rfe/${l.amendmentRfeId}`} className="mt-1 inline-block text-xs font-medium underline underline-offset-2">
                        This lesson suggests changing a setting. Vote on it.
                      </Link>
                    )}
                    <p className="mt-2 text-xs text-zinc-400">
                      {cohort ? batchLabel(cohort.number) : l.cohortId} · written by {l.writtenBy === "template" ? "the agent's template" : l.writtenBy} ·{" "}
                      {formatDate(l.at)}
                    </p>
                  </li>
                );
              })}
            </ol>
          </div>
        ))}
      </section>

      <section id="slices" className="scroll-mt-20 space-y-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Results by type of venture</h2>
          <p className="text-sm text-zinc-500">
            Compare ventures by market, customer, business model and more. The agent suggests each venture&apos;s labels and the steward confirms
            them. Pick a value to see the lessons that apply to it.
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Compare by">
          {TAG_AXES.map((a) => (
            <Link
              key={a}
              href={`/learning?axis=${a}#slices`}
              scroll={false}
              role="tab"
              aria-selected={a === axis}
              className={cn(
                "inline-flex h-7 items-center rounded-full border px-3 text-xs font-medium transition",
                a === axis ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white text-zinc-600 hover:border-zinc-300",
              )}
            >
              {TAG_AXIS_LABELS[a]}
            </Link>
          ))}
        </div>
        <Card size="sm">
          <CardContent>
            {slices.length === 0 ? (
              <p className="py-4 text-sm text-zinc-500">No venture has this label yet. It fills in as ventures end or find customers.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{TAG_AXIS_LABELS[axis]}</TableHead>
                    <TableHead className="text-right">Ventures</TableHead>
                    <TableHead className="text-right">Reached minimum</TableHead>
                    <TableHead className="text-right">First customer</TableHead>
                    <TableHead className="text-right">Ended</TableHead>
                    <TableHead className="text-right">Requests answered</TableHead>
                    <TableHead className="text-right">Typical units paid</TableHead>
                    <TableHead className="text-right">Lessons</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {slices.map((s) => (
                    <TableRow key={s.value} className={cn(filters.some((f) => f.axis === axis && f.value === s.value) && "bg-sky-50/60")}>
                      <TableCell className="font-medium">
                        {(LESSON_AXES as readonly string[]).includes(axis) ? (
                          <Link href={filterHref(axis, s.value)} scroll={false} className="hover:underline">
                            {s.label}
                          </Link>
                        ) : (
                          s.label
                        )}
                      </TableCell>
                      <Num>{s.ventures}</Num>
                      <Num>{s.funded}</Num>
                      <Num>{s.customer1}</Num>
                      <Num>{s.killed}</Num>
                      <Num>{s.requests}</Num>
                      <Num>{s.medianUnits ?? "—"}</Num>
                      <Num>{s.lessons}</Num>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Card size="sm">
          <CardHeader>
            <CardTitle>Business model · customer · end market</CardTitle>
            <CardDescription>
              The standard comparison. Reaching the minimum means the venture sold enough seats to start. New batches spread their spots across
              end markets and business models using these results, so every kind gets a turn and some spots go to kinds not tried yet.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats.cuts.length === 0 ? (
              <p className="text-sm text-zinc-500">No venture has opened for seats yet.</p>
            ) : (
              <ul className="space-y-2 text-sm">
                {stats.cuts.map((c) => (
                  <li key={c.key} className="flex flex-wrap items-baseline justify-between gap-x-3">
                    <span>
                      <span className="font-medium text-zinc-900">{c.label}</span>
                      <span className="text-zinc-600">
                        : {c.funded} of {c.tried} reached the minimum
                      </span>
                    </span>
                    <span className="text-xs text-zinc-500 tabular-nums">
                      {c.survived} running · {c.killed} ended
                      {c.medianDaysToFirstCustomer !== undefined && ` · ${c.medianDaysToFirstCustomer} days to first customer`}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card size="sm">
          <CardHeader>
            <CardTitle>Batches</CardTitle>
            <CardDescription>Notes the agent wrote when each batch closed.</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-sm">
              {cohorts.map((c) => (
                <li key={c.id}>
                  <div className="flex items-center gap-2">
                    <Link href={`/batches/${c.number}`} className="font-medium hover:underline">
                      {batchLabel(c.number)}
                    </Link>
                    <BatchStatusPill cohort={c} />
                    <span className="ml-auto text-xs text-zinc-500">{c.ventureIds.length} ventures</span>
                  </div>
                  {c.notes[0] && <p className="mt-1 text-zinc-600">{c.notes[0]}</p>}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card size="sm">
          <CardHeader>
            <CardTitle>Which recruiting posts worked</CardTitle>
            <CardDescription>How many people joined from each post, and how many gave answers that held up.</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.drafts.length === 0 ? (
              <p className="text-sm text-zinc-500">No recruiting post has gone out yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Post</TableHead>
                    <TableHead className="text-right">Joined</TableHead>
                    <TableHead className="text-right">Verified</TableHead>
                    <TableHead className="text-right">Followed</TableHead>
                    <TableHead className="text-right">Held up</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.drafts.map((d) => (
                    <TableRow key={d.rfeId}>
                      <TableCell className="max-w-56">
                        <Link href={`/rfe/${d.rfeId}`} className="block truncate hover:underline">
                          {d.title}
                        </Link>
                        <span className="text-xs text-zinc-500">{channel(d.channel)}</span>
                      </TableCell>
                      <Num>{d.arrivals}</Num>
                      <Num>{d.qualified}</Num>
                      <Num>{d.followed}</Num>
                      <Num>{d.right}</Num>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card size="sm">
          <CardHeader>
            <CardTitle>Whose advice held up</CardTitle>
            <CardDescription>By type of member: how often the agent took their advice, and how often it turned out right.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Members in</TableHead>
                  <TableHead className="text-right">Answers</TableHead>
                  <TableHead className="text-right">Followed</TableHead>
                  <TableHead className="text-right">Held up</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.clusters.map((c) => (
                  <TableRow key={c.cluster}>
                    <TableCell>{clusterLabel(c.cluster)}</TableCell>
                    <Num>{c.answers}</Num>
                    <Num>{c.followed}</Num>
                    <Num>{c.answers ? formatPct((c.right / c.answers) * 100, 0) : "—"}</Num>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card size="sm">
          <CardHeader>
            <CardTitle>Which share links worked, by channel</CardTitle>
            <CardDescription>Everyone&apos;s share links, from the first visit to a claimed role. Later stages count people, not clicks.</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.shares.byChannel.length === 0 ? (
              <p className="text-sm text-zinc-500">Nobody has visited through a share link yet.</p>
            ) : (
              <FunnelTable rows={stats.shares.byChannel} label={(k) => (SHARE_CHANNEL_LABELS as Record<string, string>)[k] ?? k} />
            )}
          </CardContent>
        </Card>
        <Card size="sm">
          <CardHeader>
            <CardTitle>Which share links worked, by venture</CardTitle>
            <CardDescription>
              {stats.shares.waitlist.batches + stats.shares.waitlist.ventures} people waiting: {stats.shares.waitlist.batches} for a batch,{" "}
              {stats.shares.waitlist.ventures} for a seat in a full venture.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats.shares.byVenture.length === 0 ? (
              <p className="text-sm text-zinc-500">No venture has been shared yet.</p>
            ) : (
              <FunnelTable
                rows={stats.shares.byVenture}
                waiting
                label={(id) => {
                  const v = store.ventures.find((x) => x.id === id);
                  return !v ? id : isRevealed(store, v) ? v.name : (v.codename ?? codenameSlug(v).toUpperCase());
                }}
              />
            )}
          </CardContent>
        </Card>
      </div>

      <Card size="sm">
        <CardHeader>
          <CardTitle>Seats sold, by price</CardTitle>
          <CardDescription>Every venture that has sold seats, cheapest first. The agent prices the next venture from this, not from a guess.</CardDescription>
        </CardHeader>
        <CardContent>
          {stats.sellThrough.length === 0 ? (
            <p className="text-sm text-zinc-500">No venture has sold seats yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Venture</TableHead>
                  <TableHead className="text-right">Seat price</TableHead>
                  <TableHead className="hidden sm:table-cell">Customer</TableHead>
                  <TableHead className="text-right">Sold</TableHead>
                  <TableHead className="text-right">Filled</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.sellThrough.map((r) => (
                  <TableRow key={r.ventureId}>
                    <TableCell className="max-w-40 truncate font-medium">{store.ventures.find((v) => v.id === r.ventureId)?.name ?? r.ventureId}</TableCell>
                    <Num>{formatUsd(r.priceUsd)}</Num>
                    <TableCell className="hidden text-zinc-600 sm:table-cell">{r.customer}</TableCell>
                    <Num>
                      {r.sold} of {r.needed}
                    </Num>
                    <Num>{Math.round((100 * r.sold) / Math.max(1, r.needed))}%</Num>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card size="sm">
          <CardHeader>
            <CardTitle>What requests pay</CardTitle>
            <CardDescription>What each kind of request usually pays, and how fast it gets answered.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Answered</TableHead>
                  <TableHead className="text-right">Typical units</TableHead>
                  <TableHead className="text-right">Hours to answer</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.byType.map((t) => (
                  <TableRow key={t.type}>
                    <TableCell>{RFE_TYPE_LABELS[t.type].label}</TableCell>
                    <Num>{t.samples}</Num>
                    <Num>{t.medianUnits}</Num>
                    <Num>{t.medianHoursToFill}</Num>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card size="sm">
          <CardHeader>
            <CardTitle>Label changes</CardTitle>
            <CardDescription>
              Every time a label was renamed, merged or added, including values added by a Protocol vote, so old and new numbers still compare.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {store.tagLog.length === 0 ? (
              <p className="text-sm text-zinc-500">No changes yet.</p>
            ) : (
              <ul className="space-y-1.5 text-sm">
                {[...store.tagLog].reverse().map((e) => (
                  <li key={e.id} className="text-zinc-700">
                    <span className="text-xs text-zinc-500">{formatDate(e.at)}</span> {TAG_AXIS_LABELS[e.axis]}:{" "}
                    {e.action === "add" ? (
                      <>added “{e.to}”</>
                    ) : (
                      <>
                        {e.action === "merge" ? "merged" : "renamed"} “{e.from}” → “{e.to}” ({e.affected} item{e.affected === 1 ? "" : "s"})
                      </>
                    )}{" "}
                    <span className="text-xs text-zinc-500">by @{e.by}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
