import type { Member, ParamValues, RoleClaim, RosterRole, RosterRoleKey, Store, Venture } from "@av/schema";
import { seatPriceOf } from "./sizing";
import { canWithdrawForDeck, latestDeck } from "./deck";
import {
  activeSeats,
  ensureMember,
  payReferrals,
  isLive,
  isOpen,
  logDecision,
  memberByHandle,
  notify,
  nStatusFor,
  ProtocolError,
  refundSeat,
  refundSeats,
  seatsSold,
  setRfeStatus,
  ventureBySlug,
} from "./ops";
import { resolveParams } from "./params";
import { recordStage } from "./sharing";
import { onSeatsFreed, settleVentureWaitlists } from "./waitlist";
import { addDays, newId } from "./util";

/* ---------- the roles a venture's own plan needs ---------- */

/** The roster from the venture's deck; a venture without one shows its older slots. */
export function rosterRoles(store: Store, venture: Venture): RosterRole[] {
  const deck = latestDeck(store, venture.id);
  if (deck) return deck.roster;
  return venture.roster.map((s) => ({
    key: (s.type === "buyer-operator" ? "icp-operator" : s.type) as RosterRoleKey,
    label: s.label,
    count: s.count,
    critical: false,
    qualifications: [],
    clusters: s.clusters,
    keywords: s.keywords,
    minDistinctClusters: 1,
    serves: [],
    derivation: "Set when the venture was spawned, before rosters were computed",
  }));
}

/** The new gates (critical roles at the raise, the seat maximum, filling the roster before formation) apply to decks under the current rule. */
export function underCurrentRule(store: Store, venture: Venture): boolean {
  return latestDeck(store, venture.id)?.seatPlan.rule === "derived";
}

export function fitsRole(member: Member, role: Pick<RosterRole, "clusters" | "keywords">): boolean {
  if (role.clusters.includes(member.cluster)) return true;
  const hay = `${member.role} ${member.industry}`.toLowerCase();
  return role.keywords.some((k) => hay.includes(k.toLowerCase()));
}

export interface RosterRow {
  role: RosterRole;
  /** Verified members who fit and claimed it. */
  filled: string[];
  /** Claimed by someone not yet verified. */
  pending: string[];
  open: number;
  /** Filled, but by fewer kinds of member than the role asks for. */
  clusterShort: boolean;
}

function activeClaims(store: Store, ventureId: string): RoleClaim[] {
  return store.roleClaims.filter((c) => c.ventureId === ventureId && c.status === "claimed").sort((a, b) => a.at.localeCompare(b.at));
}

/** Nobody needs a seat to claim a role. A claim counts once the member is verified and fits the role. */
export function rosterFill(store: Store, venture: Venture): RosterRow[] {
  const claims = activeClaims(store, venture.id);
  return rosterRoles(store, venture).map((role) => {
    const filled: string[] = [];
    const pending: string[] = [];
    for (const c of claims.filter((x) => x.roleKey === role.key)) {
      const m = memberByHandle(store, c.handle);
      if (!m || m.handle === venture.stewardHandle) continue;
      if (m.qualification === "qualified" && fitsRole(m, role)) {
        if (filled.length < role.count) filled.push(m.handle);
      } else if (m.qualification === "pending") pending.push(m.handle);
    }
    const kinds = new Set(filled.map((h) => memberByHandle(store, h)?.cluster)).size;
    return { role, filled, pending, open: role.count - filled.length, clusterShort: filled.length > 1 && kinds < Math.min(role.minDistinctClusters, role.count) };
  });
}

export interface RosterProgress {
  filled: number;
  total: number;
  pct: number;
  criticalOpen: RosterRole[];
}

export function rosterProgress(store: Store, venture: Venture, rows = rosterFill(store, venture)): RosterProgress {
  const filled = rows.reduce((s, r) => s + r.filled.length, 0);
  const total = rows.reduce((s, r) => s + r.role.count, 0);
  return {
    filled,
    total,
    pct: total ? Math.round((filled / total) * 100) : 100,
    criticalOpen: rows.filter((r) => r.role.critical && !r.filled.length).map((r) => r.role),
  };
}

const roleList = (roles: Pick<RosterRole, "label">[]) => roles.map((r) => r.label.toLowerCase()).join(", ");

/* ---------- claiming a role ---------- */

export function claimRole(store: Store, input: { slug: string; roleKey: RosterRoleKey; handle: string; note?: string; source?: string; referredBy?: string }): { claim: RoleClaim; status: "filled" | "pending" } {
  const venture = ventureBySlug(store, input.slug);
  if (!venture || venture.isProtocol) throw new ProtocolError("That venture does not exist.");
  if (!isLive(venture) || !["pitched", "funded", "formed", "operating"].includes(venture.status)) {
    throw new ProtocolError(`${venture.name} isn't taking role claims.`);
  }
  const role = rosterRoles(store, venture).find((r) => r.key === input.roleKey);
  if (!role) throw new ProtocolError(`${venture.name}'s plan has no ${input.roleKey.replace(/-/g, " ")} role.`);
  const member = ensureMember(store, input.handle, input.source, input.referredBy, venture.id);
  if (member.handle === venture.stewardHandle) throw new ProtocolError("The steward runs the venture; roles are for other members.");
  if (member.qualification === "declined") throw new ProtocolError("Verification didn't go through, so this claim can't count. Update your profile and try again.");
  if (member.qualification === "qualified" && !fitsRole(member, role)) {
    throw new ProtocolError(`Your verified profile doesn't match “${role.label}”. It needs: ${role.qualifications.join("; ") || "a matching role or industry"}.`);
  }
  const mine = activeClaims(store, venture.id).filter((c) => c.handle === member.handle);
  if (mine.some((c) => c.roleKey === role.key)) throw new ProtocolError(`You've already claimed “${role.label}”.`);
  if (mine.length) throw new ProtocolError(`You hold “${rosterRoles(store, venture).find((r) => r.key === mine[0].roleKey)?.label}” already. Withdraw it first; one role per venture.`);
  const row = rosterFill(store, venture).find((r) => r.role.key === role.key)!;
  if (member.qualification === "qualified" && row.open <= 0) throw new ProtocolError(`“${role.label}” is filled.`);
  const claim: RoleClaim = { id: newId(store, "rc"), ventureId: venture.id, roleKey: role.key, handle: member.handle, at: store.meta.clock, status: "claimed", note: input.note?.trim() || undefined };
  store.roleClaims.push(claim);
  recordStage(store, member, "role", venture.id);
  payReferrals(store, venture.id);
  const status = member.qualification === "qualified" ? "filled" : "pending";
  notify(store, venture.id, member.handle, status === "filled" ? `you're on ${venture.name}'s roster as “${role.label}”.` : `your claim on “${role.label}” counts once you're verified.`);
  afterRosterChange(store, venture);
  return { claim, status };
}

export function withdrawRole(store: Store, input: { slug: string; handle: string }) {
  const venture = ventureBySlug(store, input.slug);
  if (!venture) throw new ProtocolError("That venture does not exist.");
  const claim = activeClaims(store, venture.id).find((c) => c.handle === input.handle.replace(/^@/, ""));
  if (!claim) throw new ProtocolError("You don't hold a role in this venture.");
  claim.status = "withdrawn";
}

/** A claim or a verification can complete the raise or the roster. */
export function afterRosterChange(store: Store, venture: Venture) {
  if (venture.status === "pitched") checkRaise(store, venture);
  else if (venture.status === "funded") checkLiftoff(store, venture);
  settleVentureWaitlists(store);
}

/** Someone was just verified: their pending claims may now count. */
export function onMemberQualified(store: Store, handle: string) {
  const ids = new Set(store.roleClaims.filter((c) => c.handle === handle && c.status === "claimed").map((c) => c.ventureId));
  for (const v of store.ventures.filter((x) => ids.has(x.id))) afterRosterChange(store, v);
  payReferrals(store);
}

/* ---------- the raise: seats and the critical roles ---------- */

/** What the raise still needs, in plain words; empty once it can succeed. */
export function raiseShortfall(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): string[] {
  const out: string[] = [];
  const capital = store.rfes.find((r) => r.ventureId === venture.id && r.type === "capital");
  const n = capital ? nStatusFor(store, capital, params) : undefined;
  if (!n || n.state !== "close") {
    const need = latestDeck(store, venture.id)?.seatPlan.min ?? Math.ceil(venture.minRaiseUsd / seatPriceOf(venture, params));
    out.push(`${Math.max(0, need - seatsSold(store, venture.id))} more seats`);
  }
  if (underCurrentRule(store, venture)) {
    const open = rosterProgress(store, venture).criticalOpen;
    if (open.length) out.push(`a verified claim on ${roleList(open)}`);
  }
  return out;
}

/**
 * The raise succeeds when the seat minimum is met and, under the current rule,
 * every critical role is claimed by a verified member who fits it.
 */
export function checkRaise(store: Store, venture: Venture): boolean {
  if (venture.status !== "pitched") return false;
  const params = resolveParams(store);
  const capital = store.rfes.find((r) => r.ventureId === venture.id && r.type === "capital" && isOpen(r));
  if (!capital || raiseShortfall(store, venture, params).length) return false;
  const n = nStatusFor(store, capital, params);
  const derived = underCurrentRule(store, venture);
  setRfeStatus(capital, "quorum");
  setRfeStatus(capital, "resolved");
  capital.resolvedAt = store.meta.clock;
  capital.resolution = `Minimum met: ${n.effective} seats, $${n.effective * seatPriceOf(venture, params)}${derived ? ", and every critical role claimed" : ""}.`;
  logDecision(store, {
    ventureId: venture.id,
    title: "Minimum met: stop selling seats",
    reasoning: derived
      ? `${n.effective} seats cover the $${venture.minRaiseUsd} minimum, and ${roleList(rosterRoles(store, venture).filter((r) => r.critical))} are claimed. Next: fill at least ${params.ROSTER_FILL_AT_FORMATION}% of the roster within ${params.LIFTOFF_WINDOW_DAYS} days, then set up the company.`
      : `${n.effective} seats cover the $${venture.minRaiseUsd} budget to the first customer. Setting up the company is next.`,
    confidence: 0.95,
    model: "rule",
    transition: "funded",
    outcome: "Minimum met",
  });
  if (derived) {
    venture.liftoff = { askedAt: store.meta.clock };
    checkLiftoff(store, venture);
  }
  return true;
}

/* ---------- after the raise: fill the roster before formation money is spent ---------- */

export function liftoffDeadline(venture: Venture, params: Pick<ParamValues, "LIFTOFF_WINDOW_DAYS">): string | undefined {
  if (!venture.liftoff?.askedAt) return undefined;
  return venture.liftoff.extendedUntil ?? addDays(venture.liftoff.askedAt, params.LIFTOFF_WINDOW_DAYS);
}

/** Formation money waits until the roster is filled (current rule only). */
export function awaitingRoster(store: Store, venture: Venture): boolean {
  return venture.status === "funded" && underCurrentRule(store, venture) && !venture.liftoff?.passedAt;
}

export type LiftoffResult = "passed" | "waiting" | "asked" | "ended" | "n/a";

/**
 * At the deadline: below the bar, the steward may extend once; after that, or if
 * the steward declines, the venture ends before forming and every seat is refunded.
 */
export function checkLiftoff(store: Store, venture: Venture): LiftoffResult {
  if (!awaitingRoster(store, venture)) return "n/a";
  const params = resolveParams(store);
  const p = rosterProgress(store, venture);
  if (p.pct >= params.ROSTER_FILL_AT_FORMATION && !p.criticalOpen.length) {
    venture.liftoff = { ...venture.liftoff, passedAt: store.meta.clock };
    logDecision(store, {
      ventureId: venture.id,
      title: "The people this venture needs are in place: set up the company",
      reasoning: `${p.filled} of ${p.total} roles are filled (${p.pct}%, the bar is ${params.ROSTER_FILL_AT_FORMATION}%), with every critical role claimed. Formation money can now be spent.`,
      confidence: 0.95,
      model: "rule",
      outcome: "Roster filled",
    });
    return "passed";
  }
  const deadline = liftoffDeadline(venture, params)!;
  if (store.meta.clock < deadline) return "waiting";
  const asked = store.decisions.filter((d) => d.ventureId === venture.id && d.facts.liftoff === "extend");
  if (asked.some((d) => d.status === "awaiting_steward")) return "waiting";
  if (!venture.liftoff?.extendedUntil && !asked.length) {
    logDecision(store, {
      ventureId: venture.id,
      title: `Roster short at day ${params.LIFTOFF_WINDOW_DAYS}: extend ${params.LIFTOFF_EXTENSION_DAYS} days, or end and refund`,
      reasoning: `${p.filled} of ${p.total} roles are filled (${p.pct}%; the bar is ${params.ROSTER_FILL_AT_FORMATION}%)${p.criticalOpen.length ? `, and ${roleList(p.criticalOpen)} ${p.criticalOpen.length === 1 ? "is" : "are"} unclaimed` : ""}. The steward can extend once by ${params.LIFTOFF_EXTENSION_DAYS} days; declining ends the venture before it forms, and every seat is refunded in full.`,
      summary: `The roster is ${p.pct}% filled at the deadline; the steward extends once or ends it.`,
      confidence: 0.9,
      model: "rule",
      facts: { liftoff: "extend" },
    });
    return "asked";
  }
  endBeforeForming(store, venture, `the roster was ${p.pct}% filled${p.criticalOpen.length ? ` with ${roleList(p.criticalOpen)} open` : ""} after the extension`);
  return "ended";
}

/** The steward's call on an extension, wired from stewardDecide. */
export function onStewardLiftoff(store: Store, d: { ventureId: string; facts: { liftoff?: string } }, approved: boolean) {
  if (d.facts.liftoff !== "extend") return;
  const venture = store.ventures.find((v) => v.id === d.ventureId)!;
  if (!awaitingRoster(store, venture)) return;
  const params = resolveParams(store);
  if (approved) venture.liftoff = { ...venture.liftoff, extendedUntil: addDays(liftoffDeadline(venture, params)!, params.LIFTOFF_EXTENSION_DAYS) };
  else endBeforeForming(store, venture, "the roster wasn't filled in time and the steward didn't extend");
}

/** Ends a venture that met its minimum but couldn't fill its roster: nothing was spent, so every seat is refunded in full. */
export function endBeforeForming(store: Store, venture: Venture, why: string) {
  for (const r of store.rfes.filter((x) => x.ventureId === venture.id && isOpen(x))) {
    if (r.status === "posted") setRfeStatus(r, "quorum");
    setRfeStatus(r, "resolved");
    r.resolvedAt = store.meta.clock;
    r.resolution = "Closed: the venture ended before it formed.";
  }
  const refund = refundSeats(store, venture, `the venture ended before forming: ${why}`);
  const p = rosterProgress(store, venture);
  const pitchedAt = venture.statusHistory.find((h) => h.status === "pitched")?.at ?? venture.createdAt;
  venture.postMortem = {
    summary: `${venture.name} met its seat minimum but couldn't fill the roster its own plan needs before forming. ${refund.count} seats were refunded in full ($${refund.totalUsd}).`,
    whatWeTried: ["Opened the roles on the deck to anyone verified, with or without a seat", "Drafted recruiting posts for the open roles"],
    whyItEnded: `${why[0].toUpperCase()}${why.slice(1)}.`,
    costUsd: 0,
    lessons: [`The plan needed ${p.total} people; ${p.filled} were in place. Check who the members can reach before the next venture like this.`],
    killReason: "ran out of time",
    stageReached: "Minimum met",
    daysToKillSignal: Math.round((Date.parse(store.meta.clock) - Date.parse(pitchedAt)) / 86_400_000),
    publishedAt: store.meta.clock,
  };
  logDecision(store, {
    ventureId: venture.id,
    title: "End the venture before it forms: the roster wasn't filled",
    reasoning: `Formation money is spent only once the people the plan needs are in place. ${why[0].toUpperCase()}${why.slice(1)}, so the venture ends and ${refund.count} seats are refunded in full (Article 2).`,
    summary: "Ended before forming: the roster wasn't filled in time; every seat refunded.",
    confidence: 1,
    model: "rule",
    transition: "killed",
    outcome: `Ended; ${refund.count} seats refunded in full`,
  });
}

/* ---------- refunds ---------- */

/** After a material deck change, a holder who bought under the earlier version may take their seat back while seats are selling. */
export function withdrawSeat(store: Store, input: { slug: string; handle: string }): { usd: number } {
  const venture = ventureBySlug(store, input.slug);
  if (!venture) throw new ProtocolError("That venture does not exist.");
  const handle = input.handle.replace(/^@/, "");
  if (!canWithdrawForDeck(store, venture, handle)) {
    throw new ProtocolError("A seat can be withdrawn only while seats are selling, after a material deck change made since you took it.");
  }
  const seat = activeSeats(store, venture.id).find((l) => l.handle === handle)!;
  const usd = refundSeat(store, venture, seat, "withdrawn after a material change to the deck");
  onSeatsFreed(store, venture, 1);
  return { usd };
}

/** The roles each verified member's profile fits, for seeding claims from a venture's existing holders. */
export function claimFromHolders(store: Store, venture: Venture, handles: string[]) {
  const rows = rosterFill(store, venture);
  const taken = new Set(activeClaims(store, venture.id).map((c) => c.handle));
  for (const h of handles) {
    const m = memberByHandle(store, h);
    if (!m || taken.has(h) || m.qualification !== "qualified" || h === venture.stewardHandle) continue;
    const row = rows.find((r) => r.open > 0 && fitsRole(m, r.role));
    if (!row) continue;
    store.roleClaims.push({ id: newId(store, "rc"), ventureId: venture.id, roleKey: row.role.key, handle: h, at: store.meta.clock, status: "claimed" });
    row.filled.push(h);
    row.open--;
    taken.add(h);
  }
}
