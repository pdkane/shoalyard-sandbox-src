"""Generate the three homepage-hero concept artboards (live shoal simulation as a stand-in for video)."""
import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "project")

# One engine for all three concepts. mode: "daylight" | "deep" | "mill" (shoal mills as a column, then settles into the mark).
ENGINE = r"""
class Component extends DCLogic {
  constructor(props) {
    super(props);
    this.cv = null;
    this.raf = 0;
    this.setCanvas = (el) => { this.cv = el; if (el && !this.raf) this.start(); };
  }
  componentDidMount() { if (this.cv && !this.raf) this.start(); }
  componentWillUnmount() { cancelAnimationFrame(this.raf); this.raf = 0; }
  start() {
    const cv = this.cv, MODE = "__MODE__";
    const W = cv.clientWidth || __W__, H = cv.clientHeight || __H__;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = W * dpr; cv.height = H * dpr;
    const ctx = cv.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const N = this.props.fish ?? __N__;
    const SPEED = this.props.speed ?? 1;
    let seed = 7;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const P = __PALETTE__;
    // A shoal mixes species and sizes, like the different people who answer a venture's requests.
    const SPECIES = P.species || [{ share: 1, len: [8, 14], girth: 0.36, body: P.bodyRGB, flash: P.flashRGB, spd: 1 }];
    const pick = () => { let r = rnd(), acc = 0; for (const sp of SPECIES) { acc += sp.share; if (r <= acc) return sp; } return SPECIES[0]; };
    const fish = [];
    for (let i = 0; i < N; i++) {
      const a = rnd() * Math.PI * 2, sp = pick();
      fish.push({ x: W * (0.45 + rnd() * 0.4), y: H * (0.3 + rnd() * 0.5), vx: Math.cos(a), vy: Math.sin(a) * 0.4,
        ph: rnd() * 6.283, len: sp.len[0] + rnd() * (sp.len[1] - sp.len[0]), girth: sp.girth, B: sp.body, F: sp.flash, spd: sp.spd,
        turn: 0, h: (rnd() + rnd() + rnd()) / 3 - 0.5, th: rnd() * 6.283, rj: rnd() < 0.08 ? 1.15 + rnd() * 0.4 : 0.5 + rnd() * 0.6,
        ou: Math.sqrt(rnd()) * Math.cos(a), ov: Math.sqrt(rnd()) * Math.sin(a) });
    }
    // The four strokes of the mark, as targets for the "mill" ending (scaled into the right half).
    const strokes = [[6, 22, 44, 22], [26, 36, 70, 36], [16, 50, 52, 50], [40, 64, 88, 64]];
    const mk = { x: W * 0.53, y: H * 0.2, s: 6.2 };
    const slots = [];
    strokes.forEach(([x1, y1, x2, y2]) => {
      const n = Math.round((x2 - x1) * 1.6);
      for (let k = 0; k < n; k++) for (let r = -2; r <= 2; r++) slots.push({ x: mk.x + (x1 + (x2 - x1) * (k / (n - 1))) * mk.s, y: mk.y + y1 * mk.s + r * 10 });
    });
    const CELL = 40, cols = Math.ceil(W / CELL) + 1, rows = Math.ceil(H / CELL) + 1;
    const grid = new Array(cols * rows);
    let t = 0, last = performance.now();
    const cx = W * (MODE === "deep" ? 0.5 : 0.71), cy = H * (MODE === "deep" ? 0.86 : 0.54);
    const RX = W * (MODE === "deep" ? 0.4 : 0.22), RY = H * (MODE === "deep" ? 0.12 : 0.3);

    const step = (dt) => {
      t += dt;
      // a slow wandering point the shoal follows, like a real school drifting through frame
      const ax = cx + Math.sin(t * 0.11) * W * 0.05;
      const ay = cy + Math.sin(t * 0.17 + 1) * H * 0.04;
      const rot = Math.sin(t * 0.05) * 0.5, cr = Math.cos(rot), sr = Math.sin(rot);
      const breathe = 1 + 0.12 * Math.sin(t * 0.23);
      for (let i = 0; i < grid.length; i++) grid[i] = null;
      for (const f of fish) {
        const gi = Math.max(0, Math.min(cols - 1, (f.x / CELL) | 0)) + Math.max(0, Math.min(rows - 1, (f.y / CELL) | 0)) * cols;
        f.next = grid[gi]; grid[gi] = f;
      }
      for (const f of fish) {
        let sx = 0, sy = 0, ax2 = 0, ay2 = 0, cx2 = 0, cy2 = 0, n = 0;
        const gx = (f.x / CELL) | 0, gy = (f.y / CELL) | 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const X = gx + dx, Y = gy + dy;
          if (X < 0 || Y < 0 || X >= cols || Y >= rows) continue;
          for (let o = grid[X + Y * cols]; o; o = o.next) {
            if (o === f) continue;
            const ddx = o.x - f.x, ddy = o.y - f.y, d2 = ddx * ddx + ddy * ddy;
            if (d2 > 1600) continue;
            n++; ax2 += o.vx; ay2 += o.vy; cx2 += o.x; cy2 += o.y;
            if (d2 < 200) { sx -= ddx / (d2 + 1); sy -= ddy / (d2 + 1); }
          }
        }
        let fx = 0, fy = 0;
        if (n) { fx += (ax2 / n - f.vx) * 0.05; fy += (ay2 / n - f.vy) * 0.05; }
        fx += sx * 1.2; fy += sy * 1.2;
        // home: this fish's place in the big, slowly turning, breathing mass
        const hx = ax + (cr * f.ou * RX - sr * f.ov * RY) * breathe, hy = ay + (sr * f.ou * RX + cr * f.ov * RY) * breathe;
        fx += (hx - f.x) * 0.0011; fy += (hy - f.y) * 0.0011;
        // circulation around the centre, so the mass mills and the flanks catch the light as they turn
        const rx = f.x - ax, ry = (f.y - ay) * (RX / RY), rr = Math.hypot(rx, ry) + 1;
        fx += (-ry / rr) * 0.05; fy += (rx / rr) * 0.05 * (RY / RX);
        f.ovx = f.vx; f.ovy = f.vy;
        f.vx += fx; f.vy += fy * 0.8;
        const sp = Math.hypot(f.vx, f.vy) || 1, want = 1.5;
        f.vx = f.vx / sp * (sp + (want - sp) * 0.08); f.vy = f.vy / sp * (sp + (want - sp) * 0.08);
        f.x += f.vx * dt * 60 * SPEED; f.y += f.vy * dt * 60 * SPEED;
        const a0 = Math.atan2(f.ovy, f.ovx), a1 = Math.atan2(f.vy, f.vx);
        let da = a1 - a0; if (da > Math.PI) da -= 6.283; if (da < -Math.PI) da += 6.283;
        f.turn = f.turn * 0.9 + Math.abs(da) * 3;
      }
    };

    // "mill": a column of fish circling a vertical axis seen from the side, then settling into the four strokes
    const CYCLE = 14;
    const stepMill = (dt) => {
      t += dt;
      const c = t % CYCLE;
      const settle = c < 6 ? 0 : c < 8.5 ? (c - 6) / 2.5 : c < 12 ? 1 : 1 - (c - 12) / 2;
      const e = settle * settle * (3 - 2 * settle);
      fish.forEach((f, i) => {
        f.th += dt * SPEED * f.spd * (0.95 + 0.2 * Math.sin(f.ph));
        // a loose, irregular column: its width swells and pinches along its height, it leans and wanders,
        // and the lanes drift, so it never settles into a cylinder
        const hz = f.h;
        const env = Math.max(0.18, 1 - 2.4 * hz * hz);
        const R = W * 0.12 * env * f.rj * (0.62 + 0.32 * Math.sin(hz * 5.3 + t * 0.27) + 0.18 * Math.sin(hz * 11.7 - t * 0.41 + 1.3));
        const lean = 70 * Math.sin(hz * 3.4 + t * 0.33) + 34 * Math.sin(hz * 8.1 - t * 0.23);
        const lane = hz * H * 0.66 + Math.sin(t * 0.21 + f.ph) * 16;
        const mx = W * 0.69 + lean + Math.cos(f.th) * R, my = H * 0.52 + lane + Math.sin(f.th + f.ph) * R * 0.12;
        const s = slots[Math.floor(i * slots.length / fish.length)];
        const ox = f.x, oy = f.y;
        // each fish holds a slightly loose place in its stroke, and keeps finning while it holds
        const sx = s.x + Math.sin(f.ph * 5.1) * 4 + Math.sin(t * 1.3 + f.ph) * 1.5, sy = s.y + Math.sin(f.ph * 3.7) * 3 + Math.sin(t * 1.7 + f.ph * 2) * 1;
        f.x = mx + (sx - mx) * e; f.y = my + (sy - my) * e;
        f.depth = Math.sin(f.th) * (1 - e);
        f.settle = e;
        const vx = f.x - ox, vy = f.y - oy;
        if (Math.hypot(vx, vy) > 0.05) { f.vx = vx; f.vy = vy; }
        // ease every fish to face along the stroke as it settles
        let a = Math.atan2(f.vy, f.vx); if (a > Math.PI / 2) a -= Math.PI; if (a < -Math.PI / 2) a += Math.PI;
        f.ang = e > 0.02 ? a * (1 - Math.min(1, e * 1.6)) : null;
        f.turn = (1 - e) * Math.max(0, Math.cos(f.th)) * 1.2 + e * 0.15 * (1 + Math.sin(t * 3 + i));
      });
    };

    const draw = () => {
      // water
      const g = ctx.createLinearGradient(0, 0, 0, H);
      P.water.forEach(([o, col]) => g.addColorStop(o, col));
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      // caustic light bands, drifting
      ctx.save(); ctx.globalCompositeOperation = P.lightOp;
      for (let k = 0; k < 7; k++) {
        const x0 = ((k * 233 + t * (14 + k * 3)) % (W + 600)) - 300;
        const lg = ctx.createLinearGradient(x0, 0, x0 + 160, H);
        lg.addColorStop(0, "rgba(255,255,255,0)"); lg.addColorStop(0.5, P.ray); lg.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = lg;
        ctx.beginPath(); ctx.moveTo(x0, 0); ctx.lineTo(x0 + 70, 0); ctx.lineTo(x0 + 260, H); ctx.lineTo(x0 + 120, H); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
      // fish: a slim body that flashes when its flank turns to the light
      const order = MODE === "mill" ? fish.slice().sort((a, b) => (a.depth || 0) - (b.depth || 0)) : fish;
      for (const f of order) {
        // strokes stay near horizontal, like the mark; fish follow their heading fully
        const ang = f.ang != null ? f.ang : P.strokes ? Math.atan2(f.vy * 0.35, f.vx) : Math.atan2(f.vy, f.vx);
        // flank toward the light, plus a wave of flashes rolling across the school
        const flank = Math.pow(0.5 + 0.5 * Math.cos(2 * ang + f.ph * 0.35 + t * 0.9 - f.x * 0.006 + f.y * 0.004), 5);
        const flash = Math.min(1, flank * 0.85 + f.turn * 0.8);
        const depth = MODE === "mill" ? (f.depth || 0) : 0;
        // in the mark every fish eases to a similar size, so the four strokes read crisply
        const L = MODE === "mill" ? (f.len + (Math.min(f.len, 12) - f.len) * (f.settle || 0)) * (1 + depth * 0.25) : f.len;
        ctx.save();
        ctx.translate(f.x, f.y); ctx.rotate(ang);
        ctx.globalAlpha = MODE === "mill" ? 0.55 + 0.45 * (depth + 1) / 2 : 0.92;
        const B = f.B, F = f.F, G = f.girth;
        ctx.fillStyle = "rgb(" + (B[0] + (F[0] - B[0]) * flash | 0) + "," + (B[1] + (F[1] - B[1]) * flash | 0) + "," + (B[2] + (F[2] - B[2]) * flash | 0) + ")";
        if (P.strokes) {
          // abstract: each member is a rounded stroke, like the mark, not a fish
          ctx.strokeStyle = ctx.fillStyle; ctx.lineCap = "round";
          ctx.lineWidth = Math.max(2.4, L * G * 0.62);
          ctx.beginPath(); ctx.moveTo(-L * 0.8, 0); ctx.lineTo(L * 0.8, 0); ctx.stroke();
          ctx.restore();
          continue;
        }
        ctx.beginPath();
        ctx.moveTo(L, 0);
        ctx.quadraticCurveTo(L * 0.25, -L * G, -L * 0.75, 0);
        ctx.quadraticCurveTo(L * 0.25, L * G, L, 0);
        ctx.fill();
        ctx.beginPath(); ctx.moveTo(-L * 0.7, 0); ctx.lineTo(-L * 1.05, -L * G * 0.5); ctx.lineTo(-L * 1.05, L * G * 0.5); ctx.closePath(); ctx.fill();
        if (flash > 0.08) {
          ctx.globalAlpha *= flash; ctx.fillStyle = P.glint;
          ctx.beginPath(); ctx.ellipse(L * 0.15, -L * 0.04, L * 0.5, L * 0.1, 0, 0, 6.283); ctx.fill();
        }
        ctx.restore();
      }
      // legibility veil behind the statement
      if (P.veil) {
        const v = ctx.createLinearGradient(0, 0, W * 0.6, 0);
        v.addColorStop(0, P.veil); v.addColorStop(0.55, P.veil); v.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = v; ctx.fillRect(0, 0, W * 0.6, H);
      }
    };

    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const tick = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      (MODE === "mill" ? stepMill : step)(dt);
      draw();
      if (!reduce) this.raf = requestAnimationFrame(tick);
    };
    for (let k = 0; k < (MODE === "mill" ? 1 : 240); k++) (MODE === "mill" ? stepMill : step)(1 / 60);
    this.raf = requestAnimationFrame(tick);
  }
  renderVals() {
    return { setCanvas: this.setCanvas };
  }
}
"""

PALETTES = {
    "daylight": {
        "water": [[0, "#FFFFFF"], [0.55, "#F2F5F4"], [1, "#DCE6E3"]],
        "lightOp": "source-over", "ray": "rgba(227,239,237,0.22)",
        "body": "#4B575B", "flash": "#0B2128", "glint": "#7FB8B0",
        "bodyRGB": [160, 176, 177], "flashRGB": [11, 33, 40],
        "veil": "rgba(255,255,255,0.8)",
    },
    "deep": {
        "water": [[0, "#173A40"], [0.45, "#0F2C33"], [1, "#0B2128"]],
        "lightOp": "lighter", "ray": "rgba(127,184,176,0.08)",
        "body": "#5E7F82", "flash": "#DCE6E3", "glint": "#FFFFFF",
        "bodyRGB": [62, 98, 102], "flashRGB": [236, 244, 242],
        "veil": None,
    },
    "mill": {
        "water": [[0, "#FFFFFF"], [1, "#F2F5F4"]],
        "lightOp": "source-over", "ray": "rgba(227,239,237,0.5)",
        "body": "#2F6F6A", "flash": "#0B2128", "glint": "#E3EFED",
        "bodyRGB": [127, 184, 176], "flashRGB": [11, 33, 40],
        "strokes": True,
        # five species from the palette: many small, a few big, different bodies and speeds
        "species": [
            {"share": 0.40, "len": [6, 9], "girth": 0.30, "body": [127, 184, 176], "flash": [11, 33, 40], "spd": 1.25},
            {"share": 0.26, "len": [10, 14], "girth": 0.34, "body": [47, 111, 106], "flash": [11, 33, 40], "spd": 1.0},
            {"share": 0.13, "len": [15, 21], "girth": 0.20, "body": [75, 87, 91], "flash": [210, 222, 219], "spd": 1.1},
            {"share": 0.11, "len": [16, 24], "girth": 0.48, "body": [106, 78, 58], "flash": [201, 168, 140], "spd": 0.7},
            {"share": 0.10, "len": [18, 27], "girth": 0.34, "body": [11, 33, 40], "flash": [127, 184, 176], "spd": 0.82},
        ],
        "veil": None,
    },
}

FONTS = '<link href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,100..900&amp;family=IBM+Plex+Sans:wght@400;500;600&amp;family=IBM+Plex+Mono:wght@400;500&amp;display=swap" rel="stylesheet">'

NAV_INK = """<svg role="img" aria-label="Shoalyard" viewBox="0 0 210 28" style="height: 24px; width: auto; display: block"><g stroke="{sc}" stroke-width="3.4" stroke-linecap="round"><line x1="2" y1="7" x2="15" y2="7"></line><line x1="9" y1="12" x2="24" y2="12"></line><line x1="6" y1="17" x2="18" y2="17"></line><line x1="14" y1="22" x2="30" y2="22"></line></g><text x="40" y="24" textLength="168" lengthAdjust="spacingAndGlyphs" fill="{tc}" style="font-family: Archivo, sans-serif; font-stretch: 112%; font-size: 24px"><tspan style="font-weight: 740">SHOAL</tspan><tspan style="font-weight: 380">YARD</tspan></text></svg>"""

def nav(dark):
    sc, tc, link = ("#7FB8B0", "#FFFFFF", "#DCE6E3") if dark else ("#2F6F6A", "#0B2128", "#4B575B")
    return f"""<header style="position: relative; z-index: 2; display: flex; align-items: center; justify-content: space-between; padding: 28px 64px">
    {NAV_INK.format(sc=sc, tc=tc)}
    <nav aria-label="Main" style="display: flex; gap: 32px; font-size: 15px">
      <a href="#" style="color: {link}; text-decoration: none">Ventures</a>
      <a href="#" style="color: {link}; text-decoration: none">How it works</a>
      <a href="#" style="color: {link}; text-decoration: none">Post-mortems</a>
      <a href="#" style="color: {link}; text-decoration: none; font-family: 'IBM Plex Mono', monospace; font-size: 13px; letter-spacing: 0.08em">THE RULES</a>
    </nav>
  </header>"""

def page(title, mode, w, h, n, body, dark=False):
    script = ENGINE.replace("__MODE__", mode).replace("__W__", str(w)).replace("__H__", str(h)).replace("__N__", str(n)).replace("__PALETTE__", json.dumps(PALETTES[mode]))
    props = json.dumps({"fish": {"editor": "int", "default": n, "min": 80, "max": 900}, "speed": {"editor": "range", "default": 1, "min": 0.3, "max": 2, "step": 0.1}, "$preview": {"width": w, "height": h}})
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
{FONTS}
<style>
body{{margin:0}}
a{{color:#2F6F6A}}a:hover{{color:#245652}}
</style>
</helmet>
<section style="position: relative; width: {w}px; height: {h}px; overflow: hidden; background: {'#0B2128' if dark else '#FFFFFF'}; color: {'#FFFFFF' if dark else '#0B2128'}; font-family: 'IBM Plex Sans', sans-serif">
  <canvas ref="{{{{setCanvas}}}}" aria-hidden="true" style="position: absolute; inset: 0; width: 100%; height: 100%; display: block"></canvas>
  {nav(dark)}
  {body}
</section>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>{script}</script>
</body>
</html>
"""

W, H = 1440, 860
EYEBROW = "margin: 0; font-family: 'IBM Plex Mono', monospace; font-size: 13px; letter-spacing: 0.08em"
CTA = "display: inline-flex; align-items: center; min-height: 52px; padding: 0 26px; background: #2F6F6A; color: #FFFFFF; font-weight: 600; font-size: 16px; text-decoration: none"

daylight = f"""<div style="position: relative; z-index: 2; padding: 96px 64px 0; max-width: 720px; display: flex; flex-direction: column; gap: 28px">
    <p style="{EYEBROW}; color: #6A4E3A">WHERE PEOPLE BUILD VENTURES TOGETHER</p>
    <h1 style="margin: 0; font-family: Archivo, sans-serif; font-stretch: 112%; font-weight: 760; font-size: 64px; line-height: 1; letter-spacing: -0.02em">AI agents build the ventures. People make the calls, and share the profits.</h1>
    <p style="margin: 0; max-width: 560px; font-size: 19px; line-height: 1.55; color: #4B575B">Each venture is a small business run by an AI agent. Take a seat to get its requests. Every accepted answer earns an equal share of its profits. Paying never does.</p>
    <div style="display: flex; gap: 16px; align-items: center">
      <a href="#" style="{CTA}">See the ventures</a>
      <a href="#" style="font-weight: 600; font-size: 16px; color: #2F6F6A">How it works</a>
    </div>
  </div>"""

deep = f"""<div style="position: relative; z-index: 2; padding: 64px 64px 0; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 24px">
    <p style="{EYEBROW}; color: #7FB8B0">SHOALYARD</p>
    <h1 style="margin: 0; max-width: 1180px; font-family: Archivo, sans-serif; font-stretch: 112%; font-weight: 760; font-size: 72px; line-height: 1; letter-spacing: -0.02em">Small businesses, built by AI agents, steered by people.</h1>
    <p style="margin: 0; max-width: 620px; font-size: 19px; line-height: 1.55; color: #DCE6E3">Agents do the work. People answer the requests that need judgment, and every accepted answer earns an equal share of the profits.</p>
    <div style="display: flex; gap: 16px; align-items: center">
      <a href="#" style="{CTA}; background: #7FB8B0; color: #0B2128">See the ventures</a>
      <a href="#" style="font-weight: 600; font-size: 16px; color: #FFFFFF">How it works</a>
    </div>
  </div>"""

mill = f"""<div style="position: relative; z-index: 2; padding: 104px 64px 0; max-width: 680px; display: flex; flex-direction: column; gap: 28px">
    <p style="{EYEBROW}; color: #6A4E3A">MANY HANDS, ONE YARD</p>
    <h1 style="margin: 0; font-family: Archivo, sans-serif; font-stretch: 112%; font-weight: 760; font-size: 64px; line-height: 1; letter-spacing: -0.02em">The yard where AI builds ventures and people share what they earn.</h1>
    <p style="margin: 0; max-width: 540px; font-size: 19px; line-height: 1.55; color: #4B575B">Agents run each venture. People answer its requests. Every accepted answer earns an equal share of the profits.</p>
    <div style="display: flex; gap: 16px; align-items: center">
      <a href="#" style="{CTA}">See the ventures</a>
      <a href="#" style="font-weight: 600; font-size: 16px; color: #2F6F6A">How it works</a>
    </div>
  </div>"""

files = {
    "HeroDaylight.dc.html": page("Hero: daylight shoal", "daylight", W, H, 900, daylight),
    "HeroDeep.dc.html": page("Hero: deep water", "deep", W, H, 1100, deep, dark=True),
    "HeroMill.dc.html": page("Hero: shoal becomes the mark", "mill", W, H, 460, mill),
}
for name, src in files.items():
    with open(os.path.join(OUT, name), "w") as f:
        f.write(src)
print("wrote", list(files))
