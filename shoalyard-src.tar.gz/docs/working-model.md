# Foundation — Agent-Operated Ventures (working model)

Oct 30, 2026 · working model, exported from Claude Docs

## The idea in one paragraph

Agents found and operate ventures; humans contribute the slivers agents can't supply and are paid through profits interests in the ventures they advance. An agent generates a venture, brands it, and raises a micro-fund of $10 seats, to a minimum it sets from its own budget, from members who opt in to receive its Requests for Expertise (RFEs): domain judgment, data, introductions, credibility, physical-world action, sign-off. Each fulfilled RFE earns a profits interest in that venture. Every decision the agent takes is logged as an RFE; governance is a reserved class of RFE voted by interest holders; every venture reports to a public standard. Ventures run their own outbound, kill fast if no customer appears, and the platform learns across cohorts. Contributors hold \~95% of each venture's profits interests, the platform \~5%. Every venture carries the mark "\[Name\], a Foundation Agent Venture."

The underlying bet: building is now cheap, reaching a buyer is not, and buyers sit in human networks. A member who holds interests across many ventures earns a diversified, fractional income from their knowledge and their network, with no single-asset exposure.

## How we got here

The constant across every version was the same: expertise is distributed, reaching buyers is the bottleneck, and contributors should earn fractionally. What changed was who runs the venture.

| Version | What it was | Why it was dropped |
| --- | --- | --- |
| Venture studio as protocol | Humans post ideas, contributors earn equity | Equity in nothing is worth nothing; selects for low-opportunity-cost contributors |
| Expert marketplace | Firms commission research, agent decomposes and routes to experts for cash | Real demand (GLG replacement), but not the fractional-income model that motivates this |
| Expert panel app | Brands commission, experts subscribe via push | Became a market-research panel (Wynter/Attest shape), lost the ownership motive |
| Knowledge collectives | \~30 people co-own a knowledge product, paid by royalty split | Right payment mechanism; formation problem unsolved (who finds the 30?) |
| Human-led formation, customer 1 | Someone posts an idea, contributors help reach customer 1 for a royalty | Needs a committed human owner per venture, which fractional contributors won't be |
| Agent-led formation | Agent is founder, posts RFEs, humans fulfil for royalty | Current model; resolves the commitment problem |

Kept from earlier versions: a share of profits over conventional equity, customer 1 as the event that triggers payment, rich contributor profiles for routing, and the "unit of expertise" as the atom.

## The model

&#91;embedded content: venture lifecycle · 2 gates, 1 learning loop\]

Two gates do the selection: members voting with $10 seats, then the market voting with a first purchase. A venture that fails either gate costs almost nothing, and what it taught feeds the next cohort's generation, pricing and kill rules.

## Primitives

Six objects make up the system. Everything else is plumbing.

| Primitive | What it is | Key rule |
| --- | --- | --- |
| Venture | An agent-operated business with its own brand, domain, identity and ledger | Series LLC under the platform parent; platform is the legal person, steward is the named officer |
| Micro-fundraise | The agent pitches; members buy $10 seats until the agent's minimum raise is met | Minimum raise = the plan's budget to customer 1, including formation and filings; the $10 buys a seat and RFE access, never a return; seat money is held until the minimum is met; if it isn't, the venture ends and every seat is refunded in full |
| RFE (Request for Expertise) | A bounded request the agent posts when it hits something it can't do: judgment, data, intro, credibility, physical action, sign-off | Carries a royalty offer; members accept or counter; critical RFEs filled redundantly |
| Profits interest | A profits interest in the venture's series LLC, granted for fulfilling an RFE | Granted for labor only, never for cash; forfeited if the input proves wrong; distributions follow the venture's business plan |
| Cohort pool | A vehicle holding a slice of profits interests from every venture launched in a period, split among that period's contributors | Proposed 70% venture-specific / 30% cohort; gives every member a reason to intro any venture |
| Steward | A human with a kill switch and sign-off on irreversible decisions (spend above X, contracts, pricing) | Stewardship is itself an RFE type and earns a profits interest |
| Brand mark | "\[Name\], a Foundation Agent Venture" | Transfers trust from platform track record; requires conduct standards; lost if standards are broken |

Contributor profile sits underneath all of these: a structured graph of roles, companies, buying authority, tools, verticals, and who they can reach, built by an agent-run onboarding interview and used for RFE routing and for conditioning idea generation on what the network can uniquely sell.

## Economics

Contributors are paid through profits interests, not a royalty on revenue. Each venture's series LLC grants a profits interest for every fulfilled RFE: a share of the venture's profits and, on a sale, of value created after the grant. Nothing is owed until there is profit to distribute, so a venture can reinvest if its plan calls for it.

The agent's business plan sets the objective and the distribution policy before the micro-fundraise:

1. **Objective**, stated in the pitch: revenue scale (reinvest, distributions deferred), profitability (distribute early and often), or exit (build to sell). Members back ventures whose objective matches what they want from their interest.
2. **Books**: the platform invoices as merchant of record and keeps the venture's accounts, so profit is verifiable, not self-reported.
3. **Split**: \~95% of profits interests to contributors, \~5% to the platform. Within the contributor share, \~70% as venture-specific grants and \~30% to a cohort vehicle.
4. **Distributions** follow the policy in the plan. Changing it is a steward sign-off, not an agent decision.

Entity formation and filings are a line in that budget, and the working recommendation is to form the series when the raise closes: profits interests cannot be granted without an entity, and a series under the platform's parent LLC costs little. Costlier steps (state registrations, licenses, sales-tax setup) are deferred until customer 1 is in sight and budgeted only if the plan needs them. When this happens is still open (see Open questions).

Platform funding has two sources: its 5% profits interest in every venture (arrives late, and only from ventures that distribute) and seat purchases (arrive first). The agent sets each venture's minimum raise from a budget it builds in the business plan: agent compute to reach customer 1, domain and tooling, entity formation and any regulatory filings, plus a buffer. Seats are $10 each and the minimum is whatever the budget needs, so a $250 venture and a $2,000 venture can both exist, and a venture whose budget no plausible seat count covers is not pitched. Across a few thousand members the seat money funds the platform's whole agent cost, including every venture that dies before customer 1.

Illustrative numbers, all placeholders: a venture with a profitability objective doing $300k/yr revenue at a 40% margin has $120k to distribute; \~$114k goes to contributors, and the 70% venture slice ($80k) across 25 interest holders averages $3.2k, weighted by RFE value. The same venture under a scale objective distributes nothing, and the interest's value rides on an eventual sale. A member fulfilling RFEs across 20 ventures with a 25% survival rate holds interests in 5 and a share of every cohort vehicle.

RFE offers are expressed in units of profits interest, set by the agent's estimate of the request's value and cleared by the market (accept/counter). Over time the platform derives real prices, including a conversion-based price for a human introduction measured as lift over the venture's own outbound. The trade-off against a revenue royalty is timing: a profits interest pays later and less certainly, which is why the objective has to be visible before anyone buys a seat.

## RFEs in detail

Every decision the agent takes is logged as an RFE; only some are pushed to members. Seven types cover everything:

| Type | What it asks for | Baseline N |
| --- | --- | --- |
| Judgment | A decision: the agent states its recommendation, confidence and stakes | 3–7 |
| Knowledge | A fact or data the agent can't verify alone | 2–3 (redundant) |
| Access | An introduction to a buyer, partner or supplier | 1 |
| Credibility | A named person vouching, or sitting in a call | 1–2 |
| Action | Something physical or legal a human must do | 1 |
| Capital | Seats in a micro-fundraise | Minimum raise |
| Stewardship | Sign-off on an irreversible decision | 1 (the steward) |

**Decision classifier.** Each decision lands in one of three bins. *Auto*: logged only. *Advisory*: pushed as a Judgment RFE; the agent decides unless responses move it. *Gated*: requires steward sign-off. The rule is uncertainty × stakes, where stakes means dollars at risk, reversibility, exposure to the mark, and whether a human's name is attached. Start with hard-coded gates (spend above a threshold, any contract, any pricing change, outbound to a new domain) and tune the advisory threshold from data. Compensation for Judgment RFEs scales with stakes and with whether the response was followed and proved right, which yields a calibration score per member.

**The N rule.** Per RFE the agent sets a minimum, a target and a stop rule. Type sets the baseline above; stakes raise it. Close early when responses agree, extend when they diverge. Weight by reputation, so high-calibration members reduce the N needed, and require profile diversity, so five similar backgrounds don't count as five. An RFE that never reaches quorum is a signal that the network has a gap, and a recruiting target.

**Attention budget.** Members set hours and a daily cap; the agent pushes only RFEs that clear the threshold and posts the rest silently to the venture page. A dud push is a churned member.

## Governance

Governance is a distinct class of RFE: everything else is the operator asking for help; this is the owners deciding. The structure is a short list of reserved matters the agent cannot decide alone; everything outside the list is the agent's call.

**Who holds what.** The agent operates and proposes but has no vote. Interest holders vote on reserved matters, weighted by vested interest. The steward certifies that a proposal conforms to the plan and the protocol and can veto on those grounds only, never on business judgment. Venture 0's 5% is non-voting.

**Reserved matters**, fixed in the protocol and identical for every venture:

- Raising additional capital, or debt above a threshold (simple majority)
- Changing the objective or the distribution policy (supermajority)
- Selling the venture or its principal assets (supermajority)
- Winding down voluntarily (simple majority)
- Replacing the steward (simple majority)
- Amending the plan in a way the agent flags as material (simple majority)

Each is a governance RFE: the agent posts the proposal with the numbers (pro forma dilution, effect on distributions, runway), a voting window and a quorum.

**Funding growth.** Three sources, in order of how little they disturb the structure: retain earnings (a distribution-policy change, so it goes to a vote); a second micro-fundraise, with existing holders getting a pro rata right to buy first; outside capital, which takes a capital interest with a return hurdle ahead of the profits interests and changes everyone's waterfall. All three use the same RFE shape: proposal, waterfall before and after, vote.

**Winding down.** Automatic when a kill rule in the plan fires (kill date without customer 1, runway below a floor, steward kill switch); no vote, because members agreed to the rules at funding. Voluntary wind-down is a reserved matter. Either way the agent settles liabilities, makes a final distribution if any, disposes of the IP, publishes the post-mortem to the learning loop and retires the mark. A *dormant* state sits between operating and killed: a member can adopt the venture and run it as a human operator outside the protocol, with existing interests converting to a royalty.

**Venture 0 itself.** Protocol amendments are reserved matters of Venture 0, voted by its interest holders with a constitutional supermajority and a notice period. Ventures stay on the protocol version they were formed under unless they opt in to the new one.

## Public reporting standard

Default open. Openness is the trust mechanism that replaces a track record, the learning commons that makes the protocol worth joining, and the audit trail that keeps an agent honest. Four reasons to withhold, and every redaction is itself logged with its reason: third-party confidentiality, member privacy, competitive timing (withhold now, publish after an embargo), and legal.

| Object | Public | Venture members only | Private (agent, steward, Venture 0) |
| --- | --- | --- | --- |
| Venture | Pitch, plan, objective, budget, minimum raise, status, kill rules | Seat and interest holders by handle | Holders by identity |
| Financials | Revenue, costs, profit, distributions; quarterly with a lag; attested against the ledger | Monthly detail | Transaction level |
| Cap table | Contributor/platform split, holder count, concentration | Each handle's percentage | Identity behind each handle |
| Decision log | Every decision, classification, reasoning, outcome; sensitive items on a 30–90 day embargo | Embargoed items in real time | — |
| RFEs | Question, type, offer, N target, resolution, aggregate agreement and dissent | Respondents by handle | Individual responses |
| Customers | Count, segment, retention | Names, with consent | Contract terms |
| Members | Handle, role type, industry, seniority band, reputation tier | Calibration detail within shared ventures | Identity, earnings, response history |
| Agent | Model version, config, protocol version | — | Credentials |
| Post-mortem | Everything, after wind-down | — | — |

**Pseudonymity by default.** Members are handles with verified attributes. The Credibility RFE is the exception: a name is disclosed to the buyer, per RFE, by opt-in. Reputation is public as a tier, not a raw score.

**Attestation.** Because Venture 0 is merchant of record and keeps the books, it stamps published financials as reconciled to the ledger. The standard defines exactly what the stamp certifies.

**Periodic report.** Continuous disclosure covers the decision and RFE logs. A quarterly report per venture in a fixed, machine-readable schema (financials, cap table summary, RFE fill rates, customer counts, runway, objective status, reserved-matter changes) lets anyone build analytics across the population. Aggregated, that is a public index: survival rates by cohort, median time to customer 1, RFE clearing prices by type, distribution yields.

## Venture 0 as a protocol

Venture 0 is not a company that runs ventures. It is a published standard, a reference operator agent, and a registry, and it is itself run on the protocol's own primitives: it raises seats, posts RFEs (pricing rules, legal templates, conduct standards, generator improvements) and grants profits interests in itself for fulfilling them. The 5% is the protocol fee, owned by Venture 0's contributors; the founding steward holds a founder's grant and the steward seat, nothing more.

**The standard** is the constitution for agent-operated ventures: the seven RFE types, the funding rule, profits-interest grant terms, steward requirements, the public decision log, the N rule, conduct standards, the ledger and reporting schemas. Anyone can run a conforming operator agent.

**The mark** certifies conformance. In US trademark law that is a certification mark (the UL and Fairtrade category): licensed to anyone who meets the standard, withdrawn from anyone who doesn't. What keeps operators inside the protocol rather than forking it is the network: members route attention only to conforming ventures, the ledger is shared, and cross-cohort learning is a commons that forkers lose.

**The centralized point.** Blockchains get trust in the ledger from consensus; here it comes from Venture 0 holding the registry, a trusted third party. That needs no cryptography, but it is the one centralized element and exactly what the 5% pays for. The principles should say so rather than claim decentralization.

**Sequencing.** The whitepaper ships with a reference implementation: the principles are written out of the pilot venture, not before it.

## System design

Seven layers, top to bottom:

1. **Protocol** — the published spec plus JSON schemas; everything below conforms to it.
2. **Registry and ledger** — ventures, members, RFEs, grants, decisions, distributions. Append-only, public except where a plan marks a field private. The one centralized thing.
3. **Operator agent** — one per venture. A loop: read state → plan → classify next decision → act or post RFE → log → repeat. Runs on a schedule and on events.
4. **Member surface** — the RFE inbox. Mobile-first, push-driven, three answer formats (structured, short text, voice). Profile graph underneath for routing.
5. **Steward console** — the sign-off queue and the kill switch.
6. **Money and legal rails** — merchant-of-record invoicing, venture books, series formation, grant issuance, distributions.
7. **Learning loop** — decisions × inputs × outcomes across cohorts, fed back into generation, RFE pricing, N rules and kill rules.

| Object | States | What moves it |
| --- | --- | --- |
| Venture | Generated → Pitched → Funded → Formed → Operating → Customer 1 → Distributing / Dormant / Killed | Minimum raise; formation; first invoice; kill rule, adoption or steward |
| RFE | Drafted → Posted → Quorum → Resolved → Scored | N rule met; agent resolves; outcome known |
| Grant | Offered → Accepted → Vested → Distributing / Forfeited | RFE resolved; input validated or proven wrong |
| Decision | Classified → Auto / Advisory / Gated → Taken → Logged → Outcome | Classifier threshold; steward |

**Where the real design work is.** The decision classifier (three bins, reliably); the routing and N engine (who to ask, how many, when to stop — the moat); and the grant ledger (a cap table with thousands of tiny positions, one instrument, vesting and forfeiture).

**Build order.** Registry and ledger as plain tables. One operator agent running the loop against one venture, classifier hard-coded. RFE inbox as a web page with email notification before it is an app. Steward console as a single approval queue. Money rails by hand until the second venture. Learning loop as a spreadsheet until there are twenty ventures of data. The protocol document is written from what the pilot forces you to decide.

## Why now

Crowd-cofounder and work-for-equity platforms failed because ideas are free, commitment is scarce, and contributors self-selected for low opportunity cost. Three things are different, and the model depends on all three holding:

1. **Agents do the early labor.** Validation, build, deck, entity, outbound, invoicing used to be months of a founder's life. The human sliver has shrunk to a size that can be sourced fractionally.
2. **Agents can be the committed party.** A human founder won't go all-in for 0.1% of a maybe; an agent will run a hundred ventures with no ego. Fractional contribution and venture commitment stop being in tension.
3. **Supply becomes infinite, so distribution is the moat.** When anyone can build, products stop differentiating on the product and search/ads stop discriminating. What remains is who vouches and who can reach the buyer, and that is a human network.

What compounds: the platform that has run thousands of ventures knows what RFE pricing clears, which contributor types matter at which stage, how buyers negotiate agents down, and which kill signals are reliable. None of that exists anywhere today. Open failure makes it accumulate faster and lets prospective members see the track record.

The cautionary precedent is Anthropic's Project Vend, where an agent running a small shop lost money and was talked into discounts. The steward and cross-cohort learning exist because of it.

## Open questions, as RFEs

These are Venture 0's first RFEs. Each is posted in the standard form: the question, the agent's (here, this doc's) current recommendation, the type, and the N it needs. Resolving them is how the protocol gets written.

| Question | Current recommendation | Type | Target N | Who should answer |
| --- | --- | --- | --- | --- |
| Will people fulfil requests from an agent, and keep doing so? | Untested; the pilot answers it | Knowledge | 20 (pilot members) | First seat holders |
| Legal structure: do profits interests granted for services to many unaffiliated people stay compensatory, or become a securities offering? | Series LLC per venture; counsel on grants | Judgment | 2–3 | Securities and LLC counsel |
| When is the entity formed: at raise close or at first contract? | At raise close; defer costlier filings | Judgment | 3 | Counsel, steward |
| Seat vs. subscription | One-time $10 seat per venture | Judgment | 7 | Prospective members |
| Distribution policy: how much is fixed at the fundraise, how much the agent can revise? | Fixed objective; revisions are reserved matters | Judgment | 5 | Interest holders |
| Cohort pool ratio | 70% venture / 30% cohort | Judgment | 5 | Interest holders |
| Do profits interests carry votes on reserved matters? | Yes, weighted by vested interest | Judgment | 2–3 | LLC counsel |
| Does the cohort vehicle vote its slice? | Abstains | Judgment | 5 | Interest holders |
| Voting thresholds and quorum per reserved matter | Simple majority; supermajority for objective change and sale | Judgment | 5 | Interest holders |
| Steward capacity: how narrow can the gated class be? | Spend threshold, contracts, pricing, new outbound domain | Judgment | 3 | Stewards |
| Buyer-side trust: does the mark help or hurt before a track record exists? | Disclose; measure in the pilot | Knowledge | 10 | Buyers reached in the pilot |
| Can idea generation be conditioned on the member graph reliably? | Build it that way from day one | Knowledge | Pilot evidence | Operator agent |
| Manipulation: are redundancy, reputation and forfeiture enough? | Minimum set; add as abuse appears | Judgment | 5 | Stewards, members |
| Embargo length for sensitive decisions | 30–90 days | Judgment | 5 | Interest holders |
| Dead-venture IP: members first, open source, or Venture 0 commons? | Members first at nominal price; dormant state for adoption | Judgment | 5 | Interest holders |
| Name. Quorum and Tessera are crowded (multiple live registrations in classes 9/35/42; .coms taken). Severalty appears clear. Unchecked: Quorate, Commonhold, Inlay, Centaur, Agentry, Moiety, Manyfold | Parked; check Quorate, Commonhold, Inlay next | Judgment | 7 | Members, counsel |
| Your role: founding steward and largest contributor to Venture 0, or operator | Founding steward and largest contributor | Judgment | 1 | You |

## What to resolve next

In order, because each answer shapes the one after it. None of these require building the platform.

- [ ] **Run one venture by hand.** Build one agent-operated venture in Claude Code with you as steward. Pick something the agent can mostly do alone (narrow B2B tool, niche data product, lead-gen service) so RFEs are few and sharp.
- [ ] **Test the micro-fundraise.** Have the agent pitch it to \~20 people you know and ask for $10 seats. Whether they pay, and what they ask before paying, is the first real signal.
- [ ] **Field 5–10 RFEs.** Record what types actually occur, how fast they're filled, what profits-interest offer clears, and whether anyone fulfils a second one.
- [ ] **Get to customer 1 or kill it.** Set a kill date before launch. Either outcome teaches more than the plan.
- [ ] **Draft the contracts.** Seat agreement, RFE grant agreement for profits interests, series LLC operating agreement, steward agreement, with counsel on the securities question and the series-LLC wrapper. Do this during the pilot, not before.
- [ ] **Decide seat vs. subscription** from what the first 20 people said.
- [ ] **Write the conduct standards** that come with the brand mark: identity isolation, outbound limits, steward sign-off class, published ledger.
- [ ] **Pick a name.**

If the pilot works once, run a second to test repeatability. Only then does the agent plumbing (RFE routing, ledger, cohort pool, cross-cohort learning) earn its build cost.

The open questions below are Venture 0's first RFEs and get posted to the pilot members alongside the pilot venture.
