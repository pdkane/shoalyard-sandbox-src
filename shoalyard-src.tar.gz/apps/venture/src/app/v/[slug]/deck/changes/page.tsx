import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { canWithdrawForDeck, decksFor, seatPriceOf, slideOf } from "@av/protocol";
import { SLIDE_TITLES, type Claim, type PitchDeck, type SlideKey } from "@av/schema";
import { BasisBadge, causeHref, versionLine } from "@/components/deck-ui";
import { WithdrawSeatForm } from "@/components/qa-forms";
import { getData } from "@/lib/data";
import { formatUsd } from "@/lib/format";
import { resolveVenture } from "@/lib/venture";
import { cn } from "@/lib/utils";

export const metadata: Metadata = { title: "What changed in the deck" };

const CAUSE_LINK: Partial<Record<PitchDeck["cause"]["kind"], string>> = { qa: "The member question", rfe: "The request that settled it", lesson: "The lesson" };

const FIELD: Record<string, string> = {
  purpose: "Purpose",
  market: "Market sizing",
  alternatives: "Alternatives",
  pricing: "Pricing",
  budget: "Proof budget",
  plan: "Business plan inputs",
  contractors: "Labour costs",
  requestPlan: "Planned requests",
  milestones: "Milestones",
  killCriteria: "Kill rules",
  premortem: "How it could fail",
  primaryMetric: "Primary metric",
  "seatPlan.min": "Seat minimum",
};

function pathLabel(path: string, deck: PitchDeck): string {
  if (path.startsWith("claims.")) {
    const key = slideOf(deck, path.slice(7));
    return key ? `Claim on ${SLIDE_TITLES[key]}` : "Claim";
  }
  const m = /^slides\.(\w+)\.headline$/.exec(path);
  if (m) return `${SLIDE_TITLES[m[1] as SlideKey] ?? m[1]} headline`;
  return FIELD[path] ?? path;
}

const isClaim = (v: unknown): v is Claim => !!v && typeof v === "object" && "basis" in v && "text" in v;

function Value({ v }: { v: unknown }) {
  if (v === undefined || v === null) return <span className="text-zinc-400">none</span>;
  if (isClaim(v)) {
    return (
      <span className="flex items-start gap-1.5">
        <BasisBadge basis={v.disproved ? "disproved" : v.basis} />
        <span className={cn(v.disproved && "line-through")}>{v.text}</span>
      </span>
    );
  }
  if (typeof v === "string" || typeof v === "number") return <span>{v}</span>;
  if (Array.isArray(v)) {
    return (
      <ul className="list-disc space-y-0.5 pl-4">
        {v.map((x, i) => {
          const o = x as Record<string, unknown>;
          const text = o.condition
            ? `${o.condition} by ${String(o.by).slice(0, 10)}`
            : o.label && typeof o.usd === "number"
              ? `${o.label}: ${formatUsd(o.usd)}`
              : String(o.label ?? o.name ?? o.title ?? o.way ?? o.job ?? JSON.stringify(o));
          return <li key={i}>{text}</li>;
        })}
      </ul>
    );
  }
  const o = v as Record<string, unknown>;
  if (typeof o.price === "number") return <span>{`${formatUsd(o.price)} per ${o.unit}, ${o.cadence}`}</span>;
  if (o.name) return <span>{`${o.name}${o.target !== undefined ? `: ${o.target} ${o.unit ?? ""}` : ""}`}</span>;
  if (o.formula) return <span>{String(o.formula)}</span>;
  return <span className="font-mono text-xs">{JSON.stringify(v)}</span>;
}

export default async function DeckChangesPage(props: PageProps<"/v/[slug]/deck/changes">) {
  const { slug } = await props.params;
  const { store, viewer, params } = await getData();
  const venture = resolveVenture(store, slug, "/deck/changes");
  const decks = decksFor(store, venture.id).filter((d) => d.status !== "proposed");
  if (!decks.length) notFound();
  const proposed = decksFor(store, venture.id).find((d) => d.status === "proposed");
  const withdraw = canWithdrawForDeck(store, venture, viewer);

  return (
    <div className="mx-auto max-w-3xl space-y-6" style={{ "--accent-color": venture.accent } as React.CSSProperties}>
      <div className="space-y-2">
        <Link href={`/v/${venture.slug}/deck`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> {venture.name}&apos;s deck
        </Link>
        <h1 className="text-2xl font-semibold tracking-tight">What changed in the deck</h1>
        <p className="text-sm text-zinc-500">
          Every version, newest first. Claims are never deleted: a disproved one is struck through. Material changes (anything seat holders relied on when they took a seat) need the
          steward&apos;s sign-off, and every holder is told.
        </p>
      </div>
      {withdraw && (
        <div className="space-y-2 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <p>The deck changed materially after you took your seat. While seats are still selling, you can take your seat back for a full refund.</p>
          <WithdrawSeatForm slug={venture.slug} price={formatUsd(store.ledger.find((l) => l.ventureId === venture.id && l.kind === "seat" && l.handle === viewer)?.usd ?? seatPriceOf(venture, params))} />
        </div>
      )}
      {proposed && (
        <p className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-600">
          v{proposed.version} is waiting for the steward: {proposed.changes.filter((c) => c.material).map((c) => pathLabel(c.path, proposed)).join(", ")}.
        </p>
      )}
      <ol className="space-y-4">
        {[...decks].reverse().map((d) => {
          const href = causeHref(d, venture.slug);
          const material = d.changes.some((c) => c.material);
          return (
            <li key={d.id} id={`v${d.version}`} className="scroll-mt-20 space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium text-zinc-900">{versionLine(d)}</p>
                <div className="flex items-center gap-1.5">
                  {d.version > 1 && (
                    <span className={cn("rounded-full border px-2 py-0.5 text-[11px] font-medium", material ? "border-violet-200 bg-violet-50 text-violet-800" : "border-zinc-200 text-zinc-600")}>
                      {material ? "Material: signed by the steward" : "Not material"}
                    </span>
                  )}
                  {d.status === "superseded" && <span className="text-xs text-zinc-400">superseded</span>}
                </div>
              </div>
              <p className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-zinc-500">
                {href && (
                  <Link href={href} className="underline underline-offset-2">
                    {CAUSE_LINK[d.cause.kind] ?? "What caused it"}
                  </Link>
                )}
                {d.decisionId && (
                  <Link href={`/v/${venture.slug}/decisions/${d.decisionId}`} className="underline underline-offset-2">
                    The decision on the log
                  </Link>
                )}
                <Link href={`/v/${venture.slug}/deck?v=${d.version}`} className="inline-flex items-center gap-0.5 underline underline-offset-2">
                  Read v{d.version} <ArrowRight className="size-3" />
                </Link>
              </p>
              {d.banner && <p className="text-xs text-zinc-500">{d.banner}</p>}
              {d.changes.length > 0 ? (
                <ul className="divide-y divide-zinc-100 text-sm">
                  {d.changes.map((c, i) => (
                    <li key={i} className="space-y-1.5 py-2.5">
                      <p className="text-xs font-medium tracking-wide text-zinc-500 uppercase">
                        {pathLabel(c.path, d)}
                        {c.material && <span className="ml-1.5 text-violet-700 normal-case">material</span>}
                      </p>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <div className="rounded-md bg-zinc-50 p-2 text-zinc-600">
                          <p className="mb-0.5 text-[11px] text-zinc-400">Before</p>
                          <Value v={c.before} />
                        </div>
                        <div className="rounded-md bg-emerald-50/60 p-2 text-zinc-800">
                          <p className="mb-0.5 text-[11px] text-zinc-400">After</p>
                          <Value v={c.after} />
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-zinc-500">{d.version === 1 ? "The first version." : "No field-level changes recorded."}</p>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
