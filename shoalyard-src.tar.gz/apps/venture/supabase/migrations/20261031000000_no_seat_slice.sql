-- Seats never earn units, so there is no seat slice in the contributor pool.
alter table public.grants drop constraint if exists grants_slice_check;
alter table public.grants add constraint grants_slice_check check (slice in ('rfe','steward','cohort','founder'));
