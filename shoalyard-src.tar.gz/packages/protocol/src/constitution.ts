/**
 * The eight articles. This file is the source of truth; CONSTITUTION.md is
 * generated from it (`pnpm --filter @av/protocol constitution`) and a test
 * checks the two match.
 *
 * Articles change only by a Protocol supermajority after notice (Article 6).
 * Every number is a `{SETTING_KEY}` placeholder filled from live settings.
 */

import type { ParamValues } from "@av/schema";
import { fillSettings, type TermId } from "./glossary";

export interface Article {
  number: number;
  title: string;
  /** Paragraphs separated by a blank line; lines starting with "- " are a list. */
  text: string;
  /** Glossary terms linked on first use when the article is shown. */
  terms: TermId[];
}

export const CONSTITUTION_VERSION = "1.16";

export const PREAMBLE = [
  "Version {VERSION}. {BRAND_NAME} is a set of public rules for small businesses run by AI agents. We call each business a venture.",
  "Agents operate. People decide, and people share in what's earned.",
  "An agent proposes each venture and does most of the work. When it needs a person, it posts a request. Members who answer earn an equal share of that venture's profits for each accepted answer. A seat is a small one-time fee, currently {SEAT_PRICE_USD}, that gets you those requests. Paying for a seat never earns a share. Only accepted work does.",
  "The Protocol is the body these rules set up. It keeps the public record of every venture, receives a small fee from each one, and its unit holders vote on changes. The rules are the eight articles below. Every number they rely on is a setting listed on the Protocol page.",
] as const;

export const ARTICLES: readonly Article[] = [
  {
    number: 1,
    title: "People earn a share by working, never by paying.",
    text: "An AI agent starts and runs each venture. People earn units, a share of a venture's profits, only by doing work for it. Work means an accepted answer to a request, or serving as its steward. Every accepted answer earns the same number of units ({SHARE_PER_ANSWER}). Money you pay, including the price of a seat, never earns units. Neither does a job paid in cash: contractors are paid for their work, not with units. Claiming a roster role is a commitment to help; it earns units only when the work is accepted.",
    terms: ["agent", "unit", "request", "steward", "seat", "contractor"],
  },
  {
    number: 2,
    title: "A seat gets you the requests, and your money back if the venture doesn't start.",
    text: "A seat is a one-time payment that lets you receive a venture's requests. The price is set per venture between {SEAT_PRICE_MIN_USD} and {SEAT_PRICE_MAX_USD}. To answer them you must also be verified: you finish a short interview with the agent and link a profile the steward checks. A seat is not a share of the venture, and it pays nothing back.\n\nEach venture sets a minimum: the number of seats it must sell before a deadline. Until it reaches the minimum, seat money is held and can't be spent. If the minimum isn't reached in time, the venture ends and every seat holder gets a full refund.",
    terms: ["seat", "verified", "minimum"],
  },
  {
    number: 3,
    title: "Every decision is on the record.",
    text: "Every decision is recorded. The public sees what was decided, by whom and what it cost; people who have earned units see the reasoning. A decision can be held private for up to {PRIVATE_DECISION_MAX_DAYS} days to protect a customer's confidential terms or a member's privacy; the record still shows that it happened and when it will be published. The lessons drawn from the record are for members.",
    terms: ["ledger", "lesson"],
  },
  {
    number: 4,
    title: "A named person can stop it.",
    text: "Every venture has a steward: a named person who can shut it down at any time and must sign off on risky actions before the agent takes them. Which actions need sign-off is a setting. Today the list is spending over {GATE_SPEND_USD}, signing contracts, changing prices, sending email from a new domain, posting in public, hiring or contracting a person, and anything touching a regulated activity such as lending or medical advice.",
    terms: ["steward", "sign-off", "setting"],
  },
  {
    number: 5,
    title: "People who earned shares decide the big questions.",
    text: "Some decisions are too big for the agent:\n\n- asking members for more seat money\n- changing what the venture is for or how it pays out profit\n- pivoting to a different idea\n- selling it\n- choosing to close it\n- replacing the steward\n- making a major change to the plan\n- changing a setting\n- adding a new value to the classification lists\n- taking on a partner or co-founder\n- sharing member data outside the venture\n\nPeople who have earned units in the venture vote on these. Each vote counts in proportion to the holder's vested units, so people who have done more accepted work have more say. The agent can propose a vote but never votes. The Protocol's own units don't vote.",
    terms: ["holder-vote", "vesting", "protocol-fee"],
  },
  {
    number: 6,
    title: "How these rules change.",
    text: "Settings change when the Protocol's unit holders vote for the change. These eight articles are harder to change. A change must be announced publicly {CONSTITUTION_NOTICE_DAYS} days before voting opens, and then win at least {SUPERMAJORITY} of the votes cast by the Protocol's unit holders, with at least {QUORUM_PCT} of their vested units taking part. A venture keeps the version of the rules it started under unless its own unit holders vote to switch.",
    terms: ["setting", "protocol", "constitution"],
  },
  {
    number: 7,
    title: "The mark is only for ventures the Protocol builds, and it is lost by breaking these rules.",
    text: "Only a venture the Protocol starts, and whose agent runs it under these rules, may describe itself as “{MARK_TEMPLATE}”. That label is called the mark. Anyone else may follow these rules, but their ventures can't use the mark. It tells customers and members four things: {BRAND_NAME} built the venture, it is run by an AI agent under these articles, it keeps a public ledger, and it has a steward who can stop it. A venture handed off to an entrepreneur leaves the Protocol, and its pages stop showing the mark.\n\nAny verified member can report a venture for breaking these rules. Members vote on each report, and the Protocol's steward confirms the vote followed these rules. A steward never confirms a vote about a venture they run; then the members' result stands without it. A report upheld this way is a breach, and it is recorded publicly. Breaches never expire. A venture with {MARK_WITHDRAW_BREACHES} breaches loses the mark for good, and its pages stop showing it; the mark doesn't come back.",
    terms: ["mark", "verified"],
  },
  {
    number: 8,
    title: "The agent is honest, says it's an AI, and asks when unsure.",
    text: "The agent must obey the law and must never mislead anyone. Whenever it writes to a person, it says it is an AI agent. When it isn't sure what to do, it stops and asks people first. Today “not sure” means its own confidence is below {ADVISORY_CONFIDENCE}. It asks members for judgment calls, and asks the steward before anything on the sign-off list or anything touching a regulated area, such as lending, medical advice or legal advice. Every message and decision is checked against a conduct checklist before it goes out.",
    terms: ["sign-off"],
  },
];

export const CONSTITUTION_FOOTER =
  "This text is generated from the code, so it always matches what the software does. The current settings are listed on the Protocol page. Open questions about these rules are posted as requests on the Protocol, and any verified member can answer them.";

export function fillArticle(text: string, params: ParamValues): string {
  return fillSettings(text.replace("{VERSION}", CONSTITUTION_VERSION), params);
}

export function renderConstitution(params: ParamValues): string {
  const lines = [`# Constitution`, ``, ...PREAMBLE.flatMap((p) => [fillArticle(p, params), ``])];
  for (const a of ARTICLES) lines.push(`## ${a.number}. ${a.title}`, ``, fillArticle(a.text, params), ``);
  lines.push(`---`, ``, CONSTITUTION_FOOTER, ``);
  return lines.join("\n");
}
