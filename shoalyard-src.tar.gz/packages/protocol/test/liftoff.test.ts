import assert from "node:assert/strict";
import { test } from "node:test";
import type { Store } from "@av/schema";
import { advanceBatches } from "../src/batches";
import { amendDeck, latestDeck } from "../src/deck";
import { activeSeats, buySeat, logDecision, seatsSold, stewardDecide, transitionVenture, ventureBySlug } from "../src/ops";
import { checkLiftoff, claimRole, raiseShortfall, rosterFill, rosterProgress, withdrawSeat } from "../src/roster";
import { buildSeed } from "../src/seed";

const seed = buildSeed();
const OPEN = "2026-11-07T13:00:00.000Z";
const CLOSE = "2026-11-12T12:00:00.000Z";
const SLUG = "lumper-line";
const PLAN = latestDeck(seed, SLUG)!.seatPlan;
const MIN = PLAN.min;
const MAX = PLAN.max;

/** Batch 003 live and public, with Lumper Line selling seats under the current rule. */
function live(): Store {
  const s = structuredClone(seed) as Store;
  s.meta.clock = OPEN;
  advanceBatches(s);
  assert.equal(ventureBySlug(s, SLUG)!.status, "pitched");
  return s;
}

function buy(s: Store, n: number, from = 0) {
  for (let i = from; i < from + n; i++) buySeat(s, { slug: SLUG, handle: `seat_${String(i).padStart(2, "0")}` });
}

function claimCritical(s: Store) {
  claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "dispatch_dana" });
  claimRole(s, { slug: SLUG, roleKey: "domain-expert", handle: "cfo_ines" });
}

/** Seats met and both critical roles claimed: the raise succeeds and the 21-day clock starts. */
function raised(): Store {
  const s = live();
  claimCritical(s);
  buy(s, MIN);
  const v = ventureBySlug(s, SLUG)!;
  assert.equal(v.status, "funded");
  return s;
}

const at = (s: Store, iso: string) => {
  s.meta.clock = iso;
  return advanceBatches(s);
};

test("the minimum alone isn't enough: an unverified claim on a critical role ends the venture at the window's close", () => {
  const s = live();
  const v = ventureBySlug(s, SLUG)!;
  const { status } = claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "newbie_ned" });
  assert.equal(status, "pending");
  claimRole(s, { slug: SLUG, roleKey: "domain-expert", handle: "cfo_ines" });
  buy(s, MIN);
  assert.equal(v.status, "pitched", "the minimum is met, but the operator claim isn't verified");
  const operator = latestDeck(s, v.id)!.roster.find((r) => r.key === "icp-operator")!.label.toLowerCase();
  assert.deepEqual(raiseShortfall(s, v), [`a verified claim on ${operator}`]);
  const sold = seatsSold(s, v.id);
  const events = at(s, CLOSE);
  assert.equal(v.status, "killed");
  assert.equal(seatsSold(s, v.id), 0);
  assert.equal(s.ledger.filter((l) => l.ventureId === v.id && l.kind === "refund").length, sold);
  assert.equal(v.postMortem?.killReason, "could not reach buyer");
  assert.ok(events.some((e) => e.message.startsWith("Lumper Line ended at the window's close, still needing a verified claim")));
});

test("anyone can claim a role without a seat; with the critical roles claimed, the minimum completes the raise", () => {
  const s = live();
  const v = ventureBySlug(s, SLUG)!;
  claimCritical(s);
  assert.ok(!activeSeats(s, v.id).some((l) => l.handle === "dispatch_dana"), "the claim needed no seat");
  buy(s, MIN - 1);
  assert.equal(v.status, "pitched");
  assert.deepEqual(raiseShortfall(s, v), ["1 more seats"]);
  buy(s, 1, MIN - 1);
  assert.equal(v.status, "funded");
  assert.equal(v.liftoff?.askedAt, s.meta.clock);
  assert.match(s.decisions.at(-1)!.reasoning, /fill at least 50% of the roster within 21 days/);
});

test("role claims are checked: one per member, verified profiles must fit, filled roles close", () => {
  const s = live();
  assert.throws(() => claimRole(s, { slug: SLUG, roleKey: "builder", handle: "dispatch_dana" }), /doesn't match/);
  claimRole(s, { slug: SLUG, roleKey: "builder", handle: "gis_greta" });
  assert.throws(() => claimRole(s, { slug: SLUG, roleKey: "builder", handle: "scrapewright" }), /is filled/);
  claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "dispatch_dana" });
  assert.throws(() => claimRole(s, { slug: SLUG, roleKey: "domain-expert", handle: "dispatch_dana" }), /one role per venture/);
  assert.throws(() => claimRole(s, { slug: SLUG, roleKey: "channel", handle: "MP" }), /steward runs the venture/);
});

test("seats stop at the maximum; roles stay open", () => {
  const s = live();
  buy(s, MAX);
  assert.throws(() => buy(s, 1, MAX), new RegExp(`All ${MAX} seats in Lumper Line are taken\\. You can still claim a role`));
  assert.doesNotThrow(() => claimRole(s, { slug: SLUG, roleKey: "builder", handle: "gis_greta" }));
});

test("formation waits for the roster; filling half of it with the critical roles lets the venture form", () => {
  const s = raised();
  const v = ventureBySlug(s, SLUG)!;
  assert.throws(() => transitionVenture(s, v, "formed"), /Fill the roster first/);
  const { decision: formation } = logDecision(s, { ventureId: v.id, title: "File the series formation", reasoning: "Formation filing.", confidence: 0.9, model: "rule", facts: { spendUsd: 55, budgetLine: "formation" } });
  assert.equal(formation.status, "rejected");
  claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "lanehauler" });
  claimRole(s, { slug: SLUG, roleKey: "domain-expert", handle: "bookkeep_bo" });
  claimRole(s, { slug: SLUG, roleKey: "builder", handle: "gis_greta" });
  assert.equal(rosterProgress(s, v).filled, 5);
  assert.ok(!v.liftoff?.passedAt, "5 of 12 is under half");
  claimRole(s, { slug: SLUG, roleKey: "channel", handle: "tms_tara" });
  assert.equal(rosterProgress(s, v).pct, 50);
  assert.ok(v.liftoff?.passedAt);
  assert.doesNotThrow(() => transitionVenture(s, v, "formed"));
});

test("short at day 21: the steward extends once; still short after the extension, the venture ends and every seat is refunded", () => {
  const s = raised();
  const v = ventureBySlug(s, SLUG)!;
  const sold = seatsSold(s, v.id);
  assert.equal(checkLiftoff(s, v), "waiting");
  at(s, "2026-11-29T13:00:00.000Z");
  const ask = s.decisions.find((d) => d.ventureId === v.id && d.facts.liftoff === "extend")!;
  assert.equal(ask.status, "awaiting_steward");
  assert.ok(ask.binReasons.some((r) => /steward extends once/.test(r)));
  stewardDecide(s, ask.id, true, "Two operators are mid-verification.", v.stewardHandle);
  assert.equal(v.liftoff?.extendedUntil, "2026-12-12T13:00:00.000Z");
  at(s, "2026-12-05T12:00:00.000Z");
  assert.equal(v.status, "funded");
  at(s, "2026-12-12T14:00:00.000Z");
  assert.equal(v.status, "killed");
  assert.equal(s.ledger.filter((l) => l.ventureId === v.id && l.kind === "refund").length, sold);
  assert.equal(v.postMortem?.killReason, "ran out of time");
  assert.equal(v.postMortem?.costUsd, 0);
  assert.ok(!s.decisions.some((d) => d.ventureId === v.id && d.status === "taken" && d.facts.spendUsd > 0), "no formation money was spent");
});

test("declining the extension ends the venture at once", () => {
  const s = raised();
  const v = ventureBySlug(s, SLUG)!;
  at(s, "2026-11-29T13:00:00.000Z");
  const ask = s.decisions.find((d) => d.ventureId === v.id && d.facts.liftoff === "extend")!;
  stewardDecide(s, ask.id, false, "Nobody new in three weeks.", v.stewardHandle);
  assert.equal(v.status, "killed");
  assert.equal(seatsSold(s, v.id), 0);
});

test("withdrawing after a material change refunds that one seat", () => {
  const s = live();
  const v = ventureBySlug(s, SLUG)!;
  buy(s, 5);
  assert.throws(() => withdrawSeat(s, { slug: SLUG, handle: "seat_00" }), /only while seats are selling, after a material deck change/);
  const { decision } = amendDeck(s, v, { patch: { pricing: { ...latestDeck(s, v.id)!.pricing, price: 149 } }, title: "raise the price", reason: "Brokers pay more for data.", cause: { kind: "steward" } });
  stewardDecide(s, decision.id, true, "Checked against two quotes.", v.stewardHandle);
  const { usd } = withdrawSeat(s, { slug: SLUG, handle: "seat_00" });
  assert.equal(usd, ventureBySlug(s, SLUG)!.seatPriceUsd);
  assert.equal(seatsSold(s, v.id), 4);
  assert.equal(s.ledger.filter((l) => l.ventureId === v.id && l.kind === "refund").length, 1);
});

test("before the first customer, seat money pays only for the published plan", () => {
  const s = raised();
  const v = ventureBySlug(s, SLUG)!;
  for (const [roleKey, handle] of [["icp-operator", "lanehauler"], ["domain-expert", "bookkeep_bo"], ["builder", "gis_greta"], ["channel", "tms_tara"]] as const) {
    claimRole(s, { slug: SLUG, roleKey, handle });
  }
  const spend = (title: string, facts: Record<string, unknown>) => logDecision(s, { ventureId: v.id, title, reasoning: "Spend.", confidence: 0.9, model: "rule", facts: facts as never }).decision;
  assert.equal(spend("Buy the lumper-rate data feed", { spendUsd: 40, budgetLine: "api" }).status, "taken");
  const off = spend("Sponsor a freight podcast", { spendUsd: 30 });
  assert.equal(off.status, "rejected");
  assert.match(off.outcome ?? "", /Off plan/);
  const deck = latestDeck(s, v.id)!;
  assert.equal(deck.seatPlan.shortfallUsd, 0, "seats at the venture's price cover the whole proof");
  Object.assign(deck.seatPlan, { contingencyUsd: 0, shortfallUsd: 100 });
  const noSlack = spend("Top up the data feed", { spendUsd: 30, budgetLine: "api" });
  assert.equal(noSlack.status, "rejected");
  assert.match(noSlack.outcome ?? "", /only \$0 of contingency/);
  const beyond = spend("A year of shared services up front", { spendUsd: deck.seatPlan.minRaiseUsd, budgetLine: "shared-services" });
  assert.equal(beyond.status, "rejected");
  assert.match(beyond.outcome ?? "", /was never raised/);
  Object.assign(deck.seatPlan, { contingencyUsd: 50, shortfallUsd: 0 });
  const over = spend("Top up the data feed", { spendUsd: 30, budgetLine: "api" });
  assert.equal(over.status, "awaiting_steward");
  assert.ok(over.binReasons.some((r) => /contingency/.test(r)));
  const tooFar = spend("Another data feed month", { spendUsd: 60, budgetLine: "api" });
  assert.equal(tooFar.status, "rejected");
  const test = spend("Run a channel test on load boards", { spendUsd: 20, budgetLine: "tools", channelTest: true });
  assert.equal(test.status, "rejected");
  assert.match(test.outcome ?? "", /written down as an experiment/);
  s.experiments.push({ id: "exp-1", ventureId: v.id, at: s.meta.clock, premise: "p", hypothesis: "h", metric: "m", successBar: "b", stopRule: "r", budgetUsd: 20, endsAt: "2026-12-30T00:00:00.000Z", status: "running" });
  assert.equal(spend("Run a channel test on load boards", { spendUsd: 20, budgetLine: "tools", channelTest: true, experimentId: "exp-1" }).status, "taken");
});

test("legacy ventures keep the old rule: no seat maximum, no critical-role gate", () => {
  const s = structuredClone(seed) as Store;
  const lien = ventureBySlug(s, "lien-clock")!;
  assert.notEqual(latestDeck(s, lien.id)!.seatPlan.rule, "derived");
  assert.deepEqual(raiseShortfall(s, lien).filter((x) => x.startsWith("a verified claim")), []);
  assert.ok(rosterFill(s, lien).some((r) => r.filled.length), "seeded holders who fit claimed roles");
});
