import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ScrollText } from "lucide-react";
import { canReadLessons, decisionTier, decisionViews } from "@av/protocol";
import { DECISION_BINS, type DecisionBin, type LedgerEntry } from "@av/schema";
import { Pill } from "@/components/badges";
import { DecisionLog } from "@/components/decision-log";
import { EmptyState } from "@/components/empty-state";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData } from "@/lib/data";
import { resolveVenture } from "@/lib/venture";
import { formatDateTime, formatNumber, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

export const metadata: Metadata = { title: "Public record" };

const KINDS: LedgerEntry["kind"][] = ["seat", "refund", "grant", "vest", "forfeit", "distribution", "contractor-pay", "service-charge", "service-cost", "handoff", "handoff-payout", "redaction", "amendment", "qualification", "breach", "status", "notify"];
const KIND_LABEL: Record<LedgerEntry["kind"], string> = {
  seat: "Seat",
  refund: "Refund",
  grant: "Units earned",
  vest: "Units vested",
  forfeit: "Units taken back",
  distribution: "Payout",
  "contractor-pay": "Contractor paid",
  "service-charge": "Shared services",
  "service-cost": "Back-office cost",
  handoff: "Hand-off",
  "handoff-payout": "Hand-off payout",
  redaction: "Withheld",
  amendment: "Setting changed",
  qualification: "Verified",
  breach: "Rule breach",
  status: "Status",
  notify: "Message",
};

export default async function LedgerPage(props: PageProps<"/v/[slug]/ledger">) {
  const { slug } = await props.params;
  const sp = await props.searchParams;
  const { store, viewer, params, member } = await getData();
  const lessonsVisible = canReadLessons(member, params);
  const venture = resolveVenture(store, slug, "/ledger");
  const kind = KINDS.includes(sp.kind as LedgerEntry["kind"]) ? (sp.kind as LedgerEntry["kind"]) : undefined;
  const bin = DECISION_BINS.includes(sp.approval as DecisionBin) ? (sp.approval as DecisionBin) : undefined;
  const all = store.ledger.filter((l) => l.ventureId === venture.id).sort((a, b) => b.at.localeCompare(a.at) || b.id.localeCompare(a.id));
  const rows = (kind ? all.filter((l) => l.kind === kind) : all.filter((l) => l.kind !== "notify")).slice(0, 300);
  const base = `/v/${venture.slug}/ledger`;
  const tier = decisionTier(store, venture, member, params);

  return (
    <div className="space-y-8" style={{ "--accent-color": venture.accent } as React.CSSProperties}>
      <div className="space-y-2">
        <Link href={`/v/${venture.slug}`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> {venture.name}
        </Link>
        <h1 className="text-2xl font-semibold tracking-tight">Public record</h1>
        <p className="text-sm text-zinc-500">
          Every money and unit movement for this venture, in order. Nothing is ever edited or deleted. The report and the units table are
          calculated from this list.
        </p>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {[undefined, ...KINDS].map((k) => {
          const count = k ? all.filter((l) => l.kind === k).length : all.filter((l) => l.kind !== "notify").length;
          if (k && count === 0) return null;
          return (
            <Link
              key={k ?? "all"}
              href={k ? `${base}?kind=${k}` : base}
              className={cn(
                "inline-flex h-7 items-center gap-1.5 rounded-full border px-3 text-xs font-medium",
                kind === k ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white text-zinc-600 hover:border-zinc-300",
              )}
            >
              {k ? KIND_LABEL[k] : "All"} <span className="opacity-70">{count}</span>
            </Link>
          );
        })}
      </div>

      {rows.length === 0 ? (
        <EmptyState icon={ScrollText} title="No entries" />
      ) : (
        <div className="overflow-hidden rounded-xl border border-zinc-200 bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-40">When (UTC)</TableHead>
                <TableHead>Kind</TableHead>
                <TableHead>Who</TableHead>
                <TableHead className="text-right">USD</TableHead>
                <TableHead className="text-right">Units</TableHead>
                <TableHead className="min-w-64">Note</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((l) => (
                <TableRow key={l.id} className={l.handle === viewer ? "bg-amber-50/60" : undefined}>
                  <TableCell className="text-xs whitespace-nowrap text-zinc-500">{formatDateTime(l.at)}</TableCell>
                  <TableCell className="text-xs font-medium">
                    {l.kind === "refund" ? <Pill className="border-emerald-200 bg-emerald-50 text-emerald-800">Refunded</Pill> : KIND_LABEL[l.kind]}
                  </TableCell>
                  <TableCell className="text-sm">{l.handle ? `@${l.handle}` : "—"}</TableCell>
                  <TableCell className={cn("text-right tabular-nums", l.kind === "refund" && "text-emerald-700")}>{l.usd !== undefined ? formatUsd(l.usd, true) : ""}</TableCell>
                  <TableCell className="text-right tabular-nums">{l.units !== undefined ? formatNumber(l.units) : ""}</TableCell>
                  <TableCell className="max-w-md text-sm whitespace-normal text-zinc-600">{l.note}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <section id="log" className="scroll-mt-20 space-y-4">
        <h2 className="text-lg font-semibold tracking-tight">Full decision log</h2>
        <DecisionLog
          decisions={decisionViews(store, venture, tier, params)}
          tier={tier}
          ventureSlug={venture.slug}
          basePath={base} bin={bin} lessons={lessonsVisible ? store.lessons : []} lessonsVisible={lessonsVisible} />
      </section>
    </div>
  );
}
