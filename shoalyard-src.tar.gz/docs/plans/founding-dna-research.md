# Founding DNA: what Agent Ventures can borrow from YC, gstack and operator practice

Research note, 30 Oct 2026. It answers: *"anything we can borrow from ycombinator/gstack around ingredients for successful ventures that would guide the way the agents actually operate the business? Any other VC primitives that could be part of the 'founding dna'?"*

The note is read-only research and changes nothing in the repo. Where it suggests names, they follow the existing `packages/schema/src/params.ts` style and the existing Venture `thesis`, `killRules`, `postMortem` and Lesson `kind` fields.

---

## 0. TL;DR

1. **gstack is real and fits the pilot closely.** It is Garry Tan's MIT-licensed set of Claude Code skills (github.com/garrytan/gstack, created March 2026, about 138k stars). It turns one agent into a "virtual team" of role prompts (Office Hours, CEO, eng manager, designer, QA, release engineer, security officer) that run as a sprint: **Think → Plan → Build → Review → Test → Ship → Reflect**. Each step writes an artifact the next one reads, and a `/learn` store carries lessons across sessions. That is the same shape as the pilot's pitch → operate → lessons loop.
2. **The most valuable thing to borrow is `/office-hours`.** Its "startup mode" has six forcing questions: demand reality, status quo, desperate specificity, narrowest wedge, observation and surprise, and future-fit. It also has anti-sycophancy rules ("interest is not demand"). These should become required pitch fields and the agent's self-critique before any pitch goes out.
3. **From the YC canon, encode a few operating loops, not more rules.** These are: one primary metric reviewed weekly (target 5%/week, Graham), a default-alive check (Graham and Blackwell), launching the narrowest wedge quickly, doing things that don't scale, talking to users every week (Mom Test rules), and a weekly member update that has lowlights and **at most 3 asks, each of which becomes an RFE**.
4. **From operator and VC practice:** a pre-mortem plus kill criteria written as "state and date" at pitch time; no moving the goalposts quietly (from gstack's "gate integrity"); unit-economics gates on acquisition spend; preregistered experiments (from gstack `/eval-plan` and Lean Startup); and a CB Insights-style taxonomy for kill reasons. Superhuman's 40% survey and staged release of seat money are worth adding later.
5. **Skip the instruments that make seats look like securities:** pro-rata, information rights as a privilege, Demo Day as a fundraising event, cliffs on anything a seat buys, and any metric framed as the value of a seat. One existing design point needs counsel now: **the seat-holder pool slice (`POOL_SEATS_UNITS = 10`) is open only to people who paid for a seat**, which links money in to profit units out. There is also existing copy ("get paid in a share of their profits", "accrues pro rata to holders") that conflicts with the no-fund-vocabulary rule. See §5.
6. **Constitution changes should be minimal.** At most one clause, the YC line "It's not your money": seat money is spent only on the venture's published plan. Everything else belongs in parameters, loops and pitch fields. A proposed 10-line Founding DNA is in §6.

---

## 1. gstack: what it is, verified

**Source:** [github.com/garrytan/gstack](https://github.com/garrytan/gstack) (README), [docs/skills.md](https://github.com/garrytan/gstack/blob/main/docs/skills.md), [ETHOS.md](https://github.com/garrytan/gstack/blob/main/ETHOS.md), [office-hours/sections/phase-2a-startup-diagnostic.md](https://github.com/garrytan/gstack/blob/main/office-hours/sections/phase-2a-startup-diagnostic.md).

- It is Garry Tan's (President and CEO of YC) open-source "software factory" for Claude Code, and it also installs on Codex, Cursor, OpenCode and others. It is all slash commands, all Markdown, MIT-licensed, and has no premium tier. The repo was created on 2026-03-11.
- It describes itself as *"a process, not a collection of tools."* The skills run in sprint order, **Think → Plan → Build → Review → Test → Ship → Reflect**, and each one hands an artifact to the next. For example, `/office-hours` writes a design doc that `/plan-ceo-review` reads, and `/plan-eng-review` writes a test plan that `/qa` picks up.

### 1.1 Roles and commands that matter for running a business

| Skill | Role | What it does (from the docs) | Business analogue for an operating agent |
|---|---|---|---|
| `/office-hours` | "YC Office Hours" | "Start here." Six forcing questions; pushes back on framing; challenges premises; proposes 2–3 implementation alternatives with effort; ends with **one concrete assignment**; writes a design doc downstream skills read. Smart routing by stage (pre-product → Q1–3; has users → Q2,4,5; paying → Q4–6). | **Pitch interrogation.** The agent runs it on its own idea before pitching; the answers become pitch fields; member Q&A is seeded from them. |
| `/plan-ceo-review` | CEO / founder ("Brian Chesky mode") | "What is the 10-star product hiding inside this request?" Four modes: **Scope Expansion, Selective Expansion, Hold Scope, Scope Reduction**. | **A scope mode for each venture stage.** Default to *Reduction* until the first customer and *Selective Expansion* after a PMF signal. |
| `/plan-eng-review` | Eng manager | Locks architecture, data flow, failure modes and trust boundaries; forces diagrams because "diagrams force hidden assumptions into the open"; it is the **only required gate**. | **Operating-plan review.** Draw the customer flow and mark which steps need a human (these become RFEs, which in turn drive the liftoff roster) and what happens when each step fails. |
| `/autoplan` | Review pipeline | Runs CEO → design → eng review with six encoded decision principles: prefer completeness, match existing patterns, **choose reversible options**, prefer what the user chose before, defer ambiguous items, escalate security. Only "taste decisions" go to one final approval gate. | **Default decision heuristics, plus one batched steward queue** for taste decisions, so MP is not interrupted for each one. |
| `/review` | Staff engineer | Finds bugs that pass CI; **"gate integrity: every weakened test, timeout, snapshot or suppression reaches a human by name."** | **No quiet goalpost moves.** Relaxing a kill rule, growth target or gate is a named steward decision with a logged reason. |
| `/investigate` | Debugger | "Iron Law: no fixes without investigation … stops after 3 failed fixes." | **No change of tactic without a diagnosis.** After 3 failed attempts, stop and escalate. |
| `/qa`, `/qa-only` | QA lead | Opens a real browser, reproduces, fixes and re-verifies; the report-only mode gives replayable evidence. | **Mystery-shop the venture each week.** The agent walks its own signup, checkout and email flow, or posts an "action" RFE for a member to try it. |
| `/ship`, `/land-and-deploy`, `/canary` | Release engineer / SRE | Tests, PR, deploy, verify production health, then a post-deploy monitoring loop. | **Launch checklist plus a post-launch watch.** Public posts stay gated, as they are today. |
| `/eval-plan` | Eval planner | "**Preregister** a paid eval before the first priced call: bars, arms, decoys and stop rules, a $0 dry run … a three-item priced pilot whose extrapolation and spend table gate the approval." | **Preregistered experiments.** Hypothesis, success bar, stop rule and budget are written before spending; a small priced pilot runs before the spend gate. This is Lean Startup with teeth. |
| `/retro` | Eng manager | Weekly, "Not vibes — data." Per-person breakdown, streaks, top 3 wins, 3 things to improve, 3 habits; **saves a JSON snapshot so the next run shows trends.** | **The weekly operating review and member update.** The snapshot feeds the learning loop. |
| `/learn` | Memory | `learnings.jsonl` with confidence, source and referenced files. Other skills **"automatically search learnings before making recommendations, and display 'Prior learning applied'."** | **Lesson inheritance made visible.** Every decision cites the lesson it applied. |
| `/careful`, `/freeze`, `/guard` | Safety | Warn on or hard-deny destructive actions; restrict edit scope. | Already covered by `GATE_*` and Article 4 (steward approves irreversible actions). |
| `/cso` | Security officer | OWASP and STRIDE audit with explicit coverage. | Already covered by `REGULATED_ACTIVITIES`; add a pre-launch "regulated-activity sweep". |
| `/captain` | Crew controller | One controller, many lanes; lanes "send a READY block and never merge"; a digest; approvals in a fixed shape. | **Later:** the Protocol as controller over many venture agents. |

### 1.2 The six forcing questions (verbatim core)

From `phase-2a-startup-diagnostic.md`:

1. **Demand reality.** "What's the strongest evidence you have that someone actually wants this — not 'is interested,' not 'signed up for a waitlist,' but would be genuinely upset if it disappeared tomorrow?" Red flags: "500 waitlist signups", "VCs are excited about the space".
2. **Status quo.** "What are your users doing right now to solve this problem — even badly? What does that workaround cost them?" Red flag: "Nothing — there's no solution."
3. **Desperate specificity.** "Name the actual human who needs this most. What's their title? What gets them promoted? What gets them fired?" Red flag: category answers ("SMBs"), because "You can't email a category."
4. **Narrowest wedge.** "What's the smallest possible version of this that someone would pay real money for — this week, not after you build the platform?"
5. **Observation and surprise.** "Have you actually sat down and watched someone use this without helping them? What did they do that surprised you?" "Surveys lie. Demos are theater."
6. **Future-fit.** "If the world looks meaningfully different in 3 years … does your product become more essential or less?" Red flag: "The market is growing 20% per year."

**Operating principles** in the same file: *specificity is the only currency; interest is not demand; the user's words beat the founder's pitch; watch, don't demo; the status quo is your real competitor; narrow beats wide, early.* The **anti-sycophancy rules** ban phrases like "That's an interesting approach" and require the agent to "take a position on every answer … AND what evidence would change it." Every session ends with **one assignment, which is an action and not a strategy.**

### 1.3 gstack Builder Ethos and how each part translates

From [ETHOS.md](https://github.com/garrytan/gstack/blob/main/ETHOS.md). Principles 5–8 are credited to Lauren Tan's pstack.

| Ethos principle | Keep for the business? | Translation |
|---|---|---|
| 1. Boil the Ocean (completeness is cheap with AI) | **Only for execution quality, not scope.** | It conflicts with "narrowest wedge" if applied to scope. Use it for "finish the onboarding, every error path and every reply," not for "build the platform." |
| 2. Search Before Building (three layers: tried-and-true, new-and-popular, first principles) | **Yes** | A pre-pitch prior-attempt search, which doubles as the tarpit check (§2). |
| 3. User Sovereignty ("AI models recommend. Users decide.") | Already present | Maps to Articles 4 and 5. Keep the phrase as the agent's posture toward MP. |
| 4. Honest Work ("a report is a claim until it is re-executed"; no ceremony unless someone "can name who reads it, what decision changes") | **Yes** | Every claim in an update links to ledger evidence. "Done, unverified" is reported as such. An update with no asks and no decisions is ceremony, so cut it. |
| 5. Attack the Premise ("Two failures that share a premise are evidence about the premise") | **Yes** | After two failed campaigns on the same buyer assumption, the next step is a cheap test of that assumption, not a third campaign. |
| 6. Separate Before Serializing Shared State | Engineering only | — |
| 7. Make Operations Idempotent ("sending an email, charging a card … a key the receiver can deduplicate on") | **Yes, in the runtime** | Every outbound email, charge and refund carries an idempotency key that is recorded before the send. This is cheap and prevents a Project Vend-style mess. |
| 8. Explain the Number ("A measurement reported without its mechanism is a rumor") | **Yes** | Every metric in an update states what was measured, n, and the noise. No growth percentages on tiny bases. |

---

## 2. YC canon on operating a startup

| Idea | Source | Core claim, in short | What the agent should do with it |
|---|---|---|---|
| **Make something people want** | YC motto (2005); CB Insights notes YC picked it "a month after" founding. [YC](https://www.ycombinator.com/) | Everything else is downstream of this. | Demand evidence is the first pitch field. Count behavior and money, not praise. |
| **Write code, talk to users** | [YC's essential startup advice](https://www.ycombinator.com/library/4D-yc-s-essential-startup-advice) | "The most important tasks for an early stage company are to write code and talk to users"; everything else is mostly "fake work" (Altman). | A weekly minimum of user conversations, plus a test of whether each task moves the primary metric. |
| **Launch now / launch early** | Same page: "launch their product right away … a mediocre product as soon as possible," as long as it holds a "quantum of utility." | | A deadline from `formed` to the first public offer. |
| **90/10 solution** | Paul Buchheit, same page | 90% of the value for 10% of the work. | Default scope mode is *Reduction* (as in gstack CEO review). |
| **Do things that don't scale** | Paul Graham, [Do Things That Don't Scale](https://paulgraham.com/ds.html) (2013); Airbnb photographing listings | Recruit users manually; "delight" early users by hand. | Concierge onboarding for the first N customers, using agent work and member "action" RFEs. The `concierge-first` phenotype already exists. |
| **10 who love you > 1000 who kind of like you** | Essential advice page | Choose customers; sometimes fire them (Seibel, *Users You Don't Want*). | Retention of the first 10 matters more than top-line count. |
| **One or two key metrics** | Geoff Ralston, *Startup Priorities*, cited on the essential advice page | "Choose what to do based nearly exclusively on how the task will impact those metrics." | `PRIMARY_METRIC`: one per venture, fixed at formation. |
| **Weekly growth rate** | Paul Graham, [Startup = Growth](https://paulgraham.com/growth.html) (2012) | "If there's one number every founder should always know, it's the company's growth rate." In YC "we measure growth rate per week." A good rate is 5–7% a week; 10% is exceptional; 1% "is a sign you haven't yet figured out what you're doing." Also: 1%/week is 1.7x a year and 5%/week is 12.6x. | A weekly growth target with a floor, which only starts once a revenue or usage base exists. |
| **Default alive vs default dead** | Paul Graham, [Default Alive or Default Dead?](https://paulgraham.com/aord.html) (2015); Trevor Blackwell's calculator | "Assuming their expenses remain constant and their revenue growth is what it has been … do they make it to profitability on the money they have left?" Also: write down Plan B and "precisely when you'll have to switch." Hiring and premature scaling are the killers. | A weekly computed status. If default dead, Plan B is written and goes to the steward. |
| **It's not your money** | Essential advice page | "The money you raise IS NOT your money … spend the money only to improve the prospects of your company." | **The constitution-level candidate** (§4.5). |
| **Unit economics** | Sam Altman, *Unit Economics*; Buchheit: never "take 80 cents from a customer and then hand them a dollar back" | | No paid acquisition while contribution margin is negative. |
| **Growth is a result of PMF, not a precursor** | Seibel, *The Real Product Market Fit* | Growing before PMF produces poor retention. | Lock acquisition spend until there is a PMF signal. |
| **Suicide, not murder** | Essential advice page | Ignore competitors early. | Spend little agent time on competitor monitoring; list alternatives once, at pitch. |
| **Office hours** | YC program; operationalized by gstack `/office-hours` | Partners interrogate the founder's framing and end with an action. | Self-run at pitch time, plus an optional "office hours" judgment RFE where qualified members play the partner. |
| **Demo Day** | YC batch finale | A public showcase, which in YC's case is a fundraising event. | Possible **batch showcase** of progress against plan. Rename it, and never include a money ask (§5). |
| **Application questions as an idea test** | YC application. The key Idea questions: "Why did you pick this idea … How do you know people need what you're making?", "Who are your competitors? What do you understand about your business that they don't?", "How do or will you make money? How much could you make?"; Progress: "How far along are you?" ([summary](https://www.roundfunded.com/en/blogs/how-to-apply-to-y-combinator-2026)) | | These map almost one-to-one onto pitch fields; three are new (§4.3). |
| **Requests for Startups** | [YC RFS](https://www.ycombinator.com/rfs); Winter 2027 includes "The $15-an-Hour Expert", "AI for City Hall", "Plaid for Government Benefits" | Published problem spaces seed applications without being required. | A Protocol-level **"Wanted" list** fed by lessons and member expertise. It is input to idea generation, not a rule. |
| **Schlep blindness** | Paul Graham, [Schlep Blindness](https://paulgraham.com/schlep.html) (2012) | Founders unconsciously avoid tedious, unglamorous problems; that is where the openings are (Stripe). | **The agent's edge:** agents don't mind paperwork. Bias generation toward `boring-urgent` and name "the schlep" in the pitch. |
| **Tarpit ideas** | Dalton Caldwell and Michael Seibel, [Avoid These Tempting Startup Ideas](https://pickscribe.com/v/GMIawSAygO4) and [Tarpit Ideas: The Sequel](https://www.youtube.com/watch?v=GU9iT7MW0rs) (2024); Jared Friedman, [How to Get and Evaluate Startup Ideas](https://www.youtube.com/watch?v=Th8JoIan4dg) | Ideas that many founders have, that friends praise ("I totally have that problem"), that have been tried often, where "nothing has changed," and where a structural reason blocks them. A tarpit is not just a bad idea. | A pre-pitch check: who tried this before, why did they fail, and **what changed?** The answer goes in `whyNow`. |
| **Founder-market fit** | Jared Friedman, same talk: "If I had to pick like one most important criteria, it'd probably be this one." Also his other 9 questions: market size, acuteness, competition, do you want it, recently possible, proxies, years-long, scalable, idea space | "Are you the right team to be working on this idea?" | For an agent venture, fit means **network-market fit**: does the qualified membership cover the roster roles this venture needs? (§4.2) |

---

## 3. Other VC and operator primitives

| Primitive | Source | Core |
|---|---|---|
| **Sequoia business plan format** | [Sequoia, Writing a Business Plan](https://sequoiacap.com/article/writing-a-business-plan) | Company purpose (one declarative sentence), Problem, Solution, **Why now**, Market potential, Competition/alternatives, Business model, Team, Financials, Vision. The older template adds Product and "the deal". |
| **Rachleff's Law / PMF** | Marc Andreessen, [The only thing that matters](https://web.archive.org/web/20070701074943/blog.pmarca.com/2007/06/the-pmarca-gu-2.html) (2007), crediting Andy Rachleff | "When a great team meets a lousy market, market wins." "The only thing that matters is getting to product/market fit." "In a great market … the market pulls product out of the startup." |
| **Sean Ellis 40% test** | Via Rahul Vohra, [How Superhuman Built an Engine to Find PMF](https://review.firstround.com/how-superhuman-built-an-engine-to-find-product-market-fit/) | "How would you feel if you could no longer use the product?" Companies with ≥40% "very disappointed" had traction; those below struggled. |
| **Superhuman PMF engine** | Same source | Survey users who "used the product at least twice in the last two weeks"; ~40 responses give "directionally correct" results. Four questions: disappointment, who benefits, main benefit, how to improve. Segment on the very-disappointed group, then build half the roadmap to double down on what they love and half to convert the "somewhat disappointed" who share the main benefit. Track it over time. Superhuman went from 22% to 58%. |
| **Lean Startup** | Eric Ries, *The Lean Startup* (2011) | Build-Measure-Learn; MVP; validated learning; regular **pivot-or-persevere** meetings. |
| **The Mom Test** | Rob Fitzpatrick, *The Mom Test* (2013) | Talk about their life, not your idea; ask about specifics in the past, not opinions about the future; talk less. Compliments are noise; **commitments** (time, reputation, money) are signal. |
| **Jobs-to-be-done** | Clayton Christensen et al., *Competing Against Luck* (2016); job-story format (Klement/Intercom) | People "hire" a product for a job in a circumstance. "When ___, I want to ___, so I can ___." |
| **Unit economics** | David Skok, [SaaS Metrics 2.0](https://www.forentrepreneurs.com/saas-metrics-2/) (LTV > 3× CAC, CAC payback < 12 months); David Sacks, burn multiple = net burn / net new ARR (via [Lenny's Newsletter](https://www.lennysnewsletter.com/p/how-to-know-if-youve-got-productmarket)) | Contribution margin must be positive before scaling. |
| **Staged financing** | W. Sahlman, "The structure and governance of venture-capital organizations," *J. Financial Economics* (1990); P. Gompers, *J. Finance* (1995) | Capital is released in stages against milestones, which keeps the option to abandon. |
| **Pre-mortem** | Gary Klein, ["Performing a Project Premortem," HBR](https://hbr.org/2007/09/performing-a-project-premortem) (2007) | "Imagine it failed. Why?" Prospective hindsight surfaces risks people otherwise stay quiet about. |
| **Kill criteria** | Annie Duke, *Quit* (2022): kill criteria as a **state and a date** | Decide in advance what would make you stop, while you are not invested. |
| **Strong opinions, weakly held** | Paul Saffo (2008) | Take a position and say what would change it. gstack's anti-sycophancy rule is the same idea. |
| **Board cadence and updates** | YC update template ([Visible summary](https://visible.vc/blog/investor-updates-faq/)): KPIs, growth, highlights (3–5), lowlights (1–3), requests (1–3); Aaron Harris, [Investor Updates](https://blog.aaronkharris.com/investor-updates): monthly, "a hell of a forcing function," put the asks high | Monthly for companies; weekly suits a batch. |
| **The ask** | Same sources | "Vague asks … yield zero results." A good ask names a person or type, gives context, and includes a copy-paste blurb. |
| **Vesting and cliffs; pro-rata; information rights** | Standard venture terms | Earned ownership over time; the right to buy into later rounds; the right to financial statements. |
| **Post-mortems** | CB Insights, [Top 12 Reasons Startups Fail](https://www.cbinsights.com/reports/CB-Insights_Top-Reasons-Startups-Fail.pdf) (2021; 111 post-mortems) | Ran out of cash 38%, no market need 35%, outcompeted 20%, flawed business model 19%, regulatory/legal 18%, pricing/cost 15%, wrong team 14%, mistimed 10%, poor product 8%, disharmony 7%, pivot gone bad 6%, burnout 5%. The categories overlap. **Caveat:** CB Insights replaced this series in 2024 with a study of 431 VC-backed shutdowns (70% ran out of capital, which it treats as a *symptom*; 43% poor PMF; 29% bad timing; 19% unit economics), per [this fact-check](https://fasterthannormal.co/research/startup-statistics-fact-check). Use the categories, not the percentages. |

---

## 4. Encodings for this system

**Kinds:** (a) agent operating rule or loop · (b) parameter with default and reason · (c) pitch or memo field · (d) learning-loop tag or lesson topic · (e) constitution-level principle.
**Verdicts:** **Now** / **Later** / **Skip**. ⚠ marks a securities flag (§5).

### 4.1 Agent loops and rules (a)

| # | Borrowed from | Encoding | Verdict |
|---|---|---|---|
| A1 | gstack `/retro`; YC update template; Harris | **Weekly member update.** It is generated every `UPDATE_CADENCE_DAYS` while the venture is `operating` or later. Sections: *Primary metric (with n and week-over-week change) · Default-alive status · Highlights · Lowlights (required, ≥1) · Decisions taken and pending · Asks (≤ `UPDATE_MAX_ASKS`) · Credits*. **Each ask is drafted as an RFE** in the same pass and linked from the update. Credits names members whose answers mattered and links their grants, replacing YC's "shout-outs". A JSON snapshot is stored so the next update shows trends. Address it to all members, not to "seat holders". | **Now.** It is the main mechanism that turns venture needs into RFEs, and the user named it. |
| A2 | gstack `/office-hours`; YC application | **Pre-pitch self-interrogation.** Before any `generated → pitched` transition, the agent answers the six forcing questions, applying the anti-sycophancy rules to itself. It must take a position and name what evidence would change it. Unanswerable questions become RFEs instead of being guessed. Ends with "the one assignment" for week 1. | **Now.** Cheap, and it raises pitch quality the most. |
| A3 | Mom Test; YC "talk to users"; gstack "watch, don't demo" | **Weekly user contact loop.** Log at least `USER_CONVERSATIONS_PER_WEEK` real conversations (agent text interviews, or member-run calls through "access" or "action" RFEs). The interview script must ask about past behavior and specifics, never "would you use…?". Each logged conversation records one **surprise**, or "none", which is itself a red flag in gstack Q5. Only **commitments** count as demand evidence. | **Now** |
| A4 | gstack `/review` "gate integrity" | **No quiet goalpost moves.** Changing a kill rule, kill date, growth target or primary metric, or waiving a gate, is a Decision `awaiting_steward` with the old value, new value and reason, and it is flagged in the next update. | **Now.** Protects members' trust in kill rules, and it is a one-line check. |
| A5 | Lean Startup; gstack `/eval-plan` | **Preregistered experiments.** Any experiment over `GATE_SPEND_USD`, or any new channel, is logged *before* it runs with: hypothesis, metric, success bar, stop rule, budget, end date. The result is scored against the bar and never re-described afterward. | **Now** |
| A6 | Ries pivot-or-persevere; board cadence | **Monthly steward review.** Every `STEWARD_REVIEW_DAYS`: metric trend, default-alive status, kill-rule status, open experiments, and an explicit **persevere / pivot / propose-kill** recommendation that MP signs. This replaces a "board meeting" and reuses A1 data. | **Now** |
| A7 | gstack "Attack the Premise"; `/investigate` "3 failed fixes" | **Premise test.** After `PREMISE_FAILURES_BEFORE_TEST` failed attempts that share an assumption (for example "brokers will reply to cold email"), the agent states the premise as a falsifiable sentence and runs the cheapest test of it (often a judgment RFE) before a third attempt. | **Now** |
| A8 | gstack `/learn` "Prior learning applied" | **Lesson citation.** Before any decision the agent searches adopted lessons, and the Decision records `lessonsApplied: [ids]`, or "none relevant". The UI shows "Prior lesson applied". | **Now.** It makes the learning loop visible and measurable. |
| A9 | gstack `/qa`; PG "do things that don't scale" | **Weekly mystery-shop.** The agent walks its own customer path end to end, or posts an "action" RFE for a member to do it, and logs breakages. | **Now** |
| A10 | gstack Ethos 7 | **Idempotency keys** on every outbound email, charge and refund, recorded before the send. | **Now** (runtime) |
| A11 | gstack "Search Before Building"; tarpit | **Prior-attempt search** before pitching: who tried this, why they stopped, what has changed since. Matches against a learned `TARPIT_PATTERNS` list force a `whyNow` answer that names the change. | **Now** |
| A12 | gstack `/autoplan` | **Batched taste decisions.** Non-gated "taste" calls are queued and shown to MP once a day in one list, instead of one interruption each. | **Later**, once decision volume is high enough to matter. |
| A13 | Superhuman PMF engine | **PMF survey loop.** Once a venture has ≥ `PMF_MIN_RESPONSES` eligible users (core use at least twice in two weeks), run the four questions monthly and segment on "very disappointed". The roadmap is split between doubling down and converting the "somewhat disappointed". | **Later.** Most early ventures won't have 40 users. Below n, ask Q1 in interviews but never report it as a percentage (Ethos 8). |
| A14 | YC Demo Day | **Batch showcase** at the end of each batch: progress against plan, primary metric, biggest lowlight, top ask. No money asks and no valuation talk. | **Later** (after Batch 002 has operating data). ⚠ |
| A15 | gstack `/captain` | One controller over many venture agents: lanes, a digest and fixed-shape approvals. | **Later** (multi-venture scale) |

### 4.2 Parameters (b)

Proposed new group: `operating`. Defaults are for the pilot's tiny ventures, not for venture-scale companies.

| Param | Default | Reason (source) | Verdict |
|---|---|---|---|
| `PRIMARY_METRIC_MAX` | `1` | One number per venture, fixed at formation, changed only via A4 (Ralston; gstack "explain the number"). | **Now** |
| `GROWTH_TARGET_WEEKLY_PCT` | `5` | Graham: 5–7%/week is good during YC. Use the low end because the bases are tiny. | **Now** |
| `GROWTH_FLOOR_WEEKLY_PCT` | `1` | Graham: 1% "is a sign you haven't yet figured out what you're doing." | **Now** |
| `GROWTH_MIN_BASE` | `10` | Weekly % is reported only once the metric base is ≥10 (customers, or $ of weekly revenue). Below that, absolute counts only (Ethos 8). | **Now** |
| `FLAT_WEEKS_TO_REVIEW` | `4` | Four consecutive weeks below the floor trigger an A6 pivot-or-persevere review early (Ries). | **Now** |
| `FLAT_REVIEWS_TO_KILL_PROPOSAL` | `2` | Two consecutive "persevere" reviews with no change send a kill proposal to the steward. Existing `killRules` still apply. | **Now** |
| `DEFAULT_ALIVE_CHECK` | `"weekly"` | Graham and Blackwell: with constant costs and the last 8 weeks' revenue growth, does the venture reach break-even before cash hits zero? Shown in A1. | **Now** |
| `DEFAULT_DEAD_GRACE_WEEKS` | `2` | Two consecutive default-dead readings require a written Plan B and the date to switch to it (Graham: "write down … precisely when"). | **Now** |
| `FIRST_OFFER_DAYS` | `14` | From `formed` to the first public offer a customer can pay for (YC "launch now"; gstack Q4 "this week"). | **Now** |
| `UNSCALABLE_FIRST_N` | `10` | The first 10 customers are onboarded by hand (Graham, *ds*; YC "10–100 who love you"). | **Now** |
| `USER_CONVERSATIONS_PER_WEEK` | `5` | Minimum logged real conversations per operating week (YC; Mom Test). | **Now** |
| `UPDATE_CADENCE_DAYS` | `7` | Weekly during a batch and early operation. Harris says monthly for companies; batches move faster (Graham measures weekly). | **Now** |
| `UPDATE_MAX_ASKS` | `3` | YC template: 1–3 requests. More asks dilute members' attention and break `DAILY_PUSH_CAP_DEFAULT`. | **Now** |
| `STEWARD_REVIEW_DAYS` | `30` | Monthly A6 review (board-cadence analogue). | **Now** |
| `PREMISE_FAILURES_BEFORE_TEST` | `2` | gstack Ethos 5. | **Now** |
| `ACQUISITION_SPEND_REQUIRES` | `{ stage: "customer1", contributionMarginPositive: true, paybackMonthsMax: 3 }` | No paid growth before a paying customer and a positive margin (Buchheit's "80 cents"; Seibel; Skok's payback < 12 months, tightened for tiny budgets). | **Now** |
| `ROSTER_COVERAGE_MIN` | `0.6` | Network-market fit: the share of the venture's liftoff-roster roles with at least one qualified member before it can be pitched (Friedman's founder-market fit, translated). Misses become recruiting gaps (`QUORUM_GAP_DAYS` logic). | **Now**. This is new and specific to agent ventures; tune it from data. |
| `PMF_VERY_DISAPPOINTED_TARGET` / `PMF_MIN_RESPONSES` | `0.40` / `40` | Ellis; Vohra. | **Later** |
| `SEAT_MONEY_RELEASE_STAGES` | e.g. `[{ at: "formed", pct: 50 }, { at: "first-offer", pct: 25 }, { at: "customer1", pct: 25 }]` | Staged release (Sahlman) as **internal budget unlocks** that the steward holds. It keeps the option to stop cheaply. | **Later.** ⚠ See §5: frame it as a spending discipline, not a protection of anyone's capital. |
| `TARPIT_PATTERNS` | learned list, seeded empty | Grows from post-mortems and the A11 search. | **Now** (empty seed) |

### 4.3 Pitch and memo fields (c)

The existing `thesis` already has `whyThis`, `whyNow`, `whyUs`, `whyAgent`, `pathToFirstCustomer`, `killSignal`, plus `killRules`, `killDate` and `budget`. Proposed additions:

| Field | From | Rule | Verdict |
|---|---|---|---|
| `demandEvidence` | gstack Q1; Mom Test | Commitments only (paid, pre-ordered, built a workflow around it, asked when it ships). **Seat sales and member enthusiasm do not count**; those buyers are members, not customers. | **Now** |
| `statusQuo` | gstack Q2; Sequoia "Problem" | The current workaround and what it costs, in hours or $. | **Now** |
| `namedBuyer` | gstack Q3 | A role, a company type, the consequence they face, and ideally a real member or prospect who said it. A category-only answer fails a lint check. Use a pseudonymous archetype where privacy requires. | **Now** |
| `jobStory` | JTBD | "When ___, I want to ___, so I can ___." | **Now** (one line) |
| `wedge` | gstack Q4; Buchheit 90/10 | The smallest offer someone pays for within `FIRST_OFFER_DAYS`. | **Now** (it can absorb `pathToFirstCustomer`) |
| `theSchlep` | Graham *Schlep Blindness* | The tedious part that keeps others out, and why an agent tolerates it. | **Now** |
| `priorAttempts` | Tarpit; gstack Ethos 2 | Who tried it, why they stopped, what changed. This feeds `whyNow`. | **Now** |
| `alternatives` + `insight` | YC app ("What do you understand … that they don't?"); Sequoia "Competition" | Real alternatives including "do nothing" and spreadsheets. "No competitors" fails a lint check. | **Now** |
| `moneyModel` | YC app ("How much could you make?") | Price × reachable customer count, not a TAM slide. | **Now** |
| `unitEconomics` | Altman; Skok | Price, cost to serve, expected acquisition cost, payback. Rough numbers are fine but must be present. | **Now** |
| `primaryMetric` + `growthTarget` | Graham | Copied into params at formation. | **Now** |
| `premortem` | Klein | The top 3 ways this dies, each tagged with a killReason value. | **Now** |
| `killRules` as state + date | Duke | Already present; add a lint check that each rule has a measurable state and a date. | **Now** (validation only) |
| `planB` | Graham *aord* | What the venture does if seat money runs short or growth stalls. | **Later**; it is only needed when default dead (§4.2). |
| `futureFit` | gstack Q6 | In 3 years, is this more essential or less, and why? | **Later**; it matters less for small, time-boxed ventures. |

**Deck order:** follow Sequoia's flow, with renames. *Purpose · Problem (statusQuo, namedBuyer, jobStory) · Solution (wedge) · Why now (priorAttempts) · Market and money (moneyModel) · Alternatives (insight) · How it runs (agent plus liftoff roster) · Numbers (unitEconomics, seat-sizing derivation) · Kill rules and pre-mortem · Vision.* **Drop Sequoia's "The deal" slide.**

**Seat-sizing derivation:** state it as *"the minimum covers the budget to run the wedge to the kill date"*: `minSeats = ceil(sum(budget to killDate) / SEAT_PRICE_USD)`. This ties sizing to the default-alive logic rather than to any valuation.

**Member Q&A:** seed it from the forcing questions the agent answered least confidently in A2.

### 4.4 Learning-loop tags and lesson topics (d)

Proposed additions to Lesson `kind`. Today it has `request-pricing | responses-needed | kill-signal | member-type-by-stage | recruiting-channel | idea-generation`.

| New `kind` | What it learns | Verdict |
|---|---|---|
| `premortem-calibration` | Did the pre-mortem name the actual killReason? This is the hit rate by phenotype. | **Now** |
| `wedge-size` | Days from formed to first offer and to customer1, against the wedge's scope. | **Now** |
| `unscalable-tactic` | Which manual tactics converted or retained the first 10 customers. | **Now** |
| `growth-pattern` | Week-over-week curves by phenotype, channel and buyer. | **Now** |
| `demand-evidence` | Which kinds of pitch evidence predicted customer1, and which didn't. | **Now** |
| `tarpit` | Patterns that keep failing; feeds `TARPIT_PATTERNS`. | **Now** |
| `ask-yield` | Which update asks turned into fulfilled RFEs, and how fast. | **Now** |
| `pmf-score` | Ellis scores over time. | **Later** |

**Extend the `TAG_VOCAB.killReason` values** to the CB Insights categories. Today they are `no demand, could not reach buyer, price, execution, legal, ran out of time`. Add **`flawed business model`, `outcompeted`, `mistimed`, `poor product`, `ran out of money`**. Note the 2024 CB Insights reframing: running out of money is usually a symptom, so record a root cause next to it. **Now.**

### 4.5 Constitution-level (e): keep this to one item, or none

| Candidate | Verdict | Reason |
|---|---|---|
| **"Seat money is spent only on the venture's published plan."** (YC: "It's not your money.") Best placed as one sentence added to Article 2. | **Adopt now (one clause)** | It protects members, it is consistent with "access, not investment," and it is the one operating idea that belongs above vote-amendable parameters. |
| "Make something people want." | **Skip** as an article | It is an operating principle. Put it first in the Founding DNA (§6), which the agent follows and which members can amend like parameters. |
| "Kill rules are set at pitch time and change only by a logged steward decision." | **Skip** as an article | Article 3 (logging) plus A4 already covers it. |
| "The agent follows the Founding DNA." | **Optional** | If you want it binding, add "…and runs it by the Founding DNA" to Article 1, and keep the DNA itself as a parameter-like list. |

### 4.6 Items to skip

| Primitive | Verdict | Reason |
|---|---|---|
| **Pro-rata rights** | **Skip** ⚠ | It is a right to put in more money on the same terms in a later round, so it is investment by definition. `EARLY_ACCESS_HOURS` is already the only priority, and it is tied to qualification, not to seats held. |
| **Information rights** | **Skip** ⚠ | Everyone already sees everything (Article 3). A privileged financial feed for seat holders would make them look like owners of a security. |
| **Cliffs on anything a seat buys** | **Skip** ⚠ | A seat buys access immediately. Cliffs belong only to earned work units. |
| **Cliff on earned units** | **Later** | `VESTING_DAYS = 14`, defined as "stood without being proven wrong," is already a better fit for RFE grants. A cliff might suit ongoing roles such as the steward slice. |
| **Burn multiple, LTV/CAC ≥ 3** | **Later** | These are ARR-scale ratios and meaningless at $100s. Payback and contribution margin (§4.2) carry the idea for now. |
| **Rachleff's sales-yield metric** | **Skip** | It only applies to enterprise sales teams. |
| **"Boil the ocean" as a scope principle** | **Skip** | It conflicts with the wedge. Keep it only for execution quality. |
| **"Ignore competitors"** | Note only | Already implied by spending little time on competitors. |

---

## 5. Securities and vocabulary flags

This is not legal advice. It is for the existing `rfe-v0-legal-structure` and the counsel note in `REGULATED_ACTIVITIES`.

The US test is *SEC v. W.J. Howey Co.*, 328 U.S. 293 (1946): an investment of money, in a common enterprise, with an expectation of profits, from the efforts of others. The SEC applied it to new instruments in its 2019 ["Framework for 'Investment Contract' Analysis of Digital Assets"](https://www.sec.gov/corpfin/framework-investment-contract-analysis-digital-assets). A seat already meets the first two prongs (money, pooled for one venture) and the fourth (the agent's efforts). **Everything therefore depends on there being no expectation of profit from the seat.** Borrowed primitives must never create one.

1. ⚠ **Already in the design: the seat-holder pool slice.** `POOL_SEATS_UNITS = 10` is "split among seat holders who qualify." Buying a seat is a precondition for profit units, so money in is linked to profit out, even though qualification requires work. **Recommendation:** open the slice to any qualified member who does the work, whether or not they hold a seat, or fold it into the request reserve. Raise this with counsel before Batch 002 seats sell.
2. ⚠ **Already in copy.** The current CONSTITUTION.md says "Members … get paid in a share of their profits," "profits interests," "its holders vote," "Owners decide," and the params say ungranted reserve "accrues pro rata to holders at sunset." The work-for-units structure may be fine (Article 1), but the wording is investment-like and breaks the product-copy rule. **Recommendation:** have counsel choose the term for earned units, then use plain operating words in copy, for example "contributors", "earned units", "payouts for work", "contributor vote".
3. ⚠ **Member update (A1).** Address it to all members and contributors, never to "seat holders". Don't frame metrics as the value or performance of a seat. No "runway of your money", "valuation", "round" or "raise". Call asks "requests".
4. ⚠ **Batch showcase (A14).** YC's Demo Day is a fundraising event. Keep the showcase to progress, lessons and asks for help. No money asks, no "oversubscribed", no seat-price scarcity framing.
5. ⚠ **Staged seat-money release (§4.2).** Frame it as a steward-held spending discipline ("budget unlocks at milestones"). Don't promise refunds of unreleased money on a later kill without counsel review, because that starts to look like a capital account. Article 2's all-or-nothing refund below the minimum (Kickstarter-like) is the clean model.
6. ⚠ **Growth targets and default-alive status.** Publish them as operating facts, since they go on the log anyway. Never put them in marketing for seats ("join a venture growing 5%/week").
7. **Vocabulary map for borrowed ideas:**

| Instead of | Use |
|---|---|
| investor update | member update / weekly update |
| board meeting | steward review |
| tranche | budget unlock |
| Demo Day | batch showcase |
| office hours | office hours (it is fine) |
| pro-rata | — (skip) |
| portfolio | batch / ventures |
| due diligence | pitch review |
| raise | seat minimum |

---

## 6. Proposed Founding DNA (10 principles the operating agent follows)

Plain-language principles for the agent. Each one lists its source, how it is enforced, and the signal to watch. They sit beside the parameters and are amendable by vote, like the parameters. Only the "not your money" clause goes in the constitution.

| # | Principle | Source | How it's enforced | Measurable signal |
|---|---|---|---|---|
| 1 | **Make something people want, and prove it with what they do and pay, not what they say.** Seat sales and member praise are not demand. | YC motto; gstack Q1 "interest is not demand"; Mom Test | Pitch field `demandEvidence` (commitments only); A2 self-interrogation; lint rejects waitlists or praise as evidence | Share of pitched ventures reaching customer1 by the kill date; days to customer1 |
| 2 | **Name the customer and what they do today.** A role and a consequence, not a category; the workaround and its cost. | gstack Q2–Q3; JTBD; Sequoia "Problem" | Pitch fields `namedBuyer`, `statusQuo`, `jobStory`; lint check | Share of pitches passing the specificity lint; pitch-to-customer1 conversion by buyer tag |
| 3 | **Ship the narrowest thing someone will pay for, fast.** | YC "launch now", 90/10; gstack Q4 and CEO-review *Reduction* | `FIRST_OFFER_DAYS = 14`; scope mode *Reduction* until customer1; `wedge` field | Days from formed to first offer; days to customer1 |
| 4 | **Do things that don't scale.** The agent and members hand-hold the first customers. | Graham, *Do Things That Don't Scale*; schlep blindness | `UNSCALABLE_FIRST_N = 10`; "action" RFEs; A9 mystery-shop | Retention of the first 10 customers; `unscalable-tactic` lessons written |
| 5 | **Talk to users every week, and ask about their past, not your idea.** | YC "talk to users"; Mom Test; gstack Q5 "watch, don't demo" | A3 loop; `USER_CONVERSATIONS_PER_WEEK = 5`; one logged surprise per conversation | Conversations per week; surprises logged; commitments per 10 conversations |
| 6 | **One number, weekly, honestly explained.** | Graham, *Startup = Growth*; Ralston; gstack "Explain the Number" | `PRIMARY_METRIC_MAX = 1`; `GROWTH_TARGET_WEEKLY_PCT = 5`, floor 1, `GROWTH_MIN_BASE = 10`; n and method shown on every number | Week-over-week growth; weeks below the floor |
| 7 | **Stay default alive. It's not your money.** No paid growth that loses money per customer. | Graham and Blackwell; YC "It's not your money"; Buchheit and Altman on unit economics | Weekly `DEFAULT_ALIVE_CHECK`; Plan B after `DEFAULT_DEAD_GRACE_WEEKS`; `ACQUISITION_SPEND_REQUIRES`; the Article 2 clause | Default-alive status; contribution margin; payback months |
| 8 | **Report weekly with lowlights and at most three asks, and turn every ask into a request.** | YC update template; Harris; gstack `/retro` | A1 loop; `UPDATE_CADENCE_DAYS = 7`; `UPDATE_MAX_ASKS = 3`; lowlights required | Updates on time; ask→RFE fulfilment rate and time (`ask-yield` lessons) |
| 9 | **Decide how you'll die before you start, and never move the line quietly.** | Klein pre-mortem; Duke kill criteria; Ries pivot-or-persevere; gstack gate integrity | `premortem` and state+date `killRules` at pitch; A4 no quiet changes; A6 monthly review; `FLAT_WEEKS_TO_REVIEW = 4` | Share of kills that fired on a pre-set rule vs ad hoc; pre-mortem hit rate |
| 10 | **Search first, test the premise, and use what earlier ventures learned.** | gstack "Search Before Building", "Attack the Premise", `/learn`; tarpit ideas | A11 prior-attempt search; A7 after 2 shared-premise failures; A8 every decision cites lessons | Share of decisions citing a lesson; repeated-failure count; tarpit matches caught before pitch |

**Order of adoption:**
1. Pitch fields (§4.3) plus A2, since they shape Batch 002.
2. A1 weekly update with asks turning into RFEs, plus the §4.2 operating parameters.
3. A4, A6, A7, A8 and the new lesson kinds.
4. Later: the PMF survey (A13), batch showcase (A14), budget unlocks, and the multi-venture controller.

---

## Sources

- gstack: [README](https://github.com/garrytan/gstack) · [skills deep dives](https://github.com/garrytan/gstack/blob/main/docs/skills.md) · [Builder Ethos](https://github.com/garrytan/gstack/blob/main/ETHOS.md) · [Office Hours startup diagnostic](https://github.com/garrytan/gstack/blob/main/office-hours/sections/phase-2a-startup-diagnostic.md)
- YC: [Essential startup advice](https://www.ycombinator.com/library/4D-yc-s-essential-startup-advice) · [Requests for Startups (W2027)](https://www.ycombinator.com/rfs) · Jared Friedman, [How to Get and Evaluate Startup Ideas](https://www.youtube.com/watch?v=Th8JoIan4dg) · Caldwell and Seibel, [Avoid These Tempting Startup Ideas](https://pickscribe.com/v/GMIawSAygO4), [Tarpit Ideas: The Sequel](https://www.youtube.com/watch?v=GU9iT7MW0rs) · Application questions ([summary](https://www.roundfunded.com/en/blogs/how-to-apply-to-y-combinator-2026))
- Paul Graham: [Startup = Growth](https://paulgraham.com/growth.html) · [Default Alive or Default Dead?](https://paulgraham.com/aord.html) · [Do Things That Don't Scale](https://paulgraham.com/ds.html) · [Schlep Blindness](https://paulgraham.com/schlep.html) · [How to Get Startup Ideas](https://paulgraham.com/startupideas.html)
- Sequoia, [Writing a Business Plan](https://sequoiacap.com/article/writing-a-business-plan) · Andreessen/Rachleff, [The only thing that matters](https://web.archive.org/web/20070701074943/blog.pmarca.com/2007/06/the-pmarca-gu-2.html)
- Vohra, [How Superhuman Built an Engine to Find PMF](https://review.firstround.com/how-superhuman-built-an-engine-to-find-product-market-fit/) · Sacks and Rachleff via [Lenny's Newsletter](https://www.lennysnewsletter.com/p/how-to-know-if-youve-got-productmarket) · Skok, [SaaS Metrics 2.0](https://www.forentrepreneurs.com/saas-metrics-2/)
- Ries, *The Lean Startup* (2011) · Fitzpatrick, *The Mom Test* (2013) · Christensen et al., *Competing Against Luck* (2016) · Duke, *Quit* (2022) · Klein, [Performing a Project Premortem](https://hbr.org/2007/09/performing-a-project-premortem) (HBR 2007) · Saffo, "Strong Opinions Weakly Held" (2008) · Sahlman (1990), Gompers (1995) on staged financing
- Updates: [Visible, YC template](https://visible.vc/blog/investor-updates-faq/) · Aaron Harris, [Investor Updates](https://blog.aaronkharris.com/investor-updates)
- CB Insights, [Top 12 Reasons Startups Fail](https://www.cbinsights.com/reports/CB-Insights_Top-Reasons-Startups-Fail.pdf) (2021) and the 2024 reframing ([fact-check](https://fasterthannormal.co/research/startup-statistics-fact-check))
- *SEC v. W.J. Howey Co.*, 328 U.S. 293 (1946) · SEC, [Framework for "Investment Contract" Analysis of Digital Assets](https://www.sec.gov/corpfin/framework-investment-contract-analysis-digital-assets) (2019)
