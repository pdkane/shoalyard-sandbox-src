import { z } from "zod";
import { Iso, Objective, RFE_TYPES } from "./primitives";
import { DECISION_BINS } from "./states";

/** One decision as the requesting viewer may see it (Article 3). Fields above their tier are left out. */
export const ReportDecision = z.object({
  id: z.string(),
  at: Iso,
  bin: z.enum(DECISION_BINS),
  status: z.string(),
  redacted: z.boolean(),
  private: z.object({ until: Iso, reason: z.string() }).optional(),
  title: z.string().optional(),
  decidedBy: z.string(),
  outcome: z.string().optional(),
  spendUsd: z.number().optional(),
  summary: z.string().optional(),
  reasoning: z.string().optional(),
  confidence: z.number().optional(),
  lessonIds: z.array(z.string()).optional(),
  answers: z.array(z.object({ handle: z.string(), at: Iso, answer: z.string() })).optional(),
});

/** Fixed, machine-readable quarterly report. Generated from the ledger, never stored. */
export const Report = z.object({
  schema: z.literal("agent-ventures/report@1"),
  venture: z.object({ slug: z.string(), name: z.string(), status: z.string(), protocolVersion: z.string() }),
  quarter: z.string(),
  generatedAt: Iso,
  attestation: z.object({
    reconciledToLedger: z.boolean(),
    statement: z.string(),
  }),
  financials: z.object({
    revenueUsd: z.number(),
    costsUsd: z.number(),
    passThroughUsd: z.number(),
    profitUsd: z.number(),
    distributedUsd: z.number(),
  }),
  capTable: z.object({
    protocolPct: z.number(),
    contributorPct: z.number(),
    holderCount: z.number(),
    grantedUnits: z.number(),
    treasuryUnits: z.number(),
    topHolderPctOfPool: z.number(),
  }),
  rfeFillRates: z.array(
    z.object({ type: z.enum(RFE_TYPES), posted: z.number(), resolved: z.number(), medianResponses: z.number() }),
  ),
  customers: z.object({ count: z.number(), segment: z.string(), retention: z.string().optional() }),
  runwayUsd: z.number(),
  objective: z.object({ objective: Objective, status: z.string() }),
  reservedMatterChanges: z.array(z.object({ at: Iso, matter: z.string(), result: z.string() })),
  decisions: z.object({ auto: z.number(), advisory: z.number(), gated: z.number(), embargoed: z.number() }),
  decisionLog: z
    .object({
      viewerTier: z.enum(["public", "verified", "unit holder", "steward"]),
      entries: z.array(ReportDecision),
    })
    .optional(),
});
export type Report = z.infer<typeof Report>;
