import {
  MEMBER_ATTRIBUTES,
  type Member,
  type MemberAttribute,
  type ParamValues,
  type Store,
  type Verification,
  type VerifySource,
} from "@av/schema";
import { resolveParams } from "./params";
import { newId } from "./util";

/** Which attributes each linked account can vouch for. The steward can vouch for any one. */
export const SOURCE_ATTRIBUTES: Record<Exclude<VerifySource, "steward">, MemberAttribute[]> = {
  linkedin: ["role", "company", "seniority", "industry"],
  x: ["handle", "reach"],
};

export const SOURCE_LABELS: Record<VerifySource, string> = {
  linkedin: "LinkedIn",
  x: "X",
  steward: "Steward review",
};

export const ATTRIBUTE_LABELS: Record<MemberAttribute, string> = {
  role: "Role",
  company: "Company",
  seniority: "Seniority",
  industry: "Industry",
  handle: "Handle",
  reach: "Reach",
};

/**
 * A way to link an outside account. The pilot ships mock providers that record
 * the link as pending until a steward confirms it; real OAuth replaces `link`.
 * LinkedIn's standard sign-in returns only name, email and photo, so employer
 * and title still need the Verified on LinkedIn partner program or steward review.
 */
export interface VerificationProvider {
  source: Exclude<VerifySource, "steward">;
  label: string;
  /** What the member types in: a profile URL or a handle. */
  prompt: string;
  normalise(input: string): string;
  link(store: Store, member: Member, ref: string): Verification;
}

function mockProvider(source: "linkedin" | "x", label: string, prompt: string, normalise: (s: string) => string): VerificationProvider {
  return {
    source,
    label,
    prompt,
    normalise,
    link(store, member, input) {
      const ref = normalise(input);
      const existing = member.verifications.find((v) => v.source === source && v.status === "pending");
      if (existing) {
        existing.ref = ref;
        existing.status = "pending";
        existing.requestedAt = store.meta.clock;
        return existing;
      }
      const v: Verification = {
        id: newId(store, "ver"),
        source,
        ref,
        attributes: SOURCE_ATTRIBUTES[source],
        status: "pending",
        requestedAt: store.meta.clock,
      };
      member.verifications.push(v);
      return v;
    },
  };
}

export class VerificationError extends Error {}

export const PROVIDERS: Record<"linkedin" | "x", VerificationProvider> = {
  linkedin: mockProvider("linkedin", "LinkedIn", "Your LinkedIn profile URL", (s) => {
    const t = s.trim().replace(/^(https?:\/\/)?/i, "https://");
    if (!/^https:\/\/([a-z]+\.)?linkedin\.com\/in\/[A-Za-z0-9_-]+\/?$/i.test(t)) {
      throw new VerificationError("Use a linkedin.com/in/ profile URL.");
    }
    return t.replace(/\/$/, "");
  }),
  x: mockProvider("x", "X", "Your X handle", (s) => {
    const t = s.trim().replace(/^@/, "").replace(/^https?:\/\/(www\.)?(x|twitter)\.com\//i, "");
    if (!/^[A-Za-z0-9_]{1,15}$/.test(t)) throw new VerificationError("X handles are up to 15 letters, numbers or underscores.");
    return `@${t}`;
  }),
};

export interface AttributeStatus {
  attribute: MemberAttribute;
  status: "verified" | "self-reported";
  sources: VerifySource[];
  score: number;
}

export function attributeStatuses(member: Member, params: ParamValues): AttributeStatus[] {
  const weights = params.VERIFICATION_WEIGHTS as Record<VerifySource, number>;
  return MEMBER_ATTRIBUTES.map((attribute) => {
    const sources = member.verifications
      .filter((v) => v.status === "confirmed" && v.attributes.includes(attribute))
      .map((v) => v.source);
    const score = Math.min(1, sources.reduce((s, src) => s + (weights[src] ?? 0), 0));
    return { attribute, status: sources.length ? "verified" : "self-reported", sources, score };
  });
}

/** Average verified weight across the six attributes, 0..1. */
export function verificationScore(member: Member, params: ParamValues): number {
  const rows = attributeStatuses(member, params);
  return rows.reduce((s, r) => s + r.score, 0) / rows.length;
}

/** Share of attributes verified by at least one source; this is the public bar. */
export function verifiedShare(member: Member, params: ParamValues): number {
  const rows = attributeStatuses(member, params);
  return rows.filter((r) => r.status === "verified").length / rows.length;
}

export function badgesFor(member: Member): VerifySource[] {
  return [...new Set(member.verifications.filter((v) => v.status === "confirmed").map((v) => v.source))];
}

export function isQualified(member: Pick<Member, "qualification"> | undefined): boolean {
  return member?.qualification === "qualified";
}

export function pendingVerifications(store: Store): { member: Member; verification: Verification }[] {
  return store.members.flatMap((member) =>
    member.verifications.filter((v) => v.status === "pending").map((verification) => ({ member, verification })),
  );
}

export function meetsQualification(member: Member, params = resolveParams({ amendments: [] })): boolean {
  return !!member.onboardedAt && verificationScore(member, params) + 1e-9 >= params.QUALIFY_MIN_SCORE;
}
