# Shoalyard opco seed — one-pager term sheet (draft for counsel)

**NOT LEGAL ADVICE. PLACEHOLDER. REPLACE WITH COUNSEL. NOT AN EXECUTED DOCUMENT.**

Derived from [`../economics-safe-seed.md`](../economics-safe-seed.md). Numbers are design intent, not negotiated terms.

---

## Parties / boxes

| Box | Intent |
| --- | --- |
| **Holdco** | Shoalyard operator: rails, brand, specialized platform agents. Control reserved for founder (~50.1% discussed). Holdco capital ≠ opco seed. |
| **Opco** | Each venture / attempt: own economic box. Entity form **counsel TBD**. |
| **Seeders** | Accredited persons only on the security path. |
| **Answerers** | Labor: cash from proof budget. **No equity by answering.** |
| **Steward** | Named human kill-switch / go-no-go judgment. |

---

## Opco seed (security path)

| Term | Placeholder |
| --- | --- |
| Who | Accredited only |
| Mechanics | Fill-or-kill escrow |
| On minimum met | Issue **SAFE** — **post-money valuation-cap style default** (YC form as starting point; see `yc-safe-placeholders/`) |
| Cap / discount / MFN / pro rata | **TBD** |
| On miss | Full refund; **no SAFE** issued |
| Riders | Wind-down, hand-off, unused capital — **required** (checklist sibling doc) |
| Public solicitation | Open: **506(c)** vs **506(b)** — see sibling decision note |
| Attestation | No public “seed for equity” without attestation |

Seed risk = venture risk. Rejection of an answer is a work outcome, not forfeiture of seed.

---

## Answers (labor — not the security)

| Term | Placeholder |
| --- | --- |
| Pay | Cash from proof budget |
| Treatment | Equal cash for similar accepted work |
| Equity | Answerers do **not** purchase equity by answering |
| Timing | Late accepted work still paid |

---

## Published waterfall (intent)

1. Gross revenue  
2. − Token / model costs (and defined pass-throughs)  
3. − Answer cash  
4. − Platform vig ~**5%** (rails / cost recovery to operator)  
5. → Remainder subject to equity / SAFE economics  

Operator also ~**20%** equity or upside alignment instrument (**counsel TBD**). Vig = rails; equity/% = upside. Exact bases and stacking: params + counsel.

---

## Explicitly out of scope for this one-pager

- Live payments, filled SAFEs, or public CTAs  
- Constitution / product rewrite  
- Non-accredited consumer “seat as equity” revival  

Pilot UI may still show legacy seat / share-per-answer demo copy — treat as **pilot/legacy**, not this term sheet.
