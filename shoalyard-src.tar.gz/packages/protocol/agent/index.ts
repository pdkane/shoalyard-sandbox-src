import type { Member, ParamValues, Rfe, Store, Venture } from "@av/schema";
import { runBackOffice } from "../src/services";
import { advanceBatches, announceBatch, batchLabel, earlyAccessAt } from "../src/batches";
import type { DeckDraft } from "../src/deck";
import type { IdeaTemplate } from "../src/ideas";
import { allocateBatchSlots, segmentKey, segmentLabel } from "../src/learning";
import { draftGapRecruiting } from "../src/network";
import { candidateIdeas } from "../src/spawn";
import { classificationLine, classificationOf } from "../src/tags";
import {
  buySeat,
  closeGovernance,
  conductTextFor,
  hasSeat,
  isLive,
  isOpen,
  logDecision,
  respond,
  seatsSold,
  ventureBySlug,
  vestDue,
} from "../src/ops";
import { seatsNeeded } from "../src/n-engine";
import { seatPriceOf } from "../src/sizing";
import { resolveParams } from "../src/params";
import { SOURCE_ATTRIBUTES } from "../src/verification";
import { addHours, rand } from "../src/util";
import { mutateStore } from "../src/store";
import { DECK_DRAFTS } from "../src/deck-content";
import { answerOpenQuestions, type AnswerDraft } from "../src/qa";
import { applyResolvedRequests, publishUpdate, reviewDue, runReview, scriptedUpdate, updateDue } from "../src/operating";
import {
  answerWithClaude,
  claudeEnabled,
  conductReviewWithClaude,
  deckWithClaude,
  ideaWithClaude,
  planWithClaude,
  proposeTagsWithClaude,
  writeLessonsWithClaude,
} from "./claude";
import { SCRIPT } from "./script";
import type { Step } from "./step";

export { SCRIPT } from "./script";
export { Step } from "./step";
export { answerWithClaude, claudeEnabled, deckWithClaude, extractAnswer, clusterWithClaude, planWithClaude } from "./claude";

const useClaudeFor = (mode: TickMode) => mode === "claude" || (mode === "auto" && claudeEnabled());

export type TickMode = "auto" | "script" | "claude";

export interface TickOptions {
  /** Only run the operator and member simulation for this venture slug. */
  venture?: string;
  mode?: TickMode;
}

export interface TickLog {
  at: string;
  venture: string;
  kind: "clock" | "vest" | "vote" | "seat" | "answer" | "resolve" | "decision" | "idle" | "fallback" | "batch" | "gap" | "lesson" | "spawn" | "qa" | "update" | "review" | "services";
  text: string;
}

/** Pseudonymous arrivals the simulator brings in from posted recruiting drafts. */
const ARRIVALS: Pick<Member, "handle" | "role" | "industry" | "seniority" | "cluster">[] = [
  { handle: "estimator_eli", role: "Senior estimator", industry: "Commercial roofing", seniority: "senior", cluster: "construction-sales" },
  { handle: "sunbelt_sam", role: "Branch manager", industry: "HVAC contracting", seniority: "senior", cluster: "construction-sales" },
  { handle: "plans_priya", role: "Preconstruction lead", industry: "General contracting", seniority: "mid", cluster: "preconstruction" },
  { handle: "county_cole", role: "Records clerk", industry: "County government", seniority: "mid", cluster: "public-records" },
  { handle: "leadgen_lou", role: "Agency owner", industry: "Contractor marketing", seniority: "executive", cluster: "contractor-marketing" },
  { handle: "tpo_tess", role: "Sales rep", industry: "Commercial roofing", seniority: "early", cluster: "construction-sales" },
  { handle: "chiller_chen", role: "Service sales", industry: "Mechanical contracting", seniority: "mid", cluster: "mechanical" },
  { handle: "proptech_paz", role: "Founder", industry: "Proptech", seniority: "executive", cluster: "data-eng" },
  { handle: "audit_ana", role: "Freight auditor", industry: "Freight audit", seniority: "mid", cluster: "freight-audit" },
  { handle: "rulesnerd", role: "Policy analyst", industry: "Cooperatives", seniority: "mid", cluster: "governance" },
  { handle: "bylaws_ben", role: "Startup lawyer", industry: "Law", seniority: "senior", cluster: "legal-counsel" },
  { handle: "zoning_zoe", role: "Permit expediter", industry: "Construction services", seniority: "mid", cluster: "permits" },
  { handle: "ductwork_dev", role: "Estimator", industry: "HVAC contracting", seniority: "mid", cluster: "mechanical" },
  { handle: "gc_gabe", role: "Project executive", industry: "General contracting", seniority: "executive", cluster: "preconstruction" },
];

const TEXT_ANSWERS: Record<Rfe["type"], string[]> = {
  knowledge: [
    "From what I've seen this is mostly right: {rec}. One caveat: it varies a lot by company size.",
    "Agree with {rec}. I checked against last quarter's numbers at my company.",
    "Partly. {rec} holds for the bigger players; smaller ones do it by hand.",
  ],
  judgment: ["Agree: {rec}.", "I'd go with {rec}, but measure it after a month."],
  access: ["Made the intro by email; they're expecting the agent's note this week.", "Introduced you to someone who owns this budget. Warm, not cold."],
  credibility: ["Happy to be named to this buyer. Did the call; they asked about data retention."],
  action: ["Done. Scan uploaded.", "Done; took twenty minutes."],
  capital: [""],
  stewardship: ["Accepted."],
};

function pick<T>(xs: T[], seed: string): T {
  return xs[Math.floor(rand(seed) * xs.length) % xs.length];
}

function simulatedAnswer(rfe: Rfe, handle: string, seed: string) {
  const r = rand(`${seed}:lean`);
  if (rfe.kind === "governance") {
    return { choice: r < 0.68 ? rfe.options![0] : rfe.options![1] };
  }
  if (rfe.format === "choice" && rfe.options?.length) {
    const recommended = rfe.options.find((o) => o === rfe.recommendation) ?? rfe.options[0];
    const others = rfe.options.filter((o) => o !== recommended);
    return { choice: r < 0.7 || !others.length ? recommended : pick(others, `${seed}:other`) };
  }
  if (rfe.format === "scale") return { scale: 3 + Math.floor(r * 3) };
  const text = pick(TEXT_ANSWERS[rfe.type], `${seed}:${handle}`).replace("{rec}", rfe.recommendation.toLowerCase());
  return { text };
}

function eligibleSimulated(store: Store, venture: Venture, rfe: Rfe): Member[] {
  const answered = new Set(store.responses.filter((r) => r.rfeId === rfe.id).map((r) => r.handle));
  return store.members.filter(
    (m) => m.simulated && m.qualification === "qualified" && !answered.has(m.handle) && (venture.isProtocol || hasSeat(store, venture.id, m.handle)),
  );
}

function simulateMembers(store: Store, venture: Venture, log: (k: TickLog["kind"], t: string) => void) {
  const t = store.meta.tick;
  for (const rfe of store.rfes.filter((r) => r.ventureId === venture.id && isOpen(r))) {
    if (rfe.type === "capital" || rfe.gtm || rfe.assignedTo) continue;
    const go = rand(`${rfe.id}:${t}:go`);
    const count = go < 0.12 ? 2 : go < (rfe.kind === "governance" ? 0.6 : 0.4) ? 1 : 0;
    const chosen = eligibleSimulated(store, venture, rfe)
      .map((m) => ({ m, r: rand(`${rfe.id}:${t}:${m.handle}`) }))
      .sort((a, b) => a.r - b.r)
      .slice(0, count);
    for (const { m } of chosen) {
      if (!isOpen(rfe)) break;
      const ans = simulatedAnswer(rfe, m.handle, `${rfe.id}:${t}:${m.handle}`);
      const res = respond(store, { rfeId: rfe.id, handle: m.handle, via: ans.text ? "text" : "structured", ...ans });
      if (rfe.kind === "governance") {
        log("vote", `@${m.handle} voted “${ans.choice}” on ${rfe.title} (weight ${res.response.weight ?? 0} units)`);
      } else {
        const n = res.n;
        log("answer", `@${m.handle} answered “${rfe.title}”${n ? ` — ${n.effective}/${n.target} distinct, ${Math.round(n.agreement * 100)}% agree` : ""}`);
        if (res.resolved) log("resolve", `Resolved “${rfe.title}”: ${rfe.resolution}`);
      }
    }
  }
}

function simulateSeats(store: Store, venture: Venture, params: ParamValues, log: (k: TickLog["kind"], t: string) => void) {
  if (venture.status !== "pitched") return;
  const t = store.meta.tick;
  const needed = seatsNeeded(venture.minRaiseUsd, seatPriceOf(venture, params));
  const posted = store.rfes.filter((r) => r.ventureId === venture.id && r.gtm?.postedAt);
  const want = 2 + Math.floor(rand(`${venture.id}:${t}:seats`) * 3);
  let bought = 0;
  const existing = store.members.filter((m) => m.simulated && !hasSeat(store, venture.id, m.handle));
  for (const m of existing.sort((a, b) => rand(`${t}:${a.handle}`) - rand(`${t}:${b.handle}`))) {
    if (bought >= want || seatsSold(store, venture.id) >= needed || venture.status !== "pitched") break;
    if (rand(`${venture.id}:${t}:${m.handle}:buy`) > 0.5) continue;
    const r = buySeat(store, { slug: venture.slug, handle: m.handle });
    bought++;
    log("seat", `@${m.handle} took a seat (${seatsSold(store, venture.id)}/${needed})${r.funded ? " — minimum met" : ""}`);
  }
  // Arrivals from posted recruiting drafts, attributed with ?ref.
  for (const a of ARRIVALS) {
    if (bought >= want || venture.status !== "pitched" || !posted.length) break;
    if (store.members.some((m) => m.handle === a.handle)) continue;
    const source = posted[bought % posted.length].id;
    store.members.push({
      ...a,
      reputationTier: "new",
      profile: { companies: [], buyingAuthority: "Recommends", tools: [], verticals: [a.industry.toLowerCase()], canReach: [] },
      dailyPushCap: params.DAILY_PUSH_CAP_DEFAULT,
      joinedAt: store.meta.clock,
      onboardedAt: store.meta.clock,
      source,
      simulated: true,
      qualification: "qualified",
      qualifiedAt: store.meta.clock,
      verifications: [
        {
          id: `ver-${a.handle}-li`,
          source: "linkedin",
          ref: `https://www.linkedin.com/in/${a.handle}`,
          attributes: [...SOURCE_ATTRIBUTES.linkedin],
          status: "confirmed",
          requestedAt: store.meta.clock,
          decidedAt: store.meta.clock,
          decidedBy: "linkedin",
        },
      ],
    });
    const r = buySeat(store, { slug: venture.slug, handle: a.handle, source });
    bought++;
    log("seat", `@${a.handle} arrived from ${source} and took a seat (${seatsSold(store, venture.id)}/${needed})${r.funded ? " — minimum met" : ""}`);
  }
}

function nextScriptStep(store: Store, venture: Venture): { step?: Step; index: number } {
  const steps = SCRIPT[venture.slug] ?? [];
  const index = store.meta.scriptCursor[venture.slug] ?? 0;
  const step = steps[index];
  if (!step) return { index };
  if (step.when && !step.when.includes(venture.status)) return { index };
  return { step, index };
}

function stepRfe(venture: Venture, step: Step) {
  return step.gtm
    ? {
        type: "action" as const,
        title: step.title,
        question:
          step.gtm.channel === "outreach"
            ? "Run these searches and send the template to people who fit. The agent never sends outreach itself."
            : "Review this draft and post it from your own account. The agent never posts or DMs.",
        recommendation: "Post as drafted",
        stakes: "low" as const,
        format: "action" as const,
        offerUnits: 0,
        audience: "Steward",
        assignedTo: venture.stewardHandle,
        gtm: step.gtm,
      }
    : step.rfe;
}

function applyStep(store: Store, venture: Venture, step: Step, model: string, conductReview?: Awaited<ReturnType<typeof conductReviewWithClaude>>) {
  const facts = { ...step.facts, ...(step.gtm ? { publicPost: true } : {}) };
  const rfe = stepRfe(venture, step);
  return logDecision(store, {
    ventureId: venture.id,
    title: step.title,
    reasoning: step.reasoning,
    summary: step.summary,
    confidence: step.confidence,
    facts,
    outcome: step.outcome,
    embargoReason: step.embargoReason,
    transition: step.transition,
    model,
    rfe,
    lessonIds: step.lessonIds,
    conductReview,
  });
}

async function operate(
  store: Store,
  venture: Venture,
  params: ParamValues,
  mode: TickMode,
  log: (k: TickLog["kind"], t: string) => void,
) {
  if (!isLive(venture)) return;
  const { step: scripted, index } = nextScriptStep(store, venture);
  const useClaude = useClaudeFor(mode);
  let step = scripted;
  let model = "script";
  if (useClaude) {
    try {
      step = await planWithClaude(store, venture, params, scripted);
      model = params.MODEL_OPERATOR;
    } catch (err) {
      log("fallback", `Claude call failed (${(err as Error).message.slice(0, 120)}); using the pre-written reply instead`);
    }
  }
  if (!step) {
    log("idle", "No new decision this tick; waiting on members");
    return;
  }
  const review = useClaude
    ? await conductReviewWithClaude(
        (({ text, outbound }) => [text, ...outbound].join("\n"))(conductTextFor({ title: step.title, reasoning: step.reasoning, rfe: stepRfe(venture, step) })),
        params,
      )
    : undefined;
  const { decision, rfe } = applyStep(store, venture, step, model, review);
  if (model === "script" || step === scripted) store.meta.scriptCursor[venture.slug] = index + 1;
  const bin = decision.bin.toUpperCase();
  const status = decision.status.replace("_", " ");
  log(
    "decision",
    `[${bin}] ${decision.embargo ? "(embargoed) " : ""}${decision.title} — ${status}${rfe ? `; posted ${rfe.type} request “${rfe.title}”` : ""}${decision.lessonIds?.length ? ` (follows ${decision.lessonIds.join(", ")})` : ""}${decision.contradicts?.length ? ` (contradicts ${decision.contradicts.join(", ")})` : ""}`,
  );
}

/** Q&A answers, the weekly update, the monthly review, and requests that resolved. */
async function operateLoop(store: Store, venture: Venture, mode: TickMode, log: (k: TickLog["kind"], t: string) => void) {
  if (venture.isProtocol) return;
  const params = resolveParams(store);
  const drafts = new Map<string, AnswerDraft>();
  if (useClaudeFor(mode)) {
    for (const q of store.questions.filter((x) => x.ventureId === venture.id && x.status === "open")) {
      try {
        drafts.set(q.id, await answerWithClaude(store, venture, q, params));
      } catch (err) {
        log("fallback", `Claude could not answer a question (${(err as Error).message.slice(0, 80)}); the script answers it`);
      }
    }
  }
  for (const q of answerOpenQuestions(store, (q) => (q.ventureId === venture.id ? drafts.get(q.id) : undefined)).filter((x) => x.ventureId === venture.id)) {
    log("qa", `Answered “${q.text.slice(0, 60)}” (${q.answer?.status}${q.status === "held" ? ", held for the steward" : q.status === "routed" ? ", routed" : ""})`);
  }
  for (const line of applyResolvedRequests(store, venture)) log("resolve", line);
  if (updateDue(store, venture, params)) {
    const u = publishUpdate(store, venture, scriptedUpdate(store, venture));
    log("update", `Week ${u.week} update: ${u.metric.name} ${u.metric.value}; default ${u.defaultAlive.status}; ${u.lowlights.length} lowlights, ${u.asks.length} asks`);
  }
  if (reviewDue(store, venture, params)) {
    const r = runReview(store, venture);
    log("review", `Monthly review: the agent recommends ${r.call}; waiting on @${venture.stewardHandle}`);
  }
}

/** Rewrite this tick's template lessons and re-propose this tick's tags with Claude, when the key is set. */
async function withClaudeAfterTick(store: Store, lessonsBefore: number, rfesBefore: number, mode: TickMode, log: (k: TickLog["kind"], t: string) => void) {
  const fresh = store.lessons.slice(lessonsBefore);
  const params = resolveParams(store);
  if (useClaudeFor(mode)) {
    try {
      await writeLessonsWithClaude(store, fresh.filter((l) => l.writtenBy === "template"), params);
    } catch (err) {
      log("fallback", `Claude could not write lessons (${(err as Error).message.slice(0, 80)}); keeping the templates`);
    }
    for (const r of store.rfes.slice(rfesBefore)) {
      if (r.tags?.length) r.tags = await proposeTagsWithClaude(store, `${r.title}\n${r.question}`, r.tags, params);
    }
  }
  for (const l of fresh) log("lesson", `${l.id} (${l.status}): ${l.headline}`);
}

/**
 * Announce the next batch: allocate slots by end market and business model, spawn one venture per
 * slot (Claude writes the ideas when the key is set; the library otherwise),
 * and draft the teaser for the steward.
 */
export async function spawnBatch(store: Store, mode: TickMode = "auto"): Promise<TickLog[]> {
  const logs: TickLog[] = [];
  const params = resolveParams(store);
  const useClaude = useClaudeFor(mode);
  const ideas: Record<string, IdeaTemplate> = {};
  const decks: Record<string, DeckDraft> = {};
  let model = "script";
  if (useClaude) {
    const picks = allocateBatchSlots(store, params);
    for (const p of picks) {
      try {
        ideas[segmentKey(p)] = await ideaWithClaude(store, p, params);
        model = params.MODEL_OPERATOR;
        try {
          decks[segmentKey(p)] = await deckWithClaude(store, ideas[segmentKey(p)], params, DECK_DRAFTS["site-record"]());
        } catch (err) {
          logs.push({ at: store.meta.clock, venture: "protocol", kind: "fallback", text: `Claude could not write a deck (${(err as Error).message.slice(0, 80)}); the script writes it` });
        }
      } catch (err) {
        if (!candidateIdeas(store, p).length) throw err;
        logs.push({ at: store.meta.clock, venture: "protocol", kind: "fallback", text: `Claude could not write a ${segmentLabel(p)} idea; using the library` });
      }
    }
  }
  const { cohort, ventures } = announceBatch(store, { ideas, decks, model });
  for (const v of ventures) {
    const contra = v.contradictions.map((c) => `contradicts ${c.lessonId}: ${c.reason}`).join("; ");
    logs.push({
      at: store.meta.clock,
      venture: v.slug,
      kind: "spawn",
      text: `${v.codename} (${v.name}, ${classificationLine(classificationOf(v))}) spawned for ${batchLabel(cohort.number)}; priors ${v.lessonIds.join(", ") || "none"}${contra ? `; ${contra}` : ""}`,
    });
  }
  logs.push({
    at: store.meta.clock,
    venture: "protocol",
    kind: "batch",
    text: `${batchLabel(cohort.number)} announced; early access ${earlyAccessAt(cohort, params).slice(0, 16).replace("T", " ")}, public ${cohort.opensAt.slice(0, 16).replace("T", " ")}, closes ${cohort.closesAt.slice(0, 16).replace("T", " ")}. Teaser drafted for the steward.`,
  });
  return logs;
}

/**
 * One turn of the operator loop on the fake clock: read state → plan →
 * classify → act or post a request → log. Also moves the world: members
 * answer, the N rule closes requests, grants vest, seats sell, votes close.
 */
export async function tick(store: Store, opts: TickOptions = {}): Promise<TickLog[]> {
  const logs: TickLog[] = [];
  const params0 = resolveParams(store);
  store.meta.clock = addHours(store.meta.clock, params0.SIM_TICK_HOURS);
  store.meta.tick += 1;
  const logger = (venture: string) => (kind: TickLog["kind"], text: string) =>
    logs.push({ at: store.meta.clock, venture, kind, text });
  logger("protocol")("clock", `Tick ${store.meta.tick}: clock moves ${params0.SIM_TICK_HOURS}h to ${store.meta.clock.slice(0, 16).replace("T", " ")}`);

  for (const g of vestDue(store)) {
    logger(g.ventureId)("vest", `${g.units} units vested for @${g.handle}`);
  }
  const lessonsBefore = store.lessons.length;
  const rfesBefore = store.rfes.length;
  for (const e of advanceBatches(store)) logger("protocol")("batch", e.message);

  const targets = opts.venture
    ? [ventureBySlug(store, opts.venture)].filter((v): v is Venture => !!v)
    : store.ventures.filter((v) => isLive(v) && v.status !== "generated");
  if (opts.venture && !targets.length) throw new Error(`No venture with slug “${opts.venture}”`);

  for (const venture of targets) {
    const log = logger(venture.slug);
    for (const rfe of store.rfes.filter((r) => r.ventureId === venture.id && r.kind === "governance" && isOpen(r))) {
      if (rfe.governance && rfe.governance.windowEndsAt <= store.meta.clock) {
        closeGovernance(store, rfe);
        log("vote", `Vote closed on “${rfe.title}”: ${rfe.resolution}`);
      }
    }
    const params = resolveParams(store);
    simulateSeats(store, venture, params, log);
    simulateMembers(store, venture, log);
    await operate(store, venture, resolveParams(store), opts.mode ?? "auto", log);
    await operateLoop(store, venture, opts.mode ?? "auto", log);
    if (!venture.isProtocol) {
      for (const d of draftGapRecruiting(store, venture, useClaudeFor(opts.mode ?? "auto") ? params.MODEL_OPERATOR : "script")) {
        log("gap", `[${d.bin.toUpperCase()}] ${d.title} — waiting on @${venture.stewardHandle}`);
      }
    }
  }
  const backOffice = runBackOffice(store);
  if (backOffice.length) {
    const usd = (kind: string) => backOffice.filter((l) => l.kind === kind).reduce((s, l) => s + (l.usd ?? 0), 0);
    logger("protocol")("services", `Back office for the month: $${usd("service-cost").toFixed(2)} of bills published, $${usd("service-charge").toFixed(2)} charged to ventures`);
  }
  await withClaudeAfterTick(store, lessonsBefore, rfesBefore, opts.mode ?? "auto", logger("protocol"));
  return logs;
}

/** Load the file store, run `ticks` ticks, save. What the app's "Advance the agent" button calls. */
export async function advanceAgent(opts: TickOptions & { ticks?: number; spawn?: boolean } = {}): Promise<TickLog[]> {
  return mutateStore(async (store) => {
    const all: TickLog[] = opts.spawn ? await spawnBatch(store, opts.mode) : [];
    for (let i = 0; i < (opts.ticks ?? 1); i++) all.push(...(await tick(store, opts)));
    return all;
  });
}

export function formatLog(l: TickLog): string {
  return `${l.at.slice(0, 16).replace("T", " ")}  ${l.venture.padEnd(13)} ${l.kind.padEnd(8)} ${l.text}`;
}

