import type { Metadata } from "next";
import Link from "next/link";
import { Clock, UserRoundX } from "lucide-react";
import { ATTRIBUTE_LABELS, attributeStatuses, badgesFor, PROVIDERS, SOURCE_LABELS, verifiedShare, ventureBySlug } from "@av/protocol";
import type { Member, ParamValues } from "@av/schema";
import { EmptyState } from "@/components/empty-state";
import { ConnectAccountForm } from "@/components/protocol-forms";
import { AttributeTable, MemberBadges } from "@/components/protocol-ui";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { formatDate } from "@/lib/format";
import { Interview } from "./interview";

export const metadata: Metadata = { title: "Get verified" };

const PLACEHOLDER = { linkedin: "linkedin.com/in/your-name", x: "@your_handle" } as const;

function QualificationCard({ member, params, step }: { member: Member; params: ParamValues; step: number }) {
  const share = verifiedShare(member, params);
  return (
    <Card id="qualify" className="scroll-mt-20">
      <CardHeader>
        <CardTitle>
          {step}. Get verified: link LinkedIn or X
        </CardTitle>
        <CardDescription>
          You need this to answer requests. The steward checks that your account matches what you told the agent. Other members only see a
          &lsquo;verified&rsquo; badge, never your account or name.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <MemberBadges badges={badgesFor(member)} labels={SOURCE_LABELS} share={share} qualification={member.qualification} />
        {member.qualification === "declined" ? (
          <p className="text-sm text-zinc-600">The steward declined this profile. You keep your seats, but can&apos;t answer requests.</p>
        ) : (
          <>
            <div className="grid gap-5 md:grid-cols-2">
              {(["linkedin", "x"] as const).map((source) => {
                const linked = member.verifications.filter((v) => v.source === source);
                const confirmed = linked.some((v) => v.status === "confirmed");
                const pending = linked.some((v) => v.status === "pending");
                return (
                  <div key={source} className="space-y-2 rounded-lg border border-zinc-200 p-4">
                    <p className="text-sm font-medium">{PROVIDERS[source].label}</p>
                    {confirmed ? (
                      <p className="text-sm text-emerald-700">Confirmed by the steward.</p>
                    ) : (
                      <>
                        {pending && (
                          <p className="flex items-center gap-1.5 text-sm text-amber-700">
                            <Clock className="size-4" /> Waiting for the steward&apos;s review.
                          </p>
                        )}
                        <ConnectAccountForm
                          source={source}
                          label={PROVIDERS[source].label}
                          prompt={pending ? "Replace the linked account" : PROVIDERS[source].prompt}
                          placeholder={PLACEHOLDER[source]}
                        />
                      </>
                    )}
                  </div>
                );
              })}
            </div>
            <AttributeTable rows={attributeStatuses(member, params)} labels={ATTRIBUTE_LABELS} sourceLabels={SOURCE_LABELS} />
            <p className="text-xs text-zinc-500">
              Pilot: no real LinkedIn or X connection is made. The steward checks each link by hand.
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default async function OnboardingPage(props: PageProps<"/onboarding">) {
  const sp = await props.searchParams;
  const { store, params, member, viewer } = await getData();
  const venture = typeof sp.v === "string" ? ventureBySlug(store, sp.v) : undefined;

  if (!member) {
    return (
      <EmptyState icon={UserRoundX} title="Take a seat first">
        Setup starts after you take a seat in a venture.{" "}
        <Link href="/" className="underline">
          See ventures
        </Link>
      </EmptyState>
    );
  }

  const qualifyFirst = !!member.onboardedAt && member.qualification !== "qualified";

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{qualifyFirst ? "Finish getting verified" : "Get set up"}</h1>
        <p className="text-sm text-zinc-500">
          {member.qualification === "qualified"
            ? `@${viewer} is verified${member.qualifiedAt ? ` since ${formatDate(member.qualifiedAt)}` : ""}. You can update your profile here.`
            : member.onboardedAt
              ? `@${viewer} finished the interview on ${formatDate(member.onboardedAt)}. One step left.`
              : "Two steps: a short interview with the agent, then link an account for the steward to confirm."}
        </p>
      </div>
      {qualifyFirst && <QualificationCard member={member} params={params} step={2} />}
      <div className="space-y-2">
        {!member.onboardedAt && <h2 className="text-sm font-medium text-zinc-500">1. Interview</h2>}
        <Interview handle={viewer} ventureName={venture?.name} />
      </div>
      {!qualifyFirst && <QualificationCard member={member} params={params} step={2} />}
      {member.qualification === "qualified" && (
        <Link href="/inbox" className={buttonVariants({ variant: "outline" })}>
          Go to your requests
        </Link>
      )}
    </div>
  );
}
