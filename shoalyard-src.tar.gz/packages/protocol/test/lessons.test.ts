import assert from "node:assert/strict";
import { test } from "node:test";
import { ARTICLES } from "../src/constitution";
import { quotedLessons } from "../src/conduct";
import { canReadLessons, lessonTeaser, lessonUse, seesLessonUse } from "../src/lesson-access";
import { hasSeat, screenDecision } from "../src/ops";
import { resolveParams } from "../src/params";
import { buildSeed } from "../src/seed";

const seeded = () => {
  const store = buildSeed();
  return { store, params: resolveParams(store) };
};

test("lessons are for qualified members by default; a vote can make them public", () => {
  const { params } = seeded();
  assert.equal(params.LESSONS_VISIBLE_TO, "qualified members");
  assert.equal(canReadLessons(undefined, params), false);
  assert.equal(canReadLessons({ qualification: "pending" }, params), false);
  assert.equal(canReadLessons({ qualification: "declined" }, params), false);
  assert.equal(canReadLessons({ qualification: "qualified" }, params), true);
  assert.equal(canReadLessons(undefined, { ...params, LESSONS_VISIBLE_TO: "public" }), true);
  assert.match(ARTICLES[2].text, /The lessons drawn from the record are for members\./);
});

test("the public view says lessons exist without saying what they are", () => {
  const { store } = seeded();
  const teaser = lessonTeaser(store);
  const kept = store.lessons.filter((l) => l.status !== "retired");
  assert.equal(teaser.count, kept.length);
  assert.ok(teaser.count > 0 && teaser.ventures > 0 && teaser.topics.length > 0);
  const shown = JSON.stringify(teaser);
  for (const l of store.lessons) {
    assert.ok(!shown.includes(l.headline), `teaser leaks ${l.id}`);
    assert.ok(!shown.includes(l.id), `teaser names ${l.id}`);
  }
});

test("seat holders see how each lesson was used in their venture; other members see the lessons only", () => {
  const { store, params } = seeded();
  const venture = store.ventures.find((v) => !v.isProtocol && lessonUse(store, v).size > 0);
  assert.ok(venture, "a seeded venture follows a lesson");
  const qualified = store.members.filter((m) => m.qualification === "qualified" && m.handle !== venture.stewardHandle);
  const holder = qualified.find((m) => hasSeat(store, venture.id, m.handle));
  const outsider = qualified.find((m) => !hasSeat(store, venture.id, m.handle));
  assert.ok(holder && outsider);
  assert.equal(seesLessonUse(store, venture, holder, params), true);
  assert.equal(seesLessonUse(store, venture, outsider, params), false);
  assert.equal(canReadLessons(outsider, params), true);
  const pendingHolder = { ...holder, qualification: "pending" as const };
  assert.equal(seesLessonUse(store, venture, pendingHolder, params), false);
  const steward = store.members.find((m) => m.handle === venture.stewardHandle);
  assert.equal(seesLessonUse(store, venture, steward, params), true);
  for (const [id, decisions] of lessonUse(store, venture)) {
    for (const d of decisions) assert.ok(store.decisions.find((x) => x.id === d.id)?.lessonIds?.includes(id));
  }
});

test("quotedLessons finds a headline or a seven-word run, and ignores ordinary copy", () => {
  const { store } = seeded();
  const l = store.lessons[0];
  assert.deepEqual(quotedLessons(`Hiring now. ${l.headline}`, store.lessons).map((x) => x.id).includes(l.id), true);
  const run = l.whatWeDoDifferently.split(/\s+/).slice(0, 7).join(" ");
  assert.ok(quotedLessons(`Our approach: ${run.toUpperCase()}!`, store.lessons).some((x) => x.id === l.id));
  assert.deepEqual(quotedLessons("An AI agent runs Permit Pulse and needs a roofing estimator for two calls a month.", store.lessons), []);
});

test("a recruiting draft that quotes a members-only lesson is blocked", () => {
  const { store, params } = seeded();
  const venture = store.ventures.find((v) => !v.isProtocol)!;
  const l = store.lessons.find((x) => x.status === "adopted")!;
  const draft = (post: string) =>
    ({
      ventureId: venture.id,
      title: "Draft a recruiting post",
      reasoning: "The roster has an open place.",
      confidence: 0.9,
      rfe: { type: "action", title: "Post this", question: "Post it?", gtm: { posts: [post] } },
    }) as unknown as Parameters<typeof screenDecision>[1];
  const quoting = screenDecision(store, draft(`Built by an AI agent. ${l.headline} Join us.`), params);
  assert.equal(quoting.result, "stop");
  assert.ok(quoting.findings.some((f) => f.includes(l.id) && f.includes("Article 3")));
  const clean = screenDecision(store, draft("Built by an AI agent. We need a roofing estimator for two calls a month."), params);
  assert.ok(!clean.findings.some((f) => f.includes("Article 3")));
  const open = screenDecision(store, draft(`Built by an AI agent. ${l.headline} Join us.`), { ...params, LESSONS_VISIBLE_TO: "public" });
  assert.ok(!open.findings.some((f) => f.includes("Article 3")));
});
