import { ImageResponse } from "next/og";
import { lookupVenture, resolveParams, ventureShareCard, type ShareCard } from "@av/protocol";
import { loadStore } from "@av/protocol/store";
import { OG_SIZE, OgCard } from "@/lib/og";

export const alt = "A venture's share card: its name, the problem, seats left, roles claimed and when the window closes";
export const size = OG_SIZE;
export const contentType = "image/png";

/** Public view only: crawlers have no cookie, and an announced venture shows its codename and teaser. */
export default async function Image({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const store = loadStore();
  const hit = lookupVenture(store, slug);
  const card: ShareCard = hit ? ventureShareCard(store, hit.venture) : { title: "Not found", line: "", accent: "#18181b", eyebrow: "", stats: [], teaser: true };
  return new ImageResponse(<OgCard card={card} brand={resolveParams(store).BRAND_NAME} />, size);
}
