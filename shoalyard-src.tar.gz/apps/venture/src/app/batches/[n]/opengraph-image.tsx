import { ImageResponse } from "next/og";
import { batchShareCard, cohortByNumber, resolveParams, type ShareCard } from "@av/protocol";
import { loadStore } from "@av/protocol/store";
import { OG_SIZE, OgCard } from "@/lib/og";

export const alt = "A batch's share card: its ventures, seats left, roles open and when the window closes";
export const size = OG_SIZE;
export const contentType = "image/png";

export default async function Image({ params }: { params: Promise<{ n: string }> }) {
  const { n } = await params;
  const store = loadStore();
  const cohort = cohortByNumber(store, Number(n));
  const card: ShareCard = cohort ? batchShareCard(store, cohort) : { title: "Not found", line: "", accent: "#18181b", eyebrow: "", stats: [], teaser: true };
  return new ImageResponse(<OgCard card={card} brand={resolveParams(store).BRAND_NAME} />, size);
}
