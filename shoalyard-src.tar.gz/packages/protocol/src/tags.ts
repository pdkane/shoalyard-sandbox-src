import {
  CLASSIFICATION_AXES,
  TAG_AXES,
  TAG_AXIS_LABELS,
  WORK_DELIVERIES,
  type Classification,
  type ClassificationAxis,
  type Lesson,
  type Rfe,
  type Store,
  type Tag,
  type TagAxis,
  type Venture,
  type WorkDelivery,
} from "@av/schema";
import { resolveParams } from "./params";
import { newId } from "./util";

/** Params vocabulary with the steward's logged additions, renames and merges applied. */
export function vocabFor(store: Store): Record<TagAxis, string[]> {
  const base = resolveParams(store).TAG_VOCAB as Record<string, string[]>;
  const out = Object.fromEntries(TAG_AXES.map((a) => [a, [...(base[a] ?? [])]])) as Record<TagAxis, string[]>;
  for (const e of [...store.tagLog].sort((a, b) => a.at.localeCompare(b.at))) {
    const list = out[e.axis];
    if (e.action === "add" && !list.includes(e.to)) list.push(e.to);
    if (e.action === "rename" || e.action === "merge") {
      const i = list.indexOf(e.from ?? "");
      if (i >= 0) list.splice(i, 1);
      if (!list.includes(e.to)) list.push(e.to);
    }
  }
  // Sub-verticals are free text: whatever is in use is in the vocabulary.
  for (const t of taggables(store).flatMap((x) => x.item.tags ?? [])) {
    if (t.axis === "subVertical" && !out.subVertical.includes(t.value)) out.subVertical.push(t.value);
  }
  return out;
}

const END_MARKET_RULES: [RegExp, string][] = [
  [/freight|dock|carrier|truck|3pl|shipper|logistic|warehouse/i, "Industrials and logistics"],
  [/roof|hvac|contractor|permit|construct|lien|subcontract/i, "Real estate and construction"],
  [/dental|clinic|hygien|patient|health/i, "Healthcare"],
  [/county|city|municipal|public records|tender/i, "Public sector"],
  [/counsel|legal|law|llc|attorney|notar/i, "Professional services"],
  [/bookkeep|invoice|financ|payment|lender/i, "Fintech"],
  [/agent|api|developer|model|software|saas/i, "Software and IT"],
];
const CUSTOMER_RULES: [RegExp, string][] = [
  [/enterprise|fortune|top-50/i, "Enterprise"],
  [/county|city|municipal|state agency/i, "Government"],
  [/mid-size|regional|dso|group practice|outside sales teams/i, "Mid-market"],
  [/consumer|homeowner|households/i, "Consumer"],
  [/broker|contractor|practice|owner|small|shop|subcontractor|ventures?\b/i, "Small business"],
];
const BUSINESS_MODEL_RULES: [RegExp, string][] = [
  [/per (call|request|lookup|check|minute|job)|metered|usage/i, "Usage-based"],
  [/marketplace|matched .* with|same-day cover/i, "Marketplace"],
  [/per (load|claim|transaction|booking|placement)|take rate|fee per/i, "Transactional or payments"],
  [/dataset|data feed|lookup|receipts|permits? .* every/i, "Data or licensing"],
  [/done for you|concierge|by hand|on shift|booked .* member/i, "Tech-enabled services"],
  [/\/mo|monthly|subscription|per month|annual plan|subscriber/i, "Subscription software"],
];

const WORK_DELIVERY_RULES: [RegExp, string][] = [
  [/\b(employees?|on staff|payroll|we hire)\b/i, "Employees"],
  [/paid (per|by the) (shift|job|package|hour)|members are paid|member who does it is paid|on shift|by hand, paid/i, "Agent plus contractors"],
];

function first(rules: [RegExp, string][], text: string): string | undefined {
  return rules.find(([re]) => re.test(text))?.[1];
}

function proposed(axis: TagAxis, value: string | undefined, by: string): Tag[] {
  return value ? [{ axis, value, status: "proposed", by }] : [];
}

const STAGE_FOR: Partial<Record<Venture["status"], string>> = {
  generated: "generated",
  pitched: "pitched",
  funded: "funded",
  formed: "formed",
  operating: "operating",
  customer1: "first customer",
  distributing: "distributing",
};

/**
 * The agent's proposed classification, as tags the steward confirms or
 * corrects. An idea's own classification wins; rules fill any axis it lacks.
 */
export function proposeVentureTags(v: Venture, classification?: Partial<Classification>, by = "agent"): Tag[] {
  const text = `${v.name} ${v.tagline} ${v.pitch} ${v.customers.segment} ${v.memo ? Object.values(v.memo).join(" ") : ""}`;
  // The named segment says most about end market and customer; fall back to the full text.
  const lead = `${v.customers.segment} ${v.tagline}`;
  const rules: Partial<Classification> = {
    endMarket: (first(END_MARKET_RULES, lead) ?? first(END_MARKET_RULES, text)) as Classification["endMarket"] | undefined,
    customer: (first(CUSTOMER_RULES, lead) ?? first(CUSTOMER_RULES, text)) as Classification["customer"] | undefined,
    businessModel: first(BUSINESS_MODEL_RULES, text) as Classification["businessModel"] | undefined,
    geography: /\b(US|U\.S\.|Texas|Arizona|Florida|Memphis|Phoenix|Atlanta|Dallas|county|counties|IRS)\b/.test(text) ? "US" : "Global",
    workDelivery: (first(WORK_DELIVERY_RULES, `${v.pitch} ${v.memo?.unitEconomics ?? ""}`) ?? "Agent only") as Classification["workDelivery"],
  };
  return CLASSIFICATION_AXES.flatMap((axis) => {
    const own = classification?.[axis];
    return own ? proposed(axis, own, by) : proposed(axis, rules[axis], "rules");
  });
}

export function proposeRfeTags(rfe: Rfe, venture: Venture, by = "rules"): Tag[] {
  const inherit = venture.tags.filter((t) => t.axis === "endMarket" || t.axis === "customer");
  if (inherit.length) return inherit.map((t) => ({ ...t, status: "proposed" as const, by }));
  const text = `${rfe.title} ${rfe.question} ${rfe.audience}`;
  return [...proposed("endMarket", first(END_MARKET_RULES, text), by), ...proposed("customer", first(CUSTOMER_RULES, text), by)];
}

/** A venture's classification as it stands: confirmed values, else the agent's proposals. */
export function classificationOf(v: Pick<Venture, "tags">): Partial<Record<ClassificationAxis, string>> {
  return Object.fromEntries(CLASSIFICATION_AXES.map((a) => [a, tagValue(v.tags, a)]).filter(([, x]) => x));
}

/** "Subscription software · Small business · Healthcare" */
export function classificationLine(c: Partial<Record<ClassificationAxis, string>>, axes: readonly ClassificationAxis[] = ["businessModel", "customer", "endMarket"]): string {
  return axes
    .map((a) => c[a])
    .filter(Boolean)
    .join(" · ");
}

/** Outcome tags, refreshed when a venture moves stage or dies. */
export function outcomeTags(v: Venture): Tag[] {
  const reached = [...v.statusHistory].reverse().find((h) => STAGE_FOR[h.status])?.status;
  const out: Tag[] = [];
  if (reached) out.push({ axis: "stage", value: STAGE_FOR[reached]!, status: "proposed", by: "rules" });
  if (v.postMortem?.killReason) out.push({ axis: "killReason", value: v.postMortem.killReason, status: "proposed", by: "rules" });
  return out;
}

/** Add tags without duplicating an axis value already present; confirmed tags win. */
export function mergeTags(existing: Tag[], incoming: Tag[]): Tag[] {
  const out = [...existing];
  for (const t of incoming) {
    const same = out.findIndex((x) => x.axis === t.axis);
    if (same < 0) out.push(t);
    else if (out[same].status === "proposed" && out[same].value !== t.value) out[same] = t;
  }
  return out;
}

export function tagValue(tags: Tag[] | undefined, axis: TagAxis): string | undefined {
  return tags?.find((t) => t.axis === axis)?.value;
}

export type Taggable = { kind: "venture"; item: Venture } | { kind: "rfe"; item: Rfe } | { kind: "lesson"; item: Lesson };

export function taggables(store: Store): Taggable[] {
  return [
    ...store.ventures.filter((v) => !v.isProtocol).map((item) => ({ kind: "venture" as const, item })),
    ...store.rfes.filter((r) => r.tags?.length).map((item) => ({ kind: "rfe" as const, item })),
    ...store.lessons.map((item) => ({ kind: "lesson" as const, item })),
  ];
}

export function tagQueue(store: Store): { kind: Taggable["kind"]; id: string; label: string; tag: Tag }[] {
  return taggables(store).flatMap((t) =>
    (t.item.tags ?? [])
      .filter((tag) => tag.status === "proposed")
      .map((tag) => ({
        kind: t.kind,
        id: t.item.id,
        label: t.kind === "venture" ? t.item.name : t.kind === "rfe" ? t.item.title : `${t.item.id}: ${t.item.headline}`,
        tag,
      })),
  );
}

export class TagError extends Error {}

/** Classification axes with a standard value list; a new value on these joins only by a Protocol vote. */
export const GOVERNED_AXES: readonly TagAxis[] = ["endMarket", "customer", "businessModel", "goToMarket", "marketType", "geography", "workDelivery"];

/** Who does a venture's work, as classified: confirmed, else proposed, else the agent alone. */
export function workDeliveryOf(v: Pick<Venture, "tags">): WorkDelivery {
  const value = tagValue(v.tags, "workDelivery");
  return (WORK_DELIVERIES as readonly string[]).includes(value ?? "") ? (value as WorkDelivery) : "Agent only";
}

export function isGovernedAxis(axis: TagAxis): boolean {
  return GOVERNED_AXES.includes(axis);
}

/** Add a value to a governed axis once a Protocol vote passes. */
export function addClassificationValue(store: Store, input: { axis: TagAxis; value: string; by: string }) {
  const value = input.value.trim();
  if (!value) throw new TagError("Give a value.");
  if (input.axis === "workDelivery") throw new TagError("The three levels of who does the work are fixed by the rules.");
  if (vocabFor(store)[input.axis].includes(value)) return;
  store.tagLog.push({ id: newId(store, "tag"), at: store.meta.clock, axis: input.axis, action: "add", to: value, by: input.by, affected: 0 });
}

function findTaggable(store: Store, kind: Taggable["kind"], id: string): { tags: Tag[]; set(tags: Tag[]): void } {
  const item =
    kind === "venture" ? store.ventures.find((v) => v.id === id) : kind === "rfe" ? store.rfes.find((r) => r.id === id) : store.lessons.find((l) => l.id === id);
  if (!item) throw new TagError(`No ${kind} ${id}`);
  return {
    tags: item.tags ?? [],
    set(tags) {
      item.tags = tags;
    },
  };
}

/** Confirm a proposed tag, optionally editing its value. Never blocks anything. */
export function confirmTag(store: Store, input: { kind: Taggable["kind"]; id: string; axis: TagAxis; value: string; newValue?: string; by: string }) {
  const target = findTaggable(store, input.kind, input.id);
  const value = (input.newValue ?? input.value).trim();
  if (!value) throw new TagError("Pick a value.");
  const vocab = vocabFor(store)[input.axis];
  if (!vocab.includes(value) && isGovernedAxis(input.axis)) {
    throw new TagError(`“${value}” is not a standard ${TAG_AXIS_LABELS[input.axis].toLowerCase()} value. Propose it as a Protocol request; a vote adds it.`);
  }
  if (!vocab.includes(value)) {
    store.tagLog.push({ id: newId(store, "tag"), at: store.meta.clock, axis: input.axis, action: "add", to: value, by: input.by, affected: 0 });
  }
  const tags = target.tags.filter((t) => !(t.axis === input.axis && t.value === input.value));
  target.set(mergeTags(tags.filter((t) => !(t.axis === input.axis && t.value === value)), [{ axis: input.axis, value, status: "confirmed", by: input.by }]));
}

/** Rename or merge a vocabulary value everywhere. Logged so history stays comparable. */
export function rewriteTagValue(store: Store, input: { axis: TagAxis; from: string; to: string; by: string }) {
  const to = input.to.trim();
  if (!to || to === input.from) throw new TagError("Give a new value.");
  const vocab = vocabFor(store)[input.axis];
  if (!vocab.includes(input.from)) throw new TagError(`“${input.from}” is not in the ${input.axis} vocabulary.`);
  const action = vocab.includes(to) ? "merge" : "rename";
  if (action === "rename" && isGovernedAxis(input.axis)) {
    throw new TagError(`Renaming a standard ${TAG_AXIS_LABELS[input.axis].toLowerCase()} value needs a Protocol vote; merge into an existing value instead.`);
  }
  let affected = 0;
  for (const t of taggables(store)) {
    const tags = t.item.tags ?? [];
    if (!tags.some((x) => x.axis === input.axis && x.value === input.from)) continue;
    affected++;
    const rewritten = tags.map((x) => (x.axis === input.axis && x.value === input.from ? { ...x, value: to } : x));
    t.item.tags = rewritten.filter((x, i) => rewritten.findIndex((y) => y.axis === x.axis && y.value === x.value) === i);
  }
  store.tagLog.push({ id: newId(store, "tag"), at: store.meta.clock, axis: input.axis, action, from: input.from, to, by: input.by, affected });
  return { action, affected };
}
