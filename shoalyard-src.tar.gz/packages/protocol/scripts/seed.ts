import { resetStore, storePath } from "../src/store";

const store = resetStore();
console.log(
  `Seeded ${store.ventures.length} ventures, ${store.members.length} members, ${store.rfes.length} requests, ` +
    `${store.decisions.length} decisions, ${store.grants.length} grants → ${storePath()}`,
);
