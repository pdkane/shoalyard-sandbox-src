import type { ParamValues, Response, Rfe, RfeType, Stakes } from "@av/schema";

export type NState = "collecting" | "close" | "extend";

export interface NStatus {
  minimum: number;
  target: number;
  /** Responses after collapsing each profile cluster to one. */
  effective: number;
  raw: number;
  /** Share of effective responses agreeing with the leading answer, 0..1. */
  agreement: number;
  leading?: string;
  state: NState;
  reason: string;
}

type NParams = Pick<
  ParamValues,
  "N_BASELINE" | "STAKES_MULTIPLIER" | "AGREEMENT_STOP" | "DIVERGENCE_EXTEND" | "EXTEND_BY" | "SEAT_PRICE_USD"
>;

export function seatsNeeded(minRaiseUsd: number, seatPriceUsd: number): number {
  return Math.ceil(minRaiseUsd / seatPriceUsd);
}

/** Minimum and target from type baseline and stakes; an explicit target overrides. */
export function nBounds(
  rfe: Pick<Rfe, "type" | "stakes" | "targetOverride" | "extended">,
  params: NParams,
  minRaiseUsd = 0,
  seatPriceUsd = params.SEAT_PRICE_USD,
): { minimum: number; target: number } {
  if (rfe.type === "capital") {
    const n = seatsNeeded(minRaiseUsd, seatPriceUsd);
    return { minimum: n, target: n };
  }
  const extra = rfe.extended ? params.EXTEND_BY : 0;
  // An explicit N (e.g. the working model's "20 pilot members") is both the minimum and the target.
  if (rfe.targetOverride) {
    return { minimum: rfe.targetOverride, target: rfe.targetOverride + extra };
  }
  const baseline = params.N_BASELINE as Record<RfeType, [number, number]>;
  const [lo, hi] = baseline[rfe.type] ?? [1, 1];
  const mult = (params.STAKES_MULTIPLIER as Record<Stakes, number>)[rfe.stakes] ?? 1;
  const target = Math.min(hi, Math.max(lo, Math.ceil(lo * mult)));
  return { minimum: lo, target: target + extra };
}

function answerKey(r: Response, format: Rfe["format"]): string | undefined {
  if (r.choice) return r.choice;
  if (format === "scale" && typeof r.scale === "number") return String(r.scale);
  return undefined;
}

/**
 * Collapse responses so one profile cluster counts once (its most common
 * answer), then measure agreement with the leading answer.
 */
export function effectiveResponses(
  rfe: Pick<Rfe, "format">,
  responses: Response[],
  clusterOf: (handle: string) => string,
): { effective: number; agreement: number; leading?: string } {
  const byCluster = new Map<string, Response[]>();
  for (const r of responses) {
    const c = clusterOf(r.handle) || r.handle;
    byCluster.set(c, [...(byCluster.get(c) ?? []), r]);
  }
  const clusterAnswers: (string | undefined)[] = [];
  const scaleValues: number[] = [];
  for (const rs of byCluster.values()) {
    const counts = new Map<string, number>();
    for (const r of rs) {
      const k = answerKey(r, rfe.format);
      if (k) counts.set(k, (counts.get(k) ?? 0) + 1);
    }
    const top = [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
    clusterAnswers.push(top);
    if (rfe.format === "scale" && top) scaleValues.push(Number(top));
  }
  const effective = byCluster.size;
  if (effective === 0) return { effective: 0, agreement: 0 };

  if (rfe.format === "scale" && scaleValues.length) {
    const sorted = [...scaleValues].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    const near = scaleValues.filter((v) => Math.abs(v - median) <= 1).length;
    return { effective, agreement: near / effective, leading: String(median) };
  }

  const structured = clusterAnswers.filter((a): a is string => !!a);
  if (!structured.length) return { effective, agreement: 1 };
  const tally = new Map<string, number>();
  for (const a of structured) tally.set(a, (tally.get(a) ?? 0) + 1);
  const [leading, count] = [...tally.entries()].sort((a, b) => b[1] - a[1])[0];
  return { effective, agreement: count / structured.length, leading };
}

/**
 * The N rule: stop early once the minimum is met and responses agree; at the
 * target, extend once if they diverge; otherwise close.
 */
export function evaluateN(
  rfe: Pick<Rfe, "type" | "stakes" | "targetOverride" | "format" | "extended">,
  responses: Response[],
  clusterOf: (handle: string) => string,
  params: NParams,
  opts: { minRaiseUsd?: number; seatsSold?: number; seatPriceUsd?: number } = {},
): NStatus {
  const { minimum, target } = nBounds(rfe, params, opts.minRaiseUsd, opts.seatPriceUsd);

  if (rfe.type === "capital") {
    const sold = opts.seatsSold ?? 0;
    return {
      minimum,
      target,
      effective: sold,
      raw: sold,
      agreement: 1,
      state: sold >= target ? "close" : "collecting",
      reason: sold >= target ? "Minimum met" : `${target - sold} more seats to the minimum`,
    };
  }

  const { effective, agreement, leading } = effectiveResponses(rfe, responses, clusterOf);
  const base = { minimum, target, effective, raw: responses.length, agreement, leading };
  const pct = (n: number) => `${Math.round(n * 100)}%`;

  if (effective < minimum) {
    return { ...base, state: "collecting", reason: `Needs ${minimum - effective} more ${minimum - effective === 1 ? "answer" : "answers"} from different kinds of people` };
  }
  if (agreement >= params.AGREEMENT_STOP && effective < target) {
    return { ...base, state: "close", reason: `Closed early: ${pct(agreement)} of answers agree` };
  }
  if (effective >= target) {
    if (agreement < params.DIVERGENCE_EXTEND && !rfe.extended) {
      return {
        ...base,
        state: "extend",
        reason: `Answers split (${pct(agreement)} agree), so the agent is asking ${params.EXTEND_BY} more people`,
      };
    }
    return { ...base, state: "close", reason: `All ${target} answers in; ${pct(agreement)} agree` };
  }
  return { ...base, state: "collecting", reason: `${target - effective} more ${target - effective === 1 ? "answer" : "answers"} wanted, ${target} in all` };
}
