import Link from "next/link";
import { HERO_CLARITY, HERO_SUBLINE, HERO_SUPPORT, HERO_TITLE } from "@av/protocol";
import { HeroShoal } from "@/components/hero-shoal";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/**
 * Homepage hero — concept C (live canvas shoal) + locked messaging.
 * Brand-first: Shoalyard as hero signal; tagline Many hands. One yard.
 */
export function HomeHero() {
  return (
    <section
      aria-label="Shoalyard"
      className="relative left-1/2 right-1/2 -ml-[50vw] -mr-[50vw] -mt-8 mb-10 w-screen overflow-hidden bg-white"
    >
      <div className="relative mx-auto min-h-[min(92vh,860px)] w-full max-w-[1440px]">
        <HeroShoal className="pointer-events-none absolute inset-0 h-full w-full" />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 left-0 w-full bg-gradient-to-b from-white via-white/92 to-white/70 md:hidden"
        />

        <div className="relative z-10 flex min-h-[min(92vh,860px)] flex-col justify-center px-6 py-16 sm:px-10 lg:px-16">
          <div className="flex max-w-[680px] flex-col gap-7">
            <h1
              className="m-0 font-heading text-[clamp(2.5rem,6vw,4.5rem)] leading-none tracking-[-0.02em] text-ink"
              style={{ fontStretch: "112%", fontWeight: 760 }}
            >
              {HERO_TITLE}
            </h1>
            <p className="m-0 font-heading text-[clamp(1.5rem,3vw,2rem)] leading-tight tracking-[-0.01em] text-ink" style={{ fontWeight: 600 }}>
              {HERO_SUBLINE}
            </p>
            <p className="m-0 text-base font-medium text-seaglass">{HERO_CLARITY}</p>
            <p className="m-0 max-w-[540px] text-lg leading-relaxed text-metal sm:text-[19px]">{HERO_SUPPORT}</p>
            <div className="flex flex-wrap items-center gap-4">
              <Link
                href="/invest"
                className={cn(buttonVariants({ size: "lg" }), "h-[52px] rounded-none px-[26px] text-base font-semibold")}
              >
                Put capital in
              </Link>
              <Link
                href="/contribute"
                className={cn(
                  buttonVariants({ size: "lg", variant: "outline" }),
                  "h-[52px] rounded-none px-[26px] text-base font-semibold",
                )}
              >
                Steer and teach
              </Link>
              <Link href="#how-it-works" className="text-base font-semibold text-seaglass hover:text-seaglass-deep">
                How it works
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
