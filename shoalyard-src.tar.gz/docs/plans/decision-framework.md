# Decision framework and visibility (decided Oct 30, 2026)

## Who decides

| Kind | Examples | Who decides |
|---|---|---|
| Routine | Scheduling, follow-ups, drafting, spend under GATE_SPEND_USD | Agent alone |
| Judgement call | Confidence below ADVISORY_CONFIDENCE, or contradicts an adopted lesson | Agent asks members first, then decides and records why |
| Risky (needs sign-off) | Spend over GATE_SPEND_USD ($100), contracts, pricing, new email domain, public posts, regulated activity, hiring or contracting a person | Steward signs off |
| Big questions | Pivot or shut down, change settings, add a classification value, take on a partner or co-founder, share member data outside the venture | Unit holders vote |
| Rules | Constitution changes | Unit holders, supermajority after notice |

Keep the existing classifier bins (auto / advisory / gated) as the implementation; relabel them in copy as "Agent decided" / "Asked members first" / "Needs sign-off". "Big questions" maps to the existing holder-vote (reserved matter) flow; add the new items to that list as a setting.

## Who sees what (tiered like lessons)

| Tier | Sees |
|---|---|
| Public | That a decision was made, its kind, who made it, the outcome, money in and out with amounts, refunds. This keeps the mark's public-ledger promise. |
| Verified members, including seat holders without units | A short reason for each decision |
| People with units in that venture, plus anyone holding Protocol units | Full reasoning, options considered, member answers, lessons followed, agent confidence |
| Steward | Everything, including decisions held private to protect confidential customer terms or member privacy; these publish after PRIVATE_DECISION_MAX_DAYS (90) |

Seats buy access to requests, not the record: seat holders without units get the verified-member view.

Setting: DECISION_DETAIL_VISIBLE_TO, default "unit holders", mirroring LESSONS_VISIBLE_TO.

## Constitution
- Article 3 becomes something like: "Every decision is recorded. The public sees what was decided, by whom and what it cost; people who have earned units see the reasoning. A decision can be held private for up to {PRIVATE_DECISION_MAX_DAYS} days to protect a customer's confidential terms or a member's privacy; the record still shows that it happened and when it will be published."
- Article 7: three upheld breaches withdraw the mark permanently. No coming back; breaches don't expire.
- Lessons are adopted automatically above the confidence setting; only lessons that would change a setting go to a vote (already the behaviour).

## Who delivers the work (decided Oct 30, 2026)
- New classification field `workDelivery`: "Agent only" | "Agent plus contractors" | "Employees". The agent proposes it and the steward confirms, like the other fields.
- Level 1 (agent only) is the default. Level 2 (contractors) is allowed per venture: hiring or contracting a person needs steward sign-off, and a level-2 venture's pitch needs steward sign-off. Level 3 is off: setting EMPLOYMENT_ALLOWED=false, protected, with an open Protocol request listing what turning it on needs (employer of record, payroll, insurance).
- Workers are not members: contractors are paid cash per job (labor), which never earns units. Members earn units for judgement, access and knowledge. One person can be both; the ledger keeps them separate (new ledger kind e.g. "contractor-pay").
- UI: the "Who does what" block gets a third column, "Paid for the work", on level-2 ventures. Level-2 pitch decks show labor costs and the contractor plan.
- Re-tag the seed: Lumper Line, Wet Ink and Chairside Shifts are likely level 2 (check their memos); the rest level 1.
- Also: rename the "Pilot: the agent follows a script for now" label to "Demo mode: the agent's replies are pre-written. Connect a Claude API key to run it live."
