import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams, type BudgetLine, type PitchDeck, type PlanInput } from "@av/schema";
import { latestDeck } from "../src/deck";
import { DECK_DRAFTS } from "../src/deck-content";
import { businessPlanFor, planConversion, planSummary } from "../src/plan";
import { buildSeed } from "../src/seed";
import { proofBudget, seatMath, seatPlanFor } from "../src/sizing";
import { classificationOf } from "../src/tags";

const params = defaultParams();
const noFees = { ...params, PAYMENT_FEES: { pct: 0, fixedUsd: 0 } };
const line = (key: string, usd: number, monthlyUsd?: number, category: BudgetLine["category"] = "tools"): BudgetLine => ({ key, label: key, category, usd, monthlyUsd, claimId: `c-budget-${key}`, stretch: false });

const input = (patch: Partial<PlanInput> = {}): PlanInput => ({
  proofMonths: 2,
  horizonMonths: 12,
  usesPerCustomerMonth: 1,
  variableUsdPerUse: 0,
  firstLeadMonth: 1,
  leadsPerMonth: 10,
  leadGrowthPct: 0,
  leadToPaid: 0.1,
  churnPct: 0,
  claims: { uses: "c-price", variable: "c-plan-variable", leads: "c-plan-leads", churn: "c-plan-churn", conversion: "c-plan-conversion" },
  ...patch,
});

const deck = (price: number, plan: PlanInput, budget = [line("tools", 200, 100), line("formation", 200, undefined, "formation")], cadence: PitchDeck["pricing"]["cadence"] = "month"): Pick<PitchDeck, "budget" | "pricing" | "plan"> => ({
  budget,
  pricing: { claimId: "c-price", price, unit: "customer", cadence },
  plan,
});

test("the plan adds whole customers from the funnel and finds break-even, payback and the after-proof need", () => {
  const plan = businessPlanFor(deck(100, input()), "Small business", noFees)!;
  assert.deepEqual(
    plan.months.map((m) => m.customers),
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
  );
  assert.equal(plan.months[0].oneTimeUsd, 200, "one-time lines land in month 1");
  assert.equal(plan.months[0].netUsd, 100 - 100 - 200);
  assert.deepEqual(
    plan.months.slice(0, 3).map((m) => m.cumulativeUsd),
    [-200, -100, 100],
  );
  assert.equal(plan.breakEvenCustomers, 1);
  assert.equal(plan.breakEvenMonth, 1);
  assert.equal(plan.paybackMonth, 3);
  assert.equal(plan.afterProofNeedUsd, 0, "past the proof it pays its own way");
  assert.equal(plan.proofBudgetUsd, 400 + 80, "itemized lines plus contingency at the seat buffer");
});

test("a slow ramp never breaks even: the plan says so and sizes what an adopter would need", () => {
  const plan = businessPlanFor(deck(15, input({ leadToPaid: 0.05 })), "Small business", noFees)!;
  assert.equal(plan.breakEvenCustomers, 7);
  assert.equal(plan.breakEvenMonth, undefined);
  assert.equal(plan.months.at(-1)!.customers, 6);
  assert.ok(plan.afterProofNeedUsd > 0);
  const atProof = plan.months[1].cumulativeUsd;
  assert.equal(plan.afterProofNeedUsd, atProof - Math.min(...plan.months.slice(2).map((m) => m.cumulativeUsd)));
  assert.match(planSummary(plan).join(" "), /doesn't reach that in 12 months/);
});

test("churn removes whole customers; card fees and per-use costs count against each sale", () => {
  const churned = businessPlanFor(deck(100, input({ churnPct: 50 })), "Small business", noFees)!;
  assert.deepEqual(
    churned.months.slice(0, 4).map((m) => m.customers),
    [1, 2, 2, 2],
  );
  const perUse = businessPlanFor(deck(45, input({ usesPerCustomerMonth: 2, variableUsdPerUse: 32 }), undefined, "per-use"), "Small business", params)!;
  assert.equal(perUse.revenuePerCustomerMonthUsd, 90);
  assert.equal(perUse.variablePerCustomerMonthUsd, Math.round((64 + 90 * 0.029 + 0.6) * 100) / 100);
  const losing = businessPlanFor(deck(45, input({ usesPerCustomerMonth: 1, variableUsdPerUse: 50 }), undefined, "per-use"), "Small business", params)!;
  assert.equal(losing.breakEvenCustomers, undefined);
  assert.match(planSummary(losing).join(" "), /costs more to serve than they pay/);
});

test("the funnel setting sets conversion unless the deck sets its own with a claim", () => {
  assert.equal(planConversion({}, "Small business", params).rate, 0.5 * 0.4 * 0.34);
  assert.deepEqual(planConversion({ leadToPaid: 0.25 }, "Small business", params), { rate: 0.25, from: "deck" });
});

test("seats are the proof budget at the venture's price, with no cap on the count, and the band ends shown", () => {
  const budget = [line("compute", 600, 150, "api"), line("insurance", 380, 95, "insurance"), line("formation", 400, undefined, "formation"), line("templates", 600, undefined, "legal")];
  const proof = proofBudget(budget, params.SEAT_BUFFER_PCT);
  assert.deepEqual(proof, { itemizedUsd: 1980, contingencyUsd: 396, totalUsd: 2376 });
  const plan = seatPlanFor({ budget, requestPlan: [], roster: [] }, params, "1.10");
  assert.equal(plan.priceUsd, params.SEAT_PRICE_MIN_USD, "without a proposal the price is the lowest allowed");
  assert.equal(plan.budgetSeats, 238);
  assert.equal(plan.min, 238, "no cap holds the count down");
  assert.equal(plan.overCap, undefined);
  assert.equal(plan.shortfallUsd, 0, "seats at the price always cover the proof");
  assert.deepEqual(
    plan.atPrices.map((a) => [a.priceUsd, a.min]),
    [
      [10, 238],
      [100, Math.max(params.SEAT_FLOOR, 24)],
    ],
  );
  const at25 = seatPlanFor({ budget, requestPlan: [], roster: [], priceUsd: 25 }, params, "1.10");
  assert.equal(at25.min, 96);
  const lines = seatMath(at25);
  assert.ok(lines.some((l) => l.label === "Seats for the proof budget" && l.value === "96 seats"));
  assert.ok(lines.some((l) => l.label === "At $10 a seat" && l.value === "238 seats · $2,380"));
  assert.ok(!lines.some((l) => /Not covered/.test(l.label)));
});

test("every seeded venture has an itemized proof budget of about $1,500–$5,000 and a 12-month plan", () => {
  const s = buildSeed();
  for (const slug of Object.keys(DECK_DRAFTS)) {
    const d = latestDeck(s, slug)!;
    const plan = businessPlanFor(d, classificationOf(s.ventures.find((v) => v.slug === slug)!).customer, params)!;
    assert.ok(plan, slug);
    assert.equal(plan.months.length, 12);
    assert.ok(d.budget.filter((b) => b.category === "shared-services").length === 2, `${slug} uses the shared back office`);
    assert.ok(!d.budget.some((b) => b.category === "formation"), `${slug} doesn't form its own company`);
    assert.ok(plan.proofBudgetUsd >= 1500 && plan.proofBudgetUsd <= 5000, `${slug}: $${plan.proofBudgetUsd}`);
    const plan2 = d.currentRule ?? d.seatPlan;
    assert.equal(plan2.proofBudgetUsd, plan.proofBudgetUsd, `${slug}: seats are sized from the same proof budget`);
    for (const b of d.budget.filter((x) => x.monthlyUsd !== undefined)) assert.equal(b.usd, b.monthlyUsd! * d.plan!.proofMonths);
    for (const cat of ["api", "shared-services", "domain"] as const) assert.ok(d.budget.some((b) => b.category === cat), `${slug} prices ${cat}`);
  }
});
