import type { Member, ParamValues, Rfe, Store, Venture } from "@av/schema";
import { seatPriceOf } from "./sizing";
import { latestDeck } from "./deck";
import { rosterFill } from "./roster";
import { lessonsFor } from "./learning";
import { hasSeat, isLive, isOpen, logDecision, nStatusFor, seatsSold, type RfeDraft } from "./ops";
import { resolveParams } from "./params";
import { holdingsFor, type HoldingRow } from "./queries";
import { seatsNeeded } from "./n-engine";
import { addDays } from "./util";

/* ---------- the roster: see roster.ts ---------- */

export { fitsRole, rosterFill, type RosterRow } from "./roster";

export interface YourVenture extends HoldingRow {
  /** Roster places this member fills, plus steward if they run it. */
  roles: string[];
  openRequests: number;
}

/** The ventures a member is part of: seats held, roles filled and units earned. */
export function yourVentures(store: Store, handle: string, params: ParamValues = resolveParams(store)): YourVenture[] {
  const rows = new Map(holdingsFor(store, handle, params).map((r) => [r.venture.id, r]));
  const out: YourVenture[] = [];
  for (const venture of store.ventures) {
    const roles = rosterFill(store, venture)
      .filter((r) => r.filled.includes(handle))
      .map((r) => r.role.label);
    if (venture.stewardHandle === handle) roles.unshift("Steward");
    const row = rows.get(venture.id);
    if (!row && roles.length === 0) continue;
    out.push({
      ...(row ?? { venture, seat: false, refundedUsd: 0, units: 0, vested: 0, accepted: 0, forfeited: 0, pctOfInterests: 0, distributedUsd: 0 }),
      roles,
      openRequests: store.rfes.filter((r) => r.ventureId === venture.id && isOpen(r)).length,
    });
  }
  return out;
}

/* ---------- network gaps ---------- */

export type NetworkGap =
  | { kind: "slot"; ventureId: string; key: string; label: string; open: number }
  | { kind: "quorum"; ventureId: string; key: string; label: string; rfeId: string };

export function networkGaps(store: Store, params: ParamValues = resolveParams(store)): NetworkGap[] {
  const gaps: NetworkGap[] = [];
  for (const v of store.ventures.filter((x) => !x.isProtocol && isLive(x) && x.status !== "generated")) {
    for (const row of rosterFill(store, v)) {
      if (row.open - row.pending.length > 0) gaps.push({ kind: "slot", ventureId: v.id, key: row.role.key, label: row.role.label, open: row.open - row.pending.length });
    }
  }
  const cutoff = addDays(store.meta.clock, -params.QUORUM_GAP_DAYS);
  for (const r of store.rfes) {
    if (!isOpen(r) || r.kind !== "request" || r.gtm || r.type === "capital" || r.assignedTo || r.postedAt > cutoff) continue;
    const v = store.ventures.find((x) => x.id === r.ventureId);
    if (!v || v.isProtocol || !isLive(v)) continue;
    const n = nStatusFor(store, r, params);
    if (n.effective < n.minimum) gaps.push({ kind: "quorum", ventureId: v.id, key: r.id, label: r.audience, rfeId: r.id });
  }
  return gaps;
}

/** Open recruiting drafts already aimed at a gap, so the agent doesn't draft twice. */
export function draftsForGap(store: Store, ventureId: string, key: string): Rfe[] {
  return store.rfes.filter((r) => r.ventureId === ventureId && r.gtm?.purpose === "gap" && r.gtm.gap === key && isOpen(r));
}

/** X and LinkedIn drafts for one gap. Gated: a human sends them (Article 8 disclosure included). */
export function gapDrafts(store: Store, venture: Venture, gap: NetworkGap, steward: string): RfeDraft[] {
  const ref = `/v/${venture.slug}`;
  const who = gap.label.toLowerCase();
  const noun = gap.kind === "slot" ? `${/^[aeiou]/.test(who) ? "an" : "a"} ${who}` : who;
  const line =
    gap.kind === "slot"
      ? `${venture.name} is run by an AI agent, and it needs ${noun}.`
      : `${venture.name} is run by an AI agent, and it needs answers from ${noun}.`;
  const youAre = gap.kind === "slot" ? `If you work as ${noun}` : "If that's you";
  const why = venture.memo?.problem ?? venture.tagline;
  return [
    {
      type: "action",
      title: `Recruit ${noun} for ${venture.name} on X`,
      question: "Post this thread from the venture's account if it reads right. Arrivals are tracked by the ref link.",
      recommendation: "Post as drafted",
      stakes: "low",
      format: "action",
      offerUnits: 0,
      audience: `Steward @${steward}`,
      assignedTo: steward,
      gtm: {
        channel: "x_post",
        purpose: "gap",
        gap: gap.key,
        posts: [
          `${line} ${why}`,
          `Answer its requests and get paid in a share of its profits. A seat gets you its requests. It is not a share and pays nothing back. ${ref}`,
        ],
      },
    },
    {
      type: "action",
      title: `Recruit ${noun} for ${venture.name} on LinkedIn`,
      question: "Post this from the steward's LinkedIn if it reads right. Arrivals are tracked by the ref link.",
      recommendation: "Post as drafted",
      stakes: "low",
      format: "action",
      offerUnits: 0,
      audience: `Steward @${steward}`,
      assignedTo: steward,
      gtm: {
        channel: "linkedin",
        purpose: "gap",
        gap: gap.key,
        posts: [
          `${line}\n\n${why}\n\n${youAre}, you can answer its requests and get paid in a share of its profits. Every decision it makes is on a public log. ${ref}`,
        ],
      },
    },
  ];
}

/**
 * Turn one open gap per venture into gated X and LinkedIn drafts. Skips gaps
 * already drafted in the last week, so the steward isn't asked twice.
 */
export function draftGapRecruiting(store: Store, venture: Venture, model = "script", params: ParamValues = resolveParams(store)) {
  const recent = addDays(store.meta.clock, -7);
  const gap = networkGaps(store, params).find(
    (g) =>
      g.ventureId === venture.id &&
      !store.rfes.some((r) => r.ventureId === venture.id && r.gtm?.purpose === "gap" && r.gtm.gap === g.key && (isOpen(r) || r.postedAt > recent)),
  );
  if (!gap) return [];
  const why =
    gap.kind === "slot"
      ? `${gap.open} ${gap.label.toLowerCase()} ${gap.open === 1 ? "spot is" : "spots are"} still open.`
      : `“${store.rfes.find((r) => r.id === gap.rfeId)?.title}” has been short of answers for ${params.QUORUM_GAP_DAYS} days.`;
  return gapDrafts(store, venture, gap, venture.stewardHandle).map(
    (draft) =>
      logDecision(store, {
        ventureId: venture.id,
        title: draft.title,
        reasoning: `${why} No member fits yet. The steward will post the draft, and we'll count who joins from it.`,
        confidence: 0.8,
        model,
        facts: { publicPost: true },
        rfe: draft,
      }).decision,
  );
}

/* ---------- before you take a seat: warnings, never blocks ---------- */

export interface ReadinessItem {
  key: "budget" | "reach" | "demand" | "lessons";
  label: string;
  value: string;
  tone: "good" | "weak" | "unknown";
  detail: string;
}

function reachTerms(v: Venture): string[] {
  const words = `${v.customers.segment} ${v.memo?.problem ?? ""}`
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 4);
  return [...new Set(words)].filter((w) => !["their", "which", "today", "every", "about", "buyer", "buyers", "pay"].includes(w));
}

export function canReachBuyer(member: Member, v: Venture): boolean {
  const terms = reachTerms(v);
  const hay = [...member.profile.canReach, ...member.profile.verticals, member.industry].join(" ").toLowerCase();
  return terms.some((t) => hay.includes(t.replace(/s$/, "")));
}

/** With lessonsVisible off (Article 3), the lessons row gives counts, not lesson text. */
export function readiness(store: Store, v: Venture, params: ParamValues = resolveParams(store), lessonsVisible = true): ReadinessItem[] {
  const qualified = store.members.filter((m) => m.qualification === "qualified" && m.handle !== v.stewardHandle);
  const reach = qualified.filter((m) => canReachBuyer(m, v));
  const need = latestDeck(store, v.id)?.seatPlan.min ?? seatsNeeded(v.minRaiseUsd, seatPriceOf(v, params));
  const sold = seatsSold(store, v.id);
  const plausible = sold + qualified.filter((m) => !hasSeat(store, v.id, m.handle) && canReachBuyer(m, v)).length + Math.ceil(qualified.length * params.READINESS_PLAUSIBLE_SHARE);
  const demand = store.rfes.find((r) => r.ventureId === v.id && r.demandCheck);
  const dn = demand ? nStatusFor(store, demand, params) : undefined;
  const contradicted = v.contradictions.map((c) => ({ ...c, lesson: store.lessons.find((l) => l.id === c.lessonId) }));
  const applies = new Set(lessonsFor(store, v).map((l) => l.id));

  return [
    {
      key: "budget",
      label: "Seats",
      value: v.status === "pitched" ? `${sold} of ${need} sold; likely to reach about ${plausible}` : `Sold all ${need} needed`,
      tone: v.status !== "pitched" || plausible >= need ? "good" : "weak",
      detail: `A $${v.minRaiseUsd} budget to the first customer needs ${need} seats at $${seatPriceOf(v, params)}. The estimate counts seats sold, verified members who know the buyer, and ${Math.round(params.READINESS_PLAUSIBLE_SHARE * 100)}% of everyone else.`,
    },
    {
      key: "reach",
      label: "Members who know the buyer",
      value: `${reach.length} of ${qualified.length} verified members`,
      tone: reach.length >= 3 ? "good" : reach.length ? "weak" : "unknown",
      detail: `Members whose verified profile or stated reach mentions ${v.customers.segment.toLowerCase()}.`,
    },
    {
      key: "demand",
      label: "‘Would you buy this?’ poll",
      value: !demand ? "Not posted" : dn?.leading ? `${dn.leading} (${Math.round(dn.agreement * 100)}% of ${dn.effective})` : `${dn?.raw ?? 0} answers so far`,
      tone: !demand ? "unknown" : dn?.leading && /yes/i.test(dn.leading) ? "good" : dn?.leading ? "weak" : "unknown",
      detail: demand ? (/any (qualified|verified) member can answer/i.test(demand.question) ? `“${demand.question}”` : `“${demand.question}” Any verified member can answer.`) : "The agent posts one poll per idea.",
    },
    {
      key: "lessons",
      label: "Goes against past lessons",
      value: !contradicted.length ? "No" : lessonsVisible ? contradicted.map((c) => c.lessonId).join(", ") : `${contradicted.length}`,
      tone: contradicted.length ? "weak" : "good",
      detail: contradicted.length
        ? !lessonsVisible
          ? `Goes against ${contradicted.length} earlier lesson${contradicted.length === 1 ? "" : "s"} (visible to members). The agent's reason: ${contradicted.map((c) => c.reason).join(" ")}`
          : contradicted.map((c) => `${c.lessonId}${c.lesson ? ` (“${c.lesson.headline}”)` : ""}: ${c.reason}`).join(" ")
        : `Checked against ${applies.size} lessons from similar ventures.`,
    },
  ];
}
