import { RFE_TYPES, VENTURE_STATUSES } from "@av/schema";
import { z } from "zod";

/** One operator decision, as the script or Claude proposes it. */
export const Step = z.object({
  title: z.string().min(4).describe("The decision, as an imperative sentence"),
  reasoning: z.string().min(10).describe("Why, in two or three plain sentences, citing numbers or member answers"),
  summary: z
    .string()
    .max(200)
    .optional()
    .describe("One plain sentence on why, for verified members. No lesson ids, member names or customer terms"),
  confidence: z.number().min(0).max(1).describe("Self-reported confidence; below the advisory threshold it asks members"),
  facts: z
    .object({
      spendUsd: z.number().optional(),
      budgetLine: z.string().optional(),
      contract: z.boolean().optional(),
      pricingChange: z.boolean().optional(),
      newOutboundDomain: z.boolean().optional(),
      publicPost: z.boolean().optional(),
      hiresPerson: z.boolean().optional(),
      bigQuestion: z.string().optional(),
    })
    .optional()
    .describe(
      "Facts the classifier gates on. Be honest: any price change, contract, new domain, public post or hire must be flagged. bigQuestion is a RESERVED_MATTERS key (pivot, voluntary-wind-down, parameter-amendment, add-classification-value, partner-or-cofounder, share-member-data) that unit holders vote on",
    ),
  outcome: z.string().optional(),
  embargoReason: z
    .enum(["third-party confidentiality", "member privacy", "competitive timing", "legal"])
    .optional()
    .describe("Only if the decision must be withheld; the reason and release date are still published"),
  transition: z.enum(VENTURE_STATUSES).optional().describe("Lifecycle move this decision makes, if any"),
  lessonIds: z
    .array(z.string().regex(/^L-\d{3}$/))
    .optional()
    .describe("Adopted lessons this decision follows, e.g. L-004. Cite them in the reasoning too"),
  rfe: z
    .object({
      type: z.enum(RFE_TYPES),
      title: z.string(),
      question: z.string(),
      recommendation: z.string(),
      stakes: z.enum(["low", "medium", "high"]),
      format: z.enum(["choice", "scale", "text", "action"]),
      options: z.array(z.string()).optional(),
      offerUnits: z.number().min(0).max(15),
      audience: z.string(),
    })
    .optional()
    .describe("A request to post with this decision. For choices, put the recommended option first"),
  gtm: z
    .object({
      channel: z.enum(["x_post", "linkedin", "outreach"]),
      posts: z.array(z.string()).optional(),
      segments: z
        .array(z.object({ segment: z.string(), queries: z.array(z.string()), template: z.string() }))
        .optional(),
    })
    .optional()
    .describe("A recruiting draft for a human to post. The agent never posts or DMs"),
  when: z.array(z.enum(VENTURE_STATUSES)).optional().describe("Script only: wait until the venture is in one of these states"),
});
export type Step = z.infer<typeof Step>;
