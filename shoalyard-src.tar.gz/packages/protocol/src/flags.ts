import type { Flag, ParamValues, Store, Venture } from "@av/schema";
import { totalVestedUnits } from "./economics";
import { ledger, memberByHandle, notify, postRfe, ProtocolError, rfeById, protocolVenture, ventureById } from "./ops";
import { markFor, resolveParams } from "./params";
import { addDays, newId } from "./util";

export const FLAG_OPTIONS = ["Uphold the flag", "Dismiss the flag"] as const;

/**
 * Any qualified member can flag a public decision, post or idea as a conduct
 * concern. Members resolve it by vote; the Protocol's steward only confirms
 * that the result follows the constitution. A steward never confirms a vote
 * about a venture they run: then the member vote stands on its own (Article 7).
 */
export function flagItem(
  store: Store,
  input: { by: string; kind: Flag["target"]["kind"]; id: string; reason: string },
): Flag {
  const params = resolveParams(store);
  const member = memberByHandle(store, input.by);
  if (member?.qualification !== "qualified") throw new ProtocolError("Only verified members can report a concern.");
  const reason = input.reason.trim();
  if (reason.length < 8) throw new ProtocolError("Say what the concern is, in a sentence.");
  let ventureId: string;
  let label: string;
  if (input.kind === "decision") {
    const d = store.decisions.find((x) => x.id === input.id);
    if (!d) throw new ProtocolError("No such decision.");
    ventureId = d.ventureId;
    label = d.title;
  } else if (input.kind === "rfe") {
    const r = rfeById(store, input.id);
    if (!r) throw new ProtocolError("No such post.");
    ventureId = r.ventureId;
    label = r.title;
  } else {
    const v = ventureById(store, input.id);
    ventureId = v.id;
    label = `${v.name}: the idea`;
  }
  if (store.flags.some((f) => f.target.id === input.id && f.status === "voting")) {
    throw new ProtocolError("That is already flagged; vote on the open flag instead.");
  }
  const venture = ventureById(store, ventureId);
  const voteIn = totalVestedUnits(store, venture.id) > 0 ? venture : protocolVenture(store);
  const flag: Flag = {
    id: newId(store, "flag"),
    ventureId,
    target: { kind: input.kind, id: input.id, label },
    by: member.handle,
    reason,
    at: store.meta.clock,
    status: "voting",
  };
  const rfe = postRfe(store, voteIn.id, {
    type: "judgment",
    kind: "governance",
    title: `Conduct flag: “${label}”`,
    question: `@${member.handle} flagged this as a conduct concern: “${reason}” Does it break the conduct rules (Article 8)?`,
    recommendation: "Members decide; the agent does not recommend on its own conduct",
    confidence: 0.5,
    stakes: "medium",
    format: "choice",
    options: [...FLAG_OPTIONS],
    offerUnits: 0,
    audience: `${voteIn.isProtocol ? "Protocol" : voteIn.name} holders`,
    governance: {
      matter: "conduct-flag",
      threshold: "simple",
      windowEndsAt: addDays(store.meta.clock, params.VOTE_WINDOW_DAYS),
      effect: "If upheld and certified, a breach is logged publicly. Repeated breaches withdraw the mark (Article 7).",
    },
  });
  rfe.flagId = flag.id;
  flag.voteRfeId = rfe.id;
  store.flags.push(flag);
  notify(store, venture.id, venture.stewardHandle, `@${member.handle} flagged “${label}”; members are voting`);
  return flag;
}

export const MEMBER_VOTE_STANDS = "member vote";

/** Who confirms a flag's result: the Protocol's steward, unless they run the flagged venture. */
export function flagConfirmer(store: Store, flag: Pick<Flag, "ventureId">): { handle: string; conflicted: boolean } {
  const handle = protocolVenture(store).stewardHandle;
  return { handle, conflicted: ventureById(store, flag.ventureId).stewardHandle === handle };
}

/** Called when the flag's vote closes. */
export function settleFlag(store: Store, flagId: string, upheld: boolean) {
  const flag = store.flags.find((f) => f.id === flagId);
  if (!flag || flag.status !== "voting") return;
  flag.status = upheld ? "upheld" : "dismissed";
  const venture = ventureById(store, flag.ventureId);
  const confirmer = flagConfirmer(store, flag);
  if (confirmer.conflicted) {
    recordResult(store, flag, MEMBER_VOTE_STANDS);
    notify(store, venture.id, venture.stewardHandle, `the vote on the flag “${flag.target.label}” closed (${flag.status}). You run ${venture.name}, so the vote stands without your confirmation`);
    return;
  }
  notify(store, venture.id, confirmer.handle, `the vote on the flag “${flag.target.label}” closed (${flag.status}); confirm it on /steward`);
}

export function breachCount(store: Store, ventureId: string): number {
  return store.ledger.filter((l) => l.ventureId === ventureId && l.kind === "breach").length;
}

export const MARK_WITHDRAWN_NOTE = "Mark withdrawn for good";

/** Breaches never expire, and a withdrawn mark never comes back, even if the setting is later raised (Article 7). */
export function markWithdrawn(store: Store, ventureId: string): boolean {
  return withdrawalRecorded(store, ventureId) || breachCount(store, ventureId) >= resolveParams(store).MARK_WITHDRAW_BREACHES;
}

function withdrawalRecorded(store: Store, ventureId: string): boolean {
  return store.ledger.some((l) => l.ventureId === ventureId && l.kind === "status" && l.note.startsWith(MARK_WITHDRAWN_NOTE));
}

/** The mark line for a venture, or undefined once it has lost the mark or been handed off (Article 7). */
export function markForVenture(store: Store, venture: Pick<Venture, "id" | "name" | "status">, params: ParamValues = resolveParams(store)): string | undefined {
  return venture.status === "handed-off" || markWithdrawn(store, venture.id) ? undefined : markFor(params, venture.name);
}

/**
 * The mark line a venture shows, if any (Article 7).
 * Protocol ventures get none — they *are* the Protocol; others lose it once withdrawn or handed off.
 */
export function ventureAttribution(
  store: Store,
  venture: Pick<Venture, "id" | "name" | "status" | "isProtocol">,
  params: ParamValues = resolveParams(store),
): { mark?: string; lines: string[] } {
  if (venture.isProtocol) return { lines: [] };
  const mark = markForVenture(store, venture, params);
  return { mark, lines: mark ? [mark] : [] };
}

/** The Protocol's steward confirms that the vote's result follows the constitution. An upheld flag becomes a public breach. */
export function certifyFlag(store: Store, flagId: string, by: string) {
  const flag = store.flags.find((f) => f.id === flagId);
  if (!flag) throw new ProtocolError("No such flag.");
  if (flag.status === "voting") throw new ProtocolError("Members are still voting on this flag.");
  if (flag.certifiedAt) return;
  const venture = ventureById(store, flag.ventureId);
  const confirmer = flagConfirmer(store, flag);
  if (confirmer.conflicted || by === venture.stewardHandle) {
    throw new ProtocolError(`@${venture.stewardHandle} runs ${venture.name}, so the member vote stands without their confirmation (Article 7).`);
  }
  if (by !== confirmer.handle) throw new ProtocolError(`Only @${confirmer.handle} confirms votes on reported concerns.`);
  recordResult(store, flag, by);
}

function recordResult(store: Store, flag: Flag, by: string) {
  const venture = ventureById(store, flag.ventureId);
  flag.certifiedAt = store.meta.clock;
  flag.certifiedBy = by;
  if (flag.status !== "upheld") return;
  ledger(store, {
    ventureId: venture.id,
    kind: "breach",
    ref: flag.id,
    note: `Conduct breach confirmed by member vote: “${flag.target.label}”. ${flag.reason}`,
  });
  const params = resolveParams(store);
  if (breachCount(store, venture.id) >= params.MARK_WITHDRAW_BREACHES && !withdrawalRecorded(store, venture.id)) {
    ledger(store, {
      ventureId: venture.id,
      kind: "status",
      note: `${MARK_WITHDRAWN_NOTE} after ${params.MARK_WITHDRAW_BREACHES} confirmed breaches (Article 7)`,
    });
  }
}
