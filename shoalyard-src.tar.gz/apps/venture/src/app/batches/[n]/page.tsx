import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { batchShareCard, canReadLessons, cohortByNumber, batchLabel, batchVentures, segmentLabel, shareText, ventureAttribution } from "@av/protocol";
import { ShareMenu } from "@/components/share-menu";
import { ShareLanding } from "@/components/scarcity";
import { isShareLanding } from "@/lib/share";
import { LESSON_TOPIC_LABELS } from "@av/schema";
import { StatusBadge } from "@/components/badges";
import { BatchPanel, NobodySelects } from "@/components/batch-ui";
import { MembersOnlyLessons } from "@/components/lessons-gate";
import { LessonLine } from "@/components/protocol-ui";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { VentureAttribution } from "@/components/venture-attribution";
import { getData } from "@/lib/data";
import { formatUsd } from "@/lib/format";

function parse(n: string): number | undefined {
  return /^\d{1,4}$/.test(n) ? Number(n) : undefined;
}

export async function generateMetadata(props: PageProps<"/batches/[n]">): Promise<Metadata> {
  const n = parse((await props.params).n);
  return { title: n ? batchLabel(n) : "Batch not found" };
}

export default async function BatchPage(props: PageProps<"/batches/[n]">) {
  const n = parse((await props.params).n);
  const data = await getData();
  const { store } = data;
  const landing = (await isShareLanding(await props.searchParams)) && !(data.signedIn && data.member?.qualification === "qualified");
  const cohort = n === undefined ? undefined : cohortByNumber(store, n);
  if (!cohort) notFound();
  const ventures = batchVentures(store, cohort);
  const lessons = store.lessons.filter((l) => l.cohortId === cohort.id);
  const dead = ventures.filter((v) => v.status === "killed" && v.postMortem);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between gap-2">
        <Link href="/batches" className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> All batches
        </Link>
        <ShareMenu path={`/batches/${cohort.number}`} text={shareText({ kind: "batch", label: batchLabel(cohort.number), line: batchShareCard(store, cohort).line })} />
      </div>
      <BatchPanel cohort={cohort} data={data} heading="h1" waitlist={!landing} />
      {landing && <ShareLanding data={data} cohort={cohort} signedIn={data.signedIn} />}
      <NobodySelects />

      <div className="grid gap-6 lg:grid-cols-2">
        {cohort.slotPlan.length > 0 && (
          <Card size="sm">
            <CardHeader>
              <CardTitle>Why these ventures</CardTitle>
              <CardDescription>How the agent chose what kinds of venture to try this time.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                {cohort.slotPlan.map((s, i) => (
                  <li key={`${s.endMarket}-${s.businessModel}-${i}`}>
                    <span className="font-medium text-zinc-900">{segmentLabel(s)}</span>
                    <span className="text-zinc-600">: {s.reason}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {cohort.notes.length > 0 && (
          <Card size="sm">
            <CardHeader>
              <CardTitle>Batch notes</CardTitle>
              <CardDescription>Written by the agent when the batch closed.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc space-y-1.5 pl-4 text-sm text-zinc-700">
                {cohort.notes.map((note) => (
                  <li key={note}>{note}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>

      {dead.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold tracking-tight">Post-mortems</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {dead.map((v) => {
              const attr = ventureAttribution(store, v, data.params);
              return (
                <Link key={v.id} href={`/v/${v.slug}`} className="rounded-xl border border-rose-200 bg-rose-50/50 p-4 text-sm hover:border-rose-300">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium">{v.name}</span>
                    <StatusBadge status={v.status} />
                  </div>
                  <VentureAttribution mark={attr.mark} className="mt-1 text-xs text-rose-900/70" />
                  <p className="mt-2 text-zinc-700">{v.postMortem!.summary}</p>
                  <p className="mt-2 text-xs text-zinc-500">
                    Why it ended: {v.postMortem!.killReason ?? "not yet published"}
                    {v.postMortem!.stageReached ? ` · Got as far as: ${v.postMortem!.stageReached.toLowerCase()}` : ""}
                    {v.postMortem!.daysToKillSignal !== undefined ? ` · Ended after ${v.postMortem!.daysToKillSignal} days` : ""} · Cost:{" "}
                    {formatUsd(v.postMortem!.costUsd)}
                  </p>
                </Link>
              );
            })}
          </div>
        </section>
      )}

      {lessons.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold tracking-tight">Lessons from this batch</h2>
          {!canReadLessons(data.member, data.params) ? (
            <MembersOnlyLessons
              teaser={{ count: lessons.length, ventures: ventures.length, topics: [...new Set(lessons.map((l) => LESSON_TOPIC_LABELS[l.topic]))] }}
              title={`${lessons.length} lesson${lessons.length === 1 ? "" : "s"} from the ${ventures.length} ventures in this batch`}
            />
          ) : (
            <ul className="space-y-2 rounded-xl border border-zinc-200 bg-white p-4 text-sm">
              {lessons.map((l) => (
                <li key={l.id} className="flex flex-wrap items-baseline gap-2">
                  <LessonLine lesson={l} />
                  <span className="text-xs text-zinc-400">{l.status}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </div>
  );
}
