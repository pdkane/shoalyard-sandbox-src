"use client";

import { useActionState } from "react";
import { Check, Flag, Link2, Megaphone, Pencil, X } from "lucide-react";
import { toast } from "sonner";
import { KILL_REASONS, MEMBER_ATTRIBUTES, type MemberAttribute, type TagAxis } from "@av/schema";
import {
  certifyFlagAction,
  confirmTagAction,
  decideVerificationAction,
  declineMemberAction,
  flagAction,
  linkAccountAction,
  publishPostMortemAction,
  rewriteTagAction,
  spawnBatchAction,
  verifyAttributeAction,
  type ActionState,
} from "@/app/actions";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const initial: ActionState = { ok: true };
const selectClass = "h-8 rounded-lg border border-zinc-200 bg-white px-2 text-sm";

/** Toasts from inside the action, so rows that leave a queue on success still confirm it. */
export function useToastAction(fn: (prev: ActionState, fd: FormData) => Promise<ActionState>) {
  return useActionState(async (prev: ActionState, fd: FormData) => {
    const next = await fn(prev, fd);
    if (next.ok && next.message) toast.success(next.message);
    return next;
  }, initial);
}

export function FlagForm({ kind, id, label }: { kind: "decision" | "rfe" | "venture"; id: string; label: string }) {
  const [state, action] = useToastAction(flagAction);
  return (
    <Dialog>
      <DialogTrigger render={<button type="button" className="inline-flex items-center gap-1 underline underline-offset-2 hover:text-zinc-800" />}>
        <Flag className="size-3" /> Flag
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Flag a conduct concern</DialogTitle>
          <DialogDescription>
            “{label}”. Members vote on whether it breaks Article 8. The Protocol&apos;s steward only confirms the vote followed the rules, and never for a venture they run: then the vote stands on its own.
          </DialogDescription>
        </DialogHeader>
        <form action={action} className="space-y-3">
          <input type="hidden" name="kind" value={kind} />
          <input type="hidden" name="id" value={id} />
          <div className="space-y-1.5">
            <Label htmlFor={`flag-${id}`}>What&apos;s the concern?</Label>
            <Textarea id={`flag-${id}`} name="reason" rows={3} required minLength={8} placeholder="It reads like a cold pitch without saying an agent wrote it…" />
          </div>
          <FormMessage state={state} />
          <DialogFooter>
            <DialogClose render={<Button variant="outline" type="button" />}>Cancel</DialogClose>
            <SubmitButton>Post the flag</SubmitButton>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function ConnectAccountForm({ source, label, prompt, placeholder }: { source: "linkedin" | "x"; label: string; prompt: string; placeholder: string }) {
  const [state, action] = useToastAction(linkAccountAction);
  return (
    <form action={action} className="space-y-2">
      <input type="hidden" name="source" value={source} />
      <Label htmlFor={`ref-${source}`}>{prompt}</Label>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input id={`ref-${source}`} name="ref" required placeholder={placeholder} autoComplete="off" className="h-9" />
        <SubmitButton className="h-9" pendingText="Connecting…">
          <Link2 /> Connect {label}
        </SubmitButton>
      </div>
      <FormMessage state={state} />
    </form>
  );
}

export function VerificationDecision({ handle, verificationId }: { handle: string; verificationId: string }) {
  const [state, action] = useToastAction(decideVerificationAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="handle" value={handle} />
      <input type="hidden" name="verificationId" value={verificationId} />
      <SubmitButton name="approve" value="yes" size="sm">
        <Check /> Confirm
      </SubmitButton>
      <SubmitButton name="approve" value="no" size="sm" variant="outline">
        <X /> Reject
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function VerifyAttributeForm({ handle, labels }: { handle: string; labels: Record<MemberAttribute, string> }) {
  const [state, action] = useToastAction(verifyAttributeAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="handle" value={handle} />
      <select name="attribute" aria-label="Attribute" className={selectClass} defaultValue="role">
        {MEMBER_ATTRIBUTES.map((a) => (
          <option key={a} value={a}>
            {labels[a]}
          </option>
        ))}
      </select>
      <SubmitButton size="sm" variant="outline">
        Verify by review
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function DeclineMemberForm({ handle }: { handle: string }) {
  const [state, action] = useToastAction(declineMemberAction);
  return (
    <form action={action} className="inline-flex items-center gap-2">
      <input type="hidden" name="handle" value={handle} />
      <SubmitButton size="sm" variant="ghost" className="text-rose-700">
        Decline
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function TagConfirmForm({
  kind,
  id,
  axis,
  value,
  vocab,
  governed,
}: {
  kind: "venture" | "rfe" | "lesson";
  id: string;
  axis: TagAxis;
  value: string;
  vocab: string[];
  /** Standard axes pick from the list; only a Protocol vote adds a value. */
  governed?: boolean;
}) {
  const [state, action] = useToastAction(confirmTagAction);
  const listId = `vocab-${axis}`;
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="kind" value={kind} />
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="axis" value={axis} />
      <input type="hidden" name="value" value={value} />
      {governed ? (
        <select name="newValue" defaultValue={value} aria-label="Value" className={`${selectClass} w-56`}>
          {[...new Set([value, ...vocab])].map((v) => (
            <option key={v} value={v}>
              {v}
            </option>
          ))}
        </select>
      ) : (
        <>
          <Input name="newValue" defaultValue={value} list={listId} aria-label="Value" className="h-8 w-56" />
          <datalist id={listId}>
            {vocab.map((v) => (
              <option key={v} value={v} />
            ))}
          </datalist>
        </>
      )}
      <SubmitButton size="sm">
        <Check /> Confirm
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function TagRewriteForm({ axes, vocab, axisLabels }: { axes: readonly TagAxis[]; vocab: Record<TagAxis, string[]>; axisLabels: Record<TagAxis, string> }) {
  const [state, action] = useToastAction(rewriteTagAction);
  return (
    <form action={action} className="flex flex-col gap-2 sm:flex-row sm:items-end">
      <div className="space-y-1.5">
        <Label htmlFor="rw-axis">Axis</Label>
        <select id="rw-axis" name="axis" className={selectClass} defaultValue="subVertical">
          {axes.map((a) => (
            <option key={a} value={a}>
              {axisLabels[a]}
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rw-from">From</Label>
        <Input id="rw-from" name="from" list="rw-from-list" required className="h-8 w-48" placeholder="e.g. Dental practices" />
        <datalist id="rw-from-list">
          {[...new Set(Object.values(vocab).flat())].map((v) => (
            <option key={v} value={v} />
          ))}
        </datalist>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rw-to">To (an existing value merges)</Label>
        <Input id="rw-to" name="to" required className="h-8 w-48" />
      </div>
      <SubmitButton size="sm" variant="outline" className="h-8">
        <Pencil /> Rename or merge
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function CertifyFlagForm({ flagId }: { flagId: string }) {
  const [state, action] = useToastAction(certifyFlagAction);
  return (
    <form action={action} className="flex items-center gap-2">
      <input type="hidden" name="flagId" value={flagId} />
      <SubmitButton size="sm">
        <Check /> Confirm the result
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function KillReasonSelect({ id, defaultValue }: { id: string; defaultValue?: string }) {
  return (
    <select id={id} name="killReason" required defaultValue={defaultValue ?? ""} className={`${selectClass} h-9 w-full`}>
      <option value="" disabled>
        Pick one…
      </option>
      {KILL_REASONS.map((k) => (
        <option key={k} value={k}>
          {k[0].toUpperCase() + k.slice(1)}
        </option>
      ))}
    </select>
  );
}

export function PublishPostMortemForm({ slug, summary, killReason }: { slug: string; summary: string; killReason?: string }) {
  const [state, action] = useToastAction(publishPostMortemAction);
  return (
    <form action={action} className="space-y-2">
      <input type="hidden" name="slug" value={slug} />
      <div className="space-y-1.5">
        <Label htmlFor={`kr-${slug}`}>Kill reason</Label>
        <KillReasonSelect id={`kr-${slug}`} defaultValue={killReason} />
      </div>
      <Textarea name="summary" rows={2} defaultValue={summary} aria-label="Summary" />
      <div className="flex items-center gap-2">
        <SubmitButton size="sm">Publish post-mortem</SubmitButton>
        <FormMessage state={state} />
      </div>
    </form>
  );
}

export function SpawnBatchForm() {
  const [state, action] = useToastAction(spawnBatchAction);
  return (
    <div className="space-y-3">
      <form action={action}>
        <SubmitButton variant="outline" pendingText="Allocating slots…">
          <Megaphone /> Announce the next batch
        </SubmitButton>
      </form>
      {state.error && <FormMessage state={state} />}
      {state.lines && state.lines.length > 0 && (
        <pre className="max-h-56 overflow-auto rounded-lg bg-zinc-950 p-3 font-mono text-xs leading-relaxed text-zinc-100">{state.lines.join("\n")}</pre>
      )}
    </div>
  );
}
