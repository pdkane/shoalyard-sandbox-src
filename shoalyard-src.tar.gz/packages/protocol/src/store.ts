import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { Store as StoreSchema, type Store } from "@av/schema";
import { buildSeed } from "./seed";

/** Walk up from `start` to the directory holding pnpm-workspace.yaml. */
export function findWorkspaceRoot(start = process.cwd()): string {
  let dir = resolve(/*turbopackIgnore: true*/ start);
  for (;;) {
    if (existsSync(join(/*turbopackIgnore: true*/ dir, "pnpm-workspace.yaml"))) return dir;
    const parent = dirname(dir);
    if (parent === dir) return resolve(/*turbopackIgnore: true*/ start);
    dir = parent;
  }
}

export function storePath(): string {
  return process.env.AV_STORE_PATH
    ? resolve(/*turbopackIgnore: true*/ process.env.AV_STORE_PATH)
    : join(/*turbopackIgnore: true*/ findWorkspaceRoot(), "data", "store.json");
}

export function saveStore(store: Store, path = storePath()): void {
  mkdirSync(dirname(path), { recursive: true });
  const tmp = `${path}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(tmp, JSON.stringify(store, null, 2) + "\n");
  renameSync(tmp, path);
}

/** Read the store; seed it on first load if the file is missing. */
export function loadStore(path = storePath()): Store {
  if (!existsSync(path)) {
    const seeded = buildSeed();
    saveStore(seeded, path);
    return seeded;
  }
  return StoreSchema.parse(JSON.parse(readFileSync(path, "utf8")));
}

let queue: Promise<unknown> = Promise.resolve();

/** Serialised read-modify-write, so two requests in one process never interleave writes. */
export function mutateStore<T>(fn: (store: Store) => T | Promise<T>, path = storePath()): Promise<T> {
  const run = queue.then(async () => {
    const store = loadStore(path);
    const result = await fn(store);
    saveStore(store, path);
    return result;
  });
  queue = run.catch(() => undefined);
  return run;
}

export function resetStore(path = storePath()): Store {
  const seeded = buildSeed();
  saveStore(seeded, path);
  return seeded;
}
