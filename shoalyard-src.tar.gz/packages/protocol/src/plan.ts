import type { BudgetCategory, BudgetLine, ParamValues, PitchDeck, PlanInput } from "@av/schema";
import { proofBudget } from "./sizing";

type PlanParams = Pick<ParamValues, "FUNNEL_RATES" | "PAYMENT_FEES" | "SEAT_BUFFER_PCT">;

export interface PlanMonth {
  month: number;
  proof: boolean;
  leads: number;
  newCustomers: number;
  customers: number;
  revenueUsd: number;
  variableUsd: number;
  contributionUsd: number;
  fixedUsd: number;
  oneTimeUsd: number;
  netUsd: number;
  cumulativeUsd: number;
  byCategory: Partial<Record<BudgetCategory, number>>;
}

export interface BusinessPlan {
  months: PlanMonth[];
  proofMonths: number;
  horizonMonths: number;
  proofBudgetUsd: number;
  itemizedUsd: number;
  contingencyUsd: number;
  /** Proof-phase spend by category, contingency last. */
  categories: { category: BudgetCategory; usd: number }[];
  conversion: number;
  conversionFrom: "funnel" | "deck";
  revenuePerCustomerMonthUsd: number;
  variablePerCustomerMonthUsd: number;
  contributionPerCustomerMonthUsd: number;
  fixedMonthlyUsd: number;
  /** Paying customers at which contribution covers the fixed costs; undefined if each customer loses money. */
  breakEvenCustomers?: number;
  /** First month whose contribution covers that month's fixed costs. */
  breakEvenMonth?: number;
  /** First month the cumulative cash is back above zero. */
  paybackMonth?: number;
  /** Cash an adopter needs after the proof: the deepest the plan goes below where the proof left it. */
  afterProofNeedUsd: number;
  /** Monthly loss at the end of the plan, when it hasn't broken even. */
  endBurnUsd: number;
  revenueTotalUsd: number;
}

const round = (n: number) => Math.round(n);

/** Paid customers per lead: the intro funnel for the customer type, unless the deck sets its own with a claim. */
export function planConversion(input: Pick<PlanInput, "leadToPaid">, customer: string | undefined, params: Pick<ParamValues, "FUNNEL_RATES">) {
  if (input.leadToPaid !== undefined) return { rate: input.leadToPaid, from: "deck" as const };
  const funnels = params.FUNNEL_RATES as Record<string, { introToCall?: number; callToPartner?: number; partnerToPaid?: number }>;
  const f = funnels[customer ?? ""] ?? funnels["Small business"];
  return { rate: (f.introToCall ?? 0) * (f.callToPartner ?? 0) * (f.partnerToPaid ?? 0), from: "funnel" as const };
}

export function revenuePerCustomerMonth(pricing: PitchDeck["pricing"], input: Pick<PlanInput, "usesPerCustomerMonth">): number {
  if (pricing.cadence === "year") return pricing.price / 12;
  if (pricing.cadence === "month") return pricing.price;
  return pricing.price * input.usesPerCustomerMonth;
}

/**
 * The 12-month plan, computed from the deck's lines, price and plan inputs. Customers are
 * whole: a month adds the customers the cumulative funnel has reached, and loses the
 * ones cumulative churn has. Recurring lines run every month; one-time lines land in month 1;
 * contingency is held, not spent.
 */
export function businessPlanFor(deck: Pick<PitchDeck, "budget" | "pricing" | "plan">, customer: string | undefined, params: PlanParams): BusinessPlan | undefined {
  const input = deck.plan;
  if (!input) return undefined;
  const lines = deck.budget.filter((b) => !b.stretch && b.category !== "contingency");
  const recurring = lines.filter((b) => b.monthlyUsd !== undefined);
  const once = lines.filter((b) => b.monthlyUsd === undefined);
  const fixedMonthlyUsd = recurring.reduce((s, b) => s + b.monthlyUsd!, 0);
  const fees = params.PAYMENT_FEES as { pct: number; fixedUsd: number };
  const { rate: conversion, from: conversionFrom } = planConversion(input, customer, params);
  const revenuePer = revenuePerCustomerMonth(deck.pricing, input);
  const uses = deck.pricing.cadence === "per-use" ? input.usesPerCustomerMonth : 1;
  const variablePer = input.variableUsdPerUse * uses + revenuePer * (fees.pct / 100) + fees.fixedUsd * uses;
  const contributionPer = revenuePer - variablePer;

  const months: PlanMonth[] = [];
  let expectedNew = 0;
  let expectedLost = 0;
  let acquired = 0;
  let lost = 0;
  let customers = 0;
  let cumulative = 0;
  for (let m = 1; m <= input.horizonMonths; m++) {
    const leads = m < input.firstLeadMonth ? 0 : round(input.leadsPerMonth * (1 + input.leadGrowthPct / 100) ** (m - input.firstLeadMonth));
    expectedNew += leads * conversion;
    expectedLost += customers * (input.churnPct / 100);
    const newCustomers = Math.floor(expectedNew + 1e-9) - acquired;
    const churned = Math.min(customers, Math.floor(expectedLost + 1e-9) - lost);
    acquired += newCustomers;
    lost += churned;
    customers = customers + newCustomers - churned;
    const revenueUsd = customers * revenuePer;
    const variableUsd = customers * variablePer;
    const oneTimeUsd = m === 1 ? once.reduce((s, b) => s + b.usd, 0) : 0;
    const byCategory: PlanMonth["byCategory"] = {};
    for (const b of recurring) byCategory[b.category] = (byCategory[b.category] ?? 0) + b.monthlyUsd!;
    if (m === 1) for (const b of once) byCategory[b.category] = (byCategory[b.category] ?? 0) + b.usd;
    const contributionUsd = revenueUsd - variableUsd;
    const netUsd = contributionUsd - fixedMonthlyUsd - oneTimeUsd;
    cumulative += netUsd;
    months.push({
      month: m,
      proof: m <= input.proofMonths,
      leads,
      newCustomers,
      customers,
      revenueUsd: round(revenueUsd),
      variableUsd: round(variableUsd),
      contributionUsd: round(contributionUsd),
      fixedUsd: round(fixedMonthlyUsd),
      oneTimeUsd: round(oneTimeUsd),
      netUsd: round(netUsd),
      cumulativeUsd: round(cumulative),
      byCategory,
    });
  }

  const proof = proofBudget(deck.budget, params.SEAT_BUFFER_PCT);
  const totals = new Map<BudgetCategory, number>();
  for (const b of lines) totals.set(b.category, (totals.get(b.category) ?? 0) + b.usd);
  const categories = [...totals].map(([category, usd]) => ({ category, usd })).sort((a, b) => b.usd - a.usd);
  if (proof.contingencyUsd) categories.push({ category: "contingency", usd: proof.contingencyUsd });

  const breakEvenMonth = months.find((x) => x.customers > 0 && x.contributionUsd >= x.fixedUsd)?.month;
  const paybackMonth = months.find((x) => x.cumulativeUsd >= 0 && x.customers > 0)?.month;
  const atProof = months[input.proofMonths - 1]?.cumulativeUsd ?? 0;
  const lowest = Math.min(atProof, ...months.slice(input.proofMonths).map((x) => x.cumulativeUsd));
  const last = months.at(-1)!;
  return {
    months,
    proofMonths: input.proofMonths,
    horizonMonths: input.horizonMonths,
    proofBudgetUsd: proof.totalUsd,
    itemizedUsd: proof.itemizedUsd,
    contingencyUsd: proof.contingencyUsd,
    categories,
    conversion,
    conversionFrom,
    revenuePerCustomerMonthUsd: round(revenuePer * 100) / 100,
    variablePerCustomerMonthUsd: round(variablePer * 100) / 100,
    contributionPerCustomerMonthUsd: round(contributionPer * 100) / 100,
    fixedMonthlyUsd: round(fixedMonthlyUsd),
    breakEvenCustomers: contributionPer > 0 ? Math.ceil(fixedMonthlyUsd / contributionPer - 1e-9) : undefined,
    breakEvenMonth,
    paybackMonth,
    afterProofNeedUsd: round(atProof - lowest),
    endBurnUsd: Math.max(0, -last.netUsd),
    revenueTotalUsd: months.reduce((s, x) => s + x.revenueUsd, 0),
  };
}

/** Proof-phase lines: recurring ones are the monthly amount × the proof months. */
export function proofLine(line: Omit<BudgetLine, "usd" | "stretch"> & { stretch?: boolean; usd?: number }, proofMonths: number): BudgetLine {
  const usd = line.monthlyUsd !== undefined ? line.monthlyUsd * proofMonths : (line.usd ?? 0);
  return { ...line, usd, stretch: line.stretch ?? false };
}

const usd = (n: number) => `$${Math.round(n).toLocaleString("en-US")}`;

/** Plain sentences for the plan slide, the venture page and the agent's answers. */
export function planSummary(plan: BusinessPlan): string[] {
  const out = [
    `Proof budget ${usd(plan.proofBudgetUsd)} for ${plan.proofMonths} months: ${usd(plan.itemizedUsd)} itemized plus ${usd(plan.contingencyUsd)} contingency.`,
    `Each paying customer brings ${usd(plan.revenuePerCustomerMonthUsd)} a month and costs ${usd(plan.variablePerCustomerMonthUsd)} to serve, card fees included, leaving ${usd(plan.contributionPerCustomerMonthUsd)} against ${usd(plan.fixedMonthlyUsd)} a month of fixed costs.`,
  ];
  if (plan.breakEvenCustomers === undefined) out.push("Each customer costs more to serve than they pay, so more customers make it worse.");
  else if (plan.breakEvenMonth) out.push(`It covers its monthly costs at ${plan.breakEvenCustomers} paying customers, reached in month ${plan.breakEvenMonth} on this ramp.`);
  else out.push(`It needs ${plan.breakEvenCustomers} paying customers to cover its monthly costs, and this ramp doesn't reach that in ${plan.horizonMonths} months; month ${plan.horizonMonths} still loses ${usd(plan.endBurnUsd)}.`);
  out.push(
    plan.afterProofNeedUsd > 0
      ? `To take it forward after the proof, an adopter would need about ${usd(plan.afterProofNeedUsd)} to reach month ${plan.horizonMonths}${plan.breakEvenMonth ? "" : ", and more after that"}.`
      : "After the proof, it pays its own way on this ramp.",
  );
  return out;
}
