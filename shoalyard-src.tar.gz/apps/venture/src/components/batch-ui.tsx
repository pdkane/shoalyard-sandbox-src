import Link from "next/link";
import { ArrowRight, Lock, Ticket } from "lucide-react";
import {
  batchLabel,
  batchVentures,
  classificationLine,
  classificationOf,
  codenameSlug,
  earlyAccessAt,
  hasSeat,
  raiseProgress,
  seatRefunds,
  seatWindow,
  ventureHref,
  seatPriceHold,
  seatPriceOf,
  scarcityFor,
  onWaitlist,
} from "@av/protocol";
import type { Cohort, Venture } from "@av/schema";
import { Pill, StatusBadge } from "@/components/badges";
import { Countdown } from "@/components/countdown";
import { SeatDisclaimer } from "@/components/protocol-ui";
import { ScarcityStrip } from "@/components/scarcity";
import { WaitlistForm } from "@/components/waitlist-form";
import { buttonVariants } from "@/components/ui/button";
import type { Data } from "@/lib/data";
import { formatDateTime, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const COHORT_PILL: Record<Cohort["status"], string> = {
  announced: "border-violet-200 bg-violet-50 text-violet-800",
  live: "border-emerald-200 bg-emerald-50 text-emerald-800",
  closed: "border-zinc-200 bg-zinc-100 text-zinc-600",
};

export function NobodySelects({ className }: { className?: string }) {
  return (
    <p className={cn("max-w-2xl text-sm text-zinc-600", className)}>
      No one picks the winners. A venture goes ahead if enough people take seats, and keeps going if a customer pays.
    </p>
  );
}

export function BatchStatusPill({ cohort }: { cohort: Cohort }) {
  return <Pill className={COHORT_PILL[cohort.status]}>{cohort.status === "live" ? "Seats open" : cohort.status === "announced" ? "Coming soon" : "Closed"}</Pill>;
}

function TeaserCard({ venture, data }: { venture: Venture; data: Data }) {
  const kind = classificationLine(classificationOf(venture), ["businessModel", "endMarket"]);
  const cohort = data.store.cohorts.find((c) => c.id === venture.cohortId);
  return (
    <Link
      href={ventureHref(data.store, venture)}
      className="group flex flex-col rounded-xl border border-dashed border-zinc-300 bg-white p-5 transition hover:border-zinc-400"
    >
      <div className="flex items-center justify-between gap-2">
        <span className="font-mono text-lg font-semibold tracking-widest">{venture.codename ?? "UNNAMED"}</span>
        <Lock className="size-4 text-zinc-400" />
      </div>
      {kind && <p className="mt-1 text-xs text-zinc-500">{kind}</p>}
      {venture.teaser && <p className="mt-3 text-sm text-pretty text-zinc-700">{venture.teaser}</p>}
      <p className="mt-4 text-xs text-zinc-500">
        {cohort ? `Verified members see the full plan first, ${formatDateTime(earlyAccessAt(cohort, data.params))} UTC.` : "Full plan shown when seats open."}
      </p>
    </Link>
  );
}

function LiveCard({ venture, data }: { venture: Venture; data: Data }) {
  const { store, params, viewer, member } = data;
  const raise = raiseProgress(store, venture, params);
  const w = seatWindow(store, venture, params);
  const seated = member ? hasSeat(store, venture.id, viewer) : false;
  const refunds = seatRefunds(store, venture.id);
  const priceHold = seatPriceHold(store, venture);
  const sc = scarcityFor(store, venture);
  const canBuy = venture.status === "pitched" && !priceHold && !sc.seats?.full && (w.state === "open" || (w.state === "early" && member?.qualification === "qualified"));
  const kind = classificationLine(classificationOf(venture), ["businessModel", "endMarket"]);
  return (
    <div
      style={{ "--accent-color": venture.accent } as React.CSSProperties}
      className="relative flex flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white p-5 shadow-xs"
    >
      <span className="absolute inset-x-0 top-0 h-1 bg-[var(--accent-color)]" />
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <Link href={`/v/${venture.slug}`} className="text-lg font-semibold tracking-tight hover:underline">
            {venture.name}
          </Link>
          {kind && <p className="text-xs text-zinc-500">{kind}</p>}
        </div>
        <StatusBadge status={venture.status} />
      </div>
      <p className="mt-2 line-clamp-2 text-sm text-zinc-600">{venture.tagline}</p>
      {refunds.count > 0 ? (
        <p className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-900">
          {refunds.count} {refunds.count === 1 ? "seat" : "seats"} refunded in full ({formatUsd(refunds.totalUsd)})
        </p>
      ) : (
        <div className="mt-4">
          <div className="flex items-baseline justify-between text-sm">
            <span className="font-medium tabular-nums">
              {raise.sold}/{raise.needed} seats
            </span>
            <span className="text-xs text-zinc-500">{formatUsd(venture.minRaiseUsd)} budget to first customer</span>
          </div>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-zinc-100">
            <div className="h-full rounded-full bg-[var(--accent-color)]" style={{ width: `${raise.pct}%` }} />
          </div>
        </div>
      )}
      <ScarcityStrip sc={sc} className="mt-3" />
      <div className="mt-4 flex flex-col gap-1.5">
        {seated ? (
          <Link href="/inbox" className={buttonVariants({ variant: "outline" })}>
            You have a seat. Go to your requests
          </Link>
        ) : canBuy ? (
          <Link href={`/v/${venture.slug}/seat`} className={buttonVariants()}>
            <Ticket /> Take a seat · {formatUsd(seatPriceOf(venture, params))}
          </Link>
        ) : (
          <Link href={`/v/${venture.slug}`} className={buttonVariants({ variant: "outline" })}>
            {sc.seats?.full ? "All seats taken: join the waitlist" : priceHold && venture.status === "pitched" ? "Seat price waiting for the steward" : w.state === "early" ? `Verified members only until ${formatDateTime(w.opensAt!)} UTC` : "Open venture"} <ArrowRight />
          </Link>
        )}
        <SeatDisclaimer />
      </div>
    </div>
  );
}

function ClosedRow({ venture }: { venture: Venture }) {
  return (
    <Link href={`/v/${venture.slug}`} className="flex items-center justify-between gap-3 rounded-lg border border-zinc-200 bg-white px-4 py-3 text-sm hover:border-zinc-300">
      <span className="font-medium">{venture.name}</span>
      <StatusBadge status={venture.status} />
    </Link>
  );
}

export function BatchPanel({ cohort, data, heading = "h2", waitlist = true }: { cohort: Cohort; data: Data; heading?: "h1" | "h2"; waitlist?: boolean }) {
  const { store, params } = data;
  const ventures = batchVentures(store, cohort);
  const clock = store.meta.clock;
  const early = earlyAccessAt(cohort, params);
  const H = heading;
  return (
    <section className="space-y-5 rounded-2xl border border-zinc-200 bg-zinc-50/80 p-6">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <H className={cn("font-semibold tracking-tight", heading === "h1" ? "text-3xl" : "text-2xl")}>{batchLabel(cohort.number)}</H>
            <BatchStatusPill cohort={cohort} />
          </div>
          <p className="max-w-xl text-sm text-zinc-600">
            {cohort.status === "announced" && (
              <>
                {ventures.length} ventures, names hidden. Verified members can take seats from {formatDateTime(early)} UTC; everyone else from{" "}
                {formatDateTime(cohort.opensAt)} UTC.
              </>
            )}
            {cohort.status === "live" && (
              <>
                {ventures.length} ventures selling seats until {formatDateTime(cohort.closesAt)} UTC. Your money is held until a venture sells enough
                seats. If it doesn&apos;t by the deadline, it ends and you get your money back.
              </>
            )}
            {cohort.status === "closed" && <>Closed {formatDateTime(cohort.closedAt ?? cohort.closesAt)} UTC. Every venture in it has published its results.</>}
          </p>
        </div>
        {cohort.status === "announced" && <Countdown to={clock < early ? early : cohort.opensAt} now={clock} label={clock < early ? "Verified members can join in" : "Seats open to everyone in"} />}
        {cohort.status === "live" && clock < cohort.closesAt && <Countdown to={cohort.closesAt} now={clock} label="Seats close in" />}
      </div>
      {cohort.status === "announced" && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {ventures.map((v) => (
              <TeaserCard key={codenameSlug(v)} venture={v} data={data} />
            ))}
          </div>
          {waitlist && (
            <WaitlistForm
              batch={cohort.number}
              handle={data.signedIn ? data.member?.handle : undefined}
              joined={data.signedIn && !!data.member && !!onWaitlist(store, data.member.handle, { cohortId: cohort.id })}
              label="Tell me when it opens"
            />
          )}
        </>
      )}
      {cohort.status === "live" && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ventures.map((v) => (
            <LiveCard key={v.id} venture={v} data={data} />
          ))}
        </div>
      )}
      {cohort.status === "closed" && (
        <div className="grid gap-2 sm:grid-cols-2">
          {ventures.map((v) => (
            <ClosedRow key={v.id} venture={v} />
          ))}
        </div>
      )}
      <Link href={`/batches/${cohort.number}`} className="inline-flex items-center gap-1 text-sm font-medium text-zinc-900 hover:underline">
        {cohort.status === "closed" ? "Read the batch record" : "See batch details"} <ArrowRight className="size-4" />
      </Link>
    </section>
  );
}
