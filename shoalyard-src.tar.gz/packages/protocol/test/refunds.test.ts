import assert from "node:assert/strict";
import { test } from "node:test";
import { PARAMS } from "@av/schema";
import { ARTICLES } from "../src/constitution";
import { advanceBatches } from "../src/batches";
import {
  ESCROW_NOTE,
  issueGrant,
  activeSeats,
  buySeat,
  closeGovernance,
  hasSeat,
  killVenture,
  logDecision,
  refundSeats,
  respond,
  seatRefunds,
  seatsSold,
  transitionVenture,
  ventureBySlug,
} from "../src/ops";
import { buildSeed } from "../src/seed";

const steward = PARAMS.FOUNDING_STEWARD_HANDLE.value;

test("Article 2 promises a full refund when the minimum isn't met, and says answering needs verification", () => {
  assert.match(ARTICLES[1].text, /Until it reaches the minimum, seat money is held and can't be spent\. If the minimum isn't reached in time, the venture ends and every seat holder gets a full refund\./);
  assert.match(ARTICLES[1].text, /To answer them you must also be verified/);
});

test("the window close refunds every seat of an unfunded venture, one row per seat", () => {
  const s = buildSeed();
  const lien = ventureBySlug(s, "lien-clock")!;
  const seats = activeSeats(s, lien.id);
  assert.ok(seats.length > 0);
  s.meta.clock = "2026-11-03T13:00:00.000Z";
  const events = advanceBatches(s);
  assert.equal(lien.status, "killed");
  const refunds = s.ledger.filter((l) => l.ventureId === lien.id && l.kind === "refund");
  assert.equal(refunds.length, seats.length);
  for (const seat of seats) {
    const r = refunds.find((x) => x.ref === seat.id)!;
    assert.equal(r.handle, seat.handle);
    assert.equal(r.usd, -seat.usd!);
    assert.ok(s.ledger.some((l) => l.kind === "notify" && l.handle === seat.handle && l.note.includes("refunded in full")));
  }
  assert.equal(seatsSold(s, lien.id), 0);
  assert.ok(!hasSeat(s, lien.id, seats[0].handle!));
  assert.ok(!s.ledger.some((l) => l.ventureId === lien.id && l.kind === "status" && (l.usd ?? 0) < 0), "no aggregate refund row");
  assert.ok(events.some((e) => e.message.includes(`Lien Clock missed its minimum`) && e.message.includes(`${seats.length} seats refunded in full`)));
  assert.deepEqual(seatRefunds(s, lien.id), { count: seats.length, totalUsd: seats.length * PARAMS.SEAT_PRICE_USD.value });
});

test("a steward kill during the raise refunds every seat", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  const sold = seatsSold(s, pp.id);
  killVenture(s, "permit-pulse", steward, "Testing the switch");
  assert.equal(pp.status, "killed");
  assert.deepEqual(seatRefunds(s, pp.id), { count: sold, totalUsd: sold * PARAMS.SEAT_PRICE_USD.value });
  const kill = s.decisions.filter((d) => d.ventureId === pp.id && d.model === "steward").at(-1)!;
  assert.match(kill.outcome ?? "", new RegExp(`${sold} seats refunded in full`));
});

test("refunds are idempotent: a second call refunds nothing", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  const sold = seatsSold(s, pp.id);
  const first = refundSeats(s, pp, "test");
  const second = refundSeats(s, pp, "test");
  assert.equal(first.count, sold);
  assert.deepEqual(second, { count: 0, totalUsd: 0 });
  killVenture(s, "permit-pulse", steward, "After a manual refund");
  assert.equal(s.ledger.filter((l) => l.ventureId === pp.id && l.kind === "refund").length, sold);
});

test("a funded venture killed before it forms refunds; after formation nothing is refunded", () => {
  const funded = buildSeed();
  const pp = ventureBySlug(funded, "permit-pulse")!;
  for (let i = 0; i < 13; i++) buySeat(funded, { slug: "permit-pulse", handle: `buyer_${i}` });
  assert.equal(pp.status, "funded");
  killVenture(funded, "permit-pulse", steward, "Before formation");
  assert.equal(seatRefunds(funded, pp.id).count, 30);

  const formed = buildSeed();
  const pp2 = ventureBySlug(formed, "permit-pulse")!;
  for (let i = 0; i < 13; i++) buySeat(formed, { slug: "permit-pulse", handle: `buyer_${i}` });
  transitionVenture(formed, pp2, "formed");
  killVenture(formed, "permit-pulse", steward, "After formation");
  assert.equal(seatRefunds(formed, pp2.id).count, 0);
  assert.equal(seatsSold(formed, pp2.id), 30);

  const operating = buildSeed();
  killVenture(operating, "dockside", steward, "Operating venture");
  assert.equal(seatRefunds(operating, "dockside").count, 0);
});

test("refunding a seat leaves every grant earned by work standing", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  issueGrant(s, { venture: pp, handle: "gis_greta", slice: "rfe", units: 2, rfeId: "rfe-permit-pulse-trade" });
  const before = s.grants.filter((g) => g.ventureId === pp.id).map((g) => [g.id, g.status]);
  assert.ok(before.length > 0);
  killVenture(s, "permit-pulse", steward, "Testing refunds");
  assert.deepEqual(
    s.grants.filter((g) => g.ventureId === pp.id).map((g) => [g.id, g.status]),
    before,
  );
  assert.ok(!s.ledger.some((l) => l.kind === "forfeit" && l.ventureId === pp.id));
});

test("escrow: a spend decision while the raise is open is stopped", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  const before = s.rfes.length;
  const { decision } = logDecision(s, { ventureId: pp.id, title: "Buy a domain", reasoning: "Ten dollars.", confidence: 0.95, facts: { spendUsd: 10 }, model: "script" });
  assert.equal(decision.status, "rejected");
  assert.ok(decision.binReasons.some((r) => r.startsWith(ESCROW_NOTE)));
  assert.equal(s.rfes.length, before);
  const free = logDecision(s, { ventureId: pp.id, title: "Draft the Monday email", reasoning: "No spend.", confidence: 0.95, model: "script" }).decision;
  assert.equal(free.status, "taken");
  const dock = ventureBySlug(s, "dockside")!;
  assert.notEqual(logDecision(s, { ventureId: dock.id, title: "Renew a tool", reasoning: "Ten dollars.", confidence: 0.95, facts: { spendUsd: 10 }, model: "script" }).decision.status, "rejected");
});

test("the seed shows Wet Ink ended during its raise with every seat refunded", () => {
  const s = buildSeed();
  const ink = ventureBySlug(s, "wet-ink")!;
  assert.equal(ink.status, "killed");
  assert.ok(ink.postMortem?.publishedAt);
  const seats = s.ledger.filter((l) => l.ventureId === ink.id && l.kind === "seat");
  assert.ok(seats.length > 0);
  assert.equal(seatRefunds(s, ink.id).count, seats.length);
});

test("a vote can't turn off the full refund; that is Article 2", () => {
  const s = buildSeed();
  const v0 = ventureBySlug(s, "protocol")!;
  const { rfe } = logDecision(s, {
    ventureId: v0.id,
    title: "Stop refunding seats",
    reasoning: "Proposed by a member.",
    confidence: 0.5,
    model: "script",
    rfe: {
      type: "judgment",
      kind: "governance",
      title: "Amend REFUND_IN_FULL",
      question: "Keep seat money when a venture misses its minimum?",
      recommendation: "No",
      stakes: "high",
      format: "choice",
      options: ["Yes", "No"],
      offerUnits: 0,
      audience: "Holders",
      governance: { matter: "Parameter amendment", threshold: "simple", windowEndsAt: "2026-11-06T12:00:00.000Z", paramKey: "REFUND_IN_FULL", currentValue: true, proposedValue: false, effect: "Ends refunds." },
    },
  });
  for (const h of ["policy_pia", "counsel_kemi", "cfo_ines", "ux_uma"]) respond(s, { rfeId: rfe!.id, handle: h, via: "structured", choice: "Yes" });
  s.meta.clock = "2026-11-07T00:00:00.000Z";
  closeGovernance(s, rfe!);
  assert.match(rfe!.resolution ?? "", /not applied/);
  assert.equal(s.amendments.filter((a) => a.paramKey === "REFUND_IN_FULL").length, 0);
});
