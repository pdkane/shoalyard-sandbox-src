import assert from "node:assert/strict";
import { test } from "node:test";
import { PARAMS, Store as StoreSchema } from "@av/schema";
import { claimById, decksFor, latestDeck, validateDeck } from "../src/deck";
import { DECK_DRAFTS } from "../src/deck-content";
import { rfeById, ventureBySlug } from "../src/ops";
import { qaFor } from "../src/qa";
import { rosterProgress } from "../src/roster";
import { buildSeed } from "../src/seed";

const s = buildSeed();
const v = (slug: string) => ventureBySlug(s, slug)!;

test("Dockside: a reconstructed v1, then v2 where the record replaces assumptions; it keeps its 20-seat minimum", () => {
  const [v1, v2] = decksFor(s, "dockside");
  assert.equal(v1.author, "reconstructed");
  assert.match(v1.banner ?? "", /Reconstructed at migration/);
  assert.equal(v1.publishedAt.slice(0, 10), "2025-10-15");
  assert.equal(v1.status, "superseded");
  assert.equal(v2.version, 2);
  assert.equal(v2.cause.kind, "migration");
  assert.equal(claimById(v2, "c-price")!.basis, "evidence");
  assert.equal(claimById(v2, "c-demand")!.basis, "evidence");
  assert.ok(claimById(v2, "c-risk-cold")!.disproved, "the cold-outbound claim is struck through, not deleted");
  assert.ok(v2.changes.some((c) => c.path === "slides.demand.headline"));
  assert.equal(v2.seatPlan.rule, "legacy-budget");
  assert.equal(v2.seatPlan.min, 20);
  const cur = v2.currentRule!;
  assert.equal(cur.min, Math.ceil(cur.proofBudgetUsd / cur.priceUsd), "the current rule prices the honest proof, with no cap on the count");
  assert.equal(cur.binding, "budget");
  assert.equal(cur.shortfallUsd, 0);
  assert.equal(v2.seatPlan.shortfallUsd, v2.seatPlan.proofBudgetUsd - 200, "the gap against the kept minimum is shown, not hidden");
  assert.deepEqual(cur.atPrices.map((a) => a.priceUsd), [10, cur.price!.upperUsd]);
  assert.equal(v2.seatPlan.priceUsd, 10, "it keeps the price it was pitched at");
  assert.ok(v2.plan, "the reconstructed deck carries a business plan");
  assert.equal(rosterProgress(s, v("dockside")).total, 12);
  assert.ok(v("dockside").killRules.includes("Runway below $150 for two consecutive months"), "an undated kill rule survives the deck");
});

test("Chairside: reconstructed, legacy 18, a roster of 11, and a counterfactual labelled as an estimate", () => {
  const deck = latestDeck(s, "chairside")!;
  assert.equal(deck.author, "reconstructed");
  assert.equal(deck.seatPlan.min, 18);
  assert.ok(deck.currentRule!.min >= deck.currentRule!.headcount);
  assert.ok(deck.roster.some((r) => r.key === "legal" && r.critical));
  const p = rosterProgress(s, v("chairside"));
  assert.equal(p.total, 11);
  const note = v("chairside").postMortem!.counterfactual ?? "";
  assert.match(note, /^Estimate/);
  assert.match(note, new RegExp(`fit ${p.filled} of its 11`));
  assert.deepEqual(qaFor(s, v("chairside")), []);
});

test("Permit Pulse: v1 at pitch, v2 from a member's question, and it keeps its 30-seat minimum beside the current rule's honest number", () => {
  const decks = decksFor(s, "permit-pulse");
  assert.equal(decks[0].cause.kind, "pitch");
  assert.equal(decks[0].publishedAt, "2026-10-28T12:00:00.000Z");
  assert.equal(decks[1].cause.kind, "qa");
  assert.match(claimById(decks[1], "c-icp")!.text, /Seven Sun Belt metros/);
  const now = latestDeck(s, "permit-pulse")!;
  assert.equal(now.seatPlan.min, 30);
  assert.ok(now.currentRule!.min > 30, "the honest number is shown beside the kept minimum");
  assert.equal(v("permit-pulse").minRaiseUsd, 300);
  assert.ok(!v("permit-pulse").budget.some((b) => /buffer/i.test(b.label)));
  assert.equal(v("permit-pulse").budget.find((b) => b.label === "Contingency"), undefined, "the kept minimum doesn't reach contingency");
  assert.equal(now.seatPlan.shortfallUsd, now.seatPlan.proofBudgetUsd - 300);
});

test("Permit Pulse's six questions cover every path: answered, the seat math, a deck change, I don't know, partial, hidden", () => {
  const qs = s.questions.filter((q) => q.ventureId === "permit-pulse");
  assert.equal(qs.length, 6);
  const by = (h: string) => qs.find((q) => q.handle === h)!;
  assert.equal(by("roofer_rita").answer?.status, "answered");
  assert.ok(by("roofer_rita").answer!.restsOn.includes("c-price"), "the price is still an assumption, shown under “this rests on”");
  assert.match(by("shingle_sam").answer!.text, /Under the current rule it would price seats at \$\d+ and ask for \d+ seats/);
  assert.equal(by("bidboard").answer?.routed?.deckVersion, 2);
  assert.equal(by("hvac_hank").answer?.status, "unknown");
  assert.equal(rfeById(s, by("hvac_hank").answer!.routed!.rfeId!)?.offerUnits, 1);
  assert.equal(by("coldcall_cass").answer?.status, "partial");
  assert.ok(claimById(latestDeck(s, "permit-pulse")!, "c-risk-terms"));
  const hidden = qs.find((q) => q.status === "hidden")!;
  assert.equal(hidden.hidden?.reason, "personal data about a person");
  assert.ok(s.ledger.some((l) => l.kind === "redaction" && l.ref === hidden.id));
  assert.ok(qs.every((q) => q.status !== "held"), "nothing seeded waits on the steward");
});

test("Dockside's two questions are a record: one routed to the carriers request, one answered from the pricing evidence", () => {
  const qs = s.questions.filter((q) => q.ventureId === "dockside");
  assert.equal(qs.length, 2);
  assert.equal(qs[0].answer?.routed?.rfeId, "rfe-dockside-carrier");
  assert.equal(qs[1].status, "answered");
  assert.deepEqual(qs[1].answer?.restsOn.filter((id) => id === "c-price"), [], "the price is evidence now");
});

test("Dockside runs the operating loop: an update, a review for the steward, and a premise test after two failures", () => {
  assert.equal(s.updates.filter((u) => u.ventureId === "dockside").length, 1);
  const review = s.reviews.find((r) => r.ventureId === "dockside")!;
  assert.equal(review.call, "persevere");
  assert.equal(s.decisions.find((d) => d.id === review.decisionId)?.status, "awaiting_steward");
  const failed = s.experiments.filter((e) => e.ventureId === "dockside" && e.status === "failed");
  assert.equal(failed.length, 2);
  assert.ok(failed[1].premiseTestRfeId && rfeById(s, failed[1].premiseTestRfeId));
});

test("every seeded deck passes the claim rules, and each new Protocol request lists its settings with current values", () => {
  for (const slug of ["dockside", "chairside", "permit-pulse"]) {
    assert.deepEqual(validateDeck(s, v(slug), DECK_DRAFTS[slug]()), [], slug);
  }
  for (const id of ["rfe-v0-seat-sizing", "rfe-v0-roster-sizing", "rfe-v0-qa", "rfe-v0-pitch-deck", "rfe-v0-operating"]) {
    const rfe = rfeById(s, id)!;
    for (const d of Object.values(PARAMS).filter((p) => p.governedBy === id)) assert.ok(rfe.question.includes(d.label), `${id} lists ${d.label}`);
  }
  assert.match(rfeById(s, "rfe-v0-seat-sizing")!.question, /Seat buffer: 20%/);
});

test("the seeded store survives a round trip through JSON and the schema", () => {
  assert.doesNotThrow(() => StoreSchema.parse(JSON.parse(JSON.stringify(s))));
});
