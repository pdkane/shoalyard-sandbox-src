import { defaultParams, PARAMS, type Amendment, type ParamKey, type ParamValues, type Store } from "@av/schema";

/** Defaults with every passed amendment applied, oldest first. */
export function resolveParams(store: Pick<Store, "amendments">): ParamValues {
  const out = defaultParams() as Record<string, unknown>;
  const sorted = [...store.amendments].sort((a, b) => a.at.localeCompare(b.at));
  for (const a of sorted) {
    if (a.paramKey in PARAMS) out[a.paramKey] = a.newValue;
  }
  return out as ParamValues;
}

export function amendmentsFor(store: Pick<Store, "amendments">, key: ParamKey): Amendment[] {
  return store.amendments.filter((a) => a.paramKey === key).sort((a, b) => a.at.localeCompare(b.at));
}

export function markFor(params: ParamValues, ventureName: string): string {
  return params.MARK_TEMPLATE.replace("{name}", ventureName);
}
