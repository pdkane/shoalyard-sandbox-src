import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams } from "@av/schema";
import { capTable, computeDistribution, tallyVote, totalVestedUnits } from "../src/economics";
import { buySeat, ventureBySlug } from "../src/ops";
import { buildSeed } from "../src/seed";

const params = defaultParams();

test("pool slices add up to the contributor pool", () => {
  assert.equal(
    params.POOL_STEWARD_UNITS + params.POOL_COHORT_UNITS + params.POOL_RFE_RESERVE_UNITS,
    params.POOL_UNITS_TOTAL,
  );
});

test("buying a seat or qualifying never earns units", () => {
  const store = buildSeed();
  assert.ok(store.grants.every((g) => ["rfe", "steward", "founder", "cohort"].includes(g.slice)));
  buySeat(store, { slug: "dockside", handle: "fresh_face" });
  assert.equal(store.grants.filter((g) => g.handle === "fresh_face").length, 0);
});

test("cap table: protocol fee off the top, 90% to contributors, reserve tracked", () => {
  const store = buildSeed();
  const dock = ventureBySlug(store, "dockside")!;
  const cap = capTable(store, dock, params);
  assert.equal(cap.protocolPct, 10);
  assert.equal(cap.contributorPct, 90);
  assert.equal(cap.unitPct, 0.9);
  const reserve = cap.slices.find((s) => s.key === "reserve")!;
  assert.equal(reserve.granted + reserve.remaining, params.POOL_RFE_RESERVE_UNITS);
  assert.equal(params.POOL_COHORT_UNITS, 0);
  assert.equal(params.SHARE_PER_ANSWER, 1);
  assert.ok(cap.reserveRemaining >= 0);
});

test("The Protocol pays no protocol fee to itself", () => {
  const store = buildSeed();
  assert.equal(capTable(store, ventureBySlug(store, "protocol")!, params).protocolPct, 0);
});

test("distribution: pass-through first, fee pari passu, unvested stays in treasury", () => {
  const d = computeDistribution({
    profitUsd: 6160,
    passThroughUsd: 410,
    protocolPct: 10,
    poolUnits: 100,
    cohortUnits: 0,
    vestedByHandle: { a: 10, b: 5 },
  });
  assert.equal(d.distributableUsd, 5750);
  assert.equal(d.protocolUsd, 575);
  assert.equal(d.contributorUsd, 5175);
  assert.equal(d.perUnitUsd, 51.75);
  assert.equal(d.holderUsd, 776.25);
  assert.equal(d.cohortUsd, 0);
  assert.equal(d.treasuryUsd, 4398.75);
  assert.equal(d.protocolUsd + d.holderUsd + d.cohortUsd + d.treasuryUsd, 5750);
});

test("no distribution when pass-through exceeds profit", () => {
  const d = computeDistribution({ profitUsd: 100, passThroughUsd: 200, protocolPct: 10, poolUnits: 100, cohortUnits: 0, vestedByHandle: { a: 1 } });
  assert.equal(d.distributableUsd, 0);
  assert.equal(d.holderUsd, 0);
});

test("votes are weighted by vested interest, with quorum", () => {
  const rfe = { options: ["Yes", "No"], governance: { threshold: "simple" as const } } as Parameters<typeof tallyVote>[0];
  const pass = tallyVote(rfe, [{ choice: "Yes", weight: 6 }, { choice: "No", weight: 4 }], 20, params);
  assert.equal(pass.passes, true);
  const noQuorum = tallyVote(rfe, [{ choice: "Yes", weight: 5 }], 20, params);
  assert.equal(noQuorum.quorumMet, false);
  assert.equal(noQuorum.passes, false);
  const tie = tallyVote(rfe, [{ choice: "Yes", weight: 5 }, { choice: "No", weight: 5 }], 20, params);
  assert.equal(tie.passes, false, "simple majority means strictly above half");
  const superRfe = { ...rfe, governance: { threshold: "super" as const } } as Parameters<typeof tallyVote>[0];
  assert.equal(tallyVote(superRfe, [{ choice: "Yes", weight: 6 }, { choice: "No", weight: 4 }], 10, params).passes, false);
});

test("seeded vested interest excludes the founder's unvested grant", () => {
  const store = buildSeed();
  const v0 = ventureBySlug(store, "protocol")!;
  const founder = store.grants.find((g) => g.ventureId === v0.id && g.slice === "founder")!;
  assert.equal(founder.status, "accepted");
  assert.ok(totalVestedUnits(store, v0.id) > 0);
});
