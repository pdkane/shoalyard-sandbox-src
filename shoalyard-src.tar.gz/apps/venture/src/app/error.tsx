"use client";

import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-3 py-16 text-center">
      <span className="flex size-11 items-center justify-center rounded-full bg-rose-50 text-rose-600">
        <AlertTriangle className="size-5" />
      </span>
      <h1 className="text-lg font-semibold">Something went wrong</h1>
      <p className="text-sm text-zinc-500">
        {error.message || "The page failed to load."} If the demo data is corrupted, run <code>pnpm seed</code> to restore it.
      </p>
      <Button onClick={reset}>Try again</Button>
    </div>
  );
}
