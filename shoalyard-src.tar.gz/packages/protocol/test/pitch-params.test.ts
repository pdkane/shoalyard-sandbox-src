import assert from "node:assert/strict";
import { test } from "node:test";
import { PARAMS, PARAM_GROUP_LABELS, SLIDE_KEYS, Store } from "@av/schema";
import { closeGovernance, logDecision, respond, ventureBySlug } from "../src/ops";
import { resolveParams } from "../src/params";
import { buildSeed } from "../src/seed";

test("every pitch, roster, Q&A and operating setting has a reason and a request that can change it", () => {
  const groups = new Set(["pitch", "roster", "qa", "operating"]);
  const defs = Object.entries(PARAMS).filter(([, d]) => groups.has(d.group));
  assert.ok(defs.length >= 40, `expected the new settings, found ${defs.length}`);
  for (const [key, d] of defs) {
    assert.ok(d.reason.length > 20, `${key} needs a reason`);
    assert.match(d.governedBy, /^rfe-v0-/, `${key} names its request`);
    assert.ok(PARAM_GROUP_LABELS[d.group]);
  }
  const p = resolveParams(buildSeed());
  assert.deepEqual(p.DECK_SLIDES, [...SLIDE_KEYS]);
  assert.equal(p.ROSTER_FILL_AT_FORMATION, 50);
  assert.equal(p.LIFTOFF_WINDOW_DAYS, 21);
  assert.deepEqual(p.CRITICAL_ROLES_AT_RAISE, ["icp-operator", "domain-expert", "legal"]);
  assert.equal(p.UPDATE_MAX_ASKS, 3);
  assert.equal(p.PREMISE_FAILURES_BEFORE_TEST, 2);
});

test("an old store without decks, claims or questions still loads", () => {
  const s = buildSeed() as Partial<ReturnType<typeof buildSeed>>;
  delete s.decks;
  delete s.questions;
  delete s.roleClaims;
  const parsed = Store.parse(s);
  assert.deepEqual(parsed.decks, []);
  assert.deepEqual(parsed.questions, []);
  assert.deepEqual(parsed.roleClaims, []);
});

test("spending seat money only on the published plan is protected: a vote can't turn it off", () => {
  const s = buildSeed();
  const v0 = ventureBySlug(s, "protocol")!;
  const { rfe } = logDecision(s, {
    ventureId: v0.id,
    title: "Amend SEAT_MONEY_ON_PLAN",
    reasoning: "Proposed by a member.",
    confidence: 0.5,
    model: "script",
    rfe: {
      type: "judgment",
      kind: "governance",
      title: "Amend SEAT_MONEY_ON_PLAN",
      question: "Let the agent spend seat money off the plan?",
      recommendation: "No",
      stakes: "high",
      format: "choice",
      options: ["Yes", "No"],
      offerUnits: 0,
      audience: "Holders",
      governance: { matter: "parameter-amendment", threshold: "simple", windowEndsAt: "2026-11-06T12:00:00.000Z", paramKey: "SEAT_MONEY_ON_PLAN", currentValue: true, proposedValue: false, effect: "Off-plan spending." },
    },
  });
  for (const h of ["policy_pia", "counsel_kemi", "cfo_ines", "ux_uma", "llc_lena"]) {
    try {
      respond(s, { rfeId: rfe!.id, handle: h, via: "structured", choice: "Yes" });
    } catch {
      /* not every holder has vested units */
    }
  }
  s.meta.clock = "2026-11-07T00:00:00.000Z";
  closeGovernance(s, rfe!);
  assert.match(rfe!.resolution ?? "", /not applied/);
  assert.equal(resolveParams(s).SEAT_MONEY_ON_PLAN, true);
});
