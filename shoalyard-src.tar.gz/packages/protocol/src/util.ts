import type { Store } from "@av/schema";

export const HOUR_MS = 3_600_000;
export const DAY_MS = 24 * HOUR_MS;

export function addHours(iso: string, hours: number): string {
  return new Date(Date.parse(iso) + hours * HOUR_MS).toISOString();
}

export function addDays(iso: string, days: number): string {
  return addHours(iso, days * 24);
}

export function isBefore(a: string, b: string): boolean {
  return Date.parse(a) < Date.parse(b);
}

/** FNV-1a, for deterministic simulation choices. */
export function hash(input: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** Deterministic 0..1 from a string seed. */
export function rand(seed: string): number {
  return hash(seed) / 0xffffffff;
}

export function newId(store: Store, prefix: string): string {
  store.meta.seq = (store.meta.seq ?? 0) + 1;
  return `${prefix}-${store.meta.seq.toString(36).padStart(3, "0")}`;
}

export function round(n: number, dp = 2): number {
  const f = 10 ** dp;
  return Math.round(n * f) / f;
}

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}
