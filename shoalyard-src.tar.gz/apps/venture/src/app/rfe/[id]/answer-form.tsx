"use client";

import { useActionState, useEffect, useRef, useState, useSyncExternalStore, useTransition } from "react";
import { Keyboard, ListChecks, Loader2, Mic, Sparkles, Square } from "lucide-react";
import { toast } from "sonner";
import type { Rfe } from "@av/schema";
import { answerAction, extractAction, type ActionState } from "@/app/actions";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

type Via = "structured" | "text" | "voice";
type Extraction = Awaited<ReturnType<typeof extractAction>>;

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start(): void;
  stop(): void;
  onresult: ((e: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
}

function getRecognition(): SpeechRecognitionLike | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
  const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
  return Ctor ? new Ctor() : null;
}

const noSubscribe = () => () => {};
function hasSpeech() {
  const w = window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown };
  return !!(w.SpeechRecognition ?? w.webkitSpeechRecognition);
}

function Choices({ rfe, value, onChange, name = "choice" }: { rfe: Rfe; value?: string; onChange: (v: string) => void; name?: string }) {
  return (
    <div className="grid gap-2" role="radiogroup">
      {rfe.options!.map((o, i) => (
        <label
          key={o}
          className={cn(
            "flex cursor-pointer items-start gap-3 rounded-lg border bg-white p-3 text-sm transition",
            value === o ? "border-zinc-900 ring-1 ring-zinc-900" : "border-zinc-200 hover:border-zinc-300",
          )}
        >
          <input type="radio" name={name} value={o} checked={value === o} onChange={() => onChange(o)} className="mt-0.5 size-4 accent-zinc-900" />
          <span className="flex-1">{o}</span>
          {i === 0 && rfe.kind === "request" && rfe.type === "judgment" && <span className="text-xs text-zinc-500">Agent&apos;s pick</span>}
        </label>
      ))}
    </div>
  );
}

function Scale({ rfe, value, onChange }: { rfe: Rfe; value?: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-2">
      <div className="grid grid-cols-5 gap-2">
        {[1, 2, 3, 4, 5].map((n) => (
          <label
            key={n}
            className={cn(
              "flex h-11 cursor-pointer items-center justify-center rounded-lg border text-sm font-medium",
              value === n ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white hover:border-zinc-300",
            )}
          >
            <input type="radio" name="scale" value={n} checked={value === n} onChange={() => onChange(n)} className="sr-only" />
            {n}
          </label>
        ))}
      </div>
      {rfe.scaleLabels && (
        <div className="flex justify-between text-xs text-zinc-500">
          <span>{rfe.scaleLabels[0]}</span>
          <span>{rfe.scaleLabels[1]}</span>
        </div>
      )}
    </div>
  );
}

export function AnswerForm({ rfe }: { rfe: Rfe }) {
  const [state, action] = useActionState<ActionState, FormData>(answerAction, { ok: true });
  const governance = rfe.kind === "governance";
  const freeForm = rfe.format === "text" || rfe.format === "action";
  const [via, setVia] = useState<Via>(freeForm ? "text" : "structured");
  const [choice, setChoice] = useState<string | undefined>();
  const [scale, setScale] = useState<number | undefined>();
  const [text, setText] = useState("");
  const [extraction, setExtraction] = useState<Extraction>(null);
  const [extracting, startExtract] = useTransition();
  const [recording, setRecording] = useState(false);
  const [interim, setInterim] = useState("");
  const speechSupported = useSyncExternalStore<boolean | null>(noSubscribe, hasSpeech, () => null);
  const rec = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    if (state.ok && state.message) toast.success(state.message);
  }, [state]);

  const structuredTabs = rfe.format === "choice" || rfe.format === "scale";
  const tabs: { key: Via; label: string; icon: typeof Mic }[] = [
    ...(structuredTabs ? [{ key: "structured" as const, label: "Pick", icon: ListChecks }] : []),
    ...(!governance ? [{ key: "text" as const, label: "Type", icon: Keyboard }] : []),
    ...(!governance ? [{ key: "voice" as const, label: "Speak", icon: Mic }] : []),
  ];

  function extract(t = text) {
    if (!t.trim() || freeForm) return;
    startExtract(async () => {
      const ex = await extractAction(rfe.id, t);
      setExtraction(ex);
      if (ex?.choice) setChoice(ex.choice);
      if (ex?.scale) setScale(ex.scale);
    });
  }

  function toggleRecording() {
    if (recording) {
      rec.current?.stop();
      return;
    }
    const r = getRecognition();
    if (!r) return;
    r.lang = "en-US";
    r.interimResults = true;
    r.continuous = true;
    let finalText = text ? `${text.trim()} ` : "";
    r.onresult = (e) => {
      let live = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        if (res.isFinal) finalText += `${res[0].transcript.trim()} `;
        else live += res[0].transcript;
      }
      setText(finalText.trim());
      setInterim(live);
    };
    r.onerror = (e) => {
      toast.error(e.error === "not-allowed" ? "Microphone access was blocked." : `Voice capture stopped: ${e.error}`);
    };
    r.onend = () => {
      setRecording(false);
      setInterim("");
      extract(finalText);
    };
    rec.current = r;
    r.start();
    setRecording(true);
  }

  if (state.ok && state.message) {
    return (
      <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900" role="status">
        {state.message}
      </div>
    );
  }

  const needsChoiceFromText = via !== "structured" && rfe.format === "choice";
  const needsScaleFromText = via !== "structured" && rfe.format === "scale";

  return (
    <form action={action} className="space-y-5">
      <input type="hidden" name="rfeId" value={rfe.id} />
      <input type="hidden" name="via" value={via} />

      {tabs.length > 1 && (
        <div className="inline-flex rounded-lg border border-zinc-200 bg-zinc-50 p-0.5" role="tablist" aria-label="How to answer">
          {tabs.map((t) => (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={via === t.key}
              onClick={() => setVia(t.key)}
              className={cn(
                "inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-sm font-medium transition",
                via === t.key ? "bg-white text-zinc-900 shadow-xs" : "text-zinc-500 hover:text-zinc-800",
              )}
            >
              <t.icon className="size-4" /> {t.label}
            </button>
          ))}
        </div>
      )}

      {via === "structured" && rfe.format === "choice" && <Choices rfe={rfe} value={choice} onChange={setChoice} />}
      {via === "structured" && rfe.format === "scale" && <Scale rfe={rfe} value={scale} onChange={setScale} />}

      {via !== "structured" && (
        <div className="space-y-2">
          {via === "voice" && (
            <div className="flex flex-wrap items-center gap-3 rounded-lg border border-zinc-200 bg-zinc-50 p-3">
              <Button
                type="button"
                variant={recording ? "destructive" : "default"}
                size="lg"
                onClick={toggleRecording}
                disabled={speechSupported === false}
              >
                {recording ? <Square /> : <Mic />} {recording ? "Stop" : text ? "Record more" : "Start recording"}
              </Button>
              <p className="text-xs text-zinc-500">
                {speechSupported === false
                  ? "This browser has no speech recognition. Type the transcript below instead."
                  : recording
                    ? "Listening… speak naturally; the transcript stays editable."
                    : "Uses your browser's speech recognition. Edit the transcript before you send."}
              </p>
              {recording && <span className="size-2.5 animate-pulse rounded-full bg-rose-500" aria-hidden />}
            </div>
          )}
          <Label htmlFor="answer-text">{via === "voice" ? "Transcript" : rfe.format === "action" ? "What you did" : "Your answer"}</Label>
          <Textarea
            id="answer-text"
            name="text"
            value={recording && interim ? `${text} ${interim}`.trim() : text}
            onChange={(e) => setText(e.target.value)}
            onBlur={() => extract()}
            rows={4}
            placeholder={
              rfe.format === "action"
                ? "Done. Filed on Tuesday; confirmation number is…"
                : rfe.options
                  ? `In your own words. e.g. “${rfe.options[0]}, because…”`
                  : "A sentence or two is plenty."
            }
          />
        </div>
      )}

      {(needsChoiceFromText || needsScaleFromText) && (
        <div className="space-y-2 rounded-lg border border-dashed border-zinc-300 p-3">
          <div className="flex items-center justify-between gap-2">
            <p className="flex items-center gap-1.5 text-sm font-medium text-zinc-800">
              <Sparkles className="size-4" /> Extracted answer
            </p>
            <Button type="button" variant="ghost" size="sm" onClick={() => extract()} disabled={!text.trim() || extracting}>
              {extracting ? <Loader2 className="animate-spin" /> : null} Re-read
            </Button>
          </div>
          {extraction && (
            <p className="text-xs text-zinc-500">
              Read by {extraction.extractedBy === "heuristic" ? "keyword match (no API key set)" : extraction.extractedBy}. Correct it if it&apos;s wrong.
            </p>
          )}
          {needsChoiceFromText && <Choices rfe={rfe} value={choice} onChange={setChoice} />}
          {needsScaleFromText && <Scale rfe={rfe} value={scale} onChange={setScale} />}
        </div>
      )}

      {!governance && rfe.offerUnits > 0 && (
        <p className="rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2 text-sm text-zinc-700">
          Accepted answers earn <strong>{rfe.offerUnits}</strong> equal share{rfe.offerUnits === 1 ? "" : "s"} — the same for everyone whose answer counts.
          <input type="hidden" name="offer" value="accept" />
        </p>
      )}

      <FormMessage state={state} />
      <SubmitButton size="lg" pendingText="Sending…">
        {governance ? "Cast vote" : "Send answer"}
      </SubmitButton>
    </form>
  );
}
