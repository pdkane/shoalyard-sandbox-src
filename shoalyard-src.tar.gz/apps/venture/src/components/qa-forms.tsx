"use client";

import { Check, EyeOff, MessageCircleQuestion, ThumbsUp, UserPlus } from "lucide-react";
import {
  approveQuestionAction,
  askQuestionAction,
  claimRoleAction,
  hideQuestionAction,
  upvoteAction,
  withdrawRoleAction,
  withdrawSeatAction,
} from "@/app/actions";
import { useToastAction } from "@/components/protocol-forms";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

const selectClass = "h-8 rounded-lg border border-zinc-200 bg-white px-2 text-sm";

function HandleField({ id }: { id: string }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>Your handle</Label>
      <Input id={id} name="handle" required minLength={2} maxLength={24} pattern="@?[A-Za-z0-9_]{2,24}" placeholder="e.g. roofer_rita" autoComplete="off" className="h-9" />
      <p className="text-xs text-zinc-500">Pseudonymous. You can get verified later; until then you count as a candidate.</p>
    </div>
  );
}

export function AskForm({ slug, left, visitor, maxChars, note }: { slug: string; left: number; visitor: boolean; maxChars: number; note?: string }) {
  const [state, action] = useToastAction(askQuestionAction);
  return (
    <form action={action} className="space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
      <input type="hidden" name="slug" value={slug} />
      <div className="space-y-1.5">
        <Label htmlFor={`ask-${slug}`} className="flex items-center gap-1.5">
          <MessageCircleQuestion className="size-4" /> Ask the agent
        </Label>
        <Textarea
          id={`ask-${slug}`}
          name="text"
          rows={3}
          required
          minLength={8}
          maxLength={maxChars}
          placeholder="What would make this fail? Where does the price come from?"
        />
      </div>
      {visitor && <HandleField id={`ask-handle-${slug}`} />}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-zinc-500">
          {left > 0 ? `${left} question${left === 1 ? "" : "s"} left today.` : "No questions left today."} The agent answers from the deck only and says when it doesn&apos;t know.
          {note ? ` ${note}` : ""}
        </p>
        <SubmitButton size="sm" disabled={left <= 0} pendingText="Asking…">
          Ask
        </SubmitButton>
      </div>
      <FormMessage state={state} />
    </form>
  );
}

export function UpvoteButton({ id, count, active, disabled, why }: { id: string; count: number; active: boolean; disabled?: boolean; why?: string }) {
  const [state, action] = useToastAction(upvoteAction);
  return (
    <form action={action} className="inline-flex flex-col items-center">
      <input type="hidden" name="id" value={id} />
      <SubmitButton
        size="sm"
        variant="outline"
        disabled={disabled}
        title={why}
        aria-pressed={active}
        aria-label={`${active ? "Remove upvote" : "Upvote"} (${count})`}
        className={cn("h-8 gap-1 px-2 tabular-nums", active && "border-zinc-900 bg-zinc-900 text-white hover:bg-zinc-800 hover:text-white")}
      >
        <ThumbsUp className="size-3.5" /> {count}
      </SubmitButton>
      {state.error && <span className="mt-1 max-w-32 text-center text-[11px] text-rose-700">{state.error}</span>}
    </form>
  );
}

export function HideQuestionForm({ id, reasons }: { id: string; reasons: string[] }) {
  const [state, action] = useToastAction(hideQuestionAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="id" value={id} />
      <select name="reason" required defaultValue="" aria-label="Reason to hide" className={selectClass}>
        <option value="" disabled>
          Hide because…
        </option>
        {reasons.map((r) => (
          <option key={r} value={r}>
            {r}
          </option>
        ))}
      </select>
      <SubmitButton size="sm" variant="outline" className="text-rose-700">
        <EyeOff /> Hide
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function ApproveQuestionForm({ id }: { id: string }) {
  const [state, action] = useToastAction(approveQuestionAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="id" value={id} />
      <Input name="note" placeholder="Note (optional)" className="h-8 w-48" />
      <SubmitButton size="sm">
        <Check /> Approve
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function ClaimRoleDialog({
  slug,
  roleKey,
  label,
  qualifications,
  visitor,
  pendingViewer,
}: {
  slug: string;
  roleKey: string;
  label: string;
  qualifications: string[];
  visitor: boolean;
  pendingViewer: boolean;
}) {
  const [state, action] = useToastAction(claimRoleAction);
  return (
    <Dialog>
      <DialogTrigger render={<Button size="sm" variant="outline" className="h-7 px-2 text-xs" />}>
        <UserPlus className="size-3.5" /> Claim
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Claim “{label}”</DialogTitle>
          <DialogDescription>
            You don&apos;t need a seat to claim a role. It counts once you&apos;re verified and your profile fits: {qualifications.join("; ") || "a matching role or industry"}.
            {pendingViewer ? " You're not verified yet, so it shows as “checking” until the steward confirms your profile." : ""}
          </DialogDescription>
        </DialogHeader>
        <form action={action} className="space-y-3">
          <input type="hidden" name="slug" value={slug} />
          <input type="hidden" name="roleKey" value={roleKey} />
          {visitor && <HandleField id={`claim-handle-${roleKey}`} />}
          <div className="space-y-1.5">
            <Label htmlFor={`claim-note-${roleKey}`}>What you&apos;d bring (optional)</Label>
            <Textarea id={`claim-note-${roleKey}`} name="note" rows={2} maxLength={240} placeholder="I run estimating at a 30-person roofing firm in Atlanta…" />
          </div>
          <FormMessage state={state} />
          <DialogFooter>
            <DialogClose render={<Button variant="outline" type="button" />}>Cancel</DialogClose>
            <SubmitButton>Claim the role</SubmitButton>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function WithdrawRoleForm({ slug }: { slug: string }) {
  const [state, action] = useToastAction(withdrawRoleAction);
  return (
    <form action={action} className="inline-flex items-center gap-2">
      <input type="hidden" name="slug" value={slug} />
      <SubmitButton size="sm" variant="ghost" className="h-7 px-2 text-xs">
        Withdraw my claim
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function WithdrawSeatForm({ slug, price }: { slug: string; price: string }) {
  const [state, action] = useToastAction(withdrawSeatAction);
  return (
    <form action={action} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="slug" value={slug} />
      <SubmitButton size="sm" variant="outline">
        Take my seat back · {price} refunded
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}
