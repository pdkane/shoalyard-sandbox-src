import {
  assertTransition,
  DECISION_TRANSITIONS,
  GRANT_TRANSITIONS,
  RFE_TRANSITIONS,
  VENTURE_STATUS_LABELS,
  VENTURE_TRANSITIONS,
  type Decision,
  type DecisionFacts,
  type Grant,
  type KillReason,
  type LedgerEntry,
  type Member,
  type MemberAttribute,
  type ParamValues,
  type Response,
  type Rfe,
  type Store,
  type TagAxis,
  type Venture,
  type VentureStatus,
} from "@av/schema";
import { classify } from "./classifier";
import { loosensBelowFloor, mergeReview, quotedLessons, screenText, type ConductResult } from "./conduct";
import { assertSeatWindow, cohortFor, closeCohort, unpublishedPostMortems } from "./batches";
import { MEMBER_VOTE_STANDS, settleFlag } from "./flags";
import { settleHandOffVote } from "./handoff";
import { citedLessonIds, contradictedLessons, escalate, runLearningPass } from "./learning";
import { addClassificationValue, mergeTags, outcomeTags, proposeRfeTags, workDeliveryOf } from "./tags";
import { matterLabel } from "./glossary";
import { latestDeck, onStewardDeckDecision, seatPriceHold, seatPriceOf, spendCheck } from "./deck";
import { awaitingRoster, checkRaise, onMemberQualified, onStewardLiftoff } from "./roster";
import { seatMath } from "./sizing";
import { attributeNewMember, recordStage, referralsDue } from "./sharing";
import { meetsQualification, PROVIDERS, verifiedShare } from "./verification";
import {
  capTable,
  computeDistribution,
  protocolPctFor,
  tallyVote,
  totalVestedUnits,
  vestedByHandle,
  vestedUnits,
} from "./economics";
import { evaluateN, type NStatus } from "./n-engine";
import { resolveParams } from "./params";
import { addDays, newId, round } from "./util";

export class ProtocolError extends Error {}

export const ESCROW_NOTE = "Seat money is held, unspent, until the minimum is met";

/** A venture's name for use mid-sentence: the Protocol's name starts with "The". */
export function inSentence(v: Pick<Venture, "name" | "isProtocol">): string {
  return v.isProtocol ? "the Protocol" : v.name;
}


const SLICE_NOTES: Record<Grant["slice"], string> = {
  rfe: "answering a request",
  steward: "stewarding",
  cohort: "batch-wide share",
  founder: "founding steward",
};

/* ---------- lookups ---------- */

export function ventureById(store: Store, id: string): Venture {
  const v = store.ventures.find((x) => x.id === id);
  if (!v) throw new ProtocolError(`No venture ${id}`);
  return v;
}

export function ventureBySlug(store: Store, slug: string): Venture | undefined {
  return store.ventures.find((x) => x.slug === slug);
}

export function protocolVenture(store: Store): Venture {
  const v = store.ventures.find((x) => x.isProtocol);
  if (!v) throw new ProtocolError("The Protocol is missing from the store");
  return v;
}

export function memberByHandle(store: Store, handle: string): Member | undefined {
  const h = handle.toLowerCase();
  return store.members.find((m) => m.handle.toLowerCase() === h);
}

export function rfeById(store: Store, id: string): Rfe | undefined {
  return store.rfes.find((r) => r.id === id);
}

function refundedSeatIds(store: Store, ventureId: string): Set<string> {
  return new Set(store.ledger.filter((l) => l.ventureId === ventureId && l.kind === "refund" && l.ref).map((l) => l.ref!));
}

/** Seats still held: refunded seats no longer count toward the raise or give access. */
export function activeSeats(store: Store, ventureId: string): LedgerEntry[] {
  const refunded = refundedSeatIds(store, ventureId);
  return store.ledger.filter((l) => l.ventureId === ventureId && l.kind === "seat" && !refunded.has(l.id));
}

export function seatHolders(store: Store, ventureId: string): string[] {
  return activeSeats(store, ventureId).filter((l) => l.handle).map((l) => l.handle!);
}

export function seatsSold(store: Store, ventureId: string): number {
  return activeSeats(store, ventureId).length;
}

export function hasSeat(store: Store, ventureId: string, handle: string): boolean {
  return store.ledger.some(
    (l) =>
      l.ventureId === ventureId &&
      l.kind === "seat" &&
      l.handle === handle &&
      !store.ledger.some((r) => r.kind === "refund" && r.ref === l.id),
  );
}

/** Seats refunded so far, for a venture and optionally one holder. */
export function seatRefunds(store: Store, ventureId: string, handle?: string): { count: number; totalUsd: number } {
  const rows = store.ledger.filter((l) => l.ventureId === ventureId && l.kind === "refund" && (!handle || l.handle === handle));
  return { count: rows.length, totalUsd: round(rows.reduce((s, l) => s - (l.usd ?? 0), 0)) };
}

export function responsesFor(store: Store, rfeId: string): Response[] {
  return store.responses.filter((r) => r.rfeId === rfeId);
}

/** Only verified attributes count toward diversity: members with no verified role or industry share one cluster. */
export function clusterLookup(store: Store): (handle: string) => string {
  const verified = (m: Member) =>
    m.verifications.some((v) => v.status === "confirmed" && (v.attributes.includes("role") || v.attributes.includes("industry")));
  const map = new Map(store.members.map((m) => [m.handle, verified(m) ? m.cluster : "unverified"]));
  return (h) => map.get(h) ?? h;
}

export const isOpen = (rfe: Pick<Rfe, "status">) => rfe.status === "posted" || rfe.status === "quorum";
export const isLive = (v: Pick<Venture, "status">) => v.status !== "killed" && v.status !== "dormant" && v.status !== "handed-off";

export function nStatusFor(store: Store, rfe: Rfe, params = resolveParams(store)): NStatus {
  const venture = ventureById(store, rfe.ventureId);
  return evaluateN(rfe, responsesFor(store, rfe.id), clusterLookup(store), params, {
    minRaiseUsd: venture.minRaiseUsd,
    seatsSold: seatsSold(store, venture.id),
    seatPriceUsd: seatPriceOf(venture, params),
  });
}

/**
 * Who may answer: qualified seat holders of the venture; every qualified
 * member for the Protocol and for public demand checks. A member gets no
 * requests until qualified.
 */
export function canAnswer(store: Store, rfe: Rfe, handle: string): boolean {
  const venture = ventureById(store, rfe.ventureId);
  if (rfe.type === "capital" || rfe.gtm) return false;
  if (rfe.assignedTo) return rfe.assignedTo === handle;
  const member = memberByHandle(store, handle);
  if (member?.qualification !== "qualified") return false;
  if (venture.isProtocol || rfe.demandCheck) return true;
  return hasSeat(store, venture.id, handle);
}

export function inboxFor(store: Store, handle: string): Rfe[] {
  const answered = new Set(store.responses.filter((r) => r.handle === handle).map((r) => r.rfeId));
  return store.rfes
    .filter((r) => isOpen(r) && !answered.has(r.id) && canAnswer(store, r, handle))
    .filter((r) => isLive(ventureById(store, r.ventureId)))
    .sort((a, b) => b.postedAt.localeCompare(a.postedAt));
}

/* ---------- ledger helpers ---------- */

export function ledger(store: Store, entry: Omit<LedgerEntry, "id" | "at"> & { at?: string }): LedgerEntry {
  const row: LedgerEntry = { id: newId(store, "l"), at: entry.at ?? store.meta.clock, ...entry };
  store.ledger.push(row);
  return row;
}

export function notify(store: Store, ventureId: string, handle: string, message: string) {
  ledger(store, { ventureId, kind: "notify", handle, note: `Would email @${handle}: ${message}` });
}

/* ---------- venture lifecycle ---------- */

export function transitionVenture(store: Store, venture: Venture, to: VentureStatus, note?: string) {
  if (venture.status === to) return;
  assertTransition(VENTURE_TRANSITIONS, venture.status, to, `${venture.name}`);
  if (to === "formed" && awaitingRoster(store, venture)) {
    throw new ProtocolError(`${venture.name} can't form yet: its own plan needs these people before it spends formation money. Fill the roster first.`);
  }
  venture.status = to;
  venture.statusHistory.push({ status: to, at: store.meta.clock, note });
  ledger(store, {
    ventureId: venture.id,
    kind: "status",
    note: `${venture.name} is now ${VENTURE_STATUS_LABELS[to]}${note ? `: ${note}` : ""}`,
  });
  if (!venture.isProtocol) venture.tags = mergeTags(venture.tags, outcomeTags(venture));
  if (to === "customer1" || to === "killed") runLearningPass(store, { kind: to === "killed" ? "kill" : "customer1", ventureId: venture.id });
  if (to === "formed" && !store.grants.some((g) => g.ventureId === venture.id && g.slice === "steward")) {
    const params = resolveParams(store);
    issueGrant(store, {
      venture,
      handle: venture.stewardHandle,
      slice: "steward",
      units: params.POOL_STEWARD_UNITS,
      note: "Steward's units, given when the company was set up",
    });
  }
}

/* ---------- RFEs ---------- */

export interface RfeDraft {
  type: Rfe["type"];
  kind?: Rfe["kind"];
  title: string;
  question: string;
  recommendation: string;
  confidence?: number;
  stakes: Rfe["stakes"];
  format: Rfe["format"];
  options?: string[];
  scaleLabels?: [string, string];
  offerUnits: number;
  audience: string;
  targetOverride?: number;
  assignedTo?: string;
  governance?: Rfe["governance"];
  gtm?: Rfe["gtm"];
  demandCheck?: boolean;
  lessonIds?: string[];
  tags?: Rfe["tags"];
  notes?: Rfe["notes"];
  id?: string;
}

export function postRfe(store: Store, ventureId: string, draft: RfeDraft, decisionId?: string): Rfe {
  const params = resolveParams(store);
  const { id, ...rest } = draft;
  const rfe: Rfe = {
    id: id ?? newId(store, "rfe"),
    ventureId,
    kind: draft.kind ?? "request",
    ...rest,
    confidence: draft.confidence ?? 0.6,
    // Equal shares: every paid request offers the same per accepted answer.
    offerUnits: draft.offerUnits > 0 ? params.SHARE_PER_ANSWER : 0,
    status: "posted",
    postedAt: store.meta.clock,
    decisionId,
  };
  const venture = ventureById(store, ventureId);
  if (!rfe.tags && !venture.isProtocol && !rfe.gtm) rfe.tags = proposeRfeTags(rfe, venture);
  store.rfes.push(rfe);
  return rfe;
}

export function setRfeStatus(rfe: Rfe, to: Rfe["status"]) {
  if (rfe.status === to) return;
  assertTransition(RFE_TRANSITIONS, rfe.status, to, `Request ${rfe.id}`);
  rfe.status = to;
}

/* ---------- decisions ---------- */

export interface DecisionInput {
  ventureId: string;
  title: string;
  reasoning: string;
  confidence: number;
  facts?: Partial<DecisionFacts>;
  outcome?: string;
  embargoReason?: string;
  transition?: VentureStatus;
  model: string;
  rfe?: RfeDraft;
  id?: string;
  /** Adopted lessons the agent used; ids cited in the reasoning are picked up too. */
  lessonIds?: string[];
  /** One short reason for verified members. Defaults to the first sentence of the reasoning. */
  summary?: string;
  /** Model review of the text against the conduct checklist, when a key is set. Can only escalate. */
  conductReview?: { result: "pass" | "concern"; reason: string; model: string };
}

/** Text the conduct screen reads for a decision, and whether any of it goes out to the public. */
export function conductTextFor(input: Pick<DecisionInput, "title" | "reasoning" | "rfe">): { text: string; outbound: string[] } {
  // A thread is read as one piece; each outreach template is sent on its own.
  const posts = input.rfe?.gtm?.posts ?? [];
  const outbound = [...(posts.length ? [posts.join("\n")] : []), ...(input.rfe?.gtm?.segments?.map((s) => s.template) ?? [])];
  return { text: [input.title, input.reasoning, input.rfe?.question ?? ""].join("\n"), outbound };
}

export function screenDecision(store: Store, input: DecisionInput, params = resolveParams(store)): ConductResult {
  const venture = ventureById(store, input.ventureId);
  const { text, outbound } = conductTextFor(input);
  const base = screenText({ text, customers: venture.customers.count, nearSeats: input.rfe?.type === "capital" }, params);
  const results = [base, ...outbound.map((t) => screenText({ text: t, outbound: true, customers: venture.customers.count, nearSeats: /seat/i.test(t) }, params))];
  if (params.LESSONS_VISIBLE_TO !== "public") {
    const quoted = outbound.flatMap((t) => quotedLessons(t, store.lessons)).map((l) => l.id);
    if (quoted.length) {
      results.push({
        result: "stop",
        findings: [`Quotes ${[...new Set(quoted)].join(", ")}. Lessons are for members (Article 3); say what the venture does instead.`],
        regulated: [],
        reviewedBy: "rules",
      });
    }
  }
  const rank = { pass: 0, concern: 1, stop: 2 } as const;
  const merged: ConductResult = {
    result: results.reduce<ConductResult["result"]>((r, x) => (rank[x.result] > rank[r] ? x.result : r), "pass"),
    findings: [...new Set(results.flatMap((r) => r.findings))],
    regulated: [...new Set(results.flatMap((r) => r.regulated))],
    reviewedBy: "rules",
  };
  merged.counselNote = merged.regulated.length
    ? `Touches ${merged.regulated.join(", ")}. Needs the steward's sign-off; a lawyer should confirm before it goes out.`
    : undefined;
  return mergeReview(merged, input.conductReview);
}

function fullFacts(f: Partial<DecisionFacts> = {}): DecisionFacts {
  return {
    spendUsd: f.spendUsd ?? 0,
    contract: f.contract ?? false,
    pricingChange: f.pricingChange ?? false,
    newOutboundDomain: f.newOutboundDomain ?? false,
    publicPost: f.publicPost ?? false,
    hiresPerson: f.hiresPerson ?? false,
    contractorPitch: f.contractorPitch ?? false,
    bigQuestion: f.bigQuestion,
    goalpostMove: f.goalpostMove ?? false,
    materialDeckChange: f.materialDeckChange ?? false,
    budgetLine: f.budgetLine,
    channelTest: f.channelTest ?? false,
    experimentId: f.experimentId,
    deckId: f.deckId,
    liftoff: f.liftoff,
    review: f.review,
  };
}

/**
 * The short reason verified members read: the first sentence, without lesson
 * ids (lessons followed are for unit holders), at most about 160 characters.
 */
export function shortReason(reasoning: string): string {
  const plain = reasoning
    .replace(/\s*\((?:per |see |follows? )?L-\d{3}(?:,\s*L-\d{3})*\)/g, "")
    .replace(/,?\s*(?:per|following|as in|see) L-\d{3}(?:(?:,| and) L-\d{3})*/gi, "")
    .replace(/\bL-\d{3}\b/g, "an earlier lesson")
    .replace(/\s+/g, " ")
    .trim();
  const first = plain.match(/^.*?[.!?](?=\s|$)/)?.[0] ?? plain;
  if (first.length <= 160) return first;
  const cut = first.slice(0, 157);
  return `${cut.slice(0, cut.lastIndexOf(" "))}…`;
}

export function decisionSummary(d: Pick<Decision, "summary" | "reasoning">): string {
  return d.summary?.trim() || shortReason(d.reasoning);
}

/** Classify, log, and act on one decision. Every decision is logged regardless of bin. */
export function logDecision(store: Store, input: DecisionInput): { decision: Decision; rfe?: Rfe } {
  const params = resolveParams(store);
  const venture = ventureById(store, input.ventureId);
  const facts = fullFacts(input.facts);
  const classified = classify(facts, input.confidence, params);
  let bin = classified.bin;
  const reasons = [...classified.reasons];
  // Going against a kept lesson means one more level of review.
  const contradicts = contradictedLessons(store, venture, {
    title: input.title,
    reasoning: input.reasoning,
    facts,
    lessonIds: input.lessonIds,
  }).map((l) => l.id);
  const lessonIds = [...new Set([...(input.lessonIds ?? []), ...citedLessonIds(input.reasoning)])].filter((id) => !contradicts.includes(id));
  if (contradicts.length) {
    bin = escalate(bin);
    reasons.push(`Goes against ${contradicts.join(", ")}, so it needed more review`);
  }

  // Conduct screen (Article 8): concerns escalate to the steward, stops reject. Never rewrites.
  const conduct = screenDecision(store, input, params);
  if (conduct.result !== "pass" && bin !== "gated") bin = "gated";
  for (const f of conduct.findings) reasons.push(`Conduct: ${f}`);
  if (conduct.counselNote) reasons.push(`Counsel: ${conduct.counselNote}`);

  // Big questions go to a unit-holder vote, whatever the agent's confidence (Article 5).
  const matters = params.RESERVED_MATTERS as Record<string, "simple" | "super">;
  const bigQuestion = facts.bigQuestion && matters[facts.bigQuestion] ? facts.bigQuestion : undefined;
  if (bigQuestion && conduct.result !== "stop") {
    bin = "advisory";
    reasons.unshift(`A big question (${matterLabel(bigQuestion)}): unit holders vote on it, not the agent (Article 5)`);
  }

  const decision: Decision = {
    id: input.id ?? newId(store, "dec"),
    ventureId: venture.id,
    title: input.title,
    reasoning: input.reasoning,
    summary: input.summary?.trim() || shortReason(input.reasoning),
    confidence: input.confidence,
    facts,
    bin,
    binReasons: reasons,
    status: bin === "auto" ? "taken" : bin === "advisory" ? "awaiting_members" : "awaiting_steward",
    at: store.meta.clock,
    model: input.model,
    transition: input.transition,
    lessonIds: lessonIds.length ? lessonIds : undefined,
    contradicts: contradicts.length ? contradicts : undefined,
    conduct: conduct.result === "pass" && conduct.reviewedBy === "rules" ? undefined : conduct,
  };
  if (conduct.result === "stop") {
    decision.status = "rejected";
    decision.takenAt = store.meta.clock;
    decision.outcome = "Blocked by the conduct check (Article 8). Nothing was posted or done.";
    store.decisions.push(decision);
    return { decision };
  }
  // Article 2 escrow: nothing is spent from seat money before the raise closes.
  if (venture.status === "pitched" && facts.spendUsd > 0) {
    decision.bin = "gated";
    decision.binReasons.push(`${ESCROW_NOTE}: $${facts.spendUsd} can't be spent while seats are still selling (Article 2)`);
    decision.status = "rejected";
    decision.takenAt = store.meta.clock;
    decision.outcome = `Stopped: ${ESCROW_NOTE.toLowerCase()}. Nothing was spent.`;
    store.decisions.push(decision);
    return { decision };
  }
  const plan = spendCheck(store, venture, { title: input.title, facts }, params);
  if (plan.verdict === "reject") {
    decision.bin = "gated";
    decision.binReasons.push(plan.reason);
    decision.status = "rejected";
    decision.takenAt = store.meta.clock;
    decision.outcome = `Stopped: ${plan.reason} Nothing was spent.`;
    store.decisions.push(decision);
    return { decision };
  }
  if (plan.line) decision.facts.budgetLine = plan.line;
  if (plan.verdict === "gate" && bin !== "gated") {
    bin = "gated";
    decision.bin = bin;
    decision.status = "awaiting_steward";
  }
  if (plan.verdict === "gate") decision.binReasons.push(plan.reason);
  if (input.embargoReason) {
    const until = addDays(store.meta.clock, Math.min(params.DEFAULT_EMBARGO_DAYS, params.PRIVATE_DECISION_MAX_DAYS));
    decision.embargo = { until, reason: input.embargoReason };
    ledger(store, {
      ventureId: venture.id,
      kind: "redaction",
      ref: decision.id,
      note: `Decision withheld (${input.embargoReason}); published ${until.slice(0, 10)}`,
    });
  }
  store.decisions.push(decision);

  let rfe: Rfe | undefined;
  if (bigQuestion) {
    const voteIn = totalVestedUnits(store, venture.id) > 0 ? venture : protocolVenture(store);
    rfe = postRfe(
      store,
      voteIn.id,
      {
        type: "judgment",
        kind: "governance",
        title: input.title,
        question: `The agent proposes: ${input.title}. This is a big question (${matterLabel(bigQuestion)}), so unit holders decide. Should it go ahead?`,
        recommendation: "Members decide; the agent can propose but never votes",
        confidence: input.confidence,
        stakes: "high",
        format: "choice",
        options: ["Yes", "No"],
        offerUnits: 0,
        audience: `${voteIn.isProtocol ? "Protocol" : venture.name} unit holders`,
        governance: {
          matter: bigQuestion,
          threshold: matters[bigQuestion],
          windowEndsAt: addDays(store.meta.clock, params.VOTE_WINDOW_DAYS),
          effect: `If it passes, the agent goes ahead with: ${input.title}.`,
        },
      },
      decision.id,
    );
    decision.rfeId = rfe.id;
    return { decision, rfe };
  }
  if (bin === "advisory") {
    const draft: RfeDraft = input.rfe ?? {
      type: "judgment",
      title: input.title,
      question: `The agent plans to: ${input.title}. Should it?`,
      recommendation: "Go ahead",
      stakes: "medium",
      format: "choice",
      options: ["Go ahead", "Hold off"],
      offerUnits: 1,
      audience: "Seat holders",
    };
    rfe = postRfe(store, venture.id, { ...draft, confidence: input.confidence, lessonIds: draft.lessonIds ?? decision.lessonIds }, decision.id);
    decision.rfeId = rfe.id;
  } else if (input.rfe) {
    rfe = postRfe(store, venture.id, { ...input.rfe, confidence: input.rfe.confidence ?? input.confidence }, decision.id);
    decision.rfeId = rfe.id;
  }

  if (bin === "auto") takeDecision(store, decision, input.outcome ?? "Taken");
  return { decision, rfe };
}

export function takeDecision(store: Store, decision: Decision, outcome: string) {
  if (decision.status !== "taken") assertTransition(DECISION_TRANSITIONS, decision.status, "taken", "Decision");
  decision.status = "taken";
  decision.takenAt = store.meta.clock;
  decision.outcome = outcome;
  if (decision.transition) {
    const v = ventureById(store, decision.ventureId);
    if (v.status !== decision.transition && VENTURE_TRANSITIONS[v.status].includes(decision.transition)) {
      transitionVenture(store, v, decision.transition, decision.title);
    }
  }
}

export function rejectDecision(store: Store, decision: Decision, outcome: string) {
  assertTransition(DECISION_TRANSITIONS, decision.status, "rejected", "Decision");
  decision.status = "rejected";
  decision.takenAt = store.meta.clock;
  decision.outcome = outcome;
}

export const EMPLOYMENT_BLOCKED =
  "Ventures that need employees can't pitch yet. Employment stays off until the Protocol has an employer of record, payroll and insurance in place; see the open request on the Protocol.";

/** A level-2 pitch waiting for the steward: seats don't open until it is signed off. */
export function pitchAwaitingSignOff(store: Store, v: Pick<Venture, "slug">): boolean {
  return store.decisions.some((d) => d.id === `dec-${v.slug}-pitch` && d.status === "awaiting_steward");
}

function seatRfe(v: Venture, params: ParamValues): RfeDraft {
  return {
      id: `rfe-${v.slug}-raise`,
      type: "capital",
      title: `Seats in ${inSentence(v)}: $${seatPriceOf(v, params)} each, $${v.minRaiseUsd} minimum`,
      question: `Take a seat to receive ${inSentence(v)}'s requests. A seat is not a share and pays nothing back. Seat money is held, unspent, until the minimum is met; if it isn't, every seat is refunded in full. To answer requests you also need to be verified.`,
      recommendation: "Take a seat if you can help with the requests below",
      stakes: "medium",
      format: "action",
      offerUnits: 0,
      audience: "Anyone who can help this venture reach its first customer",
  };
}

/**
 * Publish the pitch and open the seat request. A seat gets you requests; it is not a share.
 * A venture that pays contractors needs the steward's sign-off first; one that needs employees can't pitch.
 */
export function pitchVenture(store: Store, v: Venture, model = "rule"): Decision {
  const params = resolveParams(store);
  const delivery = workDeliveryOf(v);
  if (delivery === "Employees" && !params.EMPLOYMENT_ALLOWED) throw new ProtocolError(`${v.name}: ${EMPLOYMENT_BLOCKED}`);
  const contractors = delivery === "Agent plus contractors";
  const deck = latestDeck(store, v.id);
  const worked = deck
    ? `Seat plan from deck v${deck.version}: ${seatMath(deck.seatPlan, deck.roster)
        .map((l) => `${l.label}${l.detail ? ` (${l.detail})` : ""}: ${l.value}`)
        .join("; ")}.`
    : `The budget to the first customer is $${v.minRaiseUsd}: ${v.budget.map((b) => `${b.label.toLowerCase()} $${b.usd}`).join(", ")}.`;
  return logDecision(store, {
    ventureId: v.id,
    id: `dec-${v.slug}-pitch`,
    title: `Open seats in ${inSentence(v)}: minimum $${v.minRaiseUsd}`,
    reasoning: `${worked}${contractors ? " Contractors are paid in cash for the work, so the steward signs off on the pitch and on each hire." : ""}`,
    confidence: 0.86,
    facts: { contractorPitch: contractors },
    transition: "pitched",
    outcome: "Pitched; seats open",
    model,
    lessonIds: v.lessonIds,
    rfe: contractors ? undefined : seatRfe(v, params),
  }).decision;
}

/**
 * Pay a contractor in cash for one job. Contractors never earn units for it, and the
 * public ledger shows the amount against the hire, never the person's name.
 */
export function payContractor(store: Store, input: { hireDecisionId: string; usd: number; job: string }) {
  const hire = store.decisions.find((d) => d.id === input.hireDecisionId);
  if (!hire || !hire.facts.hiresPerson) throw new ProtocolError("Pay a contractor against the decision that hired them.");
  if (hire.status !== "taken") throw new ProtocolError("The steward hasn't signed off on this hire yet.");
  const venture = ventureById(store, hire.ventureId);
  if (workDeliveryOf(venture) !== "Agent plus contractors") throw new ProtocolError(`${venture.name} is classified as agent only; it doesn't pay contractors.`);
  if (!(input.usd > 0)) throw new ProtocolError("Give the amount paid.");
  return ledger(store, {
    ventureId: venture.id,
    kind: "contractor-pay",
    usd: round(input.usd, 2),
    ref: hire.id,
    note: `Paid ${contractorLabel(store, hire)} for ${input.job.trim()}. Cash for the work; no units.`,
  });
}

/** “Contractor 2”: numbered by hire within the venture, so the ledger never names anyone. */
export function contractorLabel(store: Store, hire: Pick<Decision, "id" | "ventureId">): string {
  const hires = store.decisions.filter((d) => d.ventureId === hire.ventureId && d.facts.hiresPerson).sort((a, b) => a.at.localeCompare(b.at) || a.id.localeCompare(b.id));
  return `Contractor ${hires.findIndex((d) => d.id === hire.id) + 1}`;
}

/* ---------- seats and onboarding ---------- */

export const HANDLE_RE = /^[A-Za-z0-9_]{2,24}$/;

/** Find a member by handle, or add a new pending candidate. Nobody needs a seat to be a member. */
export function ensureMember(store: Store, handleInput: string, source?: string, referredBy?: string, ventureId?: string): Member {
  const params = resolveParams(store);
  const handle = handleInput.replace(/^@/, "").trim();
  if (!HANDLE_RE.test(handle)) throw new ProtocolError("Handles are 2–24 letters, numbers or underscores.");
  const existing = memberByHandle(store, handle);
  if (existing) return existing;
  const member: Member = {
    handle,
    role: "New member",
    industry: "Not yet told us",
    seniority: "mid",
    reputationTier: "new",
    cluster: `solo-${handle.toLowerCase()}`,
    profile: { companies: [], buyingAuthority: "Unknown", tools: [], verticals: [], canReach: [] },
    dailyPushCap: params.DAILY_PUSH_CAP_DEFAULT,
    qualification: "pending",
    verifications: [],
    joinedAt: store.meta.clock,
    source,
  };
  store.members.push(member);
  attributeNewMember(store, member, referredBy, ventureId);
  return member;
}

export function buySeat(
  store: Store,
  input: { slug: string; handle: string; source?: string; referredBy?: string },
): { member: Member; venture: Venture; funded: boolean } {
  const params = resolveParams(store);
  const venture = ventureBySlug(store, input.slug);
  if (!venture) throw new ProtocolError("That venture does not exist.");
  if (!isLive(venture)) throw new ProtocolError(`${venture.name} is ${venture.status}; it is not selling seats.`);
  if (pitchAwaitingSignOff(store, venture)) {
    throw new ProtocolError(`${venture.name} pays contractors for its work, so the steward signs off on the pitch first. Seats open once that's done.`);
  }
  const deck = latestDeck(store, venture.id);
  const priceHold = seatPriceHold(store, venture);
  if (priceHold) throw new ProtocolError(priceHold);
  const handle = input.handle.replace(/^@/, "").trim();
  if (!HANDLE_RE.test(handle)) throw new ProtocolError("Handles are 2–24 letters, numbers or underscores.");
  assertSeatWindow(store, venture, memberByHandle(store, handle));
  if (deck && seatsSold(store, venture.id) >= deck.seatPlan.max) {
    throw new ProtocolError(`All ${deck.seatPlan.max} seats in ${venture.name} are taken. You can still claim a role on its roster without a seat.`);
  }
  const member = ensureMember(store, handle, input.source, input.referredBy, venture.id);
  if (hasSeat(store, venture.id, member.handle)) {
    throw new ProtocolError(`@${member.handle} already holds a seat in ${venture.name}.`);
  }
  ledger(store, {
    ventureId: venture.id,
    kind: "seat",
    handle: member.handle,
    usd: seatPriceOf(venture, params),
    ref: input.source,
    deckId: deck?.id,
    note: `Seat for @${member.handle}. It gets them this venture's requests; it is not a share.`,
  });
  recordStage(store, member, "seat", venture.id);
  const funded = checkRaise(store, venture);
  return { member, venture, funded };
}

export interface OnboardingProfile {
  role: string;
  industry: string;
  seniority: Member["seniority"];
  companies: string[];
  buyingAuthority: string;
  tools: string[];
  verticals: string[];
  canReach: string[];
  dailyPushCap?: number;
  cluster?: string;
}

const CLUSTER_RULES: [RegExp, string][] = [
  [/freight|logistic|broker|3pl|trucking|shipping/i, "freight-ops"],
  [/construct|roof|hvac|contractor|permit|building/i, "construction-sales"],
  [/dental|clinic|health|medical/i, "dental-ops"],
  [/law|legal|counsel|attorney|securit/i, "legal-counsel"],
  [/saas|software|growth|marketing|gtm|sales/i, "saas-gtm"],
  [/data|analytics|engineer|ml|ai/i, "data-eng"],
  [/financ|account|bookkeep|fund|invest|cfo/i, "finance-ops"],
];

/** Plain names for profile clusters, for anything a member reads. */
export const CLUSTER_LABELS: Record<string, string> = {
  "freight-ops": "freight operations",
  "construction-sales": "construction sales",
  "dental-ops": "dental practice operations",
  "legal-counsel": "law",
  "saas-gtm": "software sales and marketing",
  "data-eng": "data engineering",
  "finance-ops": "finance and accounting",
  "startup-scout": "startup scouting",
  generalist: "general business",
};

export const clusterLabel = (cluster: string) => CLUSTER_LABELS[cluster] ?? cluster.replace(/-/g, " ");

/** Heuristic profile cluster. Claude Haiku can replace this when a key is set. */
export function clusterFor(profile: Pick<OnboardingProfile, "industry" | "role" | "verticals">): string {
  const text = [profile.industry, profile.role, ...profile.verticals].join(" ");
  for (const [re, cluster] of CLUSTER_RULES) if (re.test(text)) return cluster;
  return "generalist";
}

export function completeOnboarding(store: Store, handle: string, profile: OnboardingProfile): QualifyResult {
  const member = memberByHandle(store, handle);
  if (!member) throw new ProtocolError(`No member @${handle}. Take a seat first.`);
  member.role = profile.role || member.role;
  member.industry = profile.industry || member.industry;
  member.seniority = profile.seniority;
  member.profile = {
    companies: profile.companies,
    buyingAuthority: profile.buyingAuthority,
    tools: profile.tools,
    verticals: profile.verticals,
    canReach: profile.canReach,
  };
  if (profile.dailyPushCap) member.dailyPushCap = profile.dailyPushCap;
  member.cluster = profile.cluster ?? clusterFor(profile);
  member.onboardedAt = member.onboardedAt ?? store.meta.clock;
  if (member.qualification === "declined") member.qualification = "pending";
  return maybeQualify(store, member);
}

export interface QualifyResult {
  member: Member;
  qualified: boolean;
  firstRfe?: Rfe;
}

/**
 * Qualify once the interview is done and verification clears QUALIFY_MIN_SCORE.
 * Qualifying earns nothing by itself; it opens requests, and answering them earns units.
 */
export function maybeQualify(store: Store, member: Member): QualifyResult {
  const params = resolveParams(store);
  if (member.qualification !== "pending" || !meetsQualification(member, params)) {
    return { member, qualified: member.qualification === "qualified" };
  }
  member.qualification = "qualified";
  member.qualifiedAt = store.meta.clock;
  recordStage(store, member, "qualified");
  if (member.reputationTier === "new") member.reputationTier = "contributor";
  const anchor = store.ventures.find((v) => hasSeat(store, v.id, member.handle)) ?? protocolVenture(store);
  ledger(store, {
    ventureId: anchor.id,
    kind: "qualification",
    handle: member.handle,
    note: `@${member.handle} verified (${Math.round(verifiedShare(member, params) * 100)}% of profile checked)`,
  });
  const firstRfe = rankForMember(inboxFor(store, member.handle), member)[0];
  if (firstRfe) notify(store, firstRfe.ventureId, member.handle, `you're verified; a request is waiting: “${firstRfe.title}”`);
  onMemberQualified(store, member.handle);
  return { member, qualified: true, firstRfe };
}

export function isStewardHandle(store: Store, handle: string): boolean {
  return store.ventures.some((v) => v.stewardHandle === handle);
}

/** Mock "Connect LinkedIn" / "Connect X": pending until a steward confirms the profile. */
export function linkAccount(store: Store, handle: string, source: "linkedin" | "x", input: string) {
  const member = memberByHandle(store, handle);
  if (!member) throw new ProtocolError(`No member @${handle}. Take a seat first.`);
  let v;
  try {
    v = PROVIDERS[source].link(store, member, input);
  } catch (e) {
    throw new ProtocolError((e as Error).message);
  }
  const steward = protocolVenture(store).stewardHandle;
  notify(store, protocolVenture(store).id, steward, `@${member.handle} linked ${PROVIDERS[source].label}; it waits for your review`);
  return v;
}

export function decideVerification(store: Store, input: { by: string; handle: string; verificationId: string; approve: boolean }): QualifyResult {
  if (!isStewardHandle(store, input.by)) throw new ProtocolError("Only a steward can confirm a linked account.");
  const member = memberByHandle(store, input.handle);
  const v = member?.verifications.find((x) => x.id === input.verificationId);
  if (!member || !v) throw new ProtocolError("No such verification.");
  if (v.status !== "pending") throw new ProtocolError("That link was already reviewed.");
  v.status = input.approve ? "confirmed" : "rejected";
  v.decidedAt = store.meta.clock;
  v.decidedBy = input.by;
  return maybeQualify(store, member);
}

/** Steward review can verify any single attribute. */
export function stewardVerifyAttribute(store: Store, input: { by: string; handle: string; attribute: MemberAttribute }): QualifyResult {
  if (!isStewardHandle(store, input.by)) throw new ProtocolError("Only a steward can verify an attribute.");
  const member = memberByHandle(store, input.handle);
  if (!member) throw new ProtocolError("No such member.");
  member.verifications.push({
    id: newId(store, "ver"),
    source: "steward",
    ref: `Reviewed by @${input.by}`,
    attributes: [input.attribute],
    status: "confirmed",
    requestedAt: store.meta.clock,
    decidedAt: store.meta.clock,
    decidedBy: input.by,
  });
  return maybeQualify(store, member);
}

export function declineMember(store: Store, input: { by: string; handle: string }) {
  if (!isStewardHandle(store, input.by)) throw new ProtocolError("Only a steward can decline a member.");
  const member = memberByHandle(store, input.handle);
  if (!member) throw new ProtocolError("No such member.");
  member.qualification = "declined";
  for (const v of member.verifications) if (v.status === "pending") v.status = "rejected";
}

/** Routing: favour requests whose audience or question mentions the member's verticals or role. */
export function rankForMember(rfes: Rfe[], member: Member): Rfe[] {
  const terms = [member.industry, member.role, ...member.profile.verticals, ...member.profile.canReach]
    .flatMap((t) => t.toLowerCase().split(/[^a-z0-9]+/))
    .filter((t) => t.length > 3);
  const score = (r: Rfe) => {
    const hay = `${r.audience} ${r.question} ${r.title}`.toLowerCase();
    return terms.reduce((s, t) => s + (hay.includes(t) ? 1 : 0), 0) + (r.kind === "governance" ? 0.5 : 0);
  };
  return [...rfes].sort((a, b) => score(b) - score(a) || b.postedAt.localeCompare(a.postedAt));
}

/* ---------- grants ---------- */

export function issueGrant(
  store: Store,
  input: { venture: Venture; handle: string; slice: Grant["slice"]; units: number; rfeId?: string; note?: string; vestsAt?: string },
): Grant {
  const params = resolveParams(store);
  const formed = !["generated", "pitched", "funded"].includes(input.venture.status);
  const grant: Grant = {
    id: newId(store, "g"),
    ventureId: input.venture.id,
    handle: input.handle,
    slice: input.slice,
    rfeId: input.rfeId,
    units: round(input.units, 4),
    status: "accepted",
    at: store.meta.clock,
    vestsAt: input.vestsAt ?? addDays(store.meta.clock, params.VESTING_DAYS),
    note: input.note ?? (formed ? undefined : "Given once the company is set up"),
  };
  store.grants.push(grant);
  ledger(store, {
    ventureId: input.venture.id,
    kind: "grant",
    handle: input.handle,
    units: grant.units,
    ref: grant.id,
    note: `${grant.units} units earned by @${input.handle} (${SLICE_NOTES[input.slice]}${input.rfeId ? `, ${input.rfeId}` : ""})`,
  });
  if (input.slice === "rfe") payReferrals(store, input.venture.id);
  return grant;
}

/**
 * Pay referrers whose referral filled a roster role and did the work: an access contribution,
 * from the request reserve, once per person per venture. Seat sales never pay a referral.
 */
export function payReferrals(store: Store, ventureId?: string): Grant[] {
  const params = resolveParams(store);
  const paid: Grant[] = [];
  for (const due of referralsDue(store, ventureId)) {
    const venture = ventureById(store, due.ventureId);
    const reserve = capTable(store, venture, params).slices.find((s) => s.key === "reserve")?.remaining ?? 0;
    const units = Math.min(params.REFERRAL_UNITS, reserve);
    if (units <= 0) continue;
    const grant: Grant = {
      id: newId(store, "g"),
      ventureId: venture.id,
      handle: due.referrer,
      slice: "rfe",
      units: round(units, 4),
      status: "accepted",
      at: store.meta.clock,
      vestsAt: addDays(store.meta.clock, params.VESTING_DAYS),
      note: `Referral: brought @${due.referred}, who filled a roster role and did its work`,
      referred: due.referred,
    };
    store.grants.push(grant);
    ledger(store, { ventureId: venture.id, kind: "grant", handle: due.referrer, units: grant.units, ref: grant.id, note: `${grant.units} units earned by @${due.referrer} (referral: @${due.referred} filled a role and did its work)` });
    notify(store, venture.id, due.referrer, `@${due.referred}, who came through your link, filled a role and did the work; that earned you ${grant.units} units`);
    paid.push(grant);
  }
  return paid;
}

export function vestDue(store: Store): Grant[] {
  const vested: Grant[] = [];
  for (const g of store.grants) {
    if (g.status === "accepted" && g.vestsAt && g.vestsAt <= store.meta.clock) {
      assertTransition(GRANT_TRANSITIONS, g.status, "vested", "Grant");
      g.status = "vested";
      vested.push(g);
      ledger(store, {
        at: g.vestsAt,
        ventureId: g.ventureId,
        kind: "vest",
        handle: g.handle,
        units: g.units,
        ref: g.id,
        note: `${g.units} units vested for @${g.handle}`,
      });
    }
  }
  return vested;
}

export function forfeitGrant(store: Store, grantId: string, reason: string) {
  const g = store.grants.find((x) => x.id === grantId);
  if (!g) throw new ProtocolError(`No grant ${grantId}`);
  assertTransition(GRANT_TRANSITIONS, g.status, "forfeited", "Grant");
  g.status = "forfeited";
  g.note = reason;
  ledger(store, { ventureId: g.ventureId, kind: "forfeit", handle: g.handle, units: g.units, ref: g.id, note: `Forfeited: ${reason}` });
}

/* ---------- refunds ---------- */

/**
 * Article 2: seat money is held until the minimum is met. A venture that ends
 * before it forms returns every seat in full. Grants earned by work stand.
 * Safe to call twice; a seat with a refund row is skipped.
 */
export function refundSeats(store: Store, venture: Venture, reason: string): { count: number; totalUsd: number } {
  const seats = activeSeats(store, venture.id);
  const totalUsd = seats.reduce((s, seat) => s + refundSeat(store, venture, seat, reason), 0);
  return { count: seats.length, totalUsd: round(totalUsd) };
}

/** Refund one seat in full; returns the amount. */
export function refundSeat(store: Store, venture: Venture, seat: LedgerEntry, reason: string): number {
  const usd = seat.usd ?? 0;
  ledger(store, {
    ventureId: venture.id,
    kind: "refund",
    handle: seat.handle,
    usd: -usd,
    ref: seat.id,
    note: `Seat refunded in full${seat.handle ? ` to @${seat.handle}` : ""}: ${reason}`,
  });
  if (seat.handle) notify(store, venture.id, seat.handle, `your $${usd} seat in ${venture.name} was refunded in full: ${reason}`);
  return usd;
}

/* ---------- responses and the N rule ---------- */

export interface AnswerInput {
  rfeId: string;
  handle: string;
  via: Response["via"];
  choice?: string;
  scale?: number;
  text?: string;
  transcript?: string;
  extractedBy?: string;
  counterUnits?: number;
}

export function respond(store: Store, input: AnswerInput): { response: Response; n?: NStatus; resolved: boolean } {
  const params = resolveParams(store);
  const rfe = rfeById(store, input.rfeId);
  if (!rfe) throw new ProtocolError("That request does not exist.");
  if (!isOpen(rfe)) throw new ProtocolError("That request has closed.");
  const venture = ventureById(store, rfe.ventureId);
  if (!isLive(venture)) throw new ProtocolError(`${venture.name} is ${venture.status}.`);
  if (!canAnswer(store, rfe, input.handle)) {
    const m = memberByHandle(store, input.handle);
    if (m && m.qualification !== "qualified" && !rfe.assignedTo) {
      throw new ProtocolError(`@${input.handle} gets requests once qualified. Finish the interview and link an account on /onboarding.`);
    }
    throw new ProtocolError(`@${input.handle} needs a seat in ${venture.name} to answer.`);
  }
  if (store.responses.some((r) => r.rfeId === rfe.id && r.handle === input.handle)) {
    throw new ProtocolError("You already answered this one.");
  }
  if (rfe.format === "choice" && !input.choice) throw new ProtocolError("Pick an option.");
  const response: Response = {
    id: newId(store, "resp"),
    rfeId: rfe.id,
    handle: input.handle,
    via: input.via,
    choice: input.choice,
    scale: input.scale,
    text: input.text?.trim() || undefined,
    transcript: input.transcript,
    extractedBy: input.extractedBy,
    counterUnits: input.counterUnits,
    at: store.meta.clock,
  };
  if (rfe.kind === "governance") {
    response.weight = vestedUnits(store, venture.id, input.handle);
    store.responses.push(response);
    return { response, resolved: false };
  }
  store.responses.push(response);
  const n = applyNRule(store, rfe, params);
  return { response, n, resolved: rfe.status === "resolved" };
}

export function applyNRule(store: Store, rfe: Rfe, params = resolveParams(store)): NStatus | undefined {
  if (!isOpen(rfe) || rfe.kind === "governance" || rfe.type === "capital" || rfe.gtm) return;
  const n = nStatusFor(store, rfe, params);
  if (n.state === "extend") {
    rfe.extended = true;
    if (rfe.status === "quorum") setRfeStatus(rfe, "posted");
    return nStatusFor(store, rfe, params);
  }
  if (n.effective >= n.minimum && rfe.status === "posted") setRfeStatus(rfe, "quorum");
  if (n.state === "close") resolveRfe(store, rfe, n);
  return n;
}

export function resolveRfe(store: Store, rfe: Rfe, n?: NStatus, resolution?: string) {
  const params = resolveParams(store);
  const venture = ventureById(store, rfe.ventureId);
  n = n ?? nStatusFor(store, rfe, params);
  if (rfe.status === "posted") setRfeStatus(rfe, "quorum");
  setRfeStatus(rfe, "resolved");
  rfe.resolvedAt = store.meta.clock;
  const responses = responsesFor(store, rfe.id);
  const pct = Math.round(n.agreement * 100);
  rfe.resolution =
    resolution ??
    (n.leading
      ? `${n.leading} (${pct}% of ${n.effective} distinct ${n.effective === 1 ? "profile" : "profiles"} agree)`
      : responses.length === 1
        ? `Fulfilled by @${responses[0].handle}.`
        : `${responses.length} answers received; the agent folded them into the plan.`);

  // Equal shares: each accepted answer earns SHARE_PER_ANSWER, capped by the remaining reserve.
  if (rfe.kind === "request" && rfe.type !== "capital" && !rfe.gtm && rfe.offerUnits > 0 && responses.length) {
    const handles = [...new Set(responses.map((r) => r.handle))];
    const share = params.SHARE_PER_ANSWER;
    const slice = rfe.type === "stewardship" ? "steward" : "rfe";
    const table = capTable(store, venture, params);
    const available = table.slices.find((s) => s.key === (slice === "steward" ? "steward" : "reserve"))!.remaining;
    const total = handles.length * share;
    const scale = total > available && total > 0 ? available / total : 1;
    for (const handle of handles) {
      const units = share * scale;
      if (units <= 0) continue;
      issueGrant(store, { venture, handle, slice, units, rfeId: rfe.id });
      notify(store, venture.id, handle, `your answer to “${rfe.title}” earned ${round(units)} share${units === 1 ? "" : "s"}`);
    }
  }

  if (rfe.decisionId) {
    const d = store.decisions.find((x) => x.id === rfe.decisionId);
    if (d && d.status === "awaiting_members") {
      const recommended = rfe.options?.[0] ?? rfe.recommendation;
      if (!n.leading || n.leading === recommended || n.leading === rfe.recommendation) {
        takeDecision(store, d, `Members agreed (${pct}%). The agent went ahead.`);
      } else {
        rejectDecision(store, d, `Members leaned “${n.leading}” (${pct}%). The agent held off.`);
      }
    }
  }
}

/* ---------- steward ---------- */

export function stewardDecide(store: Store, decisionId: string, approve: boolean, note: string, by: string) {
  const d = store.decisions.find((x) => x.id === decisionId);
  if (!d) throw new ProtocolError("No such decision.");
  if (d.status !== "awaiting_steward") throw new ProtocolError("That decision is not waiting on the steward.");
  const venture = ventureById(store, d.ventureId);
  if (venture.stewardHandle !== by) throw new ProtocolError(`Only @${venture.stewardHandle} can sign for ${venture.name}.`);
  d.stewardNote = note.trim() || undefined;
  const linked = d.rfeId ? rfeById(store, d.rfeId) : undefined;
  if (approve) {
    takeDecision(store, d, linked?.gtm ? "Approved; waiting for the steward to post it" : `Approved by @${by}`);
    if (d.facts.contractorPitch && !d.rfeId) {
      d.rfeId = postRfe(store, venture.id, seatRfe(venture, resolveParams(store)), d.id).id;
      d.outcome = `Approved by @${by}; seats open`;
    }
  } else {
    rejectDecision(store, d, `Rejected by @${by}`);
    if (linked && isOpen(linked)) resolveRfe(store, linked, undefined, "Draft rejected by the steward");
  }
  onStewardDeckDecision(store, d, approve);
  onStewardLiftoff(store, d, approve);
}

export function markGtmPosted(store: Store, rfeId: string, by: string, url?: string) {
  const rfe = rfeById(store, rfeId);
  if (!rfe?.gtm) throw new ProtocolError("Not a recruiting draft.");
  if (!isOpen(rfe)) throw new ProtocolError("That draft is already closed.");
  const d = rfe.decisionId ? store.decisions.find((x) => x.id === rfe.decisionId) : undefined;
  if (d?.status === "awaiting_steward") takeDecision(store, d, `Approved and posted by @${by}`);
  else if (d) d.outcome = `Posted by @${by}`;
  rfe.gtm.postedAt = store.meta.clock;
  resolveRfe(store, rfe, undefined, `Posted by @${by}${url ? ` at ${url}` : ""}. People who join from it are counted with ?ref=${rfe.id}.`);
}

export function killVenture(store: Store, slug: string, by: string, note: string, killReason?: KillReason) {
  const venture = ventureBySlug(store, slug);
  if (!venture) throw new ProtocolError("No such venture.");
  if (venture.isProtocol) throw new ProtocolError("Only the Protocol's unit holders can close the Protocol.");
  if (venture.stewardHandle !== by) throw new ProtocolError(`Only @${venture.stewardHandle} can shut this venture down.`);
  if (venture.status === "killed") return;
  const reason = note.trim() || "The steward shut it down.";
  const stageReached = venture.status;
  // Before formation nothing has been spent, so every seat goes back (Article 2).
  const beforeFormation = stageReached === "pitched" || stageReached === "funded";
  const d: Decision = {
    id: newId(store, "dec"),
    ventureId: venture.id,
    title: "Shut the venture down",
    reasoning: reason,
    summary: shortReason(reason),
    transition: "killed",
    confidence: 1,
    facts: fullFacts(),
    bin: "gated",
    binReasons: [`Steward @${by} shut it down (Article 4)`],
    status: "taken",
    at: store.meta.clock,
    takenAt: store.meta.clock,
    outcome: "Venture ended; open requests closed",
    model: "steward",
  };
  store.decisions.push(d);
  for (const r of store.rfes.filter((x) => x.ventureId === venture.id && isOpen(x))) {
    if (r.status === "posted") setRfeStatus(r, "quorum");
    setRfeStatus(r, "resolved");
    r.resolvedAt = store.meta.clock;
    r.resolution = "Closed: the venture ended.";
  }
  for (const pd of store.decisions.filter((x) => x.ventureId === venture.id && x.status.startsWith("awaiting"))) {
    rejectDecision(store, pd, "Closed: the venture ended.");
  }
  const pitchedAt = venture.statusHistory.find((h) => h.status === "pitched")?.at ?? venture.createdAt;
  if (!venture.postMortem) {
    const spent = venture.quarters.reduce((s, q) => s + q.costsUsd + q.passThroughUsd, 0);
    venture.postMortem = {
      summary: `${venture.name} was stopped by its steward. ${d.summary}`,
      whatWeTried: store.decisions
        .filter((x) => x.ventureId === venture.id && x.status === "taken" && !x.embargo && x.id !== d.id)
        .slice(-4)
        .map((x) => x.title),
      whyItEnded: reason,
      costUsd: spent,
      lessons: ["Draft written by the agent when the venture ended. The steward publishes it before the batch closes."],
    };
  }
  venture.postMortem.killReason = killReason ?? venture.postMortem.killReason;
  venture.postMortem.stageReached = VENTURE_STATUS_LABELS[stageReached];
  venture.postMortem.daysToKillSignal = Math.round((Date.parse(store.meta.clock) - Date.parse(pitchedAt)) / 86_400_000);
  // The status note is public, so it carries the one-line summary; the full reason stays on the decision.
  transitionVenture(store, venture, "killed", d.summary);
  if (beforeFormation) {
    const r = refundSeats(store, venture, "the steward ended the venture before it formed");
    if (r.count) d.outcome = `Venture ended; open requests closed; ${r.count} ${r.count === 1 ? "seat" : "seats"} refunded in full ($${r.totalUsd})`;
  }
}

/** Every killed venture publishes a structured post-mortem before its batch closes. */
export function publishPostMortem(
  store: Store,
  input: { slug: string; by: string; killReason: KillReason; summary?: string; lessons?: string[] },
) {
  const venture = ventureBySlug(store, input.slug);
  if (!venture?.postMortem || venture.status !== "killed") throw new ProtocolError("Only a killed venture has a post-mortem to publish.");
  if (venture.stewardHandle !== input.by) throw new ProtocolError(`Only @${venture.stewardHandle} publishes this post-mortem.`);
  if (venture.postMortem.publishedAt) throw new ProtocolError("Already published.");
  const pm = venture.postMortem;
  pm.killReason = input.killReason;
  if (input.summary?.trim()) pm.summary = input.summary.trim();
  if (input.lessons?.length) pm.lessons = input.lessons;
  pm.publishedAt = store.meta.clock;
  venture.tags = mergeTags(venture.tags, outcomeTags(venture));
  ledger(store, { ventureId: venture.id, kind: "status", note: `Post-mortem published (why it ended: ${pm.killReason})` });
  runLearningPass(store, { kind: "kill", ventureId: venture.id });
  const cohort = cohortFor(store, venture);
  if (cohort?.status === "live" && store.meta.clock >= cohort.closesAt && !unpublishedPostMortems(store, cohort).length) {
    closeCohort(store, cohort);
  }
}

/* ---------- governance ---------- */

export function closeGovernance(store: Store, rfe: Rfe) {
  const params = resolveParams(store);
  if (rfe.kind !== "governance" || !isOpen(rfe) || !rfe.governance) return;
  const venture = ventureById(store, rfe.ventureId);
  const votes = responsesFor(store, rfe.id);
  const tally = tallyVote(rfe, votes, totalVestedUnits(store, venture.id), params);
  const g = rfe.governance;
  const pct = (n: number) => `${Math.round(n * 100)}%`;
  const summary = `${pct(tally.yesShare)} of the units voted were in favour, and ${pct(tally.turnout)} of vested units voted (it needs ${pct(params.QUORUM_PCT)}).`;
  if (rfe.status === "posted") setRfeStatus(rfe, "quorum");
  setRfeStatus(rfe, "resolved");
  rfe.resolvedAt = store.meta.clock;
  rfe.resolution = tally.passes ? `Passed. ${summary}` : `Did not pass. ${summary}`;

  if (g.matter === "sale" && (g.proposedValue as { offerId?: string } | undefined)?.offerId) {
    settleHandOffVote(store, rfe, tally.passes, summary);
    for (const v of votes) notify(store, venture.id, v.handle, `the vote on “${rfe.title}” closed: ${tally.passes ? "passed" : "did not pass"}`);
    return;
  }

  if (rfe.flagId) {
    settleFlag(store, rfe.flagId, tally.passes);
    const stands = store.flags.find((f) => f.id === rfe.flagId)?.certifiedBy === MEMBER_VOTE_STANDS;
    rfe.resolution = `${tally.passes ? "Upheld" : "Dismissed"} by members. ${summary} ${stands ? "The steward runs this venture, so the vote stands on its own." : "The Protocol's steward confirms the result."}`;
    return;
  }

  // Article 8 is constitutional: holders can tighten the conduct checklist, never loosen it below the floor.
  // Article 2 is constitutional too: a vote can't end the full refund below the minimum.
  const refundFloor = g.paramKey === "REFUND_IN_FULL" && g.proposedValue !== true;
  // Employment is protected too: a settings vote can't turn it on before an employer of record, payroll and insurance exist.
  const employmentFloor = g.paramKey === "EMPLOYMENT_ALLOWED" && g.proposedValue === true;
  // So is spending seat money only on the published plan: the people who took seats relied on that plan.
  const planFloor = g.paramKey === "SEAT_MONEY_ON_PLAN" && g.proposedValue !== true;
  // The seat maximum can fall by vote, but rising waits for counsel: a dearer seat starts to look like buying a share.
  const counselAnswered = store.rfes.find((r) => r.id === "rfe-v0-legal-structure")?.status === "resolved";
  const priceCeiling = g.paramKey === "SEAT_PRICE_MAX_USD" && Number(g.proposedValue) > Number(g.currentValue) && !counselAnswered;
  const belowFloor =
    g.paramKey === "CONDUCT_CHECKLIST"
      ? loosensBelowFloor(g.proposedValue)
      : refundFloor
        ? ["the full refund"]
        : employmentFloor
          ? ["the employment block"]
          : planFloor
            ? ["spending only on the published plan"]
            : priceCeiling
              ? ["the seat price maximum"]
              : [];
  if (tally.passes && refundFloor) {
    rfe.resolution = `Passed, but not applied: seats below the minimum are refunded in full under Article 2. Changing that needs a change to the rules themselves. ${summary}`;
  } else if (tally.passes && employmentFloor) {
    rfe.resolution = `Passed, but not applied: ventures can employ people only once the Protocol has an employer of record, payroll and insurance, and the rules are changed to match. ${summary}`;
  } else if (tally.passes && planFloor) {
    rfe.resolution = `Passed, but not applied: seat money is spent only on the venture's published plan, which is what people relied on when they took a seat. ${summary}`;
  } else if (tally.passes && priceCeiling) {
    rfe.resolution = `Passed, but not applied: the highest seat price can rise only once counsel answers the legal-structure question, because a dearer seat starts to look like buying a share. ${summary}`;
  } else if (tally.passes && belowFloor.length) {
    rfe.resolution = `Passed, but not applied: removing ${belowFloor.join(", ")} would loosen the checklist below Article 8. That needs a change to the rules themselves. ${summary}`;
  } else if (tally.passes && g.matter === "add-classification-value" && g.proposedValue) {
    const { axis, value } = g.proposedValue as { axis: TagAxis; value: string };
    addClassificationValue(store, { axis, value, by: rfe.id });
  }

  for (const lesson of store.lessons.filter((l) => l.amendmentRfeId === rfe.id && l.status === "proposed")) {
    lesson.status = tally.passes && !belowFloor.length ? "adopted" : "retired";
  }

  if (tally.passes && g.paramKey && !belowFloor.length) {
    const [major, minor] = store.meta.protocolVersion.split(".").map(Number);
    const version = `${major}.${(minor ?? 0) + 1}`;
    store.amendments.push({
      id: newId(store, "amd"),
      paramKey: g.paramKey,
      oldValue: g.currentValue,
      newValue: g.proposedValue,
      rfeId: rfe.id,
      version,
      at: store.meta.clock,
    });
    store.meta.protocolVersion = version;
    ledger(store, {
      ventureId: venture.id,
      kind: "amendment",
      ref: rfe.id,
      note: `${g.paramKey}: ${String(g.currentValue)} → ${String(g.proposedValue)} (protocol ${version})`,
    });
  }
  const proposed = rfe.decisionId ? store.decisions.find((d) => d.id === rfe.decisionId && d.status === "awaiting_members") : undefined;
  if (proposed) {
    if (tally.passes) takeDecision(store, proposed, `Unit holders voted yes. ${summary}`);
    else rejectDecision(store, proposed, `Unit holders voted no. ${summary}`);
    for (const v of votes) notify(store, venture.id, v.handle, `the vote on “${rfe.title}” closed: ${tally.passes ? "passed" : "did not pass"}`);
    return;
  }
  logDecision(store, {
    ventureId: venture.id,
    title: tally.passes ? `Apply the vote on ${matterLabel(g.matter)}` : `Record the vote on ${matterLabel(g.matter)}: it did not pass`,
    reasoning: `Unit holders decided this, not the agent (Article 5). ${summary} ${g.effect}`,
    confidence: 1,
    model: "rule",
    outcome: tally.passes ? "Change in force" : "No change",
  });
  for (const v of votes) notify(store, venture.id, v.handle, `the vote on “${rfe.title}” closed: ${tally.passes ? "passed" : "did not pass"}`);
}

/* ---------- payouts ---------- */

export function runDistribution(store: Store, venture: Venture, quarter: string) {
  const params = resolveParams(store);
  const q = venture.quarters.find((x) => x.quarter === quarter);
  if (!q) throw new ProtocolError(`No financials for ${quarter}`);
  if (store.distributions.some((d) => d.ventureId === venture.id && d.quarter === quarter)) return;
  const calc = computeDistribution({
    profitUsd: q.revenueUsd - q.costsUsd,
    passThroughUsd: q.passThroughUsd,
    protocolPct: protocolPctFor(venture, params),
    poolUnits: params.POOL_UNITS_TOTAL,
    cohortUnits: params.POOL_COHORT_UNITS,
    vestedByHandle: vestedByHandle(store, venture.id),
  });
  const dist = {
    id: newId(store, "dist"),
    ventureId: venture.id,
    quarter,
    at: store.meta.clock,
    profitUsd: q.revenueUsd - q.costsUsd,
    passThroughUsd: q.passThroughUsd,
    protocolUsd: calc.protocolUsd,
    contributorUsd: calc.contributorUsd,
    treasuryUsd: calc.treasuryUsd,
    perUnitUsd: calc.perUnitUsd,
  };
  store.distributions.push(dist);
  ledger(store, {
    ventureId: venture.id,
    kind: "distribution",
    usd: calc.protocolUsd,
    ref: dist.id,
    note: `${quarter}: protocol fee to the Protocol`,
  });
  ledger(store, {
    ventureId: venture.id,
    kind: "distribution",
    usd: calc.cohortUsd,
    ref: dist.id,
    note: `${quarter}: batch-wide share`,
  });
  for (const p of calc.payouts) {
    ledger(store, {
      ventureId: venture.id,
      kind: "distribution",
      handle: p.handle,
      usd: p.usd,
      units: p.units,
      ref: dist.id,
      note: `${quarter}: ${p.units} vested units × $${calc.perUnitUsd}`,
    });
  }
  for (const g of store.grants) {
    if (g.ventureId === venture.id && g.status === "vested") g.status = "distributing";
  }
  return dist;
}

export function eligibleVoteWeight(store: Store, rfe: Rfe, handle: string): number {
  return vestedUnits(store, rfe.ventureId, handle);
}
