import { parseArgs } from "node:util";
import { claudeEnabled } from "./claude";
import { advanceAgent, formatLog, type TickMode } from "./index";
import { resetStore, storePath } from "../src/store";

const { values } = parseArgs({
  args: process.argv.slice(2).filter((a) => a !== "--"),
  options: {
    venture: { type: "string", short: "v" },
    ticks: { type: "string", short: "t", default: "5" },
    mode: { type: "string", short: "m", default: "auto" },
    reset: { type: "boolean", default: false },
    spawn: { type: "boolean", default: false },
  },
});

const mode = values.mode as TickMode;
if (!["auto", "script", "claude"].includes(mode)) {
  console.error("--mode must be auto, script or claude");
  process.exit(1);
}
if (mode === "claude" && !claudeEnabled()) {
  console.error("--mode claude needs ANTHROPIC_API_KEY. Use --mode script, or set the key.");
  process.exit(1);
}
if (values.reset) resetStore();

const ticks = Math.max(1, Number(values.ticks) || 1);
const driver = mode === "script" || (mode === "auto" && !claudeEnabled()) ? "replayed script" : "Claude";
console.log(`Simulating ${ticks} tick(s)${values.venture ? ` of ${values.venture}` : " across all live ventures"} with the ${driver}.`);
console.log(`Store: ${storePath()}\n`);

if (values.spawn) console.log("--spawn: announcing the next batch before the ticks.\n");
const logs = await advanceAgent({ venture: values.venture, ticks, mode, spawn: values.spawn });
let last = "";
for (const l of logs) {
  if (l.kind === "clock") {
    console.log(`\n${l.text}`);
    continue;
  }
  if (l.venture !== last) last = l.venture;
  console.log(formatLog(l));
}
console.log(`\nDone. Open http://localhost:43117${values.venture ? `/v/${values.venture}` : ""} to see the public log.`);
