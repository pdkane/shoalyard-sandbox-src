import type { Cohort, Store, Venture } from "@av/schema";
import { batchLabel } from "./batches";
import { logSeatPriceDecision, publishDeck, validateDeck, type DeckDraft } from "./deck";
import { deckDraftFor } from "./deck-content";
import { seatSummary } from "./sizing";
import { IDEA_LIBRARY, type IdeaTemplate } from "./ideas";
import { lessonsFor, segmentLabel, type Segment } from "./learning";
import { logDecision, ProtocolError, protocolVenture } from "./ops";
import { classificationLine, mergeTags, proposeVentureTags } from "./tags";
import { addDays } from "./util";
import { resolveParams } from "./params";
import { LONG_TERM_LABELS, operableProof, proofRunBy } from "./proof";

/** Qualified members per cluster: who our members can uniquely reach. */
export function graphReach(store: Store): Map<string, number> {
  const out = new Map<string, number>();
  for (const m of store.members) {
    if (m.qualification !== "qualified") continue;
    out.set(m.cluster, (out.get(m.cluster) ?? 0) + 1);
  }
  return out;
}

/** Unused library ideas in an end market and business model, best-reached first. */
export function candidateIdeas(store: Store, segment: Segment): IdeaTemplate[] {
  const reach = graphReach(store);
  const used = new Set(store.ventures.map((v) => v.slug));
  const score = (i: IdeaTemplate) => i.reachClusters.reduce((s, c) => s + (reach.get(c) ?? 0), 0);
  return IDEA_LIBRARY.filter(
    (i) => i.classification.endMarket === segment.endMarket && i.classification.businessModel === segment.businessModel && !used.has(i.slug),
  ).sort((a, b) => score(b) - score(a));
}

export interface SpawnOptions {
  idea?: IdeaTemplate;
  model?: string;
  /** Pitched under the old seat rule: keeps this minimum and budget (Article 6). */
  legacy?: Pick<Venture, "minRaiseUsd" | "budget">;
  /** A deck the model wrote; used only if it passes the same checks as the script's. */
  deck?: DeckDraft;
}

/**
 * Generate a venture into an open (announced or live) cohort. Reads adopted
 * lessons as priors, runs the repeat-mistake check on the idea, and records
 * any contradiction with the agent's reason as a disclosure. Nobody screens
 * the idea; members decide with seats.
 */
export function spawnVenture(store: Store, cohort: Cohort, segment: Segment, opts: SpawnOptions = {}): Venture {
  if (cohort.status === "closed") throw new ProtocolError("Ventures spawn into an open batch.");
  const idea = opts.idea ?? candidateIdeas(store, segment)[0];
  if (!idea) throw new ProtocolError(`The idea library has nothing left for ${segmentLabel(segment)}.`);
  let draft = deckDraftFor(idea.slug, idea)!;
  const proof = operableProof(idea.proof, resolveParams(store));
  draft = { ...draft, proof: proof.plan };

  const v: Venture = {
    id: idea.slug,
    slug: idea.slug,
    name: idea.name,
    tagline: idea.tagline,
    pitch: idea.pitch,
    isProtocol: false,
    objective: idea.objective,
    distributionPolicy: idea.distributionPolicy,
    budget: opts.legacy?.budget ?? [],
    minRaiseUsd: opts.legacy?.minRaiseUsd ?? 0,
    status: "generated",
    statusHistory: [{ status: "generated", at: store.meta.clock }],
    killRules: idea.killRules,
    killDate: addDays(cohort.closesAt, 150),
    stewardHandle: protocolVenture(store).stewardHandle,
    protocolVersion: store.meta.protocolVersion,
    voice: idea.voice,
    accent: idea.accent,
    customers: { count: 0, segment: idea.segment },
    quarters: [],
    memo: idea.memo,
    cohortId: cohort.id,
    codename: idea.codename,
    teaser: idea.teaser,
    roster: [],
    tags: [],
    lessonIds: [],
    contradictions: [],
    createdAt: store.meta.clock,
  };
  v.tags = mergeTags([], proposeVentureTags(v, idea.classification, opts.model && opts.model !== "script" ? opts.model : "agent"));
  store.ventures.push(v);
  cohort.ventureIds.push(v.id);

  const priors = lessonsFor(store, v);
  v.lessonIds = priors.map((l) => l.id);
  if (idea.differs) {
    const hit = priors.find((l) => l.guard?.keywords.some((k) => k.toLowerCase() === idea.differs!.keyword.toLowerCase()));
    if (hit) v.contradictions.push({ lessonId: hit.id, reason: idea.differs.reason.replaceAll("{lesson}", hit.id) });
  }

  const written = opts.deck && !validateDeck(store, v, { ...opts.deck, proof: proof.plan }).length;
  if (written) draft = { ...opts.deck!, proof: proof.plan };
  const deck = publishDeck(store, v, draft, { author: written ? (opts.model ?? "script") : "script", cause: { kind: "pitch" }, legacy: Boolean(opts.legacy) });
  const plan = deck.seatPlan.rule === "legacy-budget" && deck.currentRule ? deck.currentRule : deck.seatPlan;
  logSeatPriceDecision(store, v, deck, written ? (opts.model ?? "script") : "script");
  const pricing = priors.filter((l) => l.topic === "pricing-requests").map((l) => l.id);
  logDecision(store, {
    ventureId: v.id,
    title: `Spawn ${v.name} (${classificationLine(idea.classification, ["businessModel", "endMarket"])}) for ${batchLabel(cohort.number)}`,
    reasoning: [
      `${idea.memo.problem} Proposed classification: ${classificationLine(idea.classification, ["businessModel", "customer", "endMarket"])} (${idea.classification.subVertical}), ${idea.classification.marketType.toLowerCase()}, ${idea.classification.goToMarket.toLowerCase()}. The steward confirms or corrects it.`,
      `Seats: ${seatSummary(deck.seatPlan)}${deck.seatPlan.rule === "legacy-budget" ? `; the current rule would ask for ${plan.min}` : ""}. It needs ${deck.roster.reduce((s, r) => s + r.count, 0)} people in ${deck.roster.length} roles.`,
      priors.length ? `Spawned with ${priors.map((l) => l.id).join(", ")} as priors${pricing.length ? `; request offers follow ${pricing.join(", ")}` : ""}.` : "No adopted lessons apply yet.",
      ...v.contradictions.map((c) => `It contradicts ${c.lessonId}: ${c.reason}`),
      `The plan and budget stay hidden until the batch opens; until then it goes by ${idea.codename}.`,
    ]
      .filter(Boolean)
      .join(" "),
    confidence: 0.8,
    model: opts.model ?? "script",
    lessonIds: v.lessonIds.filter((id) => !v.contradictions.some((c) => c.lessonId === id)),
  });
  if (proof.rejected.length) {
    const label = cohort.status === "announced" ? (v.codename ?? v.name) : v.name;
    logDecision(store, {
      ventureId: v.id,
      title: `Reshape ${label}'s proof: ${proof.rejected.length === 1 ? "one task" : `${proof.rejected.length} tasks`} the Protocol can't run`,
      reasoning: [
        "The operability check constrains the proof, not the idea.",
        ...proof.rejected.map((i) => i.message),
        ...proof.plan.reshaped.map((r) => `Now: ${r.now} ${r.why}`),
        `Proof run by: ${proofRunBy(proof.plan)}. Long-term operator: ${LONG_TERM_LABELS[proof.plan.longTermOperator].toLowerCase()}.`,
      ].join(" "),
      confidence: 0.85,
      model: opts.model ?? "script",
    });
  }
  return v;
}
