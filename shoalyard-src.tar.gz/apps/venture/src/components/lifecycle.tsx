import { VENTURE_MAIN_PATH, VENTURE_STATUS_LABELS, type Venture } from "@av/schema";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDate } from "@/lib/format";

export function Lifecycle({ venture }: { venture: Venture }) {
  const killed = venture.status === "killed" || venture.status === "dormant";
  const reached = new Map(venture.statusHistory.map((h) => [h.status, h.at]));
  const lastMain = [...VENTURE_MAIN_PATH].reverse().find((s) => reached.has(s));
  const currentIdx = VENTURE_MAIN_PATH.indexOf(killed ? (lastMain ?? "pitched") : venture.status);

  return (
    <div>
      <ol className="grid grid-cols-3 gap-y-4 sm:grid-cols-6">
        {VENTURE_MAIN_PATH.map((s, i) => {
          const done = i < currentIdx || (i === currentIdx && killed);
          const current = i === currentIdx && !killed;
          return (
            <li key={s} className="relative flex flex-col items-start gap-1.5 pr-2">
              <div className="flex w-full items-center">
                <span
                  className={cn(
                    "z-10 flex size-6 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold",
                    done && "border-zinc-900 bg-zinc-900 text-white",
                    current && "border-[var(--accent-color)] bg-[var(--accent-color)] text-white ring-4 ring-[color-mix(in_oklch,var(--accent-color),transparent_80%)]",
                    !done && !current && "border-zinc-300 bg-white text-zinc-400",
                  )}
                >
                  {done ? <Check className="size-3.5" /> : i + 1}
                </span>
                {i < VENTURE_MAIN_PATH.length - 1 && (
                  <span className={cn("h-px flex-1", i < currentIdx ? "bg-zinc-900" : "bg-zinc-200")} />
                )}
              </div>
              <span className={cn("text-xs font-medium", current ? "text-zinc-900" : done ? "text-zinc-700" : "text-zinc-400")}>
                {VENTURE_STATUS_LABELS[s]}
              </span>
              {reached.get(s) && <span className="text-[11px] text-zinc-500">{formatDate(reached.get(s)!)}</span>}
            </li>
          );
        })}
      </ol>
      {killed && (
        <p className="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-900">
          {VENTURE_STATUS_LABELS[venture.status]} on {formatDate(reached.get(venture.status) ?? venture.createdAt)}
          {venture.statusHistory.at(-1)?.note ? ` — ${venture.statusHistory.at(-1)!.note}` : ""}
        </p>
      )}
    </div>
  );
}
