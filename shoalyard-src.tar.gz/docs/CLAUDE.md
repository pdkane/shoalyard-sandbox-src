# Agent-Operated Ventures — pilot brief for Claude Code

This repo is a quick-and-dirty pilot of a protocol for agent-operated ventures. Read this whole file before writing code. Read `docs/working-model.md` (exported from the working-model doc) for the full reasoning; this file is the build contract.

Working name for the protocol: **Foundation** (placeholder, will change). Do not bake the name into identifiers; use `protocol` / `venture0` in code and a single `BRAND_NAME` constant.

## What we're building

Two separate builds, two top-level directories, one shared schema package:

```
/packages/protocol     # Build 1: Venture 0 — the rules, schemas, reference agent
/apps/venture          # Build 2: the platform a funded venture runs on
/packages/schema       # shared types + JSON schemas; both builds import from here
/docs                  # working-model.md and anything generated from it
```

The goal of this pilot is to **visualize what this becomes**, not to ship. Prefer seeded demo data, simulated time, and a single page that tells the story over robustness. Every screen should be understandable by someone who has never read the docs.

## Build 1 — `/packages/protocol` (Venture 0)

Venture 0 is the published standard, a reference operator agent, and a registry. It is itself run on the protocol's own primitives.

Deliverables:

1. **`PROTOCOL.md`** — the constitution, written as numbered rules a human can read in ten minutes. Sections: the seven RFE types; the micro-fundraise rule; profits-interest grant terms; steward requirements; reserved matters and voting; the decision classifier; the N rule; the public reporting standard; conduct standards for the mark; protocol versioning. Pull the content from `docs/working-model.md`; where the doc is silent, mark the rule `[OPEN — RFE]` rather than inventing it.
2. **JSON schemas** in `/packages/schema`: `Venture`, `Member`, `RFE`, `Response`, `Grant`, `Decision`, `Distribution`, `Report`. Include the state machines as enums with allowed transitions.
3. **Reference operator agent** (`/packages/protocol/agent`): the loop `read state → plan → classify next decision → act or post RFE → log → repeat`. Built on the Anthropic API. Must be runnable against a venture in `/apps/venture` via a `simulate` command that advances a venture through its lifecycle in minutes with fake clock time.
4. **Decision classifier** — hard-coded gates for the pilot: any spend above `GATE_SPEND_USD`, any contract, any pricing change, any outbound to a new domain → `gated`. Everything else: `advisory` if the agent's self-reported confidence is below `ADVISORY_CONFIDENCE`, else `auto`. Log every decision regardless of bin.
5. **N engine** (v0): baseline N by RFE type (Judgment 3–7, Knowledge 2–3, Access 1, Credibility 1–2, Action 1, Capital = minimum raise, Stewardship 1); stakes multiplier; stop early on agreement, extend on divergence; diversity check so N responses from the same profile cluster count as one.
6. **Venture 0's own RFE list** — seed the registry with the "Open questions, as RFEs" table from the doc as live RFEs on Venture 0, so the first members see the protocol asking for their input on its own rules.

## Build 2 — `/apps/venture` (the platform a funded venture runs on)

Next.js + Supabase (Postgres, auth, RLS). One deployment serves many ventures; each venture has its own slug, brand and public page.

Screens, in priority order:

1. **Public venture page** `/v/[slug]` — pitch, objective (scale / profitability / exit), budget and minimum raise, seats sold vs. needed, status, open RFEs, live decision log, cap table summary, latest report. This is the page that makes the model legible. Build it first and make it good.
2. **Micro-fundraise** — buy a $10 seat (Stripe test mode is fine; a fake checkout is fine for the demo). Seat = right to receive RFEs, never a return. Venture moves `Pitched → Funded` when the agent's minimum raise is met.
3. **RFE inbox** `/inbox` — a member's open RFEs across all ventures they hold seats in. Three answer formats: structured (choice/scale/rank), short text, voice (record → transcribe → structured extract). Each RFE shows type, offer in profits-interest units, N target and progress, and closes when the N rule is met. Email notification is fine for the pilot; push comes later.
4. **Steward console** `/steward` — the gated-decision queue (approve/reject with a note) and the kill switch per venture.
5. **Ledger views** — per venture: grants (offered/accepted/vested/forfeited), the reserve remaining, cohort-vehicle slice, distributions. Per member: holdings across ventures. Keep it to tables.
6. **Report** `/v/[slug]/report` — the quarterly report in the fixed schema, rendered and downloadable as JSON.
7. **Governance** — a reserved-matter RFE with a voting window, weighted by vested interest. One screen.

Seed data: three demo ventures at different stages (one pitching, one operating with open RFEs, one killed with a post-mortem), ~25 demo members with handles and profile attributes, and a run of decisions and RFEs so every screen has content on first load.

## Economics to encode (pilot values; all are open RFEs)

- Protocol fee: **8%** of each venture's profits interests, non-voting, pari passu. Pass-through costs (payment processing, bookkeeping, formation) come off the top before any split.
- Venture contributor pool (100 units): seats 10, steward 5, cohort vehicle 25, RFE reserve 60. Max any single RFE: 15 units. Ungranted reserve stays as treasury; sunset accrues it pro rata to holders.
- Objective and distribution policy set in the plan before the fundraise; changes are reserved matters.

Put every number in `/packages/schema/params.ts` with a comment naming the RFE that governs it. Nothing hard-coded in components.

## GTM is part of the agent, not an afterthought

The pilot's first members are sourced from X. The operator agent and the Venture 0 agent both need a **recruiting capability**:

- Given a venture (or Venture 0) and its RFE needs, draft a sequence of X posts that explain the venture, the open RFEs, and the seat offer, in the venture's own voice. Store drafts as `Action` RFEs assigned to the steward: **a human posts, the agent never posts or DMs autonomously** (gated by the classifier; also keeps us inside X's rules).
- Draft targeted outreach: from a short description of who the venture needs (role, industry, seniority), produce a list of search queries and a message template per segment. Again, delivered as drafts for a human to send.
- Track which posts and outreach produced seats and RFE responses, so the learning loop has GTM data from day one.
- Landing flow for someone arriving from X: venture page → buy a seat → onboarding interview (agent-run, builds the profile graph) → first RFE within 24 hours. Make this path fast; it is the whole funnel.

## Constraints

- Pseudonymous members by default (handle + verified attributes). Real names only via opt-in on Credibility RFEs.
- Public by default per the reporting standard in the doc; redactions are logged with a reason.
- No real money moves in the pilot without a human approving in the steward console.
- The agent's reasoning for every decision is stored and shown on the public page (with an embargo flag for sensitive ones).
- Don't build: mobile app, real payments rails, series LLC automation, cross-cohort learning, reputation scoring beyond a stub. Leave clear seams for each.

## Definition of done for the pilot

Someone can open `/v/[demo-slug]`, understand in two minutes what an agent-operated venture is, buy a seat, get an RFE, answer it, see their grant appear in the ledger, watch the agent take the next decision on the public log, and see Venture 0 asking the same person to weigh in on the protocol's open questions.

## Start here

1. Create the monorepo layout above (pnpm workspaces).
2. Write `/packages/schema` first, from the state machines in the doc.
3. Scaffold `/apps/venture` with seed data and the public venture page.
4. Build the reference agent's `simulate` command and run it against the seeded ventures until the public page tells a coherent story.
5. Write `PROTOCOL.md` last, from what the build forced you to decide. Mark open rules `[OPEN — RFE]`.
