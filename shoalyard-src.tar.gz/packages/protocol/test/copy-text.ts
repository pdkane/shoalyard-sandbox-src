import { readdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import { buildSeed } from "../src/seed";

export const root = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");

export function walk(dir: string, re = /\.(tsx?|md)$/): string[] {
  return readdirSync(dir).flatMap((name) => {
    const p = join(dir, name);
    return statSync(p).isDirectory() ? walk(p, re) : re.test(name) ? [p] : [];
  });
}

/** Attributes whose values are code, not copy. */
const CODE_ATTRS = new Set(["className", "href", "id", "key", "name", "type", "value", "defaultValue", "role", "htmlFor", "src", "action", "method", "target", "rel", "scroll", "variant", "size", "side", "align"]);

export interface CopyLine {
  where: string;
  text: string;
}

/**
 * The user-facing text in a source file: JSX text, and string or template
 * literals that read as prose (they contain a space and a letter). Imports,
 * code-valued attributes, comparisons, object keys and type literals are
 * skipped, so status ids like "funded" don't count as copy.
 */
export function copyIn(file: string): CopyLine[] {
  const src = ts.createSourceFile(file, readFileSync(file, "utf8"), ts.ScriptTarget.Latest, true, file.endsWith("x") ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
  const out: CopyLine[] = [];
  const at = (n: ts.Node) => `${relative(root, file)}:${src.getLineAndCharacterOfPosition(n.getStart()).line + 1}`;
  const prose = (t: string) => /[A-Za-z]/.test(t) && /\s/.test(t.trim());
  const skip = (n: ts.Node): boolean => {
    const p = n.parent;
    if (!p) return false;
    if (ts.isImportDeclaration(p) || ts.isExportDeclaration(p) || ts.isLiteralTypeNode(p)) return true;
    if (ts.isJsxAttribute(p) && CODE_ATTRS.has(p.name.getText())) return true;
    if (ts.isBinaryExpression(p) && [ts.SyntaxKind.EqualsEqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsEqualsToken].includes(p.operatorToken.kind)) return true;
    if (ts.isPropertyAssignment(p) && p.name === n) return true;
    if (ts.isElementAccessExpression(p) || ts.isCaseClause(p)) return true;
    if (ts.isCallExpression(p) && /\b(cn|includes|startsWith|endsWith|test|match|split|replace|join|padEnd|padStart|get|find|filter|some)\b/.test(p.expression.getText())) return true;
    return false;
  };
  const visit = (n: ts.Node) => {
    if (ts.isJsxText(n)) {
      const t = n.getText().replace(/\s+/g, " ").trim();
      if (t && /[A-Za-z]/.test(t)) out.push({ where: at(n), text: t });
    } else if ((ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n)) && !skip(n)) {
      if (prose(n.text)) out.push({ where: at(n), text: n.text });
    } else if (ts.isTemplateExpression(n) && !skip(n)) {
      const t = [n.head.text, ...n.templateSpans.map((s) => s.literal.text)].join(" … ");
      if (prose(t)) out.push({ where: at(n), text: t });
    }
    ts.forEachChild(n, visit);
  };
  visit(src);
  return out;
}

/** Counsel may name legal structures in this question and its answers. */
export const LEGAL_RFE = "rfe-v0-legal-structure";

/** Seeded text people read: names, pitches, memos, decisions, requests, lessons, notes. */
export function seededCopy(): CopyLine[] {
  const s = buildSeed();
  const out: CopyLine[] = [];
  const add = (where: string, ...texts: (string | undefined)[]) => {
    for (const t of texts) if (t) out.push({ where, text: t });
  };
  for (const v of s.ventures) {
    add(`venture ${v.id}`, v.name, v.tagline, v.pitch, v.teaser, v.distributionPolicy, ...v.killRules, ...v.budget.map((b) => b.label));
    if (v.memo) add(`venture ${v.id} memo`, ...Object.values(v.memo));
    if (v.postMortem) add(`venture ${v.id} post-mortem`, v.postMortem.summary, v.postMortem.whyItEnded, ...v.postMortem.whatWeTried, ...v.postMortem.lessons);
  }
  for (const d of s.decisions) if (d.rfeId !== LEGAL_RFE) add(`decision ${d.id}`, d.title, d.reasoning, d.outcome, ...d.binReasons);
  for (const r of s.rfes) if (r.id !== LEGAL_RFE) add(`request ${r.id}`, r.title, r.question, r.recommendation, r.resolution, r.governance?.effect, ...(r.options ?? []));
  for (const l of s.lessons) add(`lesson ${l.id}`, l.headline, l.whatHappened, l.whatWeDoDifferently, l.howSure.reason);
  for (const c of s.cohorts) add(`batch ${c.number}`, ...c.notes, ...c.slotPlan.map((p) => p.reason));
  for (const e of s.ledger) add(`ledger ${e.id}`, e.note);
  return out;
}
