import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, FileText, Inbox, Lock, MessageCircleQuestion, ScrollText, Skull, Ticket, Undo2 } from "lucide-react";
import {
  capTable,
  classificationLine,
  businessPlanFor,
  HAND_OFF_STAGES,
  handOffChecklist,
  pendingConductVotes,
  conductHoldNote,
  offersFor,
  payoutPreview,
  rfeById,
  serviceChargesFor,
  sharedServicesCharge,
  classificationOf,
  cohortFor,
  batchLabel,
  EARNED_NOT_BOUGHT,
  earlyAccessAt,
  hasSeat,
  isLive,
  isRevealed,
  canReadLessons,
  lessonsFor,
  lessonUse,
  seesLessonUse,
  ventureAttribution,
  nStatusFor,
  openRfes,
  peopleDecisions,
  atLeast,
  decisionTier,
  EMPLOYMENT_BLOCKED,
  pitchAwaitingSignOff,
  workDeliveryOf,
  decisionViews,
  postMortemView,
  raiseProgress,
  readiness,
  rosterFill,
  seatRefunds,
  seatWindow,
  scarcityFor,
  onWaitlist,
  lookupVenture,
  voteStatus,
  canWithdrawForDeck,
  latestDeck,
  qaFor,
  qaWindow,
  questionsLeft,
  reviewsFor,
  updatesFor,
  type DecisionTier,
  seatPriceHold,
  seatPriceOf,
  shareText,
  ventureHref,
  LONG_TERM_LABELS,
  proofRunBy,
} from "@av/protocol";
import {
  CLASSIFICATION_AXES,
  DECISION_BINS,
  OBJECTIVE_LABELS,
  SLIDE_TITLES,
  type DecisionBin,
  type Experiment,
  type MemberUpdate,
  type StewardReview,
  type Venture,
} from "@av/schema";
import { BasisBadge, HonestyBar, PlanGlance, SeatMath, versionLine } from "@/components/deck-ui";
import { HandedOffBanner, HandOffPanel } from "@/components/handoff-ui";
import { AskForm, WithdrawSeatForm } from "@/components/qa-forms";
import { QuestionCard, questionCards } from "@/components/qa-ui";
import { ObjectiveBadge, StatusBadge } from "@/components/badges";
import { Countdown } from "@/components/countdown";
import { DecisionLog } from "@/components/decision-log";
import { MembersOnlyLessons } from "@/components/lessons-gate";
import { FlagForm } from "@/components/protocol-forms";
import {
  ClassificationCard,
  InheritedLessons,
  MemoCard,
  PeopleDecisionsPanel,
  ReadinessPanel,
  REFUND_GUARANTEE,
  RosterPanel,
  RosterTable,
  SEAT_DISCLAIMER,
  SeatDisclaimer,
  TagList,
} from "@/components/protocol-ui";
import { EmptyState } from "@/components/empty-state";
import { Lifecycle } from "@/components/lifecycle";
import { RfeCard } from "@/components/rfe-card";
import { VentureAttribution } from "@/components/venture-attribution";
import { WhoDoesWhat } from "@/components/who-does-what";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData, type Data } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { resolveVenture, rosterView } from "@/lib/venture";
import { ShareMenu } from "@/components/share-menu";
import { ScarcityStrip, ShareLanding } from "@/components/scarcity";
import { WaitlistForm } from "@/components/waitlist-form";
import { isShareLanding } from "@/lib/share";
import { formatDate, formatDateTime, formatNumber, formatPct, formatUnits, formatUsd } from "@/lib/format";

export async function generateMetadata(props: PageProps<"/v/[slug]">): Promise<Metadata> {
  const { slug } = await props.params;
  const { store } = await getData();
  const v = lookupVenture(store, slug)?.venture;
  if (!v) return { title: "Venture not found" };
  const shown = isRevealed(store, v);
  return { title: shown ? v.name : (v.codename ?? "Announced venture"), description: shown ? v.tagline : v.teaser };
}

function Teaser({ venture, data, landing }: { venture: Venture; data: Data; landing: boolean }) {
  const { store, params, member, signedIn } = data;
  const cohort = cohortFor(store, venture)!;
  const kind = classificationLine(classificationOf(venture), ["businessModel", "endMarket"]);
  const early = earlyAccessAt(cohort, params);
  const clock = store.meta.clock;
  return (
    <div className="space-y-8">
      <header className="space-y-4">
        <Link href={`/batches/${cohort.number}`} className="text-sm text-zinc-500 hover:text-zinc-900">
          {batchLabel(cohort.number)} · announced
        </Link>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-2">
            <h1 className="font-mono text-3xl font-semibold tracking-widest">{venture.codename}</h1>
            {kind && <p className="text-sm text-zinc-500">{kind}</p>}
            <p className="max-w-2xl text-lg text-pretty text-zinc-700">{venture.teaser}</p>
            <ShareMenu
              path={ventureHref(store, venture)}
              text={shareText({ kind: "venture", name: venture.codename ?? "", codename: venture.codename, announced: true, line: venture.teaser ?? "" })}
            />
          </div>
          <div className="space-y-3">
            <Countdown to={clock < early ? early : cohort.opensAt} now={clock} label={clock < early ? "Verified members can join in" : "Seats open to everyone in"} />
            {!landing && (
              <WaitlistForm
                batch={cohort.number}
                handle={signedIn ? member?.handle : undefined}
                joined={signedIn && !!member && !!onWaitlist(store, member.handle, { cohortId: cohort.id })}
                label="Tell me when it opens"
              />
            )}
          </div>
        </div>
      </header>
      {landing && !(signedIn && member?.qualification === "qualified") && <ShareLanding data={data} venture={venture} cohort={cohort} signedIn={signedIn} />}
      <Card className="border-dashed">
        <CardContent className="flex items-start gap-3 py-2 text-sm text-zinc-600">
          <Lock className="mt-0.5 size-4 shrink-0 text-zinc-400" />
          <p>
            The full plan and budget appear on {formatDateTime(early)} UTC. Verified members can take a seat then; everyone else from{" "}
            {formatDateTime(cohort.opensAt)} UTC. {SEAT_DISCLAIMER}
          </p>
        </CardContent>
      </Card>
      <div className="grid gap-6 lg:grid-cols-3">
        <ClassificationCard tags={venture.tags} hide={["subVertical"]} />
        <RosterPanel rows={rosterFill(store, venture)} />
        <InheritedLessons
          lessons={lessonsFor(store, venture)}
          cited={venture.lessonIds}
          contradictions={venture.contradictions.map((c) => ({ ...c, lesson: store.lessons.find((l) => l.id === c.lessonId) }))}
          visible={canReadLessons(member, params)}
          basePath={`/v/${venture.slug}`}
        />
      </div>
    </div>
  );
}

function Section({ id, title, description, children, action }: { id?: string; title: string; description?: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section id={id} className="scroll-mt-20 space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
          {description && <p className="text-sm text-zinc-500">{description}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

const ALIVE_STYLE: Record<MemberUpdate["defaultAlive"]["status"], string> = {
  alive: "border-emerald-200 bg-emerald-50 text-emerald-800",
  dead: "border-rose-200 bg-rose-50 text-rose-800",
  "too early": "border-zinc-200 bg-zinc-50 text-zinc-700",
};
const EXP_STYLE: Record<Experiment["status"], string> = {
  running: "border-sky-200 bg-sky-50 text-sky-800",
  passed: "border-emerald-200 bg-emerald-50 text-emerald-800",
  failed: "border-rose-200 bg-rose-50 text-rose-800",
  stopped: "border-zinc-200 bg-zinc-50 text-zinc-700",
};

const sentence = (t: string) => (/[.!?]$/.test(t.trim()) ? t.trim() : `${t.trim()}.`);

/** The weekly update, the monthly review and experiments. Numbers are public; the detail follows the decision tiers. */
function OperatingSection({
  data,
  tier,
  updates,
  reviews,
  experiments,
}: {
  data: Data;
  tier: DecisionTier;
  updates: MemberUpdate[];
  reviews: StewardReview[];
  experiments: Experiment[];
}) {
  const u = updates.at(-1);
  const r = reviews.at(-1);
  const verified = atLeast(tier, "verified");
  const holder = atLeast(tier, "unit holder");
  const reviewDecision = r ? data.store.decisions.find((d) => d.id === r.decisionId) : undefined;
  return (
    <Section
      id="operating"
      title="How it's going"
      description="A weekly update with one number and what went wrong, a monthly review the steward signs, and experiments written down before money is spent."
    >
      <div className="grid gap-4 lg:grid-cols-3">
        {u && (
          <Card size="sm">
            <CardHeader>
              <CardTitle>Week {u.week} update</CardTitle>
              <CardDescription>{formatDate(u.at)}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <p className="text-2xl font-semibold tabular-nums">
                  {u.metric.value} <span className="text-sm font-normal text-zinc-500">{u.metric.unit}</span>
                </p>
                <p className="text-xs text-zinc-500">
                  {u.metric.name}
                  {u.metric.previous !== undefined ? ` · was ${u.metric.previous}` : ""}
                </p>
              </div>
              <p className="flex flex-wrap items-center gap-1.5 text-zinc-700">
                <span className={`rounded-full border px-2 py-0.5 text-[11px] font-medium ${ALIVE_STYLE[u.defaultAlive.status]}`}>Default {u.defaultAlive.status}</span>
                <span className="text-xs">{u.defaultAlive.detail}</span>
              </p>
              {verified ? (
                <>
                  {u.highlights.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-zinc-900">Went well</p>
                      <ul className="list-disc space-y-0.5 pl-4 text-zinc-700">
                        {u.highlights.map((h) => (
                          <li key={h}>{h}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <div>
                    <p className="text-xs font-medium text-zinc-900">Went wrong</p>
                    <ul className="list-disc space-y-0.5 pl-4 text-zinc-700">
                      {u.lowlights.map((h) => (
                        <li key={h}>{h}</li>
                      ))}
                    </ul>
                  </div>
                  {u.asks.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-zinc-900">Asks</p>
                      <ul className="space-y-0.5">
                        {u.asks.map((a) => (
                          <li key={a.rfeId}>
                            <Link href={`/rfe/${a.rfeId}`} className="underline underline-offset-2">
                              {a.text}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-xs text-zinc-500">Verified members see what went well, what went wrong and the asks.</p>
              )}
            </CardContent>
          </Card>
        )}
        {r && (
          <Card size="sm">
            <CardHeader>
              <CardTitle>Monthly review</CardTitle>
              <CardDescription>
                {formatDate(r.at)} · {reviewDecision?.status === "awaiting_steward" ? "the agent recommends; awaiting the steward's signature" : "signed by the steward"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p className="text-zinc-800">
                Call: <span className="font-medium capitalize">{r.call}</span> · default {r.defaultAlive}
              </p>
              <p className="text-xs text-zinc-600">{r.metricTrend}</p>
              <ul className="space-y-1">
                {r.killRules.map((k) => (
                  <li key={k.key} className="flex items-start justify-between gap-2 text-xs">
                    <span className="text-zinc-700">
                      {k.condition} by {formatDate(k.by)}
                    </span>
                    <span className={`shrink-0 rounded-full border px-1.5 py-px ${k.status === "fired" ? "border-rose-200 bg-rose-50 text-rose-800" : k.status === "at risk" ? "border-amber-200 bg-amber-50 text-amber-900" : "border-zinc-200 text-zinc-600"}`}>
                      {k.status}
                    </span>
                  </li>
                ))}
              </ul>
              {holder ? <p className="text-xs text-pretty text-zinc-600">{r.reason}</p> : <p className="text-xs text-zinc-500">Unit holders see the agent&apos;s full reasoning.</p>}
            </CardContent>
          </Card>
        )}
        {experiments.length > 0 && (
          <Card size="sm">
            <CardHeader>
              <CardTitle>Experiments</CardTitle>
              <CardDescription>
                {experiments.filter((e) => e.status === "running").length} running · {experiments.filter((e) => e.status === "failed").length} failed ·{" "}
                {experiments.filter((e) => e.status === "passed").length} passed
              </CardDescription>
            </CardHeader>
            <CardContent>
              {verified ? (
                <ul className="space-y-3 text-sm">
                  {experiments.slice(0, 4).map((e) => (
                    <li key={e.id} className="space-y-1">
                      <p className="flex items-start gap-1.5">
                        <span className={`shrink-0 rounded-full border px-1.5 py-px text-[11px] ${EXP_STYLE[e.status]}`}>{e.status}</span>
                        <span className="text-zinc-800">{e.hypothesis}</span>
                      </p>
                      <p className="text-xs text-zinc-500">
                        Premise: {sentence(e.premise)} Success: {sentence(e.successBar)} Stop: {sentence(e.stopRule)} Budget {formatUsd(e.budgetUsd)}.
                      </p>
                      {e.result && <p className="text-xs text-zinc-700">Result: {e.result}</p>}
                      {e.premiseTestRfeId && (
                        <Link href={`/rfe/${e.premiseTestRfeId}`} className="text-xs underline underline-offset-2">
                          Two failures on this premise: the request testing it
                        </Link>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-zinc-500">Verified members see each experiment&apos;s premise, success bar and result.</p>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </Section>
  );
}

export default async function VenturePage(props: PageProps<"/v/[slug]">) {
  const { slug } = await props.params;
  const sp = await props.searchParams;
  const bin = DECISION_BINS.includes(sp.approval as DecisionBin) ? (sp.approval as DecisionBin) : undefined;
  const data = await getData();
  const { store, params, viewer, member } = data;
  const venture = resolveVenture(store, slug);
  const landing = await isShareLanding(sp);
  if (!isRevealed(store, venture)) return <Teaser venture={venture} data={data} landing={landing} />;
  const sc = scarcityFor(store, venture);
  const full = !!sc.seats?.full;

  const raise = raiseProgress(store, venture, params);
  const cohort = cohortFor(store, venture);
  const seatWin = seatWindow(store, venture, params);
  const qualified = member?.qualification === "qualified";
  const lessonsVisible = canReadLessons(member, params);
  const use = seesLessonUse(store, venture, member, params) ? lessonUse(store, venture) : undefined;
  const kind = classificationLine(classificationOf(venture), ["businessModel", "endMarket"]);
  const inherited = lessonsFor(store, venture);
  const contradictions = venture.contradictions.map((c) => ({ ...c, lesson: store.lessons.find((l) => l.id === c.lessonId) }));
  const cap = capTable(store, venture, params);
  const rfes = openRfes(store, venture.id);
  const requests = rfes.filter((r) => !r.gtm && r.type !== "capital");
  const tier = decisionTier(store, venture, member, params);
  const contractorPay = store.ledger.filter((l) => l.ventureId === venture.id && l.kind === "contractor-pay");
  const decisions = decisionViews(store, venture, tier, params);
  const pm = venture.postMortem ? postMortemView(venture.postMortem, tier) : undefined;
  const seated = member ? hasSeat(store, venture.id, viewer) : false;
  const refunds = seatRefunds(store, venture.id);
  const refundLine = `${refunds.count} ${refunds.count === 1 ? "seat" : "seats"} refunded in full (${formatUsd(refunds.totalUsd)})`;
  const live = isLive(venture);
  const delivery = workDeliveryOf(venture);
  const awaitingSignOff = pitchAwaitingSignOff(store, venture);
  const employmentBlocked = delivery === "Employees" && !params.EMPLOYMENT_ALLOWED;
  const priceHold = seatPriceHold(store, venture);
  const sellingSeats =
    live &&
    !venture.isProtocol &&
    !awaitingSignOff &&
    !priceHold &&
    !employmentBlocked &&
    (venture.status !== "pitched" || seatWin.state === "none" || seatWin.state === "open" || (seatWin.state === "early" && qualified));
  const earlyOnly = live && venture.status === "pitched" && seatWin.state === "early" && !qualified;
  const q = venture.quarters.at(-1);
  const clock = store.meta.clock;
  const style = { "--accent-color": venture.accent } as React.CSSProperties;
  const attr = ventureAttribution(store, venture, params);
  const deck = latestDeck(store, venture.id);
  const plan = deck && businessPlanFor(deck, classificationOf(venture).customer, params);
  const roster = rosterView(data, venture);
  const withdrawable = seated && canWithdrawForDeck(store, venture, viewer);
  const qa = deck && !venture.isProtocol ? qaWindow(store, venture, params) : undefined;
  const questions = qa ? qaFor(store, venture, { viewer: member ? viewer : undefined, sort: "top" }) : [];
  const canAsk = qa?.state === "open" || (qa?.state === "early" && qualified);
  const updates = updatesFor(store, venture.id);
  const reviews = reviewsFor(store, venture.id);
  const experiments = store.experiments.filter((e) => e.ventureId === venture.id).sort((a, b) => b.at.localeCompare(a.at));
  const handOff = !venture.isProtocol && HAND_OFF_STAGES.includes(venture.status) ? handOffChecklist(store, venture, params) : undefined;
  const offerViews = offersFor(store, venture.id).map((offer) => ({
    offer,
    preview: payoutPreview(store, venture, offer.contributors.cashUsd, params),
    vote: offer.voteRfeId ? rfeById(store, offer.voteRfeId) : undefined,
    held: pendingConductVotes(store, venture.id) ? conductHoldNote(pendingConductVotes(store, venture.id)) : undefined,
  }));
  const handOffPaid = store.ledger.filter((l) => l.ventureId === venture.id && l.kind === "handoff-payout" && l.handle).length;

  return (
    <div style={style} className="space-y-10">
      <header className="space-y-5">
        <div className="h-1.5 w-16 rounded-full bg-[var(--accent-color)]" />
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-3xl font-semibold tracking-tight">{venture.name}</h1>
              <StatusBadge status={venture.status} />
            </div>
            {venture.isProtocol ? (
              <p className="text-sm text-zinc-500">
                The organization that runs these rules
                {cohort && (
                  <>
                    {" · "}
                    <Link href={`/batches/${cohort.number}`} className="underline underline-offset-2 hover:text-zinc-900">
                      {batchLabel(cohort.number)}
                    </Link>
                  </>
                )}
                {kind && ` · ${kind}`}
              </p>
            ) : (
              <div className="space-y-1">
                <VentureAttribution mark={attr.mark} />
                {(cohort || kind) && (
                  <p className="text-sm text-zinc-500">
                    {cohort && (
                      <Link href={`/batches/${cohort.number}`} className="underline underline-offset-2 hover:text-zinc-900">
                        {batchLabel(cohort.number)}
                      </Link>
                    )}
                    {kind && `${cohort ? " · " : ""}${kind}`}
                  </p>
                )}
              </div>
            )}
            <p className="max-w-2xl text-lg text-pretty text-zinc-700">{venture.tagline}</p>
            {priceHold && live && !venture.isProtocol && (
              <p className="max-w-2xl rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">{priceHold}</p>
            )}
            {awaitingSignOff && (
              <p className="max-w-2xl rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                {venture.name} pays <TermServer id="contractor">contractors</TermServer> for its work, so the steward signs off on the pitch
                before seats open.
              </p>
            )}
            {employmentBlocked && (
              <p className="max-w-2xl rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-900">
                {EMPLOYMENT_BLOCKED}{" "}
                <Link href="/rfe/rfe-v0-employment" className="font-medium underline underline-offset-2">
                  The open request
                </Link>
              </p>
            )}
            {!venture.isProtocol && venture.status === "pitched" && (
              <dl className="max-w-2xl space-y-1 rounded-lg border border-zinc-200 bg-white p-3 text-sm text-zinc-700">
                <div>
                  <dt className="inline font-medium text-zinc-900">What you&apos;d do: </dt>
                  <dd className="inline">
                    take a <TermServer id="seat">seat</TermServer>, get <TermServer id="verified">verified</TermServer>, then answer the
                    agent&apos;s questions about {venture.customers.segment.toLowerCase()}. Each answer earns{" "}
                    <TermServer id="unit">units</TermServer>.
                  </dd>
                </div>
                <div>
                  <dt className="inline font-medium text-zinc-900">
                    If it doesn&apos;t sell {raise.needed} seats{seatWin.closesAt ? ` by ${formatDate(seatWin.closesAt)}` : ""}:{" "}
                  </dt>
                  <dd className="inline">it ends and you get your money back.</dd>
                </div>
              </dl>
            )}
            <ScarcityStrip sc={sc} />
            <div className="flex flex-wrap gap-1.5 pt-1">
              <ObjectiveBadge objective={venture.objective} />
            </div>
            <TagList tags={venture.tags.filter((t) => !(CLASSIFICATION_AXES as readonly string[]).includes(t.axis) && !(live && t.axis === "stage"))} />
          </div>
          <div className="flex flex-col items-start gap-1.5 lg:items-end">
            <div className="flex flex-wrap gap-2">
              {!venture.isProtocol && (
                <ShareMenu
                  path={ventureHref(store, venture)}
                  text={shareText({ kind: "venture", name: venture.name, announced: false, line: venture.tagline })}
                  className="h-10"
                />
              )}
              {sellingSeats && !seated && !full && (
                <Link href={`/v/${venture.slug}/seat`} className={buttonVariants({ size: "lg" })}>
                  <Ticket /> Take a seat · {formatUsd(seatPriceOf(venture, params))}
                </Link>
              )}
              {earlyOnly && !seated && (
                <span className={buttonVariants({ size: "lg", variant: "outline", className: "pointer-events-none opacity-70" })}>
                  Verified members only until {formatDateTime(seatWin.opensAt!)}
                </span>
              )}
              {seated && (
                <Link href="/inbox" className={buttonVariants({ size: "lg" })}>
                  <Inbox /> You have a seat. Go to your requests
                </Link>
              )}
              <Link href={`/v/${venture.slug}/ledger`} className={buttonVariants({ size: "lg", variant: "outline" })}>
                <ScrollText /> Public record
              </Link>
              {q && (
                <Link href={`/v/${venture.slug}/report`} className={buttonVariants({ size: "lg", variant: "outline" })}>
                  <FileText /> Report
                </Link>
              )}
            </div>
            {full && !seated && !landing && (
              <WaitlistForm
                slug={venture.slug}
                handle={data.signedIn ? member?.handle : undefined}
                joined={data.signedIn && !!member && !!onWaitlist(store, member.handle, { ventureId: venture.id })}
                label="Join the waitlist"
              />
            )}
            {sc.closesAt && (
              <div className="pt-1">
                <Countdown to={sc.publicOpensAt ?? sc.closesAt} now={clock} label={sc.publicOpensAt ? "Seats open to everyone in" : "Seats close in"} />
              </div>
            )}
            {!venture.isProtocol && live && <SeatDisclaimer />}
            {qualified && !venture.isProtocol && (
              <span className="text-xs text-zinc-500">
                <FlagForm kind="venture" id={venture.id} label={`${venture.name}: the idea`} />
              </span>
            )}
          </div>
        </div>
      </header>

      {landing && !venture.isProtocol && !(data.signedIn && qualified) && <ShareLanding data={data} venture={venture} cohort={cohort} full={full} signedIn={data.signedIn} />}

      {pm && venture.postMortem && (
        <Card className="border-rose-200 bg-rose-50/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-rose-900">
              <Skull className="size-5" /> What happened
            </CardTitle>
            {attr.mark && (
              <VentureAttribution mark={attr.mark} className="text-rose-900/70" />
            )}
            <CardDescription className="text-rose-900/80">{pm.summary}</CardDescription>
            {venture.postMortem.counterfactual && (
              <div className="mt-2 flex items-start gap-2 rounded-lg border border-amber-200 bg-white/70 p-3 text-sm text-zinc-700">
                <BasisBadge basis="estimate" className="mt-0.5" />
                <p className="text-pretty">{venture.postMortem.counterfactual}</p>
              </div>
            )}
          </CardHeader>
          <CardContent className="grid gap-6 text-sm md:grid-cols-3">
            <div>
              <p className="mb-2 font-medium text-zinc-900">What we tried</p>
              {pm.whatWeTried ? (
                <ul className="list-disc space-y-1 pl-4 text-zinc-700">
                  {pm.whatWeTried.map((w) => (
                    <li key={w}>{w}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-zinc-500">People with units in this venture, or in the Protocol, see what was tried and the full reason it ended.</p>
              )}
            </div>
            <div>
              <p className="mb-2 font-medium text-zinc-900">Why it ended</p>
              {(pm.whyItEnded ?? pm.shortWhy) && <p className="text-zinc-700">{pm.whyItEnded ?? pm.shortWhy}</p>}
              <dl className="mt-3 space-y-0.5 text-zinc-500">
                <div>Kill-rule category: {pm.killReason ?? "not yet published"}</div>
                {pm.stageReached && <div>Got as far as: {pm.stageReached}</div>}
                {pm.daysToKillSignal !== undefined && <div>Days until it was clear: {pm.daysToKillSignal}</div>}
                <div>Total cost: {formatUsd(pm.costUsd)}</div>
                {refunds.count > 0 && <div>{refundLine}</div>}
                <div>{pm.publishedAt ? `Published ${formatDate(pm.publishedAt)}` : "Draft. The steward will publish it before the batch closes."}</div>
              </dl>
            </div>
            <div>
              <p className="mb-2 font-medium text-zinc-900">Lessons</p>
              {lessonsVisible ? (
                <ul className="list-disc space-y-1 pl-4 text-zinc-700">
                  {venture.postMortem.lessons.map((w) => (
                    <li key={w}>{w}</li>
                  ))}
                </ul>
              ) : (
                <MembersOnlyLessons
                  teaser={{ count: venture.postMortem.lessons.length, ventures: 1, topics: [] }}
                  title={`${venture.postMortem.lessons.length} lesson${venture.postMortem.lessons.length === 1 ? "" : "s"} from this venture`}
                  showTopics={false}
                />
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {venture.handOff && <HandedOffBanner venture={venture} payouts={handOffPaid} />}

      {(handOff || offerViews.length > 0) && !venture.handOff && (
        <Section
          id="hand-off"
          title="Handing it off"
          description="One of three ways a venture ends: shut down, kept running by its agent, or adopted by an entrepreneur who takes it forward with their own money."
        >
          <HandOffPanel
            venture={venture}
            ready={!!handOff?.ready}
            items={handOff?.items ?? []}
            offers={offerViews}
            viewer={viewer}
            isSteward={viewer === venture.stewardHandle}
            canOffer={qualified && viewer !== venture.stewardHandle}
          />
        </Section>
      )}

      <Section
        id="people"
        title="The people behind it"
        description={
          venture.isProtocol
            ? "Members answer the Protocol's questions and its unit holders vote on its rules. The agent does the running."
            : "The agent proposed this venture and does the running. These are the people it needs, and the calls they've made."
        }
      >
        <div className={roster.rows.length > 0 ? "grid gap-6 lg:grid-cols-[1.4fr_1fr] lg:items-start" : ""}>
          {roster.rows.length > 0 && <RosterTable rows={roster.rows} slug={venture.slug} gate={roster.gate} claim={roster.claim} />}
          <PeopleDecisionsPanel rows={peopleDecisions(store, venture, atLeast(tier, "unit holder"))} />
        </div>
        <WhoDoesWhat
          contractors={
            delivery === "Agent plus contractors"
              ? {
                  count: contractorPay.length,
                  totalUsd: contractorPay.reduce((n, l) => n + (l.usd ?? 0), 0),
                  ledgerHref: `/v/${venture.slug}/ledger?kind=contractor-pay`,
                }
              : undefined
          }
        />
      </Section>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>{deck ? "The deck" : "The pitch"}</CardTitle>
            <CardDescription>
              Written by the agent. Steward: @{venture.stewardHandle}.{deck ? ` ${versionLine(deck)}.` : ""}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {deck ? (
              <div className="space-y-4">
                <p className="text-pretty text-zinc-800">{deck.purpose}</p>
                <dl className="space-y-3">
                  {(["problem", "solution", "customer"] as const).map((k) => {
                    const s = deck.slides.find((x) => x.key === k);
                    return s ? (
                      <div key={k}>
                        <dt className="text-xs font-medium tracking-wide text-zinc-500 uppercase">{SLIDE_TITLES[k]}</dt>
                        <dd className="text-sm text-pretty text-zinc-800">
                          <Link href={`/v/${venture.slug}/deck#${k}`} className="hover:underline">
                            {s.headline}
                          </Link>
                        </dd>
                      </div>
                    ) : null;
                  })}
                </dl>
                <HonestyBar deck={deck} className="max-w-md" />
                {deck.banner && <p className="text-xs text-zinc-500">{deck.banner}</p>}
                <div className="flex flex-wrap gap-2">
                  <Link href={`/v/${venture.slug}/deck`} className={buttonVariants()}>
                    <FileText /> Open the deck
                  </Link>
                  {deck.version > 1 && (
                    <Link href={`/v/${venture.slug}/deck/changes`} className={buttonVariants({ variant: "outline" })}>
                      What changed
                    </Link>
                  )}
                </div>
              </div>
            ) : (
              <p className="whitespace-pre-line text-pretty text-zinc-700">{venture.pitch}</p>
            )}
            <div className="rounded-lg bg-zinc-50 p-4 text-sm">
              <p className="font-medium text-zinc-900">
                Goal: {OBJECTIVE_LABELS[venture.objective].label}
              </p>
              <p className="mt-1 text-zinc-600">{OBJECTIVE_LABELS[venture.objective].meaning}</p>
              <p className="mt-2 text-zinc-600">How profit is paid out: {venture.distributionPolicy}</p>
            </div>
            {!venture.isProtocol && <Lifecycle venture={venture} />}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{venture.isProtocol ? "Members" : "Seats"}</CardTitle>
            <CardDescription>
              {venture.isProtocol
                ? "Any verified member can answer the Protocol's questions. No seat is needed."
                : `${SEAT_DISCLAIMER} ${REFUND_GUARANTEE}`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {refunds.count > 0 && (
              <p className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-900">
                <Undo2 className="size-4 shrink-0" /> {refundLine}
              </p>
            )}
            {!venture.isProtocol && (
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-semibold tabular-nums">
                  {raise.sold}
                  <span className="text-lg font-normal text-zinc-400">/{raise.needed}</span>
                </span>
                <span className="text-sm text-zinc-500">{raise.pct}%</span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-zinc-100">
                <div className="h-full rounded-full bg-[var(--accent-color)]" style={{ width: `${raise.pct}%` }} />
              </div>
              <p className="mt-2 text-sm text-zinc-600">
                {raise.sold} of {raise.needed} seats sold ({formatUsd(raise.raisedUsd)} of {formatUsd(venture.minRaiseUsd)})
                {venture.status === "pitched" && seatWin.closesAt ? `. Deadline: ${formatDate(seatWin.closesAt)}.` : "."}
              </p>
            </div>
            )}
            {deck && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-zinc-900">Why {deck.seatPlan.min} seats</p>
                <SeatMath plan={deck.seatPlan} current={deck.currentRule} roles={deck.roster} compact />
                <Link href={`/v/${venture.slug}/deck#ask`} className="inline-flex items-center gap-1 text-xs text-zinc-600 underline underline-offset-2 hover:text-zinc-900">
                  The full calculation and the refund rules <ArrowRight className="size-3" />
                </Link>
              </div>
            )}
            {deck?.proof && (
              <p className="text-sm text-zinc-600">
                Proof run by: <span className="font-medium text-zinc-900">{proofRunBy(deck.proof)}</span>. Long-term operator: <span className="font-medium text-zinc-900">{LONG_TERM_LABELS[deck.proof.longTermOperator].toLowerCase()}</span>.{" "}
                <Link href={`/v/${venture.slug}/deck#howItRuns`} className="underline underline-offset-2 hover:text-zinc-900">
                  Who runs each task
                </Link>
              </p>
            )}
            {deck && plan && (
              <PlanGlance plan={plan} slug={venture.slug} services={{ monthlyUsd: sharedServicesCharge(params).monthlyUsd, billedUsd: serviceChargesFor(store, venture.id).totalUsd }} />
            )}
            {withdrawable && (
              <div className="space-y-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                <p>The deck changed materially after you took your seat. You can take it back for a full refund while seats are selling.</p>
                <WithdrawSeatForm slug={venture.slug} price={formatUsd(seatPriceOf(venture, params))} />
              </div>
            )}
            <ul className="space-y-1.5 text-sm text-zinc-600">
              {!venture.isProtocol && <li>After you take a seat, get verified: you can&apos;t answer requests until the steward checks your profile.</li>}
              <li>
                {EARNED_NOT_BOUGHT} Demo units (up to {params.MAX_UNITS_PER_RFE} per request) may still appear on pilot screens.
              </li>
            </ul>
            {sellingSeats && !seated && (
              <div className="space-y-1.5">
                <Link href={`/v/${venture.slug}/seat`} className={buttonVariants({ className: "w-full" })}>
                  Take a seat <ArrowRight />
                </Link>
                <SeatDisclaimer />
              </div>
            )}
            {earlyOnly && <p className="text-sm text-zinc-500">Verified members only until {formatDateTime(seatWin.opensAt!)} UTC. Everyone else can take a seat after that.</p>}
            {!live && <p className="text-sm text-zinc-500">Seats are closed for this venture.</p>}
          </CardContent>
        </Card>
      </div>

      {!venture.isProtocol && (venture.memo || venture.roster.length > 0 || inherited.length > 0) && (
        <div className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-[2fr_1fr] lg:items-start">
            {venture.memo && <MemoCard memo={venture.memo} />}
            <ClassificationCard tags={venture.tags} />
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            {live && <ReadinessPanel items={readiness(store, venture, params, lessonsVisible)} />}
            <InheritedLessons
              lessons={inherited}
              cited={venture.lessonIds}
              contradictions={contradictions}
              visible={lessonsVisible}
              use={use}
              basePath={`/v/${venture.slug}`}
            />
          </div>
        </div>
      )}

      {qa && qa.state !== "none" && (
        <Section
          id="qa"
          title="Questions and answers"
          description="Ask the agent about the deck. It answers from the deck only, cites what it used, and sends what it doesn't know to members."
          action={
            <Link href={`/v/${venture.slug}/qa`} className={buttonVariants({ variant: "outline", size: "sm" })}>
              All {questions.length} question{questions.length === 1 ? "" : "s"} <ArrowRight />
            </Link>
          }
        >
          <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr] lg:items-start">
            <div className="space-y-3">
              {questions.length === 0 ? (
                <EmptyState icon={MessageCircleQuestion} title="No questions yet">
                  Ask the first one.
                </EmptyState>
              ) : (
                questionCards(data, venture, questions.slice(0, 3)).map((c) => <QuestionCard key={c.q.id} {...c} />)
              )}
            </div>
            {canAsk ? (
              <AskForm
                slug={venture.slug}
                left={questionsLeft(store, venture, member, params)}
                visitor={!member}
                maxChars={params.QA_MAX_CHARS}
                note={member?.qualification === "pending" ? `Before you're verified: ${params.QA_PENDING_DAILY} a day.` : undefined}
              />
            ) : (
              <p className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-600">{qa.reason}</p>
            )}
          </div>
        </Section>
      )}

      {(updates.length > 0 || reviews.length > 0 || experiments.length > 0) && (
        <OperatingSection data={data} tier={tier} updates={updates} reviews={reviews} experiments={experiments} />
      )}

      <Section
        id="requests"
        title="Where your judgement is needed"
        description={live ? "The calls and introductions the agent can't make alone. Each one says why it needs a person." : undefined}
        action={
          member && requests.length > 0 ? (
            <Link href="/inbox" className={buttonVariants({ variant: "outline", size: "sm" })}>
              Your inbox <ArrowRight />
            </Link>
          ) : undefined
        }
      >
        {requests.length === 0 ? (
          <EmptyState icon={Inbox} title={live ? "No open requests" : "Requests closed"}>
            {live ? "New requests appear as the agent works." : "Open requests were closed when the venture ended."}
          </EmptyState>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {requests.map((r) => (
              <RfeCard
                key={r.id}
                rfe={r}
                venture={venture}
                clock={clock}
                n={r.kind === "request" && !r.assignedTo ? nStatusFor(store, r, params) : undefined}
                vote={r.kind === "governance" ? voteStatus(store, r, params) : undefined}
              />
            ))}
          </div>
        )}
      </Section>

      <div className="grid gap-10 lg:grid-cols-[1.6fr_1fr]">
        <Section
          id="log"
          title="The agent's work log"
          description="Everything the agent did, who decided it and what it cost. A few entries are published later; for those you see why and when."
        >
          <DecisionLog
            decisions={decisions}
            tier={tier}
            ventureSlug={venture.slug}
            basePath={`/v/${venture.slug}`}
            bin={bin}
            limit={12}
            flaggable={qualified}
            lessons={lessonsVisible ? store.lessons : []}
            lessonsVisible={lessonsVisible}
          />
        </Section>

        <div className="space-y-10">
          <Section title="Who holds units" description="Units that have vested get a vote and a share of each payout.">
            <Card size="sm">
              <CardContent className="space-y-4">
                <div className="flex h-3 overflow-hidden rounded-full bg-zinc-100" aria-hidden>
                  <div className="bg-zinc-900" style={{ width: `${cap.protocolPct}%` }} />
                  <div className="bg-[var(--accent-color)]" style={{ width: `${cap.contributorPct}%` }} />
                </div>
                <p className="text-sm text-zinc-600">
                  {cap.protocolPct > 0
                    ? `${formatPct(cap.protocolPct, 0)} of the profit share goes to the Protocol as its fee. The other ${formatPct(cap.contributorPct, 0)} is ${cap.poolUnits} units for the people who do the work.`
                    : `No protocol fee: all of the profit share is ${cap.poolUnits} units for the people who do the work.`}
                </p>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Earned by</TableHead>
                      <TableHead className="text-right">Earned</TableHead>
                      <TableHead className="text-right">Of</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cap.slices
                      .filter((s) => s.allocated > 0)
                      .map((s) => (
                      <TableRow key={s.key}>
                        <TableCell>{s.label}</TableCell>
                        <TableCell className="text-right tabular-nums">{formatNumber(s.granted)}</TableCell>
                        <TableCell className="text-right tabular-nums text-zinc-500">{formatNumber(s.allocated)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div>
                  <p className="mb-2 text-xs font-medium tracking-wide text-zinc-500 uppercase">
                    Top holders · {cap.holderCount} total
                  </p>
                  <ul className="space-y-1.5 text-sm">
                    {cap.holders.slice(0, 6).map((h) => (
                      <li key={h.handle} className="flex items-center justify-between gap-2">
                        <span className={h.handle === viewer ? "font-semibold" : ""}>@{h.handle}</span>
                        <span className="tabular-nums text-zinc-600">
                          {formatUnits(h.units)} · {formatPct(h.pctOfInterests)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </Section>

          <Section title="Budget to first customer">
            <Card size="sm">
              <CardContent>
                <ul className="divide-y divide-zinc-100 text-sm">
                  {venture.budget.map((b) => (
                    <li key={b.label} className="flex justify-between py-2">
                      <span className="text-zinc-700">{b.label}</span>
                      <span className="tabular-nums">{formatUsd(b.usd)}</span>
                    </li>
                  ))}
                  <li className="flex justify-between py-2 font-medium">
                    <span>Minimum (seats × {formatUsd(seatPriceOf(venture, params))})</span>
                    <span className="tabular-nums">{formatUsd(venture.minRaiseUsd)}</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </Section>

          <Section title="When it shuts down" description="Set before launch. The steward can also shut it down at any time and must say why.">
            <ul className="space-y-2 text-sm">
              {venture.killRules.map((k) => (
                <li key={k} className="rounded-lg border border-zinc-200 bg-white px-3 py-2 text-zinc-700">
                  {k}
                </li>
              ))}
              {venture.killDate && <li className="text-zinc-500">Shut-down date: {formatDate(venture.killDate)}</li>}
            </ul>
          </Section>

          {q && (
            <Section
              title={`Latest report · ${q.quarter}`}
              action={
                <Link href={`/v/${venture.slug}/report`} className={buttonVariants({ variant: "ghost", size: "sm" })}>
                  Full report <ArrowRight />
                </Link>
              }
            >
              <Card size="sm">
                <CardContent>
                  <dl className="grid grid-cols-2 gap-3 text-sm">
                    {[
                      ["Revenue", formatUsd(q.revenueUsd)],
                      ["Costs", formatUsd(q.costsUsd)],
                      ["Fixed costs", formatUsd(q.passThroughUsd)],
                      ["Cash left", formatUsd(q.runwayUsd)],
                      ["Customers", `${venture.customers.count} ${venture.customers.segment}`],
                      ["Retention", venture.customers.retention ?? "—"],
                    ].map(([k, v]) => (
                      <div key={k}>
                        <dt className="text-xs text-zinc-500">{k}</dt>
                        <dd className="font-medium tabular-nums">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </CardContent>
              </Card>
            </Section>
          )}
        </div>
      </div>
    </div>
  );
}
