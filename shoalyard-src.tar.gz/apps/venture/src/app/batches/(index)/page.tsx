import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { currentBatch, batchLabel, batchVentures, classificationLine, classificationOf, nextAnnouncedBatch, onWaitlist } from "@av/protocol";
import { WaitlistForm } from "@/components/waitlist-form";
import { BatchPanel, BatchStatusPill, NobodySelects } from "@/components/batch-ui";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { formatDate } from "@/lib/format";

export const metadata: Metadata = { title: "Batches" };

export default async function BatchesPage() {
  const data = await getData();
  const { store, params } = data;
  const current = currentBatch(store);
  const all = [...store.cohorts].sort((a, b) => b.number - a.number);

  return (
    <div className="space-y-10">
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold tracking-tight">Batches</h1>
        <p className="max-w-2xl text-sm text-zinc-600">
          New ventures come out in <TermServer id="batch">batches</TermServer> of about {params.VENTURES_PER_BATCH}. Each batch is announced{" "}
          {params.BATCH_ANNOUNCE_LEAD_DAYS} days ahead with code names only. <TermServer id="verified">Verified</TermServer> members can take seats{" "}
          {params.EARLY_ACCESS_HOURS} hours before everyone else. Any venture that doesn&apos;t sell its{" "}
          <TermServer id="minimum">minimum</TermServer> number of seats in the window ends, and everyone is refunded.
        </p>
        <NobodySelects />
      </div>

      {current && <BatchPanel cohort={current} data={data} />}

      {!nextAnnouncedBatch(store) && (
        <section className="space-y-2 rounded-xl border border-dashed border-zinc-300 bg-white p-5">
          <h2 className="text-base font-semibold tracking-tight">The next batch isn&apos;t announced yet</h2>
          <p className="text-sm text-zinc-600">Leave a handle and you&apos;ll hear when it is, with its code names and opening date.</p>
          <WaitlistForm
            handle={data.signedIn ? data.member?.handle : undefined}
            joined={data.signedIn && !!data.member && !!onWaitlist(store, data.member.handle, {})}
            label="Tell me about the next batch"
          />
        </section>
      )}

      <section className="space-y-3">
        <h2 className="text-lg font-semibold tracking-tight">All batches</h2>
        <ul className="divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white">
          {all.map((c) => {
            const vs = batchVentures(store, c);
            return (
              <li key={c.id}>
                <Link href={`/batches/${c.number}`} className="flex flex-col gap-2 p-4 transition hover:bg-zinc-50 sm:flex-row sm:items-center sm:justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{batchLabel(c.number)}</span>
                      <BatchStatusPill cohort={c} />
                    </div>
                    <p className="text-sm text-zinc-500">
                      {c.status === "announced"
                        ? vs.map((v) => v.codename).join(" · ")
                        : vs.map((v) => v.name).join(" · ")}
                    </p>
                    <p className="text-xs text-zinc-400">
                      {vs
                        .map((v) => classificationLine(classificationOf(v), ["businessModel", "endMarket"]))
                        .filter(Boolean)
                        .join("; ")}
                    </p>
                  </div>
                  <span className="flex items-center gap-1 text-xs text-zinc-500">
                    {c.status === "closed" ? `Closed ${formatDate(c.closedAt ?? c.closesAt)}` : `Opens ${formatDate(c.opensAt)}`}
                    <ArrowRight className="size-4" />
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
