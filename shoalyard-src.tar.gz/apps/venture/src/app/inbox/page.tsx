import { AccountLabel } from "@/components/account-label";
import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2, Inbox, PartyPopper, ShieldAlert } from "lucide-react";
import { inboxFor, nStatusFor, rankForMember, ventureById, ventureBySlug, voteStatus } from "@av/protocol";
import { GRANT_STATUS_LABELS } from "@av/schema";
import { EmptyState } from "@/components/empty-state";
import { RfeCard } from "@/components/rfe-card";
import { RfeTypeBadge } from "@/components/badges";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { buttonVariants } from "@/components/ui/button";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { formatAgo, formatUnits } from "@/lib/format";

export const metadata: Metadata = { title: "Inbox" };

export default async function InboxPage(props: PageProps<"/inbox">) {
  const sp = await props.searchParams;
  const { store, params, viewer, member, isSteward } = await getData();
  if (!member) {
    return (
      <EmptyState icon={Inbox} title="No requests yet">
        Take a seat in a venture and the agent will start sending you its questions.
      </EmptyState>
    );
  }
  const rfes = rankForMember(inboxFor(store, viewer), member);
  const welcome = typeof sp.welcome === "string" ? sp.welcome : undefined;
  const joined = typeof sp.joined === "string" ? ventureBySlug(store, sp.joined) : undefined;
  const answered = store.responses
    .filter((r) => r.handle === viewer)
    .sort((a, b) => b.at.localeCompare(a.at))
    .slice(0, 8)
    .map((resp) => {
      const rfe = store.rfes.find((r) => r.id === resp.rfeId)!;
      const grant = store.grants.find((g) => g.rfeId === rfe.id && g.handle === viewer);
      return { resp, rfe, grant, venture: ventureById(store, rfe.ventureId) };
    });

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <AccountLabel />
          <h1 className="text-2xl font-semibold tracking-tight">Your inbox</h1>
          <p className="text-sm text-zinc-500">
            Where your judgement is needed: the calls the agent can&apos;t make without you, picked for @{viewer}, best match first.
            We&apos;ll send at most {member.dailyPushCap} a day. Answer by
            clicking, typing or speaking. Each <TermServer id="request">request</TermServer> says how many{" "}
            <TermServer id="unit">units</TermServer> it pays.
          </p>
        </div>
        {!member.onboardedAt && (
          <Link href="/onboarding" className={buttonVariants()}>
            Finish setting up
          </Link>
        )}
      </div>

      {member.qualification !== "qualified" && (
        <Alert className="border-amber-200 bg-amber-50/60">
          <ShieldAlert className="text-amber-700" />
          <AlertTitle>{member.qualification === "declined" ? "Profile declined" : "Not verified yet"}</AlertTitle>
          <AlertDescription>
            {member.qualification === "declined" ? (
              "The steward declined this profile. You keep your seats, but requests stay closed to you."
            ) : (
              <>
                You&apos;ll get requests once you&apos;re <TermServer id="verified">verified</TermServer>.{" "}
                {member.verifications.some((v) => v.status === "pending")
                  ? "Your link is waiting for the steward."
                  : "Link LinkedIn or X to start."}{" "}
                <Link href="/onboarding?step=qualify#qualify" className="font-medium underline">
                  Get verified
                </Link>
              </>
            )}
          </AlertDescription>
        </Alert>
      )}

      {(welcome || joined) && (
        <Alert className="border-emerald-200 bg-emerald-50/60">
          <PartyPopper className="text-emerald-700" />
          <AlertTitle>{welcome ? "You're in." : `Welcome back to ${joined?.name}.`}</AlertTitle>
          <AlertDescription>
            Your seat is on the public record. You earn units by answering requests, and they vest {params.VESTING_DAYS} days after you earn them.{" "}
            {rfes.length > 0 ? "The first request is waiting below." : ""}
          </AlertDescription>
        </Alert>
      )}

      {rfes.length === 0 ? (
        <EmptyState icon={CheckCircle2} title="You're all caught up">
          New requests arrive as the agents work.
          {isSteward ? " You can run the demo forward from the Steward page." : ""}
        </EmptyState>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {rfes.map((r, i) => (
            <RfeCard
              key={r.id}
              rfe={r}
              venture={ventureById(store, r.ventureId)}
              clock={store.meta.clock}
              showVenture
              highlight={welcome ? r.id === welcome : i === 0 && !!joined}
              n={r.kind === "request" && !r.assignedTo ? nStatusFor(store, r, params) : undefined}
              vote={r.kind === "governance" ? voteStatus(store, r, params) : undefined}
            />
          ))}
        </div>
      )}

      {answered.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold tracking-tight">Your recent answers</h2>
          <ul className="divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white">
            {answered.map(({ resp, rfe, grant, venture }) => (
              <li key={resp.id}>
                <Link href={`/rfe/${rfe.id}`} className="flex flex-col gap-1 p-4 hover:bg-zinc-50 sm:flex-row sm:items-center sm:gap-3">
                  <RfeTypeBadge type={rfe.type} governance={rfe.kind === "governance"} className="self-start sm:self-auto" explain={false} />
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{rfe.title}</span>
                  <span className="text-xs text-zinc-500">
                    {venture.name} · {formatAgo(resp.at, store.meta.clock)} ·{" "}
                    {grant ? (
                      <span className="text-emerald-700">
                        {formatUnits(grant.units)} · {GRANT_STATUS_LABELS[grant.status].toLowerCase()}
                      </span>
                    ) : rfe.status === "resolved" ? (
                      "resolved"
                    ) : rfe.kind === "governance" ? (
                      `voted with ${resp.weight ?? 0} units`
                    ) : (
                      "waiting for more answers"
                    )}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
