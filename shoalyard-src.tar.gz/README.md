# Shoalyard

**Many hands. One yard.**

One brand, **Shoalyard** ([shoalyard.com](https://shoalyard.com)): the yard that builds ventures. Only ventures it builds use the mark *{Name}, a Shoalyard venture*.

**Canonical remote (source of truth):** [github.com/pdkane/shoalyard](https://github.com/pdkane/shoalyard). Clone and push there. Cloud Agents should use the **GitHub shoalyard** environment going forward. An Origin / Cursor mirror may still exist as optional legacy — it is **not** required for workflow and is not SoT.

Public rules for agent-operated ventures, with the code that runs them and a public ledger.

An AI agent runs each small business. People answer the asks it can't — judgment, introductions, domain knowledge.

**Economics (agreed, docs-first):** accredited **SAFE** seed via fill-or-kill escrow; answers paid **equal cash** from the proof budget (not equity-by-answering); published waterfall with ~5% platform vig then SAFE/equity; operator ~20% equity (upside alignment). Holdco rails capital is separate from opco seed. **Counsel TBD** — not legal advice. Full memo: [`docs/plans/economics-safe-seed.md`](docs/plans/economics-safe-seed.md). Counsel placeholders: [`docs/plans/counsel/`](docs/plans/counsel/). Pilot UI may still show legacy “seat / equal share” demo copy.

Each venture has a named steward who can stop it, under an eight-article constitution. The Protocol keeps the registry and ledger and runs shared back office.

This repository is the pilot: the protocol rules, a scripted operator agent with an optional Claude mode, and a web app on seeded data.

## Layout

| Path | What it is |
| --- | --- |
| `packages/schema` | Zod schemas, state machines, amendable parameters (`params.ts`), holdco agent role stubs. |
| `packages/protocol` | Constitution, classifier, N rule, economics (pilot equal shares; agreed SAFE+cash in docs), qualification, learning loop, batches, store, seed, tests. |
| `packages/protocol/agent` | Operator: `tick()`, scripted pilot, Claude adapter, `simulate` CLI. |
| `apps/venture` | Next.js app: home, about, invest, contribute, batches, venture pages, seats, inbox, steward, learning, ledger, protocol. |
| `apps/venture/supabase/migrations` | Postgres schema with RLS for a later move off the JSON store. Not applied. |
| `docs/` | `STATUS.md` (start here), brief, working model, plan notes, counsel packet. |
| `brand/` | Logo, seal, tokens. |

## Run it

Requires Node 22+ and pnpm 10.

```bash
pnpm install
pnpm seed          # writes data/store.json
pnpm dev           # http://localhost:43117
```

## How money works (agreed model)

1. **Accredited seed ≠ answer pay.** Seed is real capital in fill-or-kill escrow; on minimum → SAFE (post-money default, terms TBD); on miss → refund, no SAFE. No public seed-for-equity without attestation (**counsel TBD**; lean 506(c) if advertising).
2. **Accepted answer = equal cash** from the proof budget. Late accepted work still paid. Answerers do not buy equity by answering. No agent-weighted ownership units for answers.
3. **Waterfall (published):** gross − token costs − answer cash − ~5% platform vig → then equity/SAFE economics; operator also ~20% equity (upside alignment) (vig = rails, equity = upside).
4. **Keep:** fill-or-kill minimum, public ledger, mark vs Shoalyard credit, equal cash for similar accepted work.
5. **Steward** can kill the venture; governance of SAFE/equity holders is counsel TBD.

Legacy pilot screens may still say “seat / share per answer” until the rollout in the economics memo.

## Walk-through

1. Open Batch 002 and take a seat in Permit Pulse (fake checkout) — **pilot/legacy** seat UI.
2. Finish onboarding and link LinkedIn (mock). Steward `@MP` confirms verification.
3. Answer a request — demo units still appear on the ledger and Holdings.
4. As `@MP`, advance the agent; decisions appear on the public log.
5. Share a venture page: anyone can share; a referral earns only when the person fills a role and works.

## Checks

```bash
pnpm typecheck
pnpm test
pnpm lint
pnpm build
pnpm simulate -- --venture permit-pulse --ticks 5
```
