import Link from "next/link";
import { Check, Handshake, X } from "lucide-react";
import { MARK_ENDS_NOTE, type ChecklistItem, type PayoutPreview } from "@av/protocol";
import type { HandOffOffer, OfferStatus, Rfe, Venture } from "@av/schema";
import { CheckOfferForm, OfferForm, WithdrawOfferForm } from "@/components/handoff-forms";
import { Pill } from "@/components/badges";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDate, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

const OFFER_LABELS: Record<OfferStatus, string> = {
  submitted: "Waiting for the steward's check",
  voting: "Unit holders are voting",
  approved: "Approved",
  declined: "Not approved",
  withdrawn: "Withdrawn",
};

export function Checklist({ items }: { items: ChecklistItem[] }) {
  return (
    <ul className="space-y-2">
      {items.map((i) => (
        <li key={i.key} className="flex items-start gap-2 text-sm">
          <span className={cn("mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-full", i.met ? "bg-emerald-100 text-emerald-700" : "bg-zinc-100 text-zinc-500")}>
            {i.met ? <Check className="size-3" /> : <X className="size-3" />}
          </span>
          <span>
            <Link href={`/protocol#${i.param}`} className="font-medium text-zinc-900 underline-offset-2 hover:underline">
              {i.label}
            </Link>
            <span className="block text-zinc-500">{i.detail}</span>
          </span>
        </li>
      ))}
    </ul>
  );
}

export interface OfferView {
  offer: HandOffOffer;
  preview: PayoutPreview;
  vote?: Pick<Rfe, "id" | "status" | "resolution">;
  /** Why the hand-off is waiting, e.g. a conduct vote still open. */
  held?: string;
}

export function OfferCard({ view, viewer, isSteward }: { view: OfferView; viewer: string; isSteward: boolean }) {
  const { offer, preview, vote, held } = view;
  const open = offer.status === "submitted" || offer.status === "voting";
  return (
    <div className="space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-medium">
          @{offer.entrepreneur} · {formatUsd(offer.priceUsd)}
        </p>
        <Pill className={cn(offer.status === "approved" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : open ? "border-amber-200 bg-amber-50 text-amber-900" : "border-zinc-200 bg-zinc-50 text-zinc-600")}>
          {OFFER_LABELS[offer.status]}
        </Pill>
      </div>
      <p className="text-sm text-pretty text-zinc-700">{offer.summary}</p>
      <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
        <div>
          <dt className="text-xs text-zinc-500">Price</dt>
          <dd className="font-medium tabular-nums">{formatUsd(offer.priceUsd)}</dd>
        </div>
        <div>
          <dt className="text-xs text-zinc-500">Cash to contributors</dt>
          <dd className="font-medium tabular-nums">{formatUsd(offer.contributors.cashUsd)}</dd>
        </div>
        <div>
          <dt className="text-xs text-zinc-500">Per vested unit</dt>
          <dd className="font-medium tabular-nums">{formatUsd(preview.perUnitUsd, true)}</dd>
        </div>
        <div>
          <dt className="text-xs text-zinc-500">Profit share kept</dt>
          <dd className="font-medium tabular-nums">{offer.contributors.retainedSharePct}%</dd>
        </div>
      </dl>
      {offer.check && (
        <div className="space-y-1 rounded-lg bg-zinc-50 p-3 text-sm">
          <p className="font-medium">
            The steward&apos;s check, {formatDate(offer.check.at)}: {offer.check.passed ? "follows the rules" : "doesn't follow the rules"}
          </p>
          <ul className="space-y-0.5 text-zinc-600">
            {offer.check.items.map((i) => (
              <li key={i.label}>
                {i.ok ? "✓" : "✗"} {i.label}
                <span className="text-zinc-500">: {i.detail}</span>
              </li>
            ))}
          </ul>
          {offer.check.warnings.map((w) => (
            <p key={w} className="text-xs text-amber-800">
              {w}
            </p>
          ))}
        </div>
      )}
      {offer.outcome && <p className="text-sm text-zinc-600">{offer.outcome}</p>}
      {held && open && <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">Blocked: {held}</p>}
      <div className="flex flex-wrap items-center gap-3">
        {vote && (
          <Link href={`/rfe/${vote.id}`} className="text-sm font-medium underline underline-offset-2">
            {vote.status === "resolved" ? "See the vote" : "Vote on it"}
          </Link>
        )}
        {isSteward && offer.status === "submitted" && !held && <CheckOfferForm offerId={offer.id} />}
        {viewer === offer.entrepreneur && open && <WithdrawOfferForm offerId={offer.id} />}
      </div>
    </div>
  );
}

export function HandOffPanel({
  venture,
  ready,
  items,
  offers,
  viewer,
  isSteward,
  canOffer,
}: {
  venture: Pick<Venture, "slug" | "name">;
  ready: boolean;
  items: ChecklistItem[];
  offers: OfferView[];
  viewer: string;
  isSteward: boolean;
  canOffer: boolean;
}) {
  const metCount = items.filter((i) => i.met).length;
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Handshake className="size-5" /> {ready ? "Ready to hand off" : `Not ready to hand off: ${metCount} of ${items.length}`}
          </CardTitle>
          <CardDescription>
            Once it has proved a named buyer pays, an entrepreneur can adopt it with their own money. Only earned units are paid; seats never share in a hand-off.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Checklist items={items} />
        </CardContent>
      </Card>
      <div className="space-y-3">
        {offers.length === 0 && <p className="text-sm text-zinc-500">No offers yet.</p>}
        {offers.map((o) => (
          <OfferCard key={o.offer.id} view={o} viewer={viewer} isSteward={isSteward} />
        ))}
        {ready && canOffer && <OfferForm slug={venture.slug} name={venture.name} />}
        {ready && !canOffer && !isSteward && <p className="text-xs text-zinc-500">Verified members can offer to adopt it. A pseudonymous handle is fine.</p>}
      </div>
    </div>
  );
}

export function HandedOffBanner({ venture, payouts }: { venture: Pick<Venture, "name" | "handOff">; payouts: number }) {
  const h = venture.handOff!;
  return (
    <Card className="border-amber-200 bg-amber-50/60">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-amber-950">
          <Handshake className="size-5" /> Handed off to @{h.entrepreneur}
        </CardTitle>
        <CardDescription className="text-amber-950/80">
          Unit holders approved it on {formatDate(h.at)}. @{h.entrepreneur} paid {formatUsd(h.priceUsd)} and runs it with their own money.{" "}
          {formatUsd(h.payoutUsd)} went to {payouts} people with earned units, by vested units
          {h.retainedSharePct > 0 ? `, and they keep ${h.retainedSharePct}% of its profit` : ""}. Seat holders without units got nothing.
        </CardDescription>
      </CardHeader>
      <CardContent className="text-sm text-amber-950/80">{MARK_ENDS_NOTE}</CardContent>
    </Card>
  );
}
