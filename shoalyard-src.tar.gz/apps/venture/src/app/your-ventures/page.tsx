import type { Metadata } from "next";
import Link from "next/link";
import { Users } from "lucide-react";
import { yourVentures } from "@av/protocol";
import { AccountLabel } from "@/components/account-label";
import { Pill, StatusBadge } from "@/components/badges";
import { EmptyState } from "@/components/empty-state";
import { buttonVariants } from "@/components/ui/button";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { formatNumber } from "@/lib/format";

export const metadata: Metadata = { title: "Your ventures" };

export default async function YourVenturesPage() {
  const { store, params, viewer, member } = await getData();
  const rows = member ? yourVentures(store, viewer, params) : [];

  return (
    <div className="space-y-8">
      <div>
        <AccountLabel />
        <h1 className="text-2xl font-semibold tracking-tight">Your ventures</h1>
        <p className="text-sm text-zinc-500">
          The ventures @{viewer} is part of: where you hold a <TermServer id="seat">seat</TermServer>, fill a place on the team, or have earned{" "}
          <TermServer id="unit">units</TermServer>. See <Link href="/holdings" className="underline underline-offset-2">your units</Link> for the
          numbers.
        </p>
      </div>

      {rows.length === 0 ? (
        <EmptyState icon={Users} title="Not part of a venture yet">
          Pick a venture worth backing, take a seat and bring your judgement where it&apos;s needed.
          <div className="mt-3">
            <Link href="/" className={buttonVariants({ size: "sm" })}>
              Find a venture
            </Link>
          </div>
        </EmptyState>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2">
          {rows.map((r) => (
            <li key={r.venture.id} className="space-y-2 rounded-xl border border-zinc-200 bg-white p-4">
              <div className="flex flex-wrap items-center gap-2">
                <Link href={`/v/${r.venture.slug}`} className="font-medium hover:underline">
                  {r.venture.name}
                </Link>
                <StatusBadge status={r.venture.status} />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {r.seat && <Pill>Seat</Pill>}
                {r.venture.isProtocol && !r.seat && <Pill>Member</Pill>}
                {r.roles.map((role) => (
                  <Pill key={role} className="border-sky-200 bg-sky-50 text-sky-800">
                    {role}
                  </Pill>
                ))}
              </div>
              <p className="text-sm text-zinc-500">
                {formatNumber(r.units)} units · {r.openRequests} open request{r.openRequests === 1 ? "" : "s"}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
