import type { ProofPlan, ProofTask } from "@av/schema";

const t = (key: string, runBy: ProofTask["runBy"], task: string, extra: Partial<ProofTask> = {}): ProofTask => ({ key, runBy, task, needs: [], ...extra });

/**
 * Each venture's and idea's proof plan, as the agent wrote it. Some are written the way a founder would first
 * think of them (Bid Desk hires a coordinator; Cert Chase quotes insurance); the operability check sends those
 * back and the agent reshapes them when the venture is spawned.
 */
export const PROOF_PLANS: Record<string, ProofPlan> = {
  dockside: {
    tasks: [
      t("draft", "agent", "Read each rate confirmation and the ELD timestamps, and draft the dispute letter."),
      t("clauses", "member request", "Brokerage operators mark which clauses shippers actually pay on.", { roleKey: "icp-operator" }),
      t("send", "agent", "Send the letter for the broker to sign, and track the reply until it's paid or refused."),
    ],
    longTermOperator: "agents",
    operatorReason: "Drafting, sending and tracking are software; members keep the clause list current through requests.",
    entrepreneurBuilds: "Nothing new: a buyer would adopt the clause list, the broker accounts and the letter engine as they run today.",
    reshaped: [],
  },
  chairside: {
    tasks: [
      t("match", "agent", "Take a practice's same-morning request by text and offer the shift to hygienists nearby."),
      t("cover", "contractor", "A hygienist covers the shift, paid per shift, under their own state licence.", { needs: ["in-person"], place: "the practice" }),
      t("confirm", "member request", "Practice managers confirm the shift was covered and the rate was right.", { roleKey: "icp-operator" }),
    ],
    longTermOperator: "hand-off expected",
    operatorReason: "Cover is a person in the chair. The agent can match shifts, but a staffing operator would run the bench.",
    entrepreneurBuilds: "A bench of hygienists who take same-morning shifts in one metro, and a staffing agency licence where the state requires one.",
    reshaped: [],
  },
  "permit-pulse": {
    tasks: [
      t("pull", "agent", "Pull new commercial permits from county portals every Monday and remove duplicates."),
      t("which", "member request", "Contractor sales leads say which permit types turn into bids.", { roleKey: "icp-operator" }),
      t("send", "agent", "Send the Monday list and count which permits get a call."),
    ],
    longTermOperator: "agents",
    operatorReason: "Scraping and the weekly list are software; members tune what counts as a lead.",
    entrepreneurBuilds: "Nothing beyond the scrapers and the list. A data company could adopt it as one more feed.",
    reshaped: [],
  },
  "lien-clock": {
    tasks: [
      t("dates", "agent", "Read the sub's invoices and work out each project's notice and filing dates under Texas and Arizona rules."),
      t("review", "member request", "Construction lien counsel among the members checks the date rules before launch.", { roleKey: "legal" }),
      t("letters", "agent", "Draft each notice letter for a person at the sub to sign and send."),
    ],
    longTermOperator: "agents",
    operatorReason: "The dates are computable and the letters are drafts; a person at the sub always signs.",
    entrepreneurBuilds: "A rules table for each new state, reviewed by counsel whenever a state changes its notice windows.",
    reshaped: [],
  },
  "wet-ink": {
    tasks: [
      t("book", "agent", "Take a signing or filing request by API and book a member near the office."),
      t("sign", "member request", "A notary among the members does the signing or filing in person and returns a scan.", { roleKey: "domain-expert", needs: ["in-person"], place: "the county office or the signer's address" }),
      t("custody", "agent", "Log the chain of custody and return it with the scan."),
    ],
    longTermOperator: "hand-off expected",
    operatorReason: "Every request is a person somewhere in particular; past a few metros it needs a notary network someone runs.",
    entrepreneurBuilds: "A network of commissioned notaries in each metro it serves, and the scheduling to keep them busy.",
    reshaped: [],
  },
  "bid-desk": {
    tasks: [
      t("find", "agent", "Find public tenders a small contractor can win, and read the package requirements."),
      t("assemble", "member request", "Hire a bid coordinator to assemble the first ten packages by hand.", {
        roleKey: "domain-expert",
        needs: ["employee"],
        what: "people who've won tenders assemble the first ten packages by hand, paid per package",
      }),
      t("record", "agent", "Write down every step of each package, and automate the repeatable parts after ten."),
      t("sign", "member request", "Contractor owners review and sign each package before it goes in.", { roleKey: "icp-operator" }),
    ],
    longTermOperator: "agents",
    operatorReason: "After ten packages the repeatable steps are software; members answer the parts that need judgement.",
    entrepreneurBuilds: "Nothing if automation works. If it doesn't, a bid-writing service with its own staff.",
    reshaped: [],
  },
  "site-record": {
    tasks: [
      t("timeline", "agent", "Turn each sub's photos and check-ins into a dated, tamper-evident timeline per job."),
      t("accept", "member request", "GC project managers say what their accounts team accepts as proof of work done.", { roleKey: "domain-expert" }),
      t("dispute", "member request", "Subcontractor owners use a timeline in a real payment dispute and report what happened.", { roleKey: "icp-operator" }),
    ],
    longTermOperator: "agents",
    operatorReason: "Capture and timelines are software; the sub takes the photos as they work.",
    entrepreneurBuilds: "Nothing new: a construction-software company could adopt it as a feature.",
    reshaped: [],
  },
  "lumper-line": {
    tasks: [
      t("collect", "member request", "Brokers and carriers send lumper receipts by warehouse.", { roleKey: "icp-operator" }),
      t("verify", "agent", "Check each receipt against the load and the warehouse, and flag outliers."),
      t("price", "member request", "Warehouse or freight-pricing experts check the outliers.", { roleKey: "domain-expert" }),
      t("sell", "agent", "Sell brokers a lookup they use before they quote."),
    ],
    longTermOperator: "agents",
    operatorReason: "The receipts come from members; checking and the lookup are software.",
    entrepreneurBuilds: "Nothing new while members keep sending receipts; a load board could adopt the data.",
    reshaped: [],
  },
  "cert-chase": {
    tasks: [
      t("request", "agent", "Request each sub's certificate of insurance and read the limits and expiry dates."),
      t("quote", "agent", "Tell the GC which coverage a sub is missing and quote a policy to close the gap.", {
        licence: "insurance producer licence",
        what: "quotes that close a sub's coverage gap",
      }),
      t("chase", "agent", "Chase expired certificates and tell a person only when one is wrong."),
      t("check", "member request", "GC office managers say which limits their contracts require.", { roleKey: "icp-operator" }),
    ],
    longTermOperator: "agents",
    operatorReason: "Collecting and reading certificates is software; the GC still decides who works on site.",
    entrepreneurBuilds: "Nothing for collecting and chasing certificates.",
    reshaped: [],
  },
  "punch-list": {
    tasks: [
      t("app", "agent", "Build the punch list alone: items, photos and sign-off for a five-person crew."),
      t("use", "member request", "GC owners run a real closeout on it and say what's missing.", { roleKey: "icp-operator" }),
      t("price", "agent", "Test the price with the first ten crews."),
    ],
    longTermOperator: "agents",
    operatorReason: "It's a small piece of software; support questions go to the agent.",
    entrepreneurBuilds: "Nothing new: a construction suite could adopt it as its cheapest plan.",
    reshaped: [],
  },
  "relay-line": {
    tasks: [
      t("route", "agent", "Give each venture a number and route calls to the member on shift."),
      t("answer", "member request", "Members on shift answer, say up front the business is agent-run, and log the call.", { roleKey: "icp-operator" }),
      t("log", "agent", "Turn each call log into the venture's next action."),
    ],
    longTermOperator: "hand-off expected",
    operatorReason: "Answering is a person on a shift. Past a few ventures it needs someone to run the rota.",
    entrepreneurBuilds: "A rota of answerers with cover for nights and weekends, and the training that keeps calls honest.",
    reshaped: [],
  },
};

export function proofPlanFor(slug: string): ProofPlan | undefined {
  const p = PROOF_PLANS[slug];
  return p && structuredClone(p);
}
