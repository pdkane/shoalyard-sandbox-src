# Counsel packet (placeholders)

**NOT LEGAL ADVICE.** **PLACEHOLDER.** **REPLACE WITH COUNSEL.**

Nothing in this folder is an executed instrument, an offering document, or advice. Shoalyard has not closed a seed, issued a SAFE, or chosen an exemption posture. Every file here is a working packet for counsel to replace, edit, or discard.

Official public Y Combinator SAFE forms are mirrored under [`yc-safe-placeholders/`](yc-safe-placeholders/) **only as reference placeholders**. YC owns those forms; use the live downloads at [ycombinator.com/documents](https://www.ycombinator.com/documents) / [ycombinator.com/safe](https://www.ycombinator.com/safe) and have counsel adapt them. Shoalyard riders (wind-down, hand-off, unused capital) are **not** in the stock YC forms.

## Packet index

| Path | Purpose |
| --- | --- |
| [`yc-safe-placeholders/`](yc-safe-placeholders/) | Mirrored YC post-money SAFE forms + user guide (placeholder copies) |
| [`term-sheet-one-pager.md`](term-sheet-one-pager.md) | One-pager term sheet from `economics-safe-seed.md` |
| [`wind-down-handoff-riders-checklist.md`](wind-down-handoff-riders-checklist.md) | Rider checklist for counsel |
| [`506c-vs-506b-decision-note.md`](506c-vs-506b-decision-note.md) | Open decision: 506(c) vs 506(b) |

Source economics: [`../economics-safe-seed.md`](../economics-safe-seed.md). Locked messaging: [`../messaging.md`](../messaging.md).

## Explicit non-claims

- These are **not** executed docs.
- These are **not** ready for public seed CTAs.
- Cap, discount, entity, escrow, and exemption choices remain **counsel TBD**.
