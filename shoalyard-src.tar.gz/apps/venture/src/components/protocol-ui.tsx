import Link from "next/link";
import { BadgeCheck, CircleDashed, CircleHelp, TriangleAlert } from "lucide-react";
import { classificationOf, type PeopleDecision, type ReadinessItem, type RosterRow, type AttributeStatus } from "@av/protocol";
import {
  CLASSIFICATION_AXES,
  customerModel,
  LESSON_TOPIC_LABELS,
  MEMO_LABELS,
  RFE_TYPE_LABELS,
  TAG_AXIS_LABELS,
  type Lesson,
  type Memo,
  type Tag,
  type VerifySource,
} from "@av/schema";
import { Pill } from "@/components/badges";
import { Explain } from "@/components/explain";
import { MembersOnlyLessons } from "@/components/lessons-gate";
import { ClaimRoleDialog, WithdrawRoleForm } from "@/components/qa-forms";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

/** Pilot/legacy seat path — agreed model is accredited SAFE seed + cash answers. Keep the core sentence for copy tests. */
export const SEAT_DISCLAIMER = "A seat gets you this venture's requests. It is not a share and pays nothing back.";
export const REFUND_GUARANTEE = "We hold your money, unspent, until enough seats sell. If they don't sell by the deadline, you get it all back.";

export function SeatDisclaimer({ className }: { className?: string }) {
  return (
    <p className={cn("text-xs text-metal", className)}>
      <span className="font-medium text-timber">Pilot/legacy. </span>
      {SEAT_DISCLAIMER} Agreed model: accredited SAFE seed and cash for answers — counsel TBD on live seed CTAs.
    </p>
  );
}

export function MemoCard({ memo }: { memo: Memo }) {
  const keys = Object.keys(MEMO_LABELS) as (keyof Memo)[];
  return (
    <Card>
      <CardHeader>
        <CardTitle>Memo</CardTitle>
        <CardDescription>The agent&apos;s case for the venture, in the same seven parts for every idea.</CardDescription>
      </CardHeader>
      <CardContent>
        <dl className="grid gap-4 sm:grid-cols-2">
          {keys.map((k) => (
            <div key={k} className={cn("rounded-lg bg-zinc-50 p-3", k === "killMetric" && "bg-rose-50/60 sm:col-span-2")}>
              <dt className="text-xs font-medium tracking-wide text-zinc-500 uppercase">{MEMO_LABELS[k]}</dt>
              <dd className="mt-1 text-sm text-pretty text-zinc-800">{memo[k]}</dd>
            </div>
          ))}
        </dl>
      </CardContent>
    </Card>
  );
}

/** The standard classification, read from tags: solid once the steward confirms, dashed while proposed. */
export function ClassificationCard({ tags, hide = [] }: { tags: Tag[]; hide?: Tag["axis"][] }) {
  const c = classificationOf({ tags });
  const model = customerModel(c);
  const rows = CLASSIFICATION_AXES.filter((a) => !hide.includes(a)).map((axis) => ({ axis, tag: tags.find((t) => t.axis === axis) }));
  const pending = rows.some((r) => r.tag?.status === "proposed");
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>Classification</CardTitle>
        <CardDescription>
          {pending ? "Proposed by the agent; the steward confirms or corrects each value." : "Proposed by the agent and confirmed by the steward."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-2.5 text-sm">
          {rows.map(({ axis, tag }) => (
            <div key={axis} className={cn(axis === "subVertical" && "col-span-2")}>
              <dt className="text-xs text-zinc-500">{TAG_AXIS_LABELS[axis]}</dt>
              <dd className={cn("text-zinc-900", tag?.status === "proposed" && "text-zinc-600 italic")}>
                {tag ? (
                  <Link href={`/learning?axis=${axis}#slices`} className="hover:underline">
                    {tag.value}
                  </Link>
                ) : (
                  "—"
                )}
                {axis === "customer" && model && <span className="ml-1.5 text-xs text-zinc-500 not-italic">{model}</span>}
              </dd>
            </div>
          ))}
        </dl>
      </CardContent>
    </Card>
  );
}

const TONE: Record<ReadinessItem["tone"], { icon: typeof BadgeCheck; cls: string }> = {
  good: { icon: BadgeCheck, cls: "text-emerald-600" },
  weak: { icon: TriangleAlert, cls: "text-amber-600" },
  unknown: { icon: CircleHelp, cls: "text-zinc-400" },
};

export function ReadinessPanel({ items }: { items: ReadinessItem[] }) {
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>Before you take a seat</CardTitle>
        <CardDescription>Four checks the agent runs on every idea. A warning doesn&apos;t block anything. It&apos;s for you to weigh.</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {items.map((i) => {
            const T = TONE[i.tone];
            return (
              <li key={i.key} className="flex gap-2.5">
                <T.icon className={cn("mt-0.5 size-4 shrink-0", T.cls)} />
                <div className="min-w-0 text-sm">
                  <p>
                    <span className="font-medium text-zinc-900">{i.label}:</span> <span className="text-zinc-700">{i.value}</span>
                  </p>
                  <p className="text-xs text-zinc-500">{i.detail}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}

export function RosterPanel({ rows }: { rows: RosterRow[] }) {
  const filled = rows.reduce((s, r) => s + r.filled.length, 0);
  const total = rows.reduce((s, r) => s + r.role.count, 0);
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>The people this venture needs</CardTitle>
        <CardDescription>
          {filled} of {total} spots filled by verified members. You don&apos;t need a seat to claim a role. For open spots, the agent writes a recruiting post and the steward posts it.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2.5">
          {rows.map((r) => (
            <li key={r.role.key} className="text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium text-zinc-800">{r.role.label}</span>
                <span className="text-xs tabular-nums text-zinc-500">
                  {r.filled.length}/{r.role.count}
                </span>
              </div>
              <div className="mt-1 flex flex-wrap gap-1">
                {r.filled.map((h) => (
                  <Link key={h} href={`/m/${h}`} className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs text-emerald-800 hover:underline">
                    @{h}
                  </Link>
                ))}
                {r.pending.map((h) => (
                  <Link key={h} href={`/m/${h}`} className="rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs text-amber-800 hover:underline">
                    @{h} · checking
                  </Link>
                ))}
                {Array.from({ length: Math.max(0, r.open - r.pending.length) }, (_, i) => (
                  <span key={i} className="inline-flex items-center gap-1 rounded-full border border-dashed border-zinc-300 px-2 py-0.5 text-xs text-zinc-500">
                    <CircleDashed className="size-3" /> open
                  </span>
                ))}
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

export interface RosterClaimContext {
  open: boolean;
  visitor: boolean;
  pendingViewer: boolean;
  myRoleKey?: string;
}

function rowStatus(r: RosterRow): { word: string; className: string } {
  if (r.clusterShort) return { word: "Needs more kinds of member", className: "border-amber-200 bg-amber-50 text-amber-900" };
  if (r.open <= 0) return { word: "Filled", className: "border-emerald-200 bg-emerald-50 text-emerald-800" };
  if (r.filled.length) return { word: "Partly filled", className: "border-sky-200 bg-sky-50 text-sky-800" };
  return { word: "Open", className: "border-zinc-200 bg-white text-zinc-600" };
}

/** Every role the plan calls for, who holds it, and the arithmetic behind its count. */
export function RosterTable({ rows, slug, gate, claim }: { rows: RosterRow[]; slug: string; gate?: React.ReactNode; claim?: RosterClaimContext }) {
  const filled = rows.reduce((s, r) => s + r.filled.length, 0);
  const total = rows.reduce((s, r) => s + r.role.count, 0);
  const critical = rows.filter((r) => r.role.critical);
  const criticalDone = critical.filter((r) => r.filled.length > 0).length;
  return (
    <div className="space-y-3">
      <div className="space-y-1">
        <p className="text-sm font-medium text-zinc-900">
          {filled} of {total} roles filled
          {critical.length > 0 && (
            <span className="font-normal text-zinc-600">
              {" "}
              · critical: {criticalDone} of {critical.length} claimed by a verified member
            </span>
          )}
        </p>
        {gate && <div className="text-sm text-zinc-600">{gate}</div>}
        <p className="text-xs text-zinc-500">You don&apos;t need a seat to claim a role. A claim counts once you&apos;re verified and your profile fits.</p>
      </div>
      <ul className="divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white">
        {rows.map((r) => {
          const st = rowStatus(r);
          const mine = claim?.myRoleKey === r.role.key;
          return (
            <li key={r.role.key} id={`role-${r.role.key}`} className="scroll-mt-24 space-y-2 p-3 sm:p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="flex flex-wrap items-center gap-1.5 text-sm font-medium text-zinc-900">
                    {r.role.label}
                    {r.role.critical && <span className="rounded-full border border-violet-200 bg-violet-50 px-1.5 py-0.5 text-[10px] font-medium text-violet-800">Critical</span>}
                  </p>
                  {r.role.qualifications.length > 0 && <p className="text-xs text-pretty text-zinc-500">{r.role.qualifications.join(" · ")}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs tabular-nums text-zinc-500">
                    {r.filled.length}/{r.role.count}
                  </span>
                  <span className={cn("rounded-full border px-2 py-0.5 text-[11px] font-medium", st.className)}>{st.word}</span>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-1">
                {r.filled.map((h) => (
                  <Link key={h} href={`/m/${h}`} className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs text-emerald-800 hover:underline">
                    @{h}
                  </Link>
                ))}
                {r.pending.map((h) => (
                  <Link key={h} href={`/m/${h}`} className="rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs text-amber-800 hover:underline">
                    @{h} · checking
                  </Link>
                ))}
                {Array.from({ length: Math.max(0, r.open - r.pending.length) }, (_, i) => (
                  <span key={i} className="inline-flex items-center gap-1 rounded-full border border-dashed border-zinc-300 px-2 py-0.5 text-xs text-zinc-500">
                    <CircleDashed className="size-3" /> open
                  </span>
                ))}
                {claim?.open && !claim.myRoleKey && r.open > 0 && (
                  <ClaimRoleDialog
                    slug={slug}
                    roleKey={r.role.key}
                    label={r.role.label}
                    qualifications={r.role.qualifications}
                    visitor={claim.visitor}
                    pendingViewer={claim.pendingViewer}
                  />
                )}
                {mine && (
                  <span className="inline-flex items-center gap-1 text-xs text-zinc-600">
                    Your claim <WithdrawRoleForm slug={slug} />
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-500">
                {r.role.serves.length > 0 && (
                  <span className="flex flex-wrap items-center gap-1">
                    Answers:
                    {r.role.serves.map((t) => (
                      <Link key={t} href={`/v/${slug}#requests`} className="rounded border border-zinc-200 px-1.5 py-px text-[11px] text-zinc-700 hover:border-zinc-400">
                        {RFE_TYPE_LABELS[t].label}
                      </Link>
                    ))}
                  </span>
                )}
                <details className="group">
                  <summary className="cursor-pointer list-none underline underline-offset-2 [&::-webkit-details-marker]:hidden">Why this many</summary>
                  <p className="mt-1 text-pretty text-zinc-600">{r.role.derivation}</p>
                </details>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

const WHO_STYLES: Record<PeopleDecision["who"], string> = {
  members: "border-emerald-200 bg-emerald-50 text-emerald-800",
  "unit holders": "border-fuchsia-200 bg-fuchsia-50 text-fuchsia-800",
  steward: "border-violet-200 bg-violet-50 text-violet-800",
};

export function PeopleDecisionsPanel({ rows }: { rows: PeopleDecision[] }) {
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>Who decided what, and how it went</CardTitle>
        <CardDescription>The calls people made for this venture. The agent carried them out.</CardDescription>
      </CardHeader>
      <CardContent>
        {rows.length === 0 ? (
          <p className="text-sm text-zinc-500">No one has made a call for this venture yet. The first ones come as requests.</p>
        ) : (
          <ul className="space-y-3">
            {rows.map((r) => (
              <li key={r.href + r.at} className="text-sm">
                <div className="flex flex-wrap items-center gap-1.5">
                  <Pill className={WHO_STYLES[r.who]}>{r.whoLabel}</Pill>
                  <Link href={r.href} className="font-medium text-zinc-900 hover:underline">
                    {r.title}
                  </Link>
                </div>
                <p className="mt-1 text-zinc-700">
                  <span className="text-zinc-500">Decided: </span>
                  {r.decided}
                </p>
                {r.howItWent && (
                  <p className="text-zinc-600">
                    <span className="text-zinc-500">How it went: </span>
                    {r.howItWent}
                  </p>
                )}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

export function LessonLine({ lesson }: { lesson: Lesson }) {
  return (
    <span>
      <Link href={`/learning#${lesson.id}`} className="font-mono text-xs font-medium text-sky-800 hover:underline">
        {lesson.id}
      </Link>{" "}
      <span className="text-zinc-800">{lesson.headline}</span>
    </span>
  );
}

export function InheritedLessons({
  lessons,
  cited,
  contradictions,
  visible,
  use,
  basePath,
}: {
  lessons: Lesson[];
  cited: string[];
  contradictions: { lessonId: string; reason: string; lesson?: Lesson }[];
  /** Lessons are for members (Article 3). */
  visible: boolean;
  /** For seat holders and the team: the decisions here that followed each lesson. */
  use?: Map<string, { id: string; title: string }[]>;
  basePath: string;
}) {
  if (!visible) {
    const topics = [...new Set(lessons.map((l) => LESSON_TOPIC_LABELS[l.topic]))];
    return (
      <Card size="sm">
        <CardHeader>
          <CardTitle>Lessons it starts with</CardTitle>
          <CardDescription>What earlier, similar ventures learned. The agent must follow these or explain why not.</CardDescription>
        </CardHeader>
        <CardContent>
          {lessons.length === 0 && contradictions.length === 0 ? (
            <p className="text-sm text-zinc-500">No kept lesson matches this kind of venture yet.</p>
          ) : (
            <MembersOnlyLessons
              teaser={{ count: lessons.length, ventures: 0, topics }}
              title={`Starts with ${lessons.length} lesson${lessons.length === 1 ? "" : "s"} from earlier ventures${contradictions.length ? `, and goes against ${contradictions.length}` : ""}`}
            />
          )}
        </CardContent>
      </Card>
    );
  }
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>Lessons it starts with</CardTitle>
        <CardDescription>
          What earlier, similar ventures learned. The agent must follow these or explain why not.
          {use ? " As part of this venture, you also see where each one was used." : ""}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {lessons.length === 0 && contradictions.length === 0 ? (
          <p className="text-sm text-zinc-500">No kept lesson matches this kind of venture yet.</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {lessons.map((l) => {
              const usedIn = use?.get(l.id) ?? [];
              return (
                <li key={l.id} className="flex flex-col gap-0.5">
                  <LessonLine lesson={l} />
                  <span className="text-zinc-600">{l.whatWeDoDifferently}</span>
                  <span className="text-xs text-zinc-500">
                    {LESSON_TOPIC_LABELS[l.topic]} · {l.howSure.level}
                    {cited.includes(l.id) ? " · used when it was proposed" : ""}
                  </span>
                  {use && (
                    <span className="text-xs text-zinc-600">
                      {usedIn.length === 0 ? (
                        "Not applied to a decision here yet."
                      ) : (
                        <>
                          Applied here:{" "}
                          {usedIn.map((d, k) => (
                            <span key={d.id}>
                              {k > 0 && "; "}
                              <Link href={`${basePath}/ledger#${d.id}`} className="underline underline-offset-2 hover:text-zinc-900">
                                {d.title}
                              </Link>
                            </span>
                          ))}
                        </>
                      )}
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        )}
        {contradictions.length > 0 && (
          <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-3 text-sm">
            <p className="font-medium text-amber-900">Goes against</p>
            <ul className="mt-1 space-y-1.5">
              {contradictions.map((c) => (
                <li key={c.lessonId} className="text-amber-900/90">
                  <Link href={`/learning#${c.lessonId}`} className="font-mono text-xs font-medium hover:underline">
                    {c.lessonId}
                  </Link>{" "}
                  {c.lesson ? `“${c.lesson.headline}” ` : ""}
                  <span className="text-amber-900/70">The agent&apos;s reason this case is different: {c.reason}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function TagList({ tags, className }: { tags: Tag[]; className?: string }) {
  if (!tags.length) return null;
  return (
    <div className={cn("flex flex-wrap gap-1.5", className)}>
      {tags.map((t) => (
        <Explain
          key={`${t.axis}:${t.value}`}
          title={`${TAG_AXIS_LABELS[t.axis]}: ${t.value}`}
          text={
            t.status === "confirmed"
              ? "A standard category, confirmed by the steward. Results and lessons are compared by these."
              : "A category the agent proposed. It's dashed until the steward confirms it."
          }
          href={`/learning?axis=${t.axis}#slices`}
          hrefLabel="How ventures like this do →"
        >
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs",
              t.status === "confirmed" ? "border-zinc-200 bg-white text-zinc-700" : "border-dashed border-zinc-300 bg-zinc-50 text-zinc-500",
            )}
          >
            <span className="text-zinc-400">{TAG_AXIS_LABELS[t.axis]}</span> {t.value}
          </span>
        </Explain>
      ))}
    </div>
  );
}

const BADGE_STYLES: Record<VerifySource, string> = {
  linkedin: "border-sky-200 bg-sky-50 text-sky-800",
  x: "border-zinc-300 bg-zinc-900 text-white",
  steward: "border-violet-200 bg-violet-50 text-violet-800",
};

export function MemberBadges({
  badges,
  labels,
  share,
  qualification,
  compact,
}: {
  badges: VerifySource[];
  labels: Record<VerifySource, string>;
  share: number;
  qualification: "pending" | "qualified" | "declined";
  compact?: boolean;
}) {
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-1.5">
        <Pill
          className={cn(
            qualification === "qualified" && "border-emerald-200 bg-emerald-50 text-emerald-800",
            qualification === "pending" && "border-amber-200 bg-amber-50 text-amber-800",
            qualification === "declined" && "border-zinc-200 bg-zinc-100 text-zinc-500",
          )}
        >
          {qualification === "qualified" ? "Verified" : qualification === "pending" ? "Verification pending" : "Declined"}
        </Pill>
        {badges.map((b) => (
          <span key={b} className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium", BADGE_STYLES[b])}>
            <BadgeCheck className="size-3" /> {labels[b]}
          </span>
        ))}
      </div>
      <VerifiedShareBar share={share} compact={compact} />
    </div>
  );
}

export function VerifiedShareBar({ share, compact }: { share: number; compact?: boolean }) {
  const pct = Math.round(share * 100);
  return (
    <div className={cn("space-y-1", compact ? "w-40" : "max-w-xs")}>
      <div className="h-1.5 overflow-hidden rounded-full bg-zinc-100" role="meter" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Profile verified">
        <div className="h-full rounded-full bg-emerald-500" style={{ width: `${pct}%` }} />
      </div>
      <p className="text-xs text-zinc-500">{pct}% of profile verified</p>
    </div>
  );
}

export function AttributeTable({ rows, labels, sourceLabels }: { rows: AttributeStatus[]; labels: Record<string, string>; sourceLabels: Record<VerifySource, string> }) {
  return (
    <ul className="grid gap-1.5 text-sm sm:grid-cols-2">
      {rows.map((r) => (
        <li key={r.attribute} className="flex items-center justify-between gap-2 rounded-md border border-zinc-200 bg-white px-3 py-1.5">
          <span className="text-zinc-700">{labels[r.attribute]}</span>
          {r.status === "verified" ? (
            <span className="inline-flex items-center gap-1 text-xs text-emerald-700">
              <BadgeCheck className="size-3.5" /> {r.sources.map((s) => sourceLabels[s]).join(", ")}
            </span>
          ) : (
            <span className="text-xs text-zinc-400">Self-reported</span>
          )}
        </li>
      ))}
    </ul>
  );
}
