import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams } from "@av/schema";
import { classify } from "../src/classifier";

const params = defaultParams();

test("spend above the gate is gated", () => {
  const c = classify({ spendUsd: params.GATE_SPEND_USD + 1 }, 0.99, params);
  assert.equal(c.bin, "gated");
  assert.match(c.reasons[0], /needs sign-off/);
});

test("spend at the gate is not gated", () => {
  assert.equal(classify({ spendUsd: params.GATE_SPEND_USD }, 0.99, params).bin, "auto");
});

test("contracts, pricing, new domains and public posts are gated, with every reason listed", () => {
  const c = classify({ contract: true, pricingChange: true, newOutboundDomain: true, publicPost: true }, 0.99, params);
  assert.equal(c.bin, "gated");
  assert.equal(c.reasons.length, 4);
});

test("a gate switched off by amendment no longer gates", () => {
  assert.equal(classify({ publicPost: true }, 0.9, { ...params, GATE_PUBLIC_POSTS: false }).bin, "auto");
});

test("low confidence without a gate is advisory", () => {
  const c = classify({}, params.ADVISORY_CONFIDENCE - 0.01, params);
  assert.equal(c.bin, "advisory");
  assert.match(c.reasons[0], /below/);
});

test("confident and ungated is auto", () => {
  assert.equal(classify({}, params.ADVISORY_CONFIDENCE, params).bin, "auto");
});

test("gates win over low confidence", () => {
  assert.equal(classify({ pricingChange: true }, 0.1, params).bin, "gated");
});
