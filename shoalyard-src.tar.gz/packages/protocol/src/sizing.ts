import type { BudgetLine, ParamValues, RequestPlanItem, RfeType, RosterRole, RosterRoleKey, SeatPlan, SeatPrice } from "@av/schema";
import { nBounds, seatsNeeded } from "./n-engine";

/** Ceiling that ignores float noise, so 4 ÷ 0.2 is 20, not 21. */
const ceil = (x: number) => Math.ceil(x - 1e-9);

type SizingParams = Pick<
  ParamValues,
  | "SEAT_PRICE_USD"
  | "SEAT_PRICE_MIN_USD"
  | "SEAT_PRICE_MAX_USD"
  | "SEAT_BUFFER_PCT"
  | "SEAT_MAX_MULTIPLE"
  | "SEAT_FLOOR"
  | "RESPONSE_RATE"
  | "CRITICAL_ROLES_AT_RAISE"
  | "N_BASELINE"
  | "STAKES_MULTIPLIER"
  | "AGREEMENT_STOP"
  | "DIVERGENCE_EXTEND"
  | "EXTEND_BY"
>;

/** The seat cap ventures pitched before per-venture pricing were sold under; they keep it (Article 6). */
export const LEGACY_SEAT_CAP = 150;

/** What a venture charges for a seat: its own price, or the one price it was pitched under. */
export function seatPriceOf(venture: { seatPriceUsd?: number }, params: Pick<ParamValues, "SEAT_PRICE_USD">): number {
  return venture.seatPriceUsd ?? params.SEAT_PRICE_USD;
}

export interface SizingInput {
  budget: BudgetLine[];
  requestPlan: RequestPlanItem[];
  roster: Pick<RosterRole, "key" | "count">[];
  /** The proposed price; code keeps it inside the band. Without one, the lowest price. */
  priceUsd?: number;
  price?: Pick<SeatPrice, "proposedBy" | "claims" | "decisionId">;
}

/** Planned requests any holder can answer, and how many seats it takes for enough of them to answer. */
export function coverageSeats(requestPlan: RequestPlanItem[], params: SizingParams): { seats: number; binding?: SeatPlan["coverage"] } {
  const rates = params.RESPONSE_RATE as Partial<Record<RfeType, number>>;
  let best: { seats: number; binding?: SeatPlan["coverage"] } = { seats: 0 };
  for (const item of requestPlan) {
    const rate = rates[item.type];
    if (item.audience !== "any-holder" || !rate) continue;
    const { target } = nBounds({ type: item.type, stakes: item.stakes }, params);
    const seats = ceil(target / rate);
    if (seats > best.seats) best = { seats, binding: { requestKey: item.key, title: item.title, type: item.type, stakes: item.stakes, target, rate } };
  }
  return best;
}

/** Itemized lines plus contingency at the seat buffer. The same at every seat price. */
export function proofBudget(budget: Pick<BudgetLine, "usd" | "stretch" | "category">[], bufferPct: number) {
  const itemizedUsd = budget.filter((b) => !b.stretch && b.category !== "contingency").reduce((s, b) => s + b.usd, 0);
  const contingencyUsd = ceil((itemizedUsd * bufferPct) / 100);
  return { itemizedUsd, contingencyUsd, totalUsd: itemizedUsd + contingencyUsd };
}

export interface PriceBand {
  proofUsd: number;
  rosterSeats: number;
  coverageSeats: number;
  /** The fewest holders the venture can run on: everyone on its roster, or enough for its requests to get answers. */
  headcount: number;
  minUsd: number;
  maxUsd: number;
  /** Proof budget ÷ headcount, before the bounds. */
  fromPeopleUsd: number;
  /** The highest price allowed: the people bound, inside the Protocol's minimum and maximum. */
  upperUsd: number;
}

/**
 * The band a seat price must sit in. A price above proof ÷ headcount would raise the budget from
 * fewer people than the venture needs, so the people set the top; the Protocol's settings bound it.
 * Nothing caps the number of seats: what the network can sell is for the market to decide, and a missed minimum refunds.
 */
export function priceBand(input: Pick<SizingInput, "budget" | "requestPlan" | "roster">, params: SizingParams): PriceBand {
  const proofUsd = proofBudget(input.budget, params.SEAT_BUFFER_PCT).totalUsd;
  const rosterSeats = input.roster.reduce((s, r) => s + r.count, 0);
  const coverage = coverageSeats(input.requestPlan, params).seats;
  const headcount = Math.max(1, rosterSeats, coverage);
  const fromPeopleUsd = Math.floor(proofUsd / headcount);
  const minUsd = params.SEAT_PRICE_MIN_USD;
  const maxUsd = Math.max(minUsd, params.SEAT_PRICE_MAX_USD);
  return { proofUsd, rosterSeats, coverageSeats: coverage, headcount, minUsd, maxUsd, fromPeopleUsd, upperUsd: Math.max(minUsd, Math.min(maxUsd, fromPeopleUsd)) };
}

export const clampPrice = (priceUsd: number, band: Pick<PriceBand, "minUsd" | "upperUsd">) => Math.max(band.minUsd, Math.min(band.upperUsd, Math.round(priceUsd)));

/**
 * The seat rule. Seats needed = proof budget ÷ the venture's price, rounded up, never below the
 * headcount it runs on or the floor. The price comes from the agent, inside the band code computes.
 */
export function seatPlanFor(input: SizingInput, params: SizingParams, protocolVersion: string): SeatPlan {
  const band = priceBand(input, params);
  const plan = derivedPlan(input, band, clampPrice(input.priceUsd ?? band.minUsd, band), params, protocolVersion);
  plan.price = { proposedBy: input.price?.proposedBy ?? "script", minUsd: band.minUsd, maxUsd: band.maxUsd, upperUsd: band.upperUsd, claims: input.price?.claims ?? [], decisionId: input.price?.decisionId };
  const ends = [...new Set([band.minUsd, band.upperUsd])];
  plan.atPrices = ends.map((priceUsd) => {
    const p = priceUsd === plan.priceUsd ? plan : derivedPlan(input, band, priceUsd, params, protocolVersion);
    return { priceUsd, min: p.min, minRaiseUsd: p.minRaiseUsd, shortfallUsd: 0 };
  });
  return plan;
}

function derivedPlan(input: SizingInput, band: PriceBand, price: number, params: SizingParams, protocolVersion: string): SeatPlan {
  const core = input.budget.filter((b) => !b.stretch && b.category !== "contingency");
  const budgetUsd = core.reduce((s, b) => s + b.usd, 0);
  const coverage = coverageSeats(input.requestPlan, params);
  const budgetSeats = ceil(band.proofUsd / price);
  const min = Math.max(params.SEAT_FLOOR, band.headcount, budgetSeats);
  const binding: SeatPlan["binding"] =
    budgetSeats >= band.headcount && budgetSeats >= params.SEAT_FLOOR
      ? "budget"
      : band.headcount >= params.SEAT_FLOOR
        ? band.coverageSeats >= band.rosterSeats
          ? "coverage"
          : "roster"
        : "floor";
  const critical = new Set(params.CRITICAL_ROLES_AT_RAISE);
  return {
    rule: "derived",
    priceUsd: price,
    budgetUsd,
    budgetSeats,
    budgetLines: core.length,
    coverageSeats: coverage.seats,
    coverage: coverage.binding,
    rosterSeats: band.rosterSeats,
    headcount: band.headcount,
    binding,
    bufferPct: params.SEAT_BUFFER_PCT,
    floor: params.SEAT_FLOOR,
    min,
    max: ceil(min * params.SEAT_MAX_MULTIPLE),
    minRaiseUsd: min * price,
    contingencyUsd: Math.max(0, min * price - budgetUsd),
    proofBudgetUsd: band.proofUsd,
    shortfallUsd: Math.max(0, band.proofUsd - min * price),
    atPrices: [],
    stretchUsd: input.budget.filter((b) => b.stretch).reduce((s, b) => s + b.usd, 0),
    criticalRoles: [...new Set(input.roster.map((r) => r.key).filter((k) => critical.has(k)))],
    paramsAt: protocolVersion,
  };
}

/**
 * A venture pitched under the old rule keeps its price and minimum (Article 6). With a deck, its itemized
 * lines are the budget and the rest of the old minimum is contingency; without one, the old buffer line is.
 */
export function legacySeatPlan(
  v: { minRaiseUsd: number; budget: { label: string; usd: number }[]; seatPriceUsd?: number },
  params: Pick<ParamValues, "SEAT_PRICE_USD" | "SEAT_BUFFER_PCT">,
  protocolVersion: string,
  lines?: Pick<BudgetLine, "usd" | "stretch" | "category">[],
): SeatPlan {
  const price = v.seatPriceUsd ?? params.SEAT_PRICE_USD;
  const min = seatsNeeded(v.minRaiseUsd, price);
  const core = lines?.filter((b) => !b.stretch && b.category !== "contingency");
  const itemized = core ? core.map((b) => b.usd) : v.budget.filter((b) => !/buffer|contingency/i.test(b.label)).map((b) => b.usd);
  const budgetUsd = itemized.reduce((s, n) => s + n, 0);
  const buffer = Math.max(0, v.minRaiseUsd - budgetUsd);
  const proof = lines ? proofBudget(lines, params.SEAT_BUFFER_PCT).totalUsd : v.minRaiseUsd;
  return {
    rule: "legacy-budget",
    priceUsd: price,
    price: { proposedBy: "kept", minUsd: price, maxUsd: price, upperUsd: price, claims: [] },
    budgetUsd,
    budgetSeats: min,
    budgetLines: itemized.length,
    coverageSeats: 0,
    rosterSeats: 0,
    headcount: 0,
    binding: "budget",
    bufferPct: 0,
    floor: 0,
    cap: LEGACY_SEAT_CAP,
    min,
    max: LEGACY_SEAT_CAP,
    minRaiseUsd: v.minRaiseUsd,
    contingencyUsd: buffer,
    proofBudgetUsd: proof,
    shortfallUsd: Math.max(0, proof - v.minRaiseUsd),
    atPrices: [],
    stretchUsd: 0,
    criticalRoles: [],
    paramsAt: protocolVersion,
  };
}

export interface SeatMathLine {
  label: string;
  detail?: string;
  value: string;
  /** The setting each figure comes from, linked on /protocol. */
  param?: string;
  total?: boolean;
}

const usd = (n: number) => `$${n.toLocaleString("en-US")}`;
const seatsText = (n: number) => `${n} ${n === 1 ? "seat" : "seats"}`;
const peopleText = (n: number) => `${n} ${n === 1 ? "person" : "people"}`;

/** Who proposed the price, in words. */
export function priceSource(plan: Pick<SeatPlan, "price">): string {
  const by = plan.price?.proposedBy;
  return by === "agent" ? "proposed by the agent" : by === "kept" ? "kept from its pitch" : "proposed by the agent's pricing rule";
}

/** The worked calculation, rendered from the plan object; never stored as prose. */
export function seatMath(plan: SeatPlan, roles?: { label: string; key: string }[]): SeatMathLine[] {
  if (plan.rule === "legacy-budget") {
    const lines: SeatMathLine[] = [
      { label: "Proof budget", detail: `${usd(plan.budgetUsd)} itemized, plus ${usd(plan.proofBudgetUsd - plan.budgetUsd)} contingency at the seat buffer`, value: usd(plan.proofBudgetUsd), param: "SEAT_BUFFER_PCT" },
      { label: "Minimum it keeps", detail: `${usd(plan.minRaiseUsd)} at ${usd(plan.priceUsd)} a seat, set when it was pitched`, value: seatsText(plan.min), param: "SEAT_PRICE_USD", total: true },
    ];
    if (plan.shortfallUsd > 0) {
      lines.push({ label: "Gap", detail: `The minimum it keeps covers ${usd(plan.minRaiseUsd)} of the ${usd(plan.proofBudgetUsd)} an honest proof costs`, value: usd(plan.shortfallUsd) });
    }
    return lines;
  }
  const band = plan.price;
  const lines: SeatMathLine[] = [
    { label: "Proof budget", detail: `${usd(plan.budgetUsd)} itemized (${plan.budgetLines} lines), plus ${usd(plan.proofBudgetUsd - plan.budgetUsd)} contingency`, value: usd(plan.proofBudgetUsd), param: "SEAT_BUFFER_PCT" },
  ];
  const coverage = plan.coverage
    ? `${seatsText(plan.coverageSeats)} so “${plan.coverage.title}” gets ${plan.coverage.target} answers at ${plan.coverage.rate} of holders answering`
    : "no request that needs many holders";
  lines.push({ label: "People it runs on", detail: `The larger of ${peopleText(plan.rosterSeats)} on the roster and ${coverage}`, value: peopleText(plan.headcount), param: "RESPONSE_RATE" });
  if (band) {
    const capped = band.upperUsd < Math.floor(plan.proofBudgetUsd / Math.max(1, plan.headcount)) ? `, held to the ${usd(band.maxUsd)} maximum` : band.upperUsd === band.minUsd ? `, raised to the ${usd(band.minUsd)} minimum` : "";
    lines.push({ label: "Highest price the people allow", detail: `${usd(plan.proofBudgetUsd)} ÷ ${peopleText(plan.headcount)}${capped}`, value: usd(band.upperUsd), param: "SEAT_PRICE_MAX_USD" });
  }
  lines.push({
    label: "Seat price",
    detail: band ? `${priceSource(plan)}, between ${usd(band.minUsd)} and ${usd(band.upperUsd)}` : undefined,
    value: usd(plan.priceUsd),
    param: "SEAT_PRICE_MIN_USD",
  });
  lines.push({ label: "Seats for the proof budget", detail: `${usd(plan.proofBudgetUsd)} ÷ ${usd(plan.priceUsd)}, rounded up`, value: seatsText(plan.budgetSeats) });
  const why = plan.binding === "budget" ? "the proof budget sets it" : plan.binding === "floor" ? `raised to the floor of ${plan.floor}` : "never below the people it runs on";
  lines.push({ label: "Minimum", detail: why, value: `${seatsText(plan.min)} · ${usd(plan.minRaiseUsd)}`, param: plan.binding === "floor" ? "SEAT_FLOOR" : undefined, total: true });
  lines.push({ label: "Maximum", detail: `${plan.min} × the multiple. No cap on the count: a missed minimum refunds every seat`, value: seatsText(plan.max), param: "SEAT_MAX_MULTIPLE" });
  lines.push({
    label: "Contingency",
    detail: `${usd(plan.minRaiseUsd)} − ${usd(plan.budgetUsd)}${plan.stretchUsd ? `; seats past the minimum pay only for the ${usd(plan.stretchUsd)} of listed stretch lines` : ""}`,
    value: usd(plan.contingencyUsd),
  });
  for (const a of plan.atPrices) {
    if (a.priceUsd === plan.priceUsd) continue;
    lines.push({
      label: `At ${usd(a.priceUsd)} a seat`,
      detail: a.priceUsd === band?.minUsd ? "the lowest price allowed" : "the highest price the people allow",
      value: `${seatsText(a.min)} · ${usd(a.minRaiseUsd)}`,
      param: a.priceUsd === band?.minUsd ? "SEAT_PRICE_MIN_USD" : "SEAT_PRICE_MAX_USD",
    });
  }
  if (plan.criticalRoles.length) {
    const names = plan.criticalRoles.map((k) => roles?.find((r) => r.key === k)?.label.toLowerCase() ?? k.replace(/-/g, " "));
    lines.push({ label: "Also needed before the raise succeeds", detail: `One claim each: ${names.join(", ")}`, value: `${plan.criticalRoles.length} roles`, param: "CRITICAL_ROLES_AT_RAISE" });
  }
  return lines;
}

const BINDING_WORDS: Record<SeatPlan["binding"], string> = {
  budget: "its proof budget",
  coverage: "the holders its requests need to get answers",
  roster: "the people on its roster",
  floor: "the seat floor",
};

/** A legacy venture shows what the current rule would ask for beside the minimum it keeps. */
export function currentRuleLine(plan: SeatPlan, current?: SeatPlan): string | undefined {
  if (plan.rule !== "legacy-budget" || !current) return undefined;
  const ends = current.atPrices.filter((a) => a.priceUsd !== current.priceUsd).map((a) => `${seatsText(a.min)} at ${usd(a.priceUsd)}`);
  return `Under the current rule it would price seats at ${usd(current.priceUsd)} and ask for ${seatsText(current.min)} (${usd(current.minRaiseUsd)}), set by ${BINDING_WORDS[current.binding]}${ends.length ? `; ${ends.join(", ")}` : ""}. It keeps its ${usd(plan.priceUsd)} price and ${plan.min}-seat minimum, set when it was pitched.`;
}

/** One line for a seat card or a pitch decision. */
export function seatSummary(plan: SeatPlan): string {
  if (plan.rule === "legacy-budget") return `${plan.min} seats: the ${usd(plan.minRaiseUsd)} budget at ${usd(plan.priceUsd)} a seat, set when it was pitched`;
  return `${plan.min} seats at ${usd(plan.priceUsd)} minimum (${BINDING_WORDS[plan.binding]} sets it), ${plan.max} at most`;
}

/* ---------- liftoff roster ---------- */

type RosterParams = Pick<
  ParamValues,
  | "FIRST_CUSTOMERS_TARGET"
  | "FUNNEL_RATES"
  | "INTROS_PER_INTRODUCER"
  | "INTROS_PER_ICP_OPERATOR"
  | "ROSTER_ICP_OPERATORS"
  | "ROSTER_DOMAIN_MIN"
  | "ROSTER_ROLE_RULES"
  | "USERS_PER_CHANNEL_MEMBER"
  | "ROSTER_MAX"
  | "CRITICAL_ROLES_AT_RAISE"
  | "N_BASELINE"
  | "STAKES_MULTIPLIER"
  | "AGREEMENT_STOP"
  | "DIVERGENCE_EXTEND"
  | "EXTEND_BY"
  | "SEAT_PRICE_USD"
>;

export interface RoleHint {
  label: string;
  qualifications: string[];
  clusters: string[];
  keywords: string[];
}

export interface RosterInput {
  customer: string;
  endMarket: string;
  /** Go-to-market motions, e.g. ["Partner or channel", "Sales-led"]. */
  motions: string[];
  requestPlan: RequestPlanItem[];
  needsIntegration: boolean;
  /** Regulated activities the deck's risks touch. */
  regulated: string[];
  hints: Partial<Record<RosterRoleKey, RoleHint>>;
}

const SERVES: Record<RosterRoleKey, RfeType[]> = {
  "icp-operator": ["judgment", "access"],
  introducer: ["access"],
  "domain-expert": ["knowledge"],
  builder: ["action"],
  channel: ["access"],
  legal: ["knowledge", "action"],
  credibility: ["credibility"],
};

const DEFAULT_HINTS: Record<RosterRoleKey, RoleHint> = {
  "icp-operator": { label: "Buyer-side operators", qualifications: ["Works in the buyer's job today"], clusters: [], keywords: [] },
  introducer: { label: "Introducers to buyers", qualifications: ["Can make a warm intro to a buyer"], clusters: [], keywords: [] },
  "domain-expert": { label: "Domain experts", qualifications: ["Knows the data, rules or market"], clusters: [], keywords: [] },
  builder: { label: "Builder", qualifications: ["Has built an integration like this"], clusters: ["data-eng"], keywords: ["engineer"] },
  channel: { label: "Channel partner", qualifications: ["Works at a distributor, association or community the buyer uses"], clusters: [], keywords: [] },
  legal: { label: "Counsel", qualifications: ["Practising lawyer in the venture's area"], clusters: ["legal-counsel"], keywords: ["counsel", "lawyer", "attorney"] },
  credibility: { label: "A vouching member", qualifications: ["Willing to be named to a buyer"], clusters: [], keywords: [] },
};

export interface RosterPlan {
  roles: RosterRole[];
  total: number;
  overMax: boolean;
  partners: number;
  intros: number;
}

/** The roster the plan needs, from the funnel arithmetic. Code sets every count. */
export function rosterPlan(input: RosterInput, params: RosterParams): RosterPlan {
  const rules = params.ROSTER_ROLE_RULES as { builderIfIntegration: number; channelPerMotion: number; legalSectors: string[]; credibilityIfPlanned: number };
  const funnels = params.FUNNEL_RATES as Record<string, { introToCall?: number; callToPartner?: number; partnerToPaid?: number; testUsers?: number }>;
  const f = funnels[input.customer] ?? funnels["Small business"];
  const critical = new Set(params.CRITICAL_ROLES_AT_RAISE);
  const roles: RosterRole[] = [];
  const add = (key: RosterRoleKey, count: number, derivation: string, minDistinctClusters = 1) => {
    if (count <= 0) return;
    const h = { ...DEFAULT_HINTS[key], ...input.hints[key] };
    roles.push({ key, label: h.label, count, critical: critical.has(key), qualifications: h.qualifications, clusters: h.clusters, keywords: h.keywords, minDistinctClusters, serves: SERVES[key], derivation });
  };
  const target = params.FIRST_CUSTOMERS_TARGET;
  const consumer = f.testUsers !== undefined;
  let partners: number;
  let intros = 0;
  const icp = params.ROSTER_ICP_OPERATORS;
  if (consumer) {
    partners = f.testUsers!;
    add("icp-operator", icp, `${icp} people who are the buyer, so a two-of-three view can exist`);
  } else {
    partners = ceil(target / f.partnerToPaid!);
    const conv = f.introToCall! * f.callToPartner!;
    intros = ceil(partners / conv);
    add("icp-operator", icp, `${icp} buyer-side members, so a two-of-three buyer view can exist; they bring ${icp * params.INTROS_PER_ICP_OPERATOR} of the intros`);
    const fromIcp = icp * params.INTROS_PER_ICP_OPERATOR;
    const introducers = Math.max(1, ceil((intros - fromIcp) / params.INTROS_PER_INTRODUCER));
    add(
      "introducer",
      introducers,
      `${intros} intros for ${partners} design partners at ${pct(f.introToCall!)} × ${pct(f.callToPartner!)}; ${fromIcp} come from buyer-side members; ${intros - fromIcp} ÷ ${params.INTROS_PER_INTRODUCER} per introducer = ${introducers}`,
    );
  }
  const knowledge = Math.max(0, ...input.requestPlan.filter((r) => r.type === "knowledge").map((r) => nBounds({ type: r.type, stakes: r.stakes }, params).target));
  const domain = Math.max(params.ROSTER_DOMAIN_MIN, knowledge);
  add("domain-expert", domain, `${domain}: the larger of ${params.ROSTER_DOMAIN_MIN} and the biggest planned Knowledge request (${knowledge} answers), from at least two kinds of expert`, 2);
  if (input.needsIntegration) add("builder", rules.builderIfIntegration, "The product reads another system's data, so one member who has built that integration");
  const channelMotions = input.motions.filter((m) => m === "Partner or channel" || m === "Community and content").length;
  const channel = consumer ? ceil(partners / params.USERS_PER_CHANNEL_MEMBER) : Math.min(2, rules.channelPerMotion * channelMotions);
  add(
    "channel",
    channel,
    consumer ? `${partners} test users ÷ ${params.USERS_PER_CHANNEL_MEMBER} per community member` : `${rules.channelPerMotion} per partner or community motion in the plan`,
  );
  const legalSector = rules.legalSectors.includes(input.endMarket);
  if (legalSector || input.regulated.length) {
    add("legal", 1, legalSector ? `${input.endMarket} is a regulated sector` : `The plan's risks touch ${input.regulated.join(", ")}`);
  }
  if (input.requestPlan.some((r) => r.type === "credibility")) add("credibility", rules.credibilityIfPlanned, "The plan includes a Credibility request");
  const total = roles.reduce((s, r) => s + r.count, 0);
  return { roles, total, overMax: total > params.ROSTER_MAX, partners, intros };
}

const pct = (n: number) => `${Math.round(n * 100)}%`;
