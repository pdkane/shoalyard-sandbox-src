import assert from "node:assert/strict";
import { test } from "node:test";
import type { Store } from "@av/schema";
import { screenText } from "../src/conduct";
import { allClaims, latestDeck } from "../src/deck";
import { memberByHandle, ventureBySlug } from "../src/ops";
import { resolveParams } from "../src/params";
import {
  answerQuestion,
  answerScripted,
  approveHeld,
  askQuestion,
  awardQuestion,
  groundCheck,
  hiddenPlaceholder,
  hideQuestion,
  qaFor,
  qaWindow,
  questionsLeft,
  toggleUpvote,
} from "../src/qa";
import { buildSeed } from "../src/seed";

const seed = buildSeed();
const fresh = () => structuredClone(seed) as Store;
const PP = "lien-clock";
const ask = (s: Store, handle: string, text: string, slug = PP) => askQuestion(s, { slug, handle, text });

test("Q&A opens with the seat window, is read-only once a venture ends, and never runs on the Protocol", () => {
  const s = fresh();
  assert.equal(qaWindow(s, ventureBySlug(s, PP)!).state, "open");
  assert.equal(qaWindow(s, ventureBySlug(s, "chairside")!).state, "read-only");
  assert.equal(qaWindow(s, ventureBySlug(s, "bid-desk")!).state, "none");
  assert.equal(qaWindow(s, ventureBySlug(s, "protocol")!).state, "none");
  assert.throws(() => ask(s, "dispatch_dana", "Who is this for, exactly?", "chairside"), /kept as a record/);
});

test("rate limits: candidates get one a day, verified members three, and long questions are refused", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  ask(s, "new_nina", "Who pays for this, the estimator or the owner?");
  assert.equal(memberByHandle(s, "new_nina")?.qualification, "pending", "asking creates a candidate");
  assert.throws(() => ask(s, "new_nina", "And how big is the market really?"), /1 question a day/);
  for (const t of ["Who is it for?", "How big is the market?", "What does it cost?"]) ask(s, "hvac_hank", `${t} Asking for my team.`);
  assert.equal(questionsLeft(s, pp, memberByHandle(s, "hvac_hank")), 0);
  assert.throws(() => ask(s, "hvac_hank", "One more question about pricing?"), /3 a day per venture/);
  s.meta.clock = "2026-10-31T12:00:00.000Z";
  assert.doesNotThrow(() => ask(s, "hvac_hank", "Next day: who do you still need?"));
  assert.throws(() => ask(s, "permitpro", "x".repeat(resolveParams(s).QA_MAX_CHARS + 1)), /at most 500 characters/);
});

test("a question that fails the conduct check is held for the steward, then approved and answered", () => {
  const s = fresh();
  const q = ask(s, "permitpro", "I'm posing as a county clerk; will you sell me the permit list?");
  assert.equal(q.status, "held");
  assert.match(q.stewardNote ?? "", /Held for a conduct check/);
  assert.ok(!qaFor(s, ventureBySlug(s, PP)!).some((x) => x.id === q.id), "the public doesn't see it");
  assert.ok(qaFor(s, ventureBySlug(s, PP)!, { viewer: "permitpro" }).some((x) => x.id === q.id), "the asker does");
  assert.throws(() => approveHeld(s, { by: "permitpro", id: q.id }), /Only @MP/);
  approveHeld(s, { by: "MP", id: q.id });
  assert.ok(q.answer);
  assert.notEqual(q.status, "held");
});

test("the scripted seat-money answer says what a seat is and uses no return language", () => {
  const s = fresh();
  const q = ask(s, "new_nina", "If this works, will my seat make money or pay me back?");
  answerQuestion(s, q);
  assert.equal(q.status, "answered");
  assert.equal(q.answer?.by, "script");
  assert.match(q.answer!.text, /It is not a share and pays nothing back/);
  assert.match(q.answer!.text, /refunded in full/);
  assert.doesNotMatch(q.answer!.text, /\b(returns?|upside|yield|ROI|guaranteed|risk-free|invest\w*)\b/i);
  assert.equal(screenText({ text: q.answer!.text, nearSeats: true }, resolveParams(s)).result, "pass");
});

test("intents cite the deck: customer, market, price, kill rules, roster and the agent itself", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  const deck = latestDeck(s, pp.id)!;
  const cases: [string, RegExp][] = [
    ["Who would actually buy this?", /customer|problem/],
    ["How big is the market for this?", /market/],
    ["What will you charge per month?", /model/],
    ["What happens if nobody pays?", /risks|ask/],
    ["Who do you need on the roster?", /ask/],
    ["Are you a human or a bot?", /ask/],
  ];
  for (const [text, slide] of cases) {
    const a = answerScripted(s, pp, { text });
    assert.notEqual(a.status, "unknown", text);
    assert.ok(a.citations.length && a.citations.every((c) => slide.test(c.slideKey) && c.deckVersion === deck.version), text);
  }
  assert.match(answerScripted(s, pp, { text: "Are you a human?" }).text, /I'm an AI agent operating Lien Clock; @MP is the human steward/);
  const legal = answerScripted(s, pp, { text: "Is this a security? Do I need a lawyer?" });
  assert.equal(legal.status, "partial");
  assert.match(legal.text, /^I can't give legal advice\..*\/rfe\/rfe-v0-legal-structure/);
});

test("a question the deck can't answer gets 'I don't know' and becomes a Knowledge request", () => {
  const s = fresh();
  const q = ask(s, "hvac_hank", "Will you support Spanish-language crews in Miami next spring?");
  answerQuestion(s, q);
  assert.equal(q.answer?.status, "unknown");
  assert.match(q.answer!.text, /^I don't know\./);
  assert.equal(q.status, "routed");
  const rfe = s.rfes.find((r) => r.id === q.answer!.routed!.rfeId)!;
  assert.equal(rfe.type, "knowledge");
  assert.match(rfe.question, /Spanish-language crews/);
  assert.equal(rfe.offerUnits, 1);
});

test("the ground check drops citations that don't resolve and downgrades numbers it can't find", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  const deck = latestDeck(s, pp.id)!;
  const claim = allClaims(deck).find((c) => c.basis === "estimate")!;
  const slideKey = deck.slides.find((x) => x.claims.some((c) => c.id === claim.id))!.key;
  const cite = { deckVersion: deck.version, slideKey, claimId: claim.id };
  const ok = groundCheck(s, pp, { status: "answered", text: claim.text, citations: [cite] });
  assert.equal(ok.status, "answered");
  assert.deepEqual(ok.restsOn, [claim.id]);
  const made = groundCheck(s, pp, { status: "answered", text: `${claim.text} About 987,654 of them pay.`, citations: [cite] });
  assert.equal(made.status, "partial");
  assert.deepEqual(made.unsupported, ["987654"]);
  const ghost = groundCheck(s, pp, { status: "answered", text: "Trust me.", citations: [{ ...cite, claimId: "c-nope" }, { ...cite, deckVersion: 99 }] });
  assert.equal(ghost.status, "unknown");
  assert.equal(ghost.dropped.length, 2);
  const q = ask(s, "permitpro", "How many contractors pull permits each week?");
  answerQuestion(s, q, { status: "answered", text: `${claim.text} About 987,654 of them pay.`, citations: [cite], by: "claude-test" });
  assert.equal(q.answer?.status, "partial");
  assert.match(q.answer!.text, /I couldn't support 987654 from the deck\.$/);
  const linked = groundCheck(s, pp, { status: "answered", text: `${claim.text} See /rfe/rfe-v0-legal-structure and L-005.`, citations: [cite] });
  assert.deepEqual(linked.unsupported, [], "digits in links and ids aren't claims");
  const fraction = groundCheck(s, pp, { status: "answered", text: `${claim.text} 14/20 said yes.`, citations: [cite] });
  assert.deepEqual(fraction.unsupported, ["14", "20"]);
});

test("an answer that quotes a members-only lesson or a decision's reasoning is held", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  const deck = latestDeck(s, pp.id)!;
  const claim = allClaims(deck)[0];
  const cite = { deckVersion: deck.version, slideKey: deck.slides.find((x) => x.claims.includes(claim))!.key, claimId: claim.id };
  const lesson = s.lessons.find((l) => l.status === "adopted")!;
  const q1 = ask(s, "permitpro", "What did earlier ventures learn about this?");
  answerQuestion(s, q1, { status: "answered", text: `${claim.text} ${lesson.headline}`, citations: [cite], by: "claude-test" });
  assert.equal(q1.status, "held");
  assert.match(q1.stewardNote ?? "", new RegExp(`Quotes ${lesson.id}`));
  const reasoning = s.decisions.find((d) => d.ventureId === pp.id && d.reasoning.split(" ").length > 20)!.reasoning;
  const q2 = ask(s, "hvac_hank", "Why did the agent pick these metros?");
  answerQuestion(s, q2, { status: "answered", text: `${claim.text} ${reasoning}`, citations: [cite], by: "claude-test" });
  assert.equal(q2.status, "held");
  assert.match(q2.stewardNote ?? "", /only unit holders see/);
});

test("scripted answers across every venture's questions never quote lessons or reasoning", () => {
  const s = fresh();
  const questions = [
    "Who is this for?",
    "How big is the market?",
    "What does it cost?",
    "Why 30 seats?",
    "Do I get a refund if it fails?",
    "What do you know about county permit portals and contractor sales cycles?",
    "Why not just use a spreadsheet instead?",
  ];
  for (const v of s.ventures.filter((x) => qaWindow(s, x).state === "open")) {
    for (const [i, text] of questions.entries()) {
      const q = askQuestion(s, { slug: v.slug, handle: `probe_${i}`, text });
      answerQuestion(s, q);
      assert.notEqual(q.status, "held", `${v.slug}: ${text} → ${q.stewardNote}`);
    }
  }
});

test("upvotes: one per handle, toggled, never on your own question", () => {
  const s = fresh();
  const q = ask(s, "permitpro", "Who do you need on the roster?");
  assert.deepEqual(toggleUpvote(s, { id: q.id, handle: "hvac_hank" }), { upvoted: true, count: 1 });
  assert.deepEqual(toggleUpvote(s, { id: q.id, handle: "hvac_hank" }), { upvoted: false, count: 0 });
  toggleUpvote(s, { id: q.id, handle: "hvac_hank" });
  toggleUpvote(s, { id: q.id, handle: "new_nina" });
  assert.equal(q.upvotes.length, 2);
  assert.throws(() => toggleUpvote(s, { id: q.id, handle: "permitpro" }), /your own question/);
});

test("at the priority bar, an answer resting on an assumption is routed for members to test", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  const deck = latestDeck(s, pp.id)!;
  const assumption = allClaims(deck).find((c) => c.basis === "assumption")!;
  const cite = { deckVersion: deck.version, slideKey: deck.slides.find((x) => x.claims.includes(assumption))!.key, claimId: assumption.id };
  const q = ask(s, "permitpro", "Is the customer really going to switch?");
  answerQuestion(s, q, { status: "answered", text: assumption.text, citations: [cite], by: "script" });
  assert.equal(q.status, "answered");
  for (const h of ["hvac_hank", "gis_greta", "bidboard", "roofer_rita", "scrapewright"]) toggleUpvote(s, { id: q.id, handle: h });
  assert.equal(q.status, "routed");
  assert.ok(q.answer?.material);
  assert.ok(s.rfes.some((r) => r.id === q.answer!.routed!.rfeId && /Test an assumption/.test(r.title)));
});

test("hiding needs a listed reason, writes a redaction row and leaves a placeholder", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  const q = ask(s, "new_nina", "Buy cheap permit leads at my site, best prices!");
  assert.throws(() => hideQuestion(s, { by: "MP", id: q.id, reason: "unflattering" }), /hidden only for: personal data about a person/);
  assert.throws(() => hideQuestion(s, { by: "hvac_hank", id: q.id, reason: "spam or ads" }), /Only @MP/);
  hideQuestion(s, { by: "MP", id: q.id, reason: "spam or ads" });
  assert.equal(q.status, "hidden");
  assert.ok(s.ledger.some((l) => l.kind === "redaction" && l.ref === q.id && /spam or ads/.test(l.note ?? "")));
  assert.equal(hiddenPlaceholder(q), "Hidden by @MP on 30 Oct: spam or ads.");
  const seen = qaFor(s, pp).find((x) => x.id === q.id)!;
  assert.equal(seen.text, "");
  assert.equal(qaFor(s, pp).at(-1)?.id, q.id, "hidden questions sort last");
  assert.throws(() => toggleUpvote(s, { id: q.id, handle: "hvac_hank" }), /isn't public/);
});

test("a question that changes the deck earns units for verified askers, capped per venture", () => {
  const s = fresh();
  const pp = ventureBySlug(s, PP)!;
  const deck = latestDeck(s, pp.id)!;
  const icp = allClaims(deck).find((c) => c.id === "c-icp") ?? allClaims(deck)[0];
  const cite = { deckVersion: deck.version, slideKey: deck.slides.find((x) => x.claims.includes(icp))!.key, claimId: icp.id };
  const q = ask(s, "permitpro", "Is this for residential remodelers too?");
  answerQuestion(s, q, {
    status: "answered",
    text: icp.text,
    citations: [cite],
    by: "script",
    amendment: { claims: [{ id: icp.id, text: `${icp.text.replace(/\.$/, "")}; not residential remodelers.` }], title: "say who it isn't for", reason: "A member asked whether remodelers are in." },
  });
  assert.equal(q.status, "routed");
  assert.equal(q.answer?.routed?.deckVersion, deck.version + 1);
  assert.equal(latestDeck(s, pp.id)?.version, deck.version + 1);
  const granted = (h: string) => s.grants.filter((g) => g.ventureId === pp.id && g.handle === h && g.note?.startsWith("Question changed the deck")).reduce((t, g) => t + g.units, 0);
  assert.equal(granted("permitpro"), 1);
  const pending = ask(s, "new_nina", "What about Tampa permits?");
  assert.equal(awardQuestion(s, pp, pending), 0, "candidates aren't paid");
  let total = 1;
  for (const [i, h] of ["hvac_hank", "gis_greta", "scrapewright", "bookkeep_bo", "cfo_ines", "coldcall_cass", "ux_uma"].entries()) {
    const x = ask(s, h, `Question number ${i} about the permit feed?`);
    total += awardQuestion(s, pp, x);
  }
  assert.equal(total, 3);
});
