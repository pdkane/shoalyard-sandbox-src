# Copy audit: plain language and a linked glossary

Read-only audit of `/workspace` as of Oct 31, 2026. I read source under `apps/venture/src`, `packages/protocol/src` and `packages/schema/src`, and crawled the running dev server at `http://localhost:43117`, so this covers both hand-written copy and seeded or computed copy such as taglines, lessons and bin reasons. I edited no files.

This plan allows for three changes already in progress:

- **"Venture 0" becomes "the Protocol".** The rendered site already says "The Protocol" (`seed.ts:148`), so nothing below uses "Venture 0".
- **Phenotypes are being replaced by standard classification.** The new fields are end market, customer, business model, go-to-market, market type and geography. Every phenotype line below is marked **(classification change)**. The fix is to delete the line or swap in the new labels, not to reword it.
- **Lessons are becoming plain-language cards.** Each card has a headline, what happened, what we'll do differently, how sure we are, what it applies to, and a topic. Lesson findings below are marked **(lesson cards)**. I quote them only to show what the new cards must avoid.

Copy rules used throughout:

- Words banned by `packages/protocol/test/copy.test.ts`: fund(s), carry, investor(s), portfolio(s), investment committee, SPV, LP(A), GP, drop.
- Words I also avoid because they sound like fund or investment language: returns, invest/investment, raise/fundraise, funded, cap table, pari passu, pro rata, treasury.

---

## 0. Top findings

1. **Article 7 promises something the UI doesn't do.** `markWithdrawn()` exists (`packages/protocol/src/flags.ts:93`), but nothing calls it. `markFor()` prints the mark on every venture regardless (`app/page.tsx:32`, `app/v/[slug]/page.tsx:163`, `app/v/[slug]/seat/page.tsx:40`, `app/v/[slug]/report/page.tsx:45`). A venture with 3 confirmed breaches still shows "X, an Agent Ventures venture".
2. **A find-and-replace bug is live.** Lesson L-007 reads "the advisory threshold could **batch** from 0.7 to 0.6" (`packages/protocol/src/seed.ts:824`). The rename from "drop" to "batch" caught the verb. It should say "could be lowered from 0.7 to 0.6".
3. **Vesting is described three different ways, and two are wrong.** The code vests everything at once (a cliff) `VESTING_DAYS` after the grant (`ops.ts:704`, `ops.ts:722`). The copy says "vesting over 14 days" (`seat/page.tsx:45`, `inbox/page.tsx:82`, `rfe/[id]/page.tsx:276`) and "vests once its input has stood for this long without being proven wrong" (`params.ts:151`). Nothing in the code checks "proven wrong". Forfeiting only happens on refunds or by hand (`seed.ts:611`).
4. **The seat promise overstates what you get.** Article 2 says a seat "buys the right to receive a venture's requests". In practice only *qualified* members can answer (`rfe/[id]/page.tsx:72-82`, `inbox/page.tsx:64`). Someone who pays and never qualifies gets nothing they can act on. The copy must say so before checkout.
5. **The Protocol's own page contradicts itself.** It shows a "Raising seats" lifecycle step and "22/20 … $220 of $200 minimum raise at $10 a seat" (`/v/protocol`, `v/[slug]/page.tsx:279-311`). The seat page says "The Protocol doesn't sell seats" (`seat/page.tsx:70`).
6. **Fund-style words are everywhere even though they pass the test.** Examples: "Funded" (status label, `states.ts:31`; Learning table headers), "minimum raise", "cap table", "micro-fundraise" (`primitives.ts:27`), "pari passu" (`params.ts:87`), "accrues pro rata to holders at sunset" (`params.ts:134`), "distributions", "treasury". I suggest extending the banned-words test (section 4.4).
7. **No page explains the whole idea from start to finish.** The home page jumps straight to "profits interest", "steward" and "eight-article constitution". Section 4.6 has a six-step "How it works".

---

## 1. Constitution rewrite (`packages/protocol/src/constitution.ts`)

The goal is the same meaning in plain words, with a title that says what each article does. Numbers stay in params, as the file header requires. I suggest `renderConstitution(brandName, markTemplate)` take `params` instead, so it can fill in `{SEAT_PRICE_USD}`, `{CONSTITUTION_NOTICE_DAYS}`, `{SUPERMAJORITY}` and `{MARK_WITHDRAW_BREACHES}` from live values. Without that change, use the bracketed fallback wording.

Bump `CONSTITUTION_VERSION` to `1.4`. Wording-only changes still count as article changes under Article 6, so the version log and the notice rule apply. Say so in the change history and post a Protocol governance request for it. That is a process step, not a code step.

### Preamble

Current (`constitution.ts:64`):
> Version 1.3. Agent Ventures is an open standard for agent-operated ventures, with a reference implementation and a public ledger. Members answer requests from agent-run ventures and get paid in a share of their profits. The Protocol is the body these articles found: it keeps the registry and ledger, receives the protocol fee, and its holders vote. Eight articles; every number lives in the parameters, which holders can change by vote.

Proposed:
> Version 1.4. Agent Ventures is a set of public rules for small businesses run by AI agents. We call each business a venture.
>
> An agent proposes each venture and does most of the work. When it needs a person, it posts a request: a judgment call, an introduction, a phone call, a signature. Members answer those requests and earn units, which are a share of that venture's profits. Members get access by buying a seat for a small one-time fee [currently $10]. Paying for a seat never earns you a share. Only the work does.
>
> The Protocol is the organization these rules set up. It keeps the public record of every venture, receives a small fee from each one, and its members vote on changes. The rules are the eight articles below. Every number they rely on, such as the seat price or the fee, is a setting listed on the Protocol page. Settings can be changed by a vote.

### Article 1

Current: **Agents operate, people contribute.** "An agent founds and runs each venture. People earn profits interests for work they do, never for money they pay."

Proposed: **People earn a share by working, never by paying.**
> An AI agent starts and runs each venture. People earn units, a share of a venture's profits, only by doing work for it. Work means answering its requests, serving as its steward, or completing the member interview and having your profile verified. Money you pay, including the price of a seat, never earns units.

Flag: The current text hides that the seat slice (`POOL_SEATS_UNITS`, `params.ts:108-115`) is earned by *qualifying*. Qualifying is an interview plus verification. That counts as "work" only if we say so. The founding steward's 15-unit "Founder's grant" (`seed.ts:233`) also needs a stated basis, such as stewardship of the Protocol. Otherwise a reader will see it as breaking this article.

### Article 2

Current: **Seats are access, not investment.** "A seat buys the right to receive a venture's requests. Seat money is held until the minimum is met; a venture that misses its minimum ends and every seat is refunded in full."

Proposed: **A seat gets you the requests, and your money back if the venture doesn't start.**
> A seat is a one-time payment that lets you receive a venture's requests. To answer them, you also finish a short interview and get your profile verified. A seat is not a share of the venture, and it pays nothing back.
>
> Each venture sets a minimum: the number of seats it must sell before a deadline. Until it reaches the minimum, seat money is held and can't be spent. If the minimum isn't reached in time, the venture ends and every seat holder gets a full refund.

Flags:
- The current text omits that answering requires qualifying. See top finding 4.
- `packages/protocol/test/refunds.test.ts:25` asserts the exact current sentence. Update it in the same commit.
- The "not investment" title is a "not X, but Y" construction. The rewrite states the limit plainly instead.

### Article 3

Current: **Everything is logged.** "Every decision, with the agent's reasoning, goes on the public log. Anything withheld is logged with the reason and a release date, and the log is a commons every later venture learns from."

Proposed: **Every decision is public.**
> Every decision the agent makes goes on the venture's public ledger, with the agent's reasoning. Sometimes a decision must stay private for a while, for example to protect a customer's confidential terms or a member's privacy. In that case the ledger still shows that a decision was made, why it is private, and the date it will be published. Every later venture can read this record and learn from it.

Flags:
- "Commons" is undefined.
- `DEFAULT_EMBARGO_DAYS` is a default, not a maximum, and "legal" is an allowed reason (`params.ts:330-335`). As written, a decision could stay private indefinitely. Add a setting for the longest allowed delay, or say in the text that the steward must renew each delay.

### Article 4

Current: **A human can stop it.** "Each venture has a steward who can kill it and must approve any action the parameters mark irreversible."

Proposed: **A named person can stop it.**
> Every venture has a steward: a named person who can shut it down at any time and must sign off on risky actions before the agent takes them. Which actions need sign-off is a setting. Today the list is spending over [$100], signing contracts, changing prices, sending email from a new domain, and posting in public.

Flag: This article is vague as written. The params never mark anything "irreversible". The gates are a list of action types (`GATE_*`, `params.ts:158-191`), and the classifier also moves decisions up when they contradict a lesson. Point the article at the actual list.

### Article 5

Current: **Owners decide what the agent cannot.** "A short list of matters goes to holders, weighted by vested interest. The agent proposes and never votes."

Proposed: **Unit holders decide the big questions.**
> Some decisions are too big for the agent:
> - asking members for more seat money
> - changing what the venture is for or how it pays out profits
> - selling it
> - choosing to close it
> - replacing the steward
> - making a major change to the plan
> - changing a setting
>
> People who have earned units in the venture vote on these. Each vote counts in proportion to the holder's vested units, so people who have done more work have more say. The agent can propose a vote but never votes.

Flags:
- "A short list" is vague. Name the list, which is `RESERVED_MATTERS`, `params.ts:262-275`, or link to it.
- "Owners" conflicts with "a seat is not a share". Use "unit holders".
- Two facts belong next to this article: the batch-wide share abstains (`COHORT_VEHICLE_VOTES`), and the protocol fee carries no vote.

### Article 6 (amendment text)

Current: **Amendment.** "Parameters change by a holder vote. These articles change only by Protocol supermajority after notice. A venture keeps the version it was formed under unless its holders opt in."

Proposed: **How these rules change.**
> Settings change when the Protocol's unit holders vote for the change. These eight articles are harder to change. A change must be announced publicly [30] days before voting opens, and then win a supermajority [two-thirds] of the votes cast by the Protocol's unit holders. A venture keeps the version of the rules it started under unless its own unit holders vote to switch.

Flags:
- "A holder vote": whose holders? In the code, global settings are voted on as Protocol governance requests, for example `ADVISORY_CONFIDENCE` on `/v/protocol`. Say "the Protocol's unit holders".
- The opt-in is not implemented. Nothing reads `venture.protocolVersion` to choose which rules apply. Only `spawn.ts:63` writes it. It is unenforceable today.
- The quorum (`QUORUM_PCT` 30%) applies to article votes too. Mention it or link it.

Footer, current (`constitution.ts:75`):
> Generated from `packages/protocol/src/constitution.ts`. Parameters: see … Open questions are live requests on the Protocol.

Proposed:
> This text is generated from the code, so it always matches what the software does. The current settings are listed on the Protocol page. Open questions about these rules are posted as requests on the Protocol, and any member can answer them.

### Article 7: the mark

Current: **The mark follows the rules.** "A venture carries the mark only while it follows these articles." The markdown version inserts the mark: “[Name], an Agent Ventures venture”.

What the mark actually is:
- `MARK_TEMPLATE` = `"{name}, an Agent Ventures venture"` (`params.ts:45-51`). It is the subtitle shown under every venture's name.
- It is lost after `MARK_WITHDRAW_BREACHES` = 3 confirmed conduct breaches (`params.ts:369-376`).
- A breach is created when any qualified member flags a decision, request or venture (`FlagForm`), members vote the flag up, and the steward certifies the vote (`flags.ts:97-117`).

Proposed: **The "Agent Ventures venture" label is earned by following these rules.**
> A venture that follows these rules may describe itself as “[Name], an Agent Ventures venture”. That label is called the mark. It tells customers and members three things: the venture is run by an AI agent under these articles, it keeps a public ledger, and it has a steward who can stop it.
>
> Any qualified member can report a venture for breaking these rules. Members vote on each report, and the steward confirms the result. A report upheld this way is a breach, and it is recorded publicly. A venture with [3] breaches loses the mark, and its pages stop showing it.

Flags. This article is unenforceable as built:
- See top finding 1: the mark is never actually removed.
- There is no way to win the mark back, and breaches never expire. Decide both and state them.
- "Follows these articles" is broader than what can be flagged. In practice only conduct breaches are counted. Either narrow the text to "breaks these rules, as decided by a member vote" (the proposal does this) or add flag categories per article.
- The steward certifies votes about the steward's own venture, which is a conflict of interest. Consider having the Protocol's steward certify instead.

### Article 8

Current: **Honest and lawful.** "The agent never breaks the law, never deceives anyone, always says it is an agent, and stops and asks a human when it is unsure."

Proposed: **The agent is honest, says it's an AI, and asks when unsure.**
> The agent must obey the law and must never mislead anyone. Whenever it writes to a person, it says it is an AI agent. When it isn't sure what to do, it stops and asks people first. Today "not sure" means its own confidence is below [70%]. It asks members for judgment calls, and asks the steward before anything on the sign-off list or anything touching a regulated area, such as lending, medical advice or legal advice. Every message and decision is checked against a conduct checklist before it goes out.

Flag: "Never breaks the law" is an absolute nobody can verify. The enforceable parts are the conduct checklist (`CONDUCT_CHECKLIST`), the regulated-activity gate (`REGULATED_ACTIVITIES`) and the confidence threshold (`ADVISORY_CONFIDENCE`). The rewrite names them so readers can check them.

---

## 2. Lexicon and glossary

**KEEP** means a lexicon term: link its first use on each page with `<Term id>`. **REPLACE** means stop using the word in UI copy and use the plain words given. I recommend 23 kept terms.

Where terms appear (page keys): Home `/`, Batches `/batches` and `/batches/[n]`, Venture `/v/[slug]`, Seat `/v/[slug]/seat`, Ledger `/v/[slug]/ledger`, Report `/v/[slug]/report`, Request `/rfe/[id]`, Protocol `/protocol`, Learning `/learning`, Steward `/steward`, Holdings `/holdings`, Member `/m/[handle]`, Inbox `/inbox`, Onboarding `/onboarding`.

### 2.1 KEEP (glossary terms)

| id | Term | One-sentence definition | Pages |
|---|---|---|---|
| `agent` | Agent | The AI that proposes, runs and keeps the books for each venture. | All |
| `venture` | Venture | A small business started and run by the agent under these rules. | All |
| `seat` | Seat | A one-time {SEAT_PRICE_USD} payment that lets you receive a venture's requests; it is not a share. | Home, Batches, Venture, Seat, Holdings, Member, Request |
| `minimum` | Minimum | The number of seats a venture must sell by its deadline to go ahead; if it falls short, everyone is refunded. | Home, Batches, Venture, Seat |
| `request` | Request | A specific ask from the agent that needs a person: a judgment call, an introduction, a fact, a signature. | All |
| `unit` | Unit | A slice of a venture's profit share, earned by doing work for it; each venture has 100. | Venture, Request, Holdings, Inbox, Learning, Report |
| `contributor-pool` | Contributor pool | The {100} units of a venture set aside for the people who work on it, after the protocol fee. | Venture, Report |
| `profit-share` | Profit share | Your units in a venture, which pay out part of its profit and give you a vote. | Home, Holdings, Seat |
| `vesting` | Vesting | Earned units become fully yours {VESTING_DAYS} days after you earn them; until then they can be taken back. | Seat, Request, Inbox, Holdings, Venture |
| `steward` | Steward | The named person who signs off on a venture's risky moves and can shut it down. | All |
| `protocol` | The Protocol | The organization these rules set up: it keeps the public record, receives the protocol fee, and its members vote on the rules. | Home, Protocol, Venture, Seat, Inbox |
| `protocol-fee` | Protocol fee | The {PROTOCOL_FEE_PCT}% of each venture's units that goes to the Protocol. | Home, Venture, Report, Protocol |
| `batch` | Batch | A group of about {VENTURES_PER_BATCH} ventures that open for seats in the same window. | Home, Batches, Venture, Learning |
| `sign-off` | Needs sign-off (gated) | A decision the agent can't take until the steward approves it. | Venture, Ledger, Steward |
| `ledger` | Ledger | The public, add-only record of every seat, refund, unit, payout and decision for a venture. | Venture, Ledger, Report, Protocol |
| `kill-rule` | Kill rule | A condition, set before launch, that ends the venture if it happens. | Venture, Batches, Steward |
| `post-mortem` | Post-mortem | The public write-up a venture publishes when it ends: what it tried, why it stopped, what it cost. | Home, Batches, Venture, Steward |
| `lesson` | Lesson | A short, evidence-backed takeaway from a past venture that later ventures must follow or explain why not. | Venture, Batches, Learning, Request |
| `qualified` | Qualified | A member whose interview is done and whose profile has been verified, so they can answer requests. | Onboarding, Inbox, Request, Batches, Member |
| `holder-vote` | Holder vote | A vote by people with vested units, weighted by how many they hold. | Protocol, Inbox, Request, Venture |
| `setting` | Setting | One of the numbers or lists the rules rely on, like the seat price; changed only by a vote. | Protocol, Request, Learning |
| `constitution` | Constitution | The eight articles every venture must follow. | Home, Protocol |
| `mark` | The mark | The label “[Name], an Agent Ventures venture”, which a venture loses after {MARK_WITHDRAW_BREACHES} confirmed rule breaches. | Home, Venture, Seat, Report, Protocol |

Longer explanations and examples (these go in `long` and `example` in `glossary.ts`):

- **agent**: "It writes the pitch, posts requests, decides small things itself, and asks people about the rest. It always says it is an AI." *Example:* "The agent decided to build the scraper first, then asked members which counties publish usable data."
- **venture**: "Each one has its own seats, units, steward, budget and public ledger." *Example:* Permit Pulse sends contractor sales teams new building permits every Monday.
- **seat**: "Buying a seat puts the venture's requests in your inbox once you qualify. It never pays anything back, and you can't sell it. If the venture misses its minimum, you get the full price back." *Example:* "You pay $10 for a seat in Permit Pulse. It sells 17 of 30 seats by the deadline, so it ends and you get your $10 back."
- **minimum**: "The minimum is the venture's budget to its first customer, divided by the seat price. Seat money is held, unspent, until the minimum is reached." *Example:* "$300 budget ÷ $10 = a minimum of 30 seats."
- **request**: "Every request shows the agent's own answer, how sure it is, how many answers it needs, and how many units it offers. You can accept the offer or ask for more." *Types:* Judgment, Knowledge, Introduction, Credibility, Task, Seats, Sign-off. *Example:* "Which trade should Permit Pulse serve first: roofing or HVAC? Offer: 2 units."
- **unit**: "Each venture has 100 units. Ten go to the Protocol as its fee. The rest are earned by answering requests, qualifying, stewarding, or being active in the batch. When the venture pays out profit, each vested unit gets the same amount." *Example:* "Dockside paid $51.75 per vested unit for Q3 2026. @MP's 5 units got $258.75."
- **contributor-pool**: "Split four ways: requests 60, everyone active in the batch 25, qualified seat holders 10, steward 5. Units nobody earns stay unclaimed." Numbers come from params.
- **profit-share**: "Legally, a 'profits interest': a share of future profit given for services, not sold." Use "profit share" in the UI. Keep "profits interest" only in the counsel note. *Example:* "Answer three requests in Dockside, earn 8.5 units, and receive 8.5 × the per-unit payout each quarter."
- **vesting**: "If your answer is shown to be wrong, or the venture refunds your seat, unvested units can be taken back (forfeited). After vesting, units vote and receive payouts." *Example:* "Earned Oct 1, vests Oct 15."
- **steward**: "The founding steward, @MP, stewards every venture in the pilot and earns 5 units per venture for it." *Example:* "The agent wanted to buy a $60 email list; the steward said no."
- **protocol**: "It runs on its own rules: members answer its questions about how the system should work, and earn units in it." *Example:* "Should a seat be a one-time payment or a subscription? That is a Protocol request."
- **protocol-fee**: "It is paid in units, so the Protocol only earns when a venture makes a profit. The Protocol's units don't vote."
- **batch**: "A batch is first announced with code names only. Qualified members get in {EARLY_ACCESS_HOURS} hours early, then seats open to everyone for {BATCH_WINDOW_HOURS / 24} days. The batch closes once every venture that ended has published its post-mortem." *Statuses:* Coming soon, Seats open, Closed.
- **sign-off**: "Other decisions are either taken by the agent on its own (and logged), or put to members first when the agent is unsure." *Example:* "Posting on X needs sign-off: the agent drafts the post, and the steward posts it."
- **ledger**: "Nothing is edited or deleted. The report and the units table are computed from it." *Example:* "Oct 5: @hvac_hank, distribution, 0.5 vested units × $51.75 = $25.88."
- **kill-rule**: "The steward can also shut a venture down at any time, with the reason recorded." *Example:* "No paying contractor by March 31, 2027."
- **post-mortem**: *Example:* "Chairside Shifts ended after 211 days because dental practices only trust hygienists they already know."
- **lesson**: "Written as a card: what happened, what we'll do differently, how sure we are, and what it applies to. If the agent plans something a lesson warns against, the decision needs more review." *Example:* "With small-business buyers, ask a member for an intro instead of cold email."
- **qualified**: "Link LinkedIn or X and the steward checks it matches what you told the agent. The public sees only a badge, never your account."
- **holder-vote**: "A vote needs at least {QUORUM_PCT}% of vested units to take part. Most votes pass with more than half; big ones need {SUPERMAJORITY}."
- **setting**: "Each one lists its reason and the Protocol request where people are discussing it." *Example:* "Seat price: $10."
- **constitution**: "Changing an article takes {CONSTITUTION_NOTICE_DAYS} days' notice and a two-thirds vote."
- **mark**: "Anyone qualified can report a breach; members vote and the steward confirms."

### 2.2 REPLACE (stop using in UI copy)

| Current term | Where it appears | Replace with |
|---|---|---|
| RFE | Code ids, routes, params `reason` text (`params.ts:70`) | "request". Keep `/rfe/` in URLs only. |
| Founding steward | Home, Steward, Member | "steward". Keep the title only on @MP's profile. |
| Announced / Live / Closed (batch) | Batch pills (`batch-ui.tsx:28`) | "Coming soon" / "Seats open" / "Closed" |
| Codename | Batches, Venture teaser | "code name", as plain English with no link |
| Liftoff | Venture roster title (`protocol-ui.tsx:96`) | remove |
| Liftoff roster, slot | Venture, Steward, decision text | "People this venture needs" and "spots" |
| Readiness, "Disclosures, never gates" | Venture (`protocol-ui.tsx:65-66`) | "Before you take a seat" |
| N, N rule, "raw", minimum vs target | `n-progress.tsx:12-13`, `n-engine.ts:121-145` | "answers needed", "4 of 4 answers (2 from similar profiles counted once)" |
| Auto / Advisory / Gated (bins) | Decision log, Steward, Report | "Agent decided" / "Asked members first" / "Needed sign-off". Keep `sign-off` as the linked term. |
| Bin, "moved up a bin" | Decision log, Learning | "needs more review" or "went to members" / "went to the steward" |
| Decision (as a jargon object) | everywhere | Fine as plain English. No link needed. |
| Classifier | params, code | "the sign-off rules". Not user-facing; keep it out of copy. |
| Kill (verb), Killed (status) | Status badge, buttons | "Ended" for the status, "Shut down" for the button. Keep `kill-rule`. |
| Kill signal | Thesis, post-mortems, lessons | "sign it isn't working", or fold into the kill rule |
| Kill switch | Venture kill rules (seeded), Steward section | "Shut down now" (button) / "Steward can shut it down any time" |
| Grant (noun) | Holdings, Request, Ledger | "units earned". Ledger kind: "Units earned". |
| Forfeit | Ledger | "Units taken back" |
| Seat slice, seat-holder slice | Venture, Seat, Holdings, Inbox | "units for qualified seat holders" |
| Cohort, cohort vehicle (slice) | Learning (`learning/page.tsx:179`), cap table, Report | "batch"; "batch-wide share (split among everyone active in the batch)" |
| Reserved matter(s) | Report (`report/page.tsx:117`), params | "Decisions only unit holders can make" |
| Supermajority, simple majority, quorum | Protocol, Request | Keep the words, but explain them inside the `holder-vote` popover, and show "needs 2/3" next to them. |
| Amendment, amend | Protocol, Inbox titles | "change" / "Change a setting: …" |
| Parameter(s) | Protocol, Request, footer | "setting(s)" (glossary term `setting`) |
| Qualification (noun) | Onboarding, Inbox | "getting verified" / "verification" |
| Verification weight(s), "bar 0.2" | Protocol request text, params | "how much each check counts" |
| Inherited lessons, "cited at spawn" | Venture (`protocol-ui.tsx:154`, `:167`) | "Lessons this venture starts with"; "used when it was proposed" |
| Repeat-mistake check, "Contradicts" | Decision log, bin reasons | "Goes against lesson L-005, so it needed more review" |
| Conduct screen, conduct flag | Decision log, Steward, Venture | "conduct check"; "Report a concern" |
| Escrow / held | Seat, Batches | "held, unspent" (plain) |
| Refund | everywhere | Plain English. No link. |
| Holdings | Nav, page title | "My units" |
| Formation, formed, series, series formation | Lifecycle, budget lines, grant notes | "Company set up"; budget line "Legal setup". Keep "series LLC" only in the counsel note. |
| Thesis, thesis card, Why this / Why us / Why an agent | Venture (`protocol-ui.tsx:30`) | "Why this could work" |
| Phenotype | Batches, Venture, Learning, Steward | **(classification change)** use the six classification labels |
| Profile cluster, "graph", member graph | Onboarding, Learning, phenotype text | "similar profiles"; "the members we have" |
| Profits interest(s) | Home, Holdings, Seat checkbox, Protocol | "profit share" (except the counsel line) |
| Distribution(s), distributing | Holdings, Ledger, status | "payout(s)"; status "Paying out profit" |
| Cap table | Venture (`v/[slug]/page.tsx:381`) | "Who holds units" |
| Minimum raise, raise, funded | Venture, Home, Learning, lessons | "minimum" / "seats sold" / "minimum met" |
| Treasury, unclaimed reserve | Report, params | "unclaimed units" |
| Pass-through costs | Report, venture report | "fixed costs taken off first (payment fees, bookkeeping, legal setup)" |
| Runway | Report, venture | "cash left" |
| Embargo, embargoed, redaction | Decision log, Ledger, Report | "Published later" / "withheld until {date}" |
| Tick, simulated clock | Footer, Steward | "Demo time" / "step". Steward page only. |
| Stakes | Request pills | "How much rides on it: low / medium / high" |
| Recruiting drafts, GTM, arrivals, attribution | Steward, Request, Learning | "Recruiting posts"; "people who joined from this post" |
| Objective (Revenue scale / Profitability / Exit) | Venture, Home | "Goal: grow first / pay out early / build to sell" |
| Demand check | Venture readiness | "'Would you buy this?' poll" |
| Stood / Right (Learning tables) | Learning | "Held up" |
| Reference implementation, open standard, registry | Home metadata, Protocol h1 | drop. Say "public rules and the software that runs them". |

---

## 3. Page-by-page copy audit

Format: `file:line`, then the current text, then the proposed rewrite. Paths are relative to `apps/venture/src/` unless they start with `packages/`. ⚠️ marks a page that lacks a plain explainer at the top.

### 3.0 Site-wide (layout, nav, shared components)

**Who sees it:** everyone, on every page.

- `app/layout.tsx:20` (meta description): "An open standard for agent-operated ventures, with a reference implementation and a public ledger."
  → "Small businesses run by AI agents. Buy a $10 seat, answer the agent's requests, earn a share of the profit."
- `app/layout.tsx:66` (footer): "Constitution v1.3 · Parameters v1.0 · A seat is access to requests, not an investment."
  → "Rules v1.4 · Settings v1.0 · A seat gets you requests. It is not a share and pays nothing back." Link "Rules" to `/protocol` and "Settings" to `/protocol#params`.
- `app/layout.tsx:69` (footer): "Simulated clock … · tick 0"
  → "Demo time: Oct 30, 12:00 PM UTC". Show "step 0" to the steward only.
- `app/layout.tsx:26-31` (nav): "Holdings", "Learning", "Protocol"
  → "My units", "Lessons", "Rules". Also add "Glossary", or a "?" link in the footer.
- `components/protocol-ui.tsx:18` `SEAT_DISCLAIMER`: "A seat is access to requests, not an investment."
  → "A seat gets you this venture's requests. It is not a share and pays nothing back." This changes the asserted string in `copy.test.ts:86` and the conduct finding at `conduct.ts:87`. Update both. It is repeated under every buy button, which is fine.
- `components/protocol-ui.tsx:19` `REFUND_GUARANTEE`: "Seat money is held until the minimum is met. If the minimum isn't met, every seat is refunded in full."
  → "We hold your money, unspent, until enough seats sell. If they don't sell by the deadline, you get it all back."
- `components/badges.tsx:40-49` (bin labels): Auto / Advisory / Gated
  → "Agent decided" / "Asked members first" / "Needs sign-off". The help text is good. Show it in the `<Term>` popover rather than only in `title`, because `title` doesn't work on touch.
- `packages/schema/src/states.ts:29-37` (status labels):
  - Generated → "Idea"
  - Raising seats → "Selling seats"
  - Funded → "Minimum met"
  - Formed → "Company set up"
  - Operating → keep
  - First customer → keep
  - Distributing profits → "Paying out profit"
  - Dormant → "Paused"
  - Killed → "Ended"
- `packages/schema/src/primitives.ts:22-28` (request types): keep the labels and fix two:
  - capital, "Seats in a micro-fundraise" → label "Seats", text "Seats the venture still needs to reach its minimum"
  - stewardship, "Sign-off on an irreversible decision" → "A sign-off the steward must give"
  - Also rename "Access" to "Introduction" and "Action" to "Task"; those are clearer.
- `packages/schema/src/primitives.ts:40-42` (objectives):
  - "Reinvest; distributions deferred. Interest value rides on growth or a sale." → "Grow first: profit is spent on growth, and payouts start later."
  - "Distribute profit early and often." → "Pay out early: most profit is paid to unit holders every quarter."
  - "Build to sell. Holders share value created after their grant." → "Build to sell: unit holders share in the sale price."
  - Rename the label "Objective" to "Goal".
- `app/not-found.tsx:12`: fine.
- `app/error.tsx:14`: "run `pnpm seed`" is developer-only. Show it only in dev.

### 3.1 Home `/`: `app/page.tsx`

**Who it's for:** a first-time visitor deciding whether this is worth $10.
**What they need:** what a venture is, what a seat gets them, how they earn, and what happens to their money. Today the hero has a headline and one paragraph of jargon. ⚠️ Add "How it works" (section 4.6) directly under the hero.

- `:94` "Pilot · scripted operator" → "Pilot: the agent follows a script for now". Show "+ Claude" only when it applies.
- `:96` "Answer requests from agent-run ventures. Get paid in a share of their profits." This is good. Keep it.
- `:100-102` "Each venture is run by an agent and a named steward under an eight-article constitution. A $10 seat gets you its requests: judgment calls, introductions, the things an agent can't do alone. Answer them and you earn a profits interest. Paying never earns one."
  → "An AI agent starts and runs each small business. A person, the steward, can stop it at any time. For $10 you get a seat: the agent sends you the questions it can't answer alone, like a judgment call or an introduction. Each answer earns units, a share of that business's profit. The $10 itself never earns anything, and you get it back if the business doesn't start."
- `:107` "Batch 002 is live" → "Batch 002: seats open now"
- `:111` "Read the constitution" → "Read the 8 rules"
- `:117-119` (stats) "Decisions logged" → "Public decisions"
- `:153` "announced: 3 codenames, early access …" → "Batch 003 is coming: 3 new ventures, names hidden until Nov 6. Verified members get in a day early."
- `:174-175` "Steward @MP (Founding Steward) · no protocol fee · every member can answer · 100% to contributors"
  → "Run by @MP. Any member can answer its questions. All of its units go to the people who answer."
- `seed.ts:148` (Protocol tagline): "The body that keeps the registry and ledger, collects the protocol fee and asks members its open questions."
  → "The organization that runs these rules. It keeps every venture's public record and asks members how the rules should work."
- `:187-188` "Earlier batches" / "Each venture has its own seats, cap table and kill rules. The dead ones publish what they learned."
  → "Past ventures" / "Each one has its own seats, units and shut-down rules. The ones that ended published what went wrong."
- `:32` (mark under each card): show it only when `!markWithdrawn()`, and link it with `<Term id="mark">`.
- `:62` "minimum raise" → "$170 of $300 needed"
- `:67` "Read the post-mortem" → "Read what went wrong"

### 3.2 Batches `/batches`: `app/batches/(index)/page.tsx`, `components/batch-ui.tsx`

**Who it's for:** visitors comparing what is open now.
**What they need:** what a batch is, the dates, and what "early access" means.

- `(index)/page.tsx:22-24` "The agent launches ventures in numbered batches of about 3, spread across phenotypes by what earlier batches learned. A batch is announced with codenames, opens to qualified members 24 hours early, and closes once every venture that died in it has published its post-mortem."
  → "New ventures come out in batches of about 3. Each batch is announced a week ahead with code names only. Verified members can take seats 24 hours before everyone else. Seats then stay open for 5 days. Any venture that doesn't sell enough seats in that time ends, and everyone is refunded." **(classification change)** delete "spread across phenotypes".
- `batch-ui.tsx:22` `NobodySelects`: "Unlike an accelerator batch, nobody selects these ventures. Members decide with seats, and buyers decide with a first purchase."
  This is a "not X, but Y" line. → "No one picks the winners. A venture goes ahead if enough people take seats, and keeps going if a customer pays." `copy.test.ts:79` asserts the old string. Update it.
- `batch-ui.tsx:42`, `:68` (phenotype name under the venture): **(classification change)** use e.g. "Construction · Small business · Subscription".
- `batch-ui.tsx:44` "Pitch revealed when seats open." / `:45` "Pitch and budget hidden until the window opens." Keep one: "Full plan shown when seats open."
- `batch-ui.tsx:83` "$300 to first customer" → "$300 budget to first customer"
- `batch-ui.tsx:93` "You hold a seat · inbox" → "You have a seat. Go to your requests"
- `batch-ui.tsx:101` "Early access: qualified members" → "Verified members only until {time}"
- `batch-ui.tsx:136-137` "3 ventures, codenames only. Qualified members get in 24 hours early …; the public window opens …"
  → "3 ventures, names hidden. Verified members can take seats from {early}; everyone else from {opens}."
- `batch-ui.tsx:142-143` "Seat money is held until each one meets its minimum; a venture that misses it ends and every seat is refunded in full."
  → "Your money is held until a venture sells enough seats. If it doesn't by the deadline, it ends and you get your money back."
- `batch-ui.tsx:146` "Every venture in it published its record." → "Every venture in it has published its results."
- `batch-ui.tsx:174` "Batch page" → "See batch details"

### 3.3 Batch detail `/batches/[n]`: `app/batches/[n]/page.tsx`

- `:44-45` "Slot allocation" / "Why the agent gave this batch's slots to these phenotypes."
  **(classification change)** → "Why these three" / "How the agent chose what kinds of venture to try this time."
- `packages/protocol/src/learning.ts:557` "Overdue: no slot in the last 3 batches (minimum 1 per rotation)" → "Not tried in the last 3 batches; every kind gets a turn."
- `learning.ts:564` "Exploration: tried 0 times so far" → "Never tried yet, so we're testing it."
- `learning.ts:576` "Outcomes: funded 1 of 1, 1 still alive (score 67%)" → "Tried once before: it sold its seats and is still running."
- `:64` "Written by the learning loop when the batch closed." → "Written by the agent when the batch closed."
- `:89-91` "Kill reason: no demand · reached Raising seats · 2 days to kill signal · cost $0" → "Why it ended: no buyers · Got as far as: selling seats · Ended after 2 days · Cost: $0"
- `packages/protocol/src/batches.ts:165` (auto post-mortem lesson): "The crowd passed on this one; the readiness panel and seat curve are the evidence." This is aphoristic.
  → "Not enough people took seats in the window. See the 'Before you take a seat' panel for what looked weak."
- `ideas.ts:118` (KESTREL teaser): "A record of the job that ends the argument about whether the job got done." Slop: it sounds clever and says nothing.
  → "Signed photo proof that a job was finished, for contractors who get paid late."
- `ideas.ts:149` (BASALT teaser): "Public tenders, filled out by people who've won them, until the software can." → "Help small firms fill out government bids, with members who've won them."
- `ideas.ts:180` (MERIDIAN teaser): "What every warehouse really charges to unload a truck, from people who pay it." This is concrete. Keep it.

### 3.4 Venture `/v/[slug]`: `app/v/[slug]/page.tsx`, `components/protocol-ui.tsx`, `components/decision-log.tsx`

**Who it's for:** someone deciding whether to take a seat, and seat holders checking progress.
**What they need:** what it sells and to whom, how many seats are left and the deadline, what they'd be asked to do, and what happens if it fails. ⚠️ The page has no summary. Add a three-line box under the tagline: "**What it is:** … **What you'd do:** answer questions about {customer}. **If it doesn't sell 30 seats by Nov 3:** you're refunded." Move the thesis, decision log and units table below the fold.

Teaser view:
- `:75-77` "The pitch, thesis and budget are revealed when early access opens on … Qualified members can take a seat then; everyone else from …" → "The full plan and budget appear on {date}. Verified members can take a seat then; everyone else a day later."
- `:84`, `:89` "What every {phenotype} venture must show" / "Kill signal: …" **(classification change)** delete.

Header:
- `:163` (mark): render only when `!markWithdrawn()`, with `<Term id="mark">`.
- `:164` (Protocol): "The body behind the Constitution and Parameters" → "The organization that runs these rules"
- `:173` (phenotype): **(classification change)**
- `:178` TagList: **(classification change)** "Stage reached: pitched" in the tag list duplicates the status badge. Hide it on live ventures.
- `:199` "Ledger" → "Public record"
- `:210` "Flag" (FlagForm label) → "Report a concern"

Post-mortem:
- `:222` "Post-mortem" → "What happened" (with the `post-mortem` term in the subtitle)
- `seed.ts:707` "It cost $180 of member seats and taught the next cohort something specific about credentialed labour." "Something specific" explains nothing.
  → "It spent $180 of seat money. The lesson: dental practices only use hygienists they already trust, so a marketplace of strangers can't fill same-day gaps."
- `:238-240` "Kill reason / Stage reached / Days to kill signal" → "Why it ended / Got as far as / Days until it was clear"
- `:243` "Draft: the steward publishes it before the batch closes" → "Draft. The steward will publish it before the batch closes."

Pitch card:
- `:262` "Written by the operating agent; steward @MP." → "Written by the agent. Steward: @MP."
- `:268-271` "Objective: … / Distribution policy: …" → "Goal: … / How profit is paid out: …"
- Lifecycle on the Protocol: hide `Lifecycle` and the seat counter when `venture.isProtocol` (top finding 5).

Seats card:
- `:282-283`: use the new `SEAT_DISCLAIMER` and `REFUND_GUARANTEE`.
- `:304` "$170 of $300 minimum raise at $10 a seat." → "17 of 30 seats sold ($170 of $300). Deadline: Nov 3."
- `:309-311` "Qualified seat holders share the 10-unit seat slice (0.33 units each). Earned by qualifying, not by paying."
  → "Get verified and you share 10 units with the other verified seat holders (about 0.33 each today)."
- `:312` "The rest is earned by answering requests: up to 15 units each." → "Most units are earned by answering requests. One request pays up to 15."
- `:322` "Early access is for qualified members; the public window opens …" → "Verified members only until {date}. Everyone else can take a seat after that."
- `:323` "This venture is closed and not selling seats." → "Seats are closed for this venture."

Thesis, readiness and roster (`protocol-ui.tsx`):
- `:30` "Thesis" → "Why this could work"
- `:34` "Phenotype: Unbundler. One job pulled out of a bloated suite." **(classification change)** delete.
- `:37` "Why the agent thinks this can work." This is fine as the fallback.
- `primitives.ts:115-120` THESIS_LABELS: "Why us" → "Who among members can help"; "Why an agent" → "Why an AI can run it"; "Kill signal" → "When we'd stop".
- `:65-66` "Readiness" / "Disclosures, never gates. Anything weak is for you to weigh before taking a seat." This is aphoristic.
  → "Before you take a seat" / "Four checks the agent runs on every idea. A warning doesn't block anything. It's for you to weigh."
- `packages/protocol/src/network.ts:193-196` "Budget coverage: 17 of 30 seats; ~24 plausible … Plausible = seats sold, plus qualified members who reach the buyer, plus a quarter of the rest."
  → "Seats: 17 of 30 sold. Likely to reach about 24, counting verified members who know the buyer and a quarter of everyone else."
- `network.ts:200` "Qualified reach to the buyer" → "Members who know the buyer"
- `network.ts:207` "Public demand check" → "'Would you buy this?' poll". `network.ts:210` repeats "Any qualified member can answer." twice in the rendered output. Remove one.
- `network.ts:214` "Lessons it contradicts: None / Checked against 6 adopted lessons with matching tags." → "Goes against past lessons: no. Checked against 6 lessons from similar ventures."
- `:96-98` "Liftoff roster" / "4 of 5 slots filled by qualified seat holders. Open slots become recruiting drafts the steward posts by hand."
  → "People this venture needs" / "4 of 5 spots filled. For open spots, the agent writes a recruiting post and the steward posts it."
- `:154-155` "What this venture inherited" / "Adopted lessons from earlier batches whose tags match this venture. The agent cites them in its decisions."
  → "Lessons it starts with" / "What earlier, similar ventures learned. The agent must follow these or explain why not." **(lesson cards)**
- `:167` "cited at spawn" → "used when proposed"
- `:175`, `:183` "Contradicts" / "Why this case differs" → "Goes against" / "The agent's reason this case is different". Keep this. It's good.

Requests and log:
- `:342` "What the agent needs from people right now." This is good.
- `:353` "Check back after the next tick." → "New requests appear as the agent works."
- `:375` "Every decision the agent takes, its bin and its reasoning. Embargoed items show only why and when they'll publish."
  → "Every decision, why the agent made it, and who had to approve it. A few are published later; for those you see why and when."
- `decision-log.tsx:105` "Why this bin:" → "Why it needed (or didn't need) approval:"
- `packages/protocol/src/classifier.ts:47` "No gate applies and confidence 76% clears the 70% threshold" → "Nothing here needs sign-off, and the agent is 76% sure (it asks members below 70%)."
- `classifier.ts:42` "Confidence 58% is below the 70% advisory threshold" → "The agent is only 58% sure, so it asked members first."
- `classifier.ts:35` "Posts publicly; a human posts, the agent drafts" → "Public post: the agent writes it, the steward posts it."
- `decision-log.tsx:116` "Contradicts L-005 · moved up a bin" → "Goes against L-005, so it needed more review"
- `decision-log.tsx:77`, `:82` "Embargoed decision / Reason: … Published in full on …" → "Published later: {reason}. Full text on {date}."
- `decision-log.tsx:128` "Conduct screen: stopped" → "Conduct check: blocked"
- `decision-log.tsx:143` "Decided by scripted operator" → "Decided by the agent (scripted)"
- `network.ts:146` "The network has a gap; a human posts the draft and arrivals are tracked to it." This is stacked jargon.
  → "No member fills this spot yet. The steward will post the draft, and we'll count who joins from it."
- `seed.ts:1035` "Every idea publishes a demand check next to its readiness panel. It is a disclosure for members deciding on seats, not a gate."
  → "Every idea gets a public 'Would you buy this?' poll so seat buyers can see real interest. A bad result doesn't stop the venture."
- `seed.ts:1008` "Spawn Permit Pulse (Unbundler) for Batch 002" → "Propose Permit Pulse for Batch 002"

Units table:
- `:381` "Cap table" / "Vested units vote and receive distributions. Parameters v1.0."
  → "Who holds units" / "Units that have vested get a vote and a share of each payout."
- `:389-390` "10% protocol fee to the Protocol, 90% to a 100-unit contributor pool." → "10 of 100 units go to the Protocol as its fee. 90 go to the people who do the work."
- Slice rows (from `economics.ts`):
  - "Seat holders (earned by onboarding)" → "Verified seat holders"
  - "Cohort vehicle" → "Everyone active in the batch"
  - "Request reserve" → "Answering requests"
  - The seat-slice wording "onboarding" vs "qualifying" is inconsistent. Use "verified" everywhere.

Budget and kill rules:
- `:429` "Budget to customer 1" → "Budget to first customer"
- `:440` "Minimum raise" → "Minimum (seats × $10)"
- Budget line "Series formation $60" (seed) → "Legal setup $60"
- `:448` "Kill rules" / "Pre-committed. The steward can also kill at any time, with the reason logged." → "When it shuts down" / "Set before launch. The steward can also shut it down at any time and must say why."
- Seeded kill rule "Steward kill switch" → "The steward can shut it down at any time"
- `:474-476` "Pass-through / Runway" → "Fixed costs / Cash left"

### 3.5 Take a seat `/v/[slug]/seat`: `app/v/[slug]/seat/page.tsx`, `seat-form.tsx`

**Who it's for:** someone about to pay.
**What they need:** exactly what $10 buys, what's still required after paying, and the refund. This page is the clearest on the site. Fix accuracy.

- `:44` "$10, once. It buys access to this venture's requests." → "$10, paid once. The agent will send you this venture's requests."
- `:45` "… Once the steward confirms it you're qualified, and you share the seat slice: about 0.33 units, vesting over 14 days."
  → "Next, a 2-minute interview and a LinkedIn or X link. Once the steward checks it, you can answer requests, and you get about 0.33 units for being a verified seat holder. Units become fully yours 14 days later." The current "vesting over" is wrong (top finding 3).
- Add a line here: "Until you're verified, you can see requests but not answer them." (top finding 4)
- `:46` "You can accept or counter every offer." → "Each request offers units. You can accept or ask for more."
- `:48` "You also join the Protocol and can answer its questions about how it runs." → "You can also answer questions about how these rules should work."
- Checkbox in `seat-form.tsx`: "I understand a seat is access to this venture's requests, not an investment. Any profits interest is earned by answering them."
  → "I understand a seat gets me this venture's requests. It is not a share and pays nothing back. I can only earn units by answering requests."
- `seat-form.tsx:41` "Pseudonymous. Shown on the ledger and cap table; your real name is never required." → "This is your public name here. You never have to give your real name."

### 3.6 Ledger `/v/[slug]/ledger`: `app/v/[slug]/ledger/page.tsx`

**Who it's for:** checkers and seat holders.
**What they need:** what each row type means. ⚠️ No row-type legend.

- `:52` "Append-only record of seats, refunds, grants, vesting, distributions and redactions. The report and cap table are computed from this."
  → "Every money and unit movement for this venture, in order. Nothing is ever edited or deleted. The report and the units table are calculated from this list."
- `:17-31` (kind labels):
  - Grant → "Units earned"
  - Vest → "Units vested"
  - Forfeit → "Units taken back"
  - Distribution → "Payout"
  - Redaction → "Withheld"
  - Amendment → "Setting changed"
  - Qualified → "Verified"
  - Breach → "Rule breach"
  - Notice → "Message"
- Row note, `ops.ts:187` and holdings: "Steward slice, granted when the series formed" → "Steward's units, given when the company was set up". This also fixes the duplicated "Steward slice · Steward slice …" on Holdings.
- Ledger note "2026-Q3: cohort vehicle" → "2026-Q3: batch-wide share"

### 3.7 Report `/v/[slug]/report`: `app/v/[slug]/report/page.tsx`

**Who it's for:** unit holders and the curious. ⚠️ Needs one line on what the report is.

- `:14` title "Quarterly report" → add "Every number on this page is calculated from the public record. The venture can't edit it."
- `packages/protocol/src/queries.ts:71` "Generated from the Agent Ventures ledger: revenue and costs as recorded by the Protocol as merchant of record; cap table from grants; nothing self-reported."
  → "Calculated from the public record. The Protocol takes customer payments for every venture, so revenue and costs aren't self-reported."
- `:59` "plus $410 pass-through" → "plus $410 fixed costs (payment fees, bookkeeping)"
- `:65` "Largest holder 8.5% of the contributor pool" → "Largest single holder: 8.5% of the units"
- `:71` "Request fill rates" → "Requests answered"
- `:101` "Decisions and governance" + "auto / advisory / gated / embargoed" → "Decisions" + "agent decided / asked members / needed sign-off / published later"
- `:117` "Reserved-matter changes" → "Unit-holder votes". The rendered row reads "conduct-flag. Dismissed by members. 14% of voted interest in favour, turnout 38% …" → "A concern about {X} was voted on: 14% agreed, so it was dismissed. 38% of units voted."
- `:131` "treasury 29.5 units" → "29.5 units not yet earned by anyone"

### 3.8 Request `/rfe/[id]`: `app/rfe/[id]/page.tsx`, `answer-form.tsx`, `components/n-progress.tsx`, `components/rfe-card.tsx`

**Who it's for:** a member answering.
**What they need:** what's being asked, why it matters, what they'll earn and when, and why they might be blocked. ⚠️ Add a one-line hint above the form, chosen by request type: "The agent has a guess (below). Tell it if you'd do something different, and why."

- `:61` "Recruiting drafts are posted by the steward by hand. The agent never posts or DMs." This is fine. Use "sends DMs".
- `:71` "Assigned to @x. Switch “view as” to answer." Demo only. Keep it.
- `:78-80` "Only qualified members answer requests. Link LinkedIn or X to qualify" → "Get verified to answer: link LinkedIn or X (2 minutes)."
- `:95` "@x has no vested units in {venture} yet, so has no vote weight on this one." → "You can vote once you have units that have vested in {venture}."
- `:108` "{stakes} stakes" → "How much rides on it: {stakes}"
- `:109` "Quorum reached" → "Enough answers in"
- `:115` "{asks}. Audience: {audience}." → "Who should answer: {audience}."
- `:126` "Cites L-001" → "Based on lesson L-001"
- `:144` "The agent's current answer" is good. Add "how sure it is: 80%".
- `:151-157` "Matter / Threshold: Supermajority (66.7%), quorum 30%" → "What's being decided / Passes if: 2 in 3 vote yes, and at least 30% of units vote"
- `:166` paramKey shown in code font (`ADVISORY_CONFIDENCE`) → show the setting's label ("Advisory threshold") and link it.
- `:210-213` "Attribution: 1 arrival, 1 qualified, 0 seats, 0 answers, 0 followed, 0 stood" → "From this post: 1 person joined, 1 got verified, 0 took seats."
- `:245` "Vote counted with weight 5." → "Your vote counted for your 5 vested units."
- `:248` "Collecting: 2 of 4 distinct responses. Your grant is issued when the request resolves." → "2 of 4 answers so far. You'll get your units when the request closes."
- `:276` "Offer: 2 units per contributor, vesting over 14 days." → "Pays 2 units to each person whose answer counts. They vest 14 days later." (top finding 3)
- `n-progress.tsx:12-13` "1/4 responses (2 raw)" → "1 of 4 answers counted (2 people answered, but their profiles are similar so they count once)". Put the explanation in a `<Term>`-style popover.
- `packages/protocol/src/n-engine.ts:130-145` reason strings:
  - "3 more distinct responses to the minimum" → "Needs 3 more answers from different kinds of people"
  - "Closed early: 75% agree at the minimum" → "Closed early: 3 of 4 agree"
  - "Responses diverge (50% agree); asking 2 more" → "Answers split 50/50, so the agent is asking 2 more people"
- `answer-form.tsx:263` "The offer" → "What you'll earn"
- `answer-form.tsx:288` "The agent accepts counters up to 1.5× the offer (3 units) when the request resolves; above that it pays the offer." → "You can ask for up to 3 units. Ask for more than that and you'll get the original 2."
- `answer-form.tsx:55` "Agent's pick" is good.
- `rfe-card.tsx:78` "Vote weighted by vested units" → "Vote: counts by vested units"
- `rfe-card.tsx:82` "Steward duty" → "For the steward"
- Inbox and Protocol request titles (seed): "Amend ADVISORY_CONFIDENCE from 0.7 to 0.6 (from L-007)" → "Ask members less often? Lower the 'ask first' bar from 70% to 60% sure". "Amend DEFAULT_EMBARGO_DAYS from 60 to 30" → "Publish private decisions after 30 days instead of 60?" Generate these from the setting's label, not its key (`ops.ts` / `learning.ts` amendment builder).
- Seeded legal request: "Legal structure: do profits interests for services stay compensatory?" This is exempt from the banned-words test and addressed to counsel. Add a plain subtitle: "For lawyers: does giving many people a share of profit for their work stay legal as designed?"

### 3.9 Inbox `/inbox`: `app/inbox/page.tsx`

**Who it's for:** members. ⚠️ No explainer for newcomers.

- `:45` "Requests for @MP, best fit first. Daily cap 10; answer from the web, by text or by voice." → "Questions picked for you, best match first. We'll send at most 10 a day. Answer by clicking, typing or speaking."
- `:20-21` "No member selected / Take a seat in a venture to get requests." → "No requests yet. Take a seat in a venture and the agent will start sending you its questions."
- `:64-67` "Requests reach qualified members only. … the steward confirms it." → "You'll get requests once you're verified. {Your link is waiting for the steward. | Link LinkedIn or X to start.}"
- `:82` "Seat slice granted: 0.33 in X, vesting over 14 days." → "You got 0.33 units in X for being a verified seat holder. They vest on {date}." (top finding 3)
- `:91-92` "Inbox zero / … a steward can advance the agent from the Steward page." → "You're all caught up. New requests arrive as the agents work." Show the steward hint only to the steward.
- `:131` "collecting" → "waiting for more answers"
- Seeded Protocol request text shown here: "A third of slots go to the least-tried phenotypes. Right shape?" **(classification change)** Also "Can idea generation be conditioned on the member graph?" → "Did the agent pick ideas our members can actually help sell?"
- Seeded "How does a member qualify…? LinkedIn counts 0.5, X 0.3, steward 0.2; the bar is 0.2." → "Right now a confirmed LinkedIn link is enough on its own; X needs the steward to check three things too. Is that the right bar?"

### 3.10 Onboarding / qualification `/onboarding`: `app/onboarding/page.tsx`, `interview.tsx`

**Who it's for:** new seat holders. The structure is good (two steps). Tighten the jargon.

- `:106` "Two steps: a short interview with the agent, then link an account for the steward to confirm." Good. Keep it.
- `:25` "2. Qualify: link an account" → "2. Get verified: link LinkedIn or X"
- `:28-29` "Only qualified members answer requests and fill roster slots. … Others see only a badge and how much of your profile is verified, never the account or your name."
  → "You need this to answer requests. The steward checks that your account matches what you told the agent. Other members only see a 'verified' badge, never your account or name."
- `:69-70` "Pilot: these are mock connections … (or LinkedIn's verification partner program)." Fine as a pilot note. Shorten to: "Pilot: no real LinkedIn or X connection is made. The steward checks each link by hand."
- `interview.tsx:193` "Profile graph" → "What the agent knows about you"
- `interview.tsx:224` "The agent uses this to route requests and to count similar profiles once, so one company can't outvote everyone." → "The agent uses this to send you the right questions. If several people from one company answer, they count as one, so no single company can outvote everyone."

### 3.11 Holdings `/holdings`: `app/holdings/page.tsx`

**Who it's for:** members checking what they've earned. ⚠️ Rename the page and add an explainer.

- `:25` "Holdings" → "My units"
- `:27-28` "@MP's seats and profits interests. Units vest 14 days after they're earned; vested units vote and receive distributions."
  → "Your seats and the units you've earned. Units vest 14 days after you earn them. Vested units get a vote and a share of each payout." This is the one accurate vesting line today. Make the others match it.
- `:33-36` "Grants / Distributions received" → "Times you earned units / Payouts received"
- `:65-66` "Of interests / Distributed" → "Share of venture / Paid to you"
- `:89` "Member" (the Protocol row) → "Member (no seat needed)"
- `:119` (slice names): "Seat slice (qualified)" → "Verified seat holder"; "Cohort slice" → "Batch-wide share"; "Founder's grant" → "Founding steward's units". Delete the duplicated `g.note` when it repeats the slice.

### 3.12 Member profile `/m/[handle]`: `app/m/[handle]/page.tsx`

- `:38` "Which attributes a linked account or the steward has verified. The accounts themselves are never shown." → "Which details have been checked, and how. The linked accounts are never shown."
- `:48` "4 answers · tier trusted" → "4 answers · Trusted member". Link "trusted" to the glossary, or drop it (calibration is a stub, `primitives.ts:208`).
- "Self-reported" (`protocol-ui.tsx:280`) is good.

### 3.13 Protocol `/protocol`: `app/protocol/page.tsx`

**Who it's for:** people checking the rules, and voters.
**Problem:** the h1 is a slogan. ⚠️ Lead with what the page is.

- `:28-29` "Constitution v1.3 / Parameters v1.0" → "Rules v1.4 · Settings v1.0"
- `:32` (h1) "An open standard for agent-operated ventures, with a reference implementation and a public ledger." → "The rules every venture follows"
- `:35-38` "The Protocol is the body: members answer its questions, the protocol fee goes to it, its holders vote, and it keeps the registry and ledger. Its Constitution is eight articles … Holders change parameters by a vote weighted by vested interest; articles change only by supermajority after 30 days' notice."
  → "These eight rules apply to every Agent Ventures venture. The numbers they depend on, like the seat price and the fee, are settings, listed below with the reason for each. Anyone with vested units in the Protocol can vote to change a setting. Changing a rule itself takes 30 days' notice and a two-thirds vote."
- `:41` "For counsel: compensatory profits interests in series LLCs, with a protocol fee to the management entity." Keep it for lawyers, but put it in a collapsed "Legal structure (for lawyers)" detail, not under the h1.
- `:46` "Articles" → "The 8 rules". Render the section 1 rewrites and auto-link terms in them (section 4.5).
- `:60-63` "Amendment votes / Weighted by vested units. Quorum 30%; simple majority over 50%, supermajority 66.7%." → "Votes on the rules / Each vote counts by vested units. A vote counts only if 30% of units take part. Most pass with more than half; rule changes need two-thirds."
- `:82` raw param key → the label
- `:102-104` "Parameters / Current values, with amendments applied. Each one points to the Protocol question where members can argue for a change." → "Settings / The current value of every number the rules use. Each links to the open question where you can argue for a change."
- `:137` "Governed by" → "Discuss it here:"
- `:160`, `:165` "Parameters v1.0 are the founding defaults …" / "Every parameter amendment bumps the Parameters version …" → "No settings have changed yet." / "Each change gets a new settings version and is recorded on the Protocol's public record."
- Param `reason` texts (shown in the table, `packages/schema/src/params.ts`):
  - `:87` "Founding steward's pilot choice. The build brief proposed 8%, the working model ~5%. Non-voting, pari passu." → "Chosen by the steward for the pilot (other drafts said 5–8%). The Protocol's units don't vote and are paid the same per unit as everyone's."
  - `:95` "Come off the top before any split." → "Paid before profit is shared out."
  - `:111` "… so it is earned by work, not by the $10 (Article 1). A placeholder until members vote on it." → "Shared by seat holders who finish the interview and get verified. That's work, so it fits Rule 1. Members can vote to change it."
  - `:127` "Cohort vehicle slice" → "Batch-wide share: split among everyone who answered any request that batch, so members help every venture."
  - `:134` "Granted for fulfilled requests. Ungranted reserve stays as treasury and accrues pro rata to holders at sunset." → "Paid out for answered requests. Units nobody earns stay unclaimed. If the venture closes, they're shared among holders by how many units each has."
  - `:151` "A grant vests once its input has stood for this long without being proven wrong." → "Units become fully yours this many days after you earn them." (top finding 3)
  - `:182` "Protects the mark from a venture spamming from a fresh domain." Good. Keep it.
  - `:188` "Keeps recruiting inside X's rules." Good.
  - `:195` "Below this self-reported confidence, the agent asks members before acting." Good.
  - `:212` "Working-model baselines. Capital uses the venture's minimum raise instead." → "Starting values. Seat requests use the venture's minimum instead."
  - `:248` "becomes a network gap" → "means no member fits, so the agent writes a recruiting post"
  - `:256` "A dud push is a churned member." This is an aphorism. → "Too many irrelevant requests make people leave."
  - `:437` "Exclusivity comes from timing, not gatekeeping." This is an aphorism. → "Verified members get a head start; nobody is shut out."
  - `:442-455` **(classification change)**: rename the phenotype params.
- `PARAM_GROUP_LABELS` (`params.ts:497-509`): "Economics" → "Money and units"; "Learning loop" → "Lessons".

### 3.14 Learning `/learning`: `app/learning/page.tsx`

**Who it's for:** curious members and voters. Currently the densest page. ⚠️ The intro is abstract. Rename to "Lessons".

- `:79-80` "Every venture's outcome feeds one shared record. At each kill, first customer and batch close, the agent writes lessons from it. Members adopt them by vote, and later ventures inherit the adopted ones. A decision that contradicts an adopted lesson moves up a bin."
  → "When a venture ends, gets its first customer, or finishes a batch, the agent writes down what it learned. Members vote on which lessons to keep. New ventures must follow kept lessons. If the agent wants to do something a lesson warns against, a person has to approve it first."
- `:86-87` "Outcomes by tag / Tags are proposed by the agent and confirmed by the steward. Slice the record by any axis." → "Results by type of venture / Compare ventures by market, customer, business model and more." **(classification change)**
- `:116`, `:156` "Funded" (column) → "Minimum met"
- `:120` "Median units" → "Typical units paid"
- `:147-148` "Phenotypes / Batch slots are allocated from these outcomes, with a floor per phenotype and an exploration share." **(classification change)** Delete the card, or → "Which kinds of venture we've tried, and how they did."
- `:179` "Each batch is a cohort. Its notes are written when it closes." → "Notes the agent wrote when each batch closed."
- `:203` "One sentence, one metric, linked evidence. Proposed lessons go to a Protocol vote." **(lesson cards)** → "Each lesson says what happened, what we'll do differently and how sure we are. Members vote before a lesson is kept."
- Lesson findings **(lesson cards)**. Quoted so the rewrite avoids these patterns:
  - `seed.ts:755` "cleared at 6–8 units" (market jargon) → "Introductions were usually paid 6–8 units."
  - `seed.ts:780` "Early dissent from buyer-side members was right in week two at Chairside; weight buyer-side answers above builders'…" (stacked nouns) → "At Chairside, the two members who actually buy staffing said early it wouldn't work, and they were right. Before a first customer, give buyers' answers more weight."
  - `seed.ts:789` "Threads that open with one real number from the ledger pull buyer-side members" → "Posts that start with a real number got buyers to join. Posts that start with the pitch didn't."
  - `seed.ts:812` "The idea the member graph could sell into … funded in 24 days" → "Dockside, where nine members work in freight, sold its seats in 24 days. Chairside, with two dental members, never found a buyer."
  - `seed.ts:824`: the "could batch" bug (top finding 2).
  - `learning.ts:290` metric "followed-and-right, freight-ops" → "Answers followed that held up"
  - `learning.ts:335` "{X} ideas funded 0 of 1." → "Tried once; didn't sell enough seats."
  - Metric line "advisory agreement, Batch 001 (curated): 1 share" means nothing. Drop the raw metric line from the cards.
  - "template" (`:214`, writtenBy) → "Written by: rule template" or hide it.
- `:241` "Proposes a parameter change: open the vote" → "This lesson suggests changing a setting. Vote on it."
- `:254` "Recruiting channels / Arrivals per posted draft, followed through to answers that stood." → "Which recruiting posts worked / How many people joined from each post, and how many gave answers that held up."
- `:293-294` "Who was right / Answers by profile cluster: how often the agent followed them, and how often they stood." → "Whose advice held up / By type of member: how often the agent took their advice, and how often it turned out right."
- `:325` "Median units paid and hours to fill, by request type." → "What each kind of request usually pays, and how fast it gets answered."
- `:353-354` "Vocabulary log / Every rename, merge and new value, so slices stay comparable over time." → "Label changes / Every time a category was renamed or merged, so old and new numbers still compare."

### 3.15 Steward `/steward`: `app/steward/page.tsx`

**Who it's for:** the steward only. Jargon matters less here, but it should still match the glossary.

- `:82-84` "signs gated decisions …, confirms members and tags, certifies flags." → "Approve risky decisions, verify members, confirm categories and confirm votes on reported concerns."
- `:93-97` "Advance the agent / Each tick moves the simulated clock 18 hours: grants vest, votes close …" → "Run the demo forward / Each step moves demo time 18 hours: units vest, votes close, batches open and close, demo members answer, and the agent takes its next step."
- `:107-109` "The agent allocates 3 slots across phenotypes …" **(classification change)** → "The agent picks 3 kinds of venture based on past results, writes hidden-name teasers, and drafts a post for you. Seats open 7 days later."
- `:120` "the public sees a badge and the verified share" → "the public sees a badge and how much is verified"
- `:182-183` "Gated queue / … and anything that contradicts an adopted lesson twice wait for you." → "Waiting for your sign-off / … and anything that goes against a kept lesson."
- `:224` "You certify that the result follows the constitution; an upheld flag becomes a public breach." → "Members vote on each reported concern. You confirm the vote was done by the rules. If upheld, it's recorded as a breach. 3 breaches and the venture loses the mark."
- `:265-266` "The agent proposes tags; nothing waits on them …" → "The agent suggests categories. Nothing waits on you. Confirm, or fix the value first. New values are added to the list and recorded." **(classification change)**
- `:323-324` "… including drafts to fill open roster slots …" → "… including posts to find people for open spots …"
- `:367-368` "Kill switch / Pre-committed kill rules are listed on each venture." → "Shut down a venture / Each venture lists its shut-down rules. You can also shut one down at any time; you must give a reason, and it's published."

---

## 4. Glossary UX proposal

### 4.1 Data: `packages/protocol/src/glossary.ts`

```ts
import type { ParamKey, ParamValues } from "@av/schema";

export interface GlossaryTerm {
  id: string;                 // anchor: /glossary#seat
  term: string;               // "Seat"
  aka?: string[];             // ["seats", "seat holder"] for auto-linking and the test
  short: string;              // one sentence, may contain {PARAM_KEY}
  long?: string;
  example?: string;
  see?: string[];             // related ids
  params?: ParamKey[];        // settings it depends on, linked on /glossary
}

export const GLOSSARY = [/* the 23 KEEP terms from section 2.1 */] as const satisfies readonly GlossaryTerm[];
export type TermId = (typeof GLOSSARY)[number]["id"];

/** Words replaced by plain language; the copy test bans them in UI strings. */
export const RETIRED_WORDS: { word: RegExp; use: string }[] = [
  { word: /\bphenotypes?\b/i, use: "classification labels" },
  { word: /\bliftoff\b/i, use: "People this venture needs" },
  { word: /\bcap table\b/i, use: "Who holds units" },
  { word: /\bminimum raise\b/i, use: "minimum" },
  { word: /\bfunded\b/i, use: "minimum met" },
  { word: /\bembargo(ed)?\b/i, use: "published later" },
  { word: /\bpari passu\b|\bpro rata\b/i, use: "same per unit" },
  /* … section 2.2 … */
];

export function termById(id: TermId): GlossaryTerm;
export function renderTerm(t: GlossaryTerm, params: ParamValues): { short: string; long?: string; example?: string };
```

- Export it from `packages/protocol/src/index.ts`.
- `renderTerm` fills `{SEAT_PRICE_USD}` and similar from live params. Definitions then stay correct after a vote, matching how `markFor` uses `MARK_TEMPLATE`.
- Agent copy (`packages/protocol/agent/script.ts`, `claude.ts`) can import `GLOSSARY` to give the model the house vocabulary in its system prompt, plus `RETIRED_WORDS` as "don't say".

### 4.2 `/glossary` page: `apps/venture/src/app/glossary/page.tsx`

- Server component. Lists terms alphabetically. Each term is an `<section id={t.id} className="scroll-mt-20 target:ring-2">`, reusing the pattern from `learning/page.tsx:207`.
- Each entry shows the term, short, long, example, "Related" links, and "Current setting: $10 (Seat price)" with a link to `/protocol#params`.
- At the top: a one-paragraph intro, then "How it works" (section 4.6) repeated, then A–Z jump links.
- Add "Glossary" to the footer, and to the nav on mobile.

### 4.3 `<Term id>` component: `apps/venture/src/components/term.tsx`

- A client component built on `@base-ui/react/popover`. Base UI is already a dependency (`tooltip.tsx:3`). Do not use Tooltip: tooltips don't open on tap.

```tsx
<Term id="seat">seat</Term>   // children optional; defaults to term.term
```

- **Trigger:** a `<button type="button">` styled `underline decoration-dotted decoration-zinc-400 underline-offset-[3px] cursor-help`, with `aria-describedby` pointing at the popup.
  - On desktop it opens on hover (`openOnHover`, `delay={150}`) and on focus.
  - On touch, the first tap opens it, and tapping outside or pressing Escape closes it.
  - The trigger is deliberately *not* a link, so a tap on mobile doesn't navigate away.
- **Popup:** `max-w-xs`, showing the term in bold, `short`, the `example` in muted text, and "More in the glossary →" linking to `/glossary#id`. Render it in a portal with `collisionPadding` so it stays on screen at 320px width.
- **Server data:** a server wrapper `TermServer` resolves `renderTerm(term, params)` and passes plain strings to the client component. That keeps `GLOSSARY` out of the client bundle and keeps definitions param-accurate.
- **No-JS fallback:** wrap the children in `<a href="/glossary#id">` inside `<noscript>`. Or render the trigger as a link and call `preventDefault` once hydrated.
- **Don't use it** in headings, buttons, badges, table headers or links. Use it in body text. For badges, show the definition in the same popover via `<Term id asChild>` around the badge instead of `title=`, which fails on touch (`badges.tsx:53`, `:73`, `:82`).

### 4.4 Tests

`packages/protocol/test/glossary.test.ts`:
1. Every `<Term id="…">` in `apps/venture/src/**/*.tsx`, found by regex `/<Term(?:Server)?\s+id="([a-z-]+)"/g`, exists in `GLOSSARY`. The `TermId` type also catches typos at typecheck time; the test catches dynamic ids.
2. Every `/glossary#id` link in the app and every `ARTICLES[n].terms` id exists.
3. Every term has `short` of 200 characters or fewer, ending with a period, with every `{PARAM}` placeholder a real `ParamKey`, and no banned or retired words in `short`, `long` or `example`.
4. Every `see` id resolves, and no two terms share an `id` or `aka`.
5. First use per page: for each `app/**/page.tsx`, no `TermId` appears more than once. This is a warning list with an allowlist, not a failure.

Extend `copy.test.ts`:
- Move `BANNED` into a shared `test/banned.ts`.
- Add a test that `RETIRED_WORDS` don't appear in `apps/venture/src`, `CONSTITUTION.md`, param `label` and `reason` fields, or seeded text. Exempt the legal request (`rfe-v0-legal-structure`) and the counsel line on `/protocol`.
- Add `\binvestment\b`, `\breturns?\b` (as in money back; consider `/\breturns? on\b/`), `\bfundrais/` and `\bfunded\b` to `BANNED`. That needs the disclaimer rewrite first.

### 4.5 Linking guidance

- **Link the first use on each page only,** in the page's explainer paragraph where possible. Repeat a link only if the next one is more than one screen away and the term is essential to the action, for example `seat` next to the buy button.
- Never link inside headings, buttons, pills or table headers.
- Link a term only where knowing it changes what the reader does. Don't link "venture" on the venture page.
- **Constitution:** give `Article` a `terms: TermId[]` field, and add a `linkTerms(text, ids)` helper in `apps/venture/src/lib/terms.tsx` that wraps the first match of each term or `aka` in `<Term>`. `renderConstitution` keeps plain text for the markdown.
- **Seeded or agent text** (decision reasoning, lesson cards): don't add markup. Run the same `linkTerms` over the lesson-card "applies to" and "topic" fields only, with a whitelist of terms.
- Keep the 23-term budget. Adding a 24th should mean retiring one, so the glossary doesn't grow without limit.

### 4.6 "How it works" for the home page (6 steps)

Place it under the hero on `/` as a numbered row, and repeat it on `/glossary`. Linked terms are shown in [brackets].

1. **An AI agent proposes a small business.** Each [venture] comes with its plan, its budget to a first customer, and the kinds of people it needs. New ones come out in [batches] of about three.
2. **Pick one and take a $10 [seat].** We hold your money, unspent. If the venture doesn't sell its [minimum] number of seats by the deadline, everyone gets a full refund.
3. **Tell the agent what you know, then get [verified].** A short chat about your work, plus a LinkedIn or X link the [steward] checks. This decides which questions you get.
4. **Answer [requests].** The agent asks for what it can't do alone: a judgment call, an introduction, a fact, a signature. Each request says how many [units] it pays.
5. **Your units become a share of the profit.** Units [vest] 14 days after you earn them. When the venture makes money, part of the profit is paid out to everyone with vested units, and units give you a vote on big decisions.
6. **Everything is public, and a person can stop it.** Every decision is on the venture's public [ledger]. The steward approves risky moves and can shut a venture down. Ventures that end publish a [post-mortem] so the next ones don't repeat the mistake.

---

## 5. Implementation checklist (in order)

1. **Fix the bugs found here.** These are independent of the copy work.
   - `packages/protocol/src/seed.ts:824`: "could batch" → "could be lowered". Then re-seed.
   - Make vesting copy describe a cliff: `seat/page.tsx:45`, `inbox/page.tsx:82`, `rfe/[id]/page.tsx:276`, `packages/schema/src/params.ts:151`.
   - Gate the mark on `markWithdrawn()` at `app/page.tsx:32`, `v/[slug]/page.tsx:163`, `seat/page.tsx:40`, `report/page.tsx:45`, and in `renderConstitution` if needed. Do this through a new `markForVenture(store, venture, params)` in `packages/protocol/src/params.ts` (or `flags.ts`) that returns `undefined` when withdrawn.
   - Hide the lifecycle and seat counter on the Protocol: `v/[slug]/page.tsx:273`, `:279-311`.
   - Remove the duplicate grant note on Holdings (`holdings/page.tsx:119-120`) and the duplicated "Any qualified member can answer." (`network.ts:210`).
2. **Add glossary data.** Create `packages/protocol/src/glossary.ts` with `GLOSSARY`, `TermId`, `RETIRED_WORDS` and `renderTerm`, and export them from `packages/protocol/src/index.ts`.
3. **Add glossary tests.** Create `packages/protocol/test/glossary.test.ts` and `packages/protocol/test/banned.ts`, and refactor `copy.test.ts` to import from `banned.ts`. Leave the `RETIRED_WORDS` check skipped until step 9.
4. **Build the UI pieces.**
   - `apps/venture/src/components/ui/popover.tsx`: a Base UI wrapper in the same style as `tooltip.tsx`.
   - `apps/venture/src/components/term.tsx`: client `Term` and server `TermServer`.
   - `apps/venture/src/lib/terms.tsx`: `linkTerms`.
   - `apps/venture/src/app/glossary/page.tsx`.
   - Footer and nav link in `app/layout.tsx` and `components/site-nav.tsx`.
5. **Rewrite the constitution.**
   - `packages/protocol/src/constitution.ts`: new preamble, the 8 articles with `terms`, the footer, version `1.4`, and `renderConstitution(params)`.
   - Regenerate with `pnpm --filter @av/protocol constitution` to produce `packages/protocol/CONSTITUTION.md`.
   - Update `packages/protocol/test/refunds.test.ts:25`. `transitions.test.ts:140` will pass after regenerating.
   - Update callers of `renderConstitution`: `packages/protocol/scripts/constitution.ts` and `transitions.test.ts:142`.
6. **Update shared strings and labels.**
   - `components/protocol-ui.tsx:18-19` (disclaimer and refund line), and the assertions in `copy.test.ts:79`, `:86`.
   - `components/batch-ui.tsx:22`.
   - `packages/protocol/src/conduct.ts:87`.
   - `packages/schema/src/states.ts:28-38` (status labels).
   - `packages/schema/src/primitives.ts:21-29`, `:39-43`, `:114-121`.
   - `components/badges.tsx:40-49`, and switch badge `title=` to the popover.
   - `app/v/[slug]/ledger/page.tsx:18-31`.
   - `packages/schema/src/params.ts` (labels, `reason` texts, `PARAM_GROUP_LABELS`).
7. **Rewrite computed copy in protocol code.**
   - `packages/protocol/src/classifier.ts:30-47` (bin reasons)
   - `n-engine.ts:121-145`
   - `network.ts:146`, `:190-221`
   - `learning.ts:290`, `:335`, `:557-576`
   - `batches.ts:162-174`, `:204`, `:218`
   - `ops.ts:187`, plus the amendment request title builder, so titles use setting labels instead of keys
   - `queries.ts:71`
   - Coordinate with the lesson-card rewrite and the classification change. Skip lesson and phenotype strings those changes replace.
8. **Rewrite page copy, one commit per page**, following section 3. Add a top explainer where marked ⚠️ and `<Term>` on first use.
   1. `app/page.tsx`: hero and How it works
   2. `app/v/[slug]/page.tsx`, plus `components/protocol-ui.tsx` and `components/decision-log.tsx`
   3. `app/v/[slug]/seat/page.tsx`, `seat-form.tsx`
   4. `app/rfe/[id]/page.tsx`, `answer-form.tsx`, `components/n-progress.tsx`, `components/rfe-card.tsx`
   5. `app/inbox/page.tsx`
   6. `app/onboarding/page.tsx`, `interview.tsx`
   7. `app/holdings/page.tsx`: rename the route title to "My units" (keep the URL)
   8. `app/batches/(index)/page.tsx`, `app/batches/[n]/page.tsx`
   9. `app/protocol/page.tsx`
   10. `app/learning/page.tsx`
   11. `app/v/[slug]/ledger/page.tsx`, `report/page.tsx`
   12. `app/m/[handle]/page.tsx`
   13. `app/steward/page.tsx`, `steward-forms.tsx`
   14. `app/layout.tsx`: metadata, footer and nav labels
9. **Rewrite seeded copy** in `packages/protocol/src/seed.ts` (taglines, post-mortem summaries, Protocol request titles and questions, decision reasoning) and `ideas.ts:118`, `:149` (teasers). Then re-seed and turn on the `RETIRED_WORDS` test from step 3.
10. **Feed agent copy.** In `packages/protocol/agent/claude.ts` and `script.ts`, import `GLOSSARY` and `RETIRED_WORDS` into the system prompt and drafting rules, so new agent text uses house terms.
11. **Verify.**
    - Run `pnpm --filter @av/protocol test` and the typecheck.
    - Crawl every route and grep the rendered text for `RETIRED_WORDS`, the same way this audit did.
    - Check on a 375px viewport that `<Term>` opens on tap and closes on outside tap or Escape, and that `/glossary#seat` scrolls to and highlights the entry.
12. **Process.** Post a Protocol governance request announcing constitution v1.4 (the wording change, plus the Article 4, 6 and 7 clarifications) with the 30-day notice. Record it in the change history.
