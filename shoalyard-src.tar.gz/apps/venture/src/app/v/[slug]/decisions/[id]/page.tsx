import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { atLeast, canReadLessons, decisionTier, decisionView } from "@av/protocol";
import { BinBadge } from "@/components/badges";
import { ConductNote, DecisionLessons, DecisionStatus, PrivateNotice, TierNote, modelLabel } from "@/components/decision-log";
import { FlagForm } from "@/components/protocol-forms";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { resolveVenture } from "@/lib/venture";
import { formatDate, formatDateTime, formatUsd } from "@/lib/format";

export const metadata: Metadata = { title: "Decision" };

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1 border-b border-zinc-100 py-2.5 last:border-0 sm:grid-cols-[10rem_1fr]">
      <dt className="text-xs font-medium text-zinc-500">{label}</dt>
      <dd className="text-sm text-zinc-800">{children}</dd>
    </div>
  );
}

export default async function DecisionPage(props: PageProps<"/v/[slug]/decisions/[id]">) {
  const { slug, id } = await props.params;
  const { store, params, member } = await getData();
  const venture = resolveVenture(store, slug, `/decisions/${id}`);
  const decision = store.decisions.find((d) => d.id === id && d.ventureId === venture.id);
  if (!decision) notFound();
  const tier = decisionTier(store, venture, member, params);
  const d = decisionView(store, decision, tier, params);
  const lessonsVisible = canReadLessons(member, params);
  const headline = (lid: string) => (lessonsVisible ? store.lessons.find((l) => l.id === lid)?.headline : undefined);
  const full = atLeast(tier, "unit holder");

  return (
    <div className="mx-auto max-w-3xl space-y-6" style={{ "--accent-color": venture.accent } as React.CSSProperties}>
      <Link href={`/v/${venture.slug}#log`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
        <ArrowLeft className="size-4" /> {venture.name}
      </Link>

      {d.redacted ? (
        <div className="space-y-3">
          <h1 className="text-2xl font-semibold tracking-tight">A private decision</h1>
          <p className="text-sm text-zinc-600">Decided by {d.decidedBy.charAt(0).toLowerCase() + d.decidedBy.slice(1)}.</p>
          <PrivateNotice d={d} />
        </div>
      ) : (
        <>
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
              <BinBadge bin={d.bin} />
              <DecisionStatus status={d.status} />
              <span>{formatDateTime(d.at)}</span>
            </div>
            <h1 className="text-2xl font-semibold tracking-tight">{d.title}</h1>
            <TierNote tier={tier} />
          </div>

          <Card>
            <CardContent>
              <dl>
                <Row label="Decided by">{d.decidedBy}</Row>
                {d.outcome && <Row label="Outcome">{d.outcome}</Row>}
                {d.takenAt && <Row label="Settled">{formatDateTime(d.takenAt)}</Row>}
                <Row label="Money">{d.spendUsd !== undefined ? formatUsd(d.spendUsd) : "None spent"}</Row>
                {d.private && <Row label={tier === "steward" ? "Private until" : "Was private until"}>{formatDate(d.private.until)} ({d.private.reason})</Row>}
                {d.rfeId && (
                  <Row label="Request">
                    <Link href={`/rfe/${d.rfeId}`} className="underline underline-offset-2">
                      The related request
                    </Link>
                  </Row>
                )}
                {d.summary && !full && <Row label="Why, in short">{d.summary}</Row>}
                {modelLabel(d.model) && <Row label="Agent">{modelLabel(d.model)}</Row>}
                {d.confidence !== undefined && <Row label="How sure">{Math.round(d.confidence * 100)}%</Row>}
              </dl>
            </CardContent>
          </Card>

          {full && (
            <Card>
              <CardHeader>
                <CardTitle>Reasoning</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-zinc-700">{d.reasoning}</p>
                {!!d.binReasons?.length && <p className="text-xs text-zinc-500">Why it did or didn&apos;t need approval: {d.binReasons.join("; ")}</p>}
                <DecisionLessons d={d} lessonsVisible={lessonsVisible} headline={headline} />
                <ConductNote d={d} />
                {d.stewardNote && <p className="text-sm text-zinc-700">Steward note: “{d.stewardNote}”</p>}
                {!!d.options?.length && (
                  <div>
                    <p className="text-xs font-medium text-zinc-500">Options put to members</p>
                    <ul className="mt-1 list-disc pl-5 text-sm text-zinc-700">
                      {d.options.map((o) => (
                        <li key={o}>
                          {o}
                          {o === d.recommendation ? " (recommended)" : ""}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {d.recommendation && !d.options?.includes(d.recommendation) && <p className="text-sm text-zinc-700">Recommended: {d.recommendation}</p>}
                {d.answers && (
                  <div>
                    <p className="text-xs font-medium text-zinc-500">
                      Members&apos; answers ({d.answers.length})
                    </p>
                    {d.answers.length > 0 ? (
                      <ul className="mt-1 space-y-1 text-sm text-zinc-700">
                        {d.answers.map((a) => (
                          <li key={`${a.handle}-${a.at}`}>
                            <Link href={`/m/${a.handle}`} className="font-medium hover:underline">
                              @{a.handle}
                            </Link>
                            : {a.answer}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="mt-1 text-sm text-zinc-500">No answers yet.</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {member?.qualification === "qualified" && d.status !== "rejected" && <FlagForm kind="decision" id={d.id} label={d.title ?? ""} />}
        </>
      )}
    </div>
  );
}
