import type { Member, MemberAttribute, Verification } from "@av/schema";

type Row = [
  handle: string,
  role: string,
  industry: string,
  seniority: Member["seniority"],
  cluster: string,
  companies: string[],
  buyingAuthority: string,
  tools: string[],
  verticals: string[],
  canReach: string[],
  tier: Member["reputationTier"],
];

const ROWS: Row[] = [
  ["dispatch_dana", "Operations lead", "Freight brokerage", "mid", "freight-ops", ["Mid-size brokerage, Memphis"], "Approves tools under $500/mo", ["McLeod", "DAT", "Google Sheets"], ["freight", "logistics"], ["Brokerage owners in the Mid-South"], "trusted"],
  ["lanehauler", "Owner-operator, 9 trucks", "Trucking", "executive", "freight-ops", ["Own fleet"], "Signs everything", ["Motive", "QuickBooks"], ["trucking", "freight"], ["Small carriers", "Factoring companies"], "contributor"],
  ["detention_dave", "Claims analyst", "Third-party logistics", "mid", "freight-ops", ["Regional 3PL"], "Recommends", ["Excel", "Salesforce"], ["logistics", "claims"], ["3PL claims teams"], "contributor"],
  ["tms_tara", "Product manager", "TMS software", "senior", "saas-gtm", ["Freight TMS vendor"], "Influences vendor partnerships", ["Jira", "Amplitude"], ["freight software", "saas"], ["TMS product teams", "Broker customers"], "trusted"],
  ["ratecon", "Carrier sales rep", "Freight brokerage", "early", "freight-ops", ["Large brokerage, Chicago"], "None", ["DAT", "Truckstop"], ["freight"], ["Carrier dispatchers"], "new"],
  ["permitpro", "Estimator", "Roofing contractor", "mid", "construction-sales", ["Roofing contractor, Phoenix"], "Recommends lead sources", ["AccuLynx", "EagleView"], ["roofing", "construction"], ["Roofing sales managers in Arizona"], "new"],
  ["hvac_hank", "Sales director", "HVAC contracting", "senior", "construction-sales", ["Commercial HVAC contractor, Dallas"], "Owns a $40k lead budget", ["ServiceTitan", "HubSpot"], ["hvac", "construction"], ["HVAC owners in Texas"], "trusted"],
  ["bidboard", "Business development", "General contracting", "mid", "construction-sales", ["Mid-size GC, Atlanta"], "Recommends", ["Procore", "BuildingConnected"], ["construction", "permits"], ["Subcontractor networks"], "new"],
  ["gis_greta", "GIS analyst", "County government", "mid", "data-eng", ["County planning office"], "None", ["ArcGIS", "PostGIS", "Python"], ["permits", "public data"], ["County data offices"], "contributor"],
  ["scrapewright", "Data engineer", "Proptech", "senior", "data-eng", ["Property data startup"], "Picks data vendors", ["Airflow", "Playwright", "dbt"], ["real estate data", "permits"], ["Data vendors"], "trusted"],
  ["hygienist_hal", "Dental hygienist", "Dental care", "mid", "dental-ops", ["Group practice, Denver"], "None", ["Dentrix"], ["dental"], ["Hygienists in Colorado"], "contributor"],
  ["ops_odile", "Practice manager", "Dental support organisation", "senior", "dental-ops", ["DSO with 14 practices"], "Approves staffing spend", ["Dentrix", "Gusto"], ["dental", "healthcare staffing"], ["Practice managers"], "contributor"],
  ["counsel_kemi", "Securities lawyer", "Law", "senior", "legal-counsel", ["Boutique securities firm"], "Advises", ["Westlaw"], ["securities", "LLC law"], ["Entity formation lawyers"], "trusted"],
  ["llc_lena", "Corporate paralegal", "Law", "mid", "legal-counsel", ["Formation services firm"], "None", ["Clio"], ["entity formation", "series LLC"], ["Registered agents"], "contributor"],
  ["growth_gus", "Growth marketer", "B2B SaaS", "mid", "saas-gtm", ["Seed-stage SaaS"], "Owns paid budget", ["HubSpot", "Clay"], ["saas", "growth"], ["Indie founders on X"], "new"],
  ["coldcall_cass", "SDR manager", "B2B SaaS", "mid", "saas-gtm", ["Series B SaaS"], "Approves outbound tools", ["Outreach", "Apollo"], ["sales", "saas"], ["SDR leaders"], "contributor"],
  ["bookkeep_bo", "Bookkeeper", "Small-business finance", "mid", "finance-ops", ["Own practice, 30 clients"], "Recommends to clients", ["QuickBooks", "Xero"], ["bookkeeping", "small business"], ["Trucking and trades owners"], "contributor"],
  ["cfo_ines", "Fractional CFO", "Finance", "executive", "finance-ops", ["Four seed-stage startups"], "Signs vendor contracts", ["NetSuite", "Ramp"], ["finance", "saas"], ["Founders", "Controllers"], "trusted"],
  ["vc_scout_ray", "Startup scout", "Accelerators", "senior", "startup-scout", ["Accelerator program"], "Recommends", ["Notion", "Affinity"], ["startups", "fintech"], ["Accelerator founders", "Angel networks"], "contributor"],
  ["maker_mo", "Indie developer", "Software", "mid", "generalist", ["Self-employed"], "Own money only", ["Next.js", "Supabase"], ["tools", "automation"], ["Indie hackers"], "contributor"],
  ["policy_pia", "Researcher", "Platform governance", "senior", "governance", ["University lab"], "None", ["R", "Zotero"], ["governance", "cooperatives"], ["Co-op researchers"], "trusted"],
  ["ux_uma", "Product designer", "Fintech", "mid", "design", ["Payments startup"], "Influences", ["Figma"], ["fintech", "design"], ["Design leads"], "contributor"],
  ["ml_milo", "ML engineer", "AI startup", "senior", "data-eng", ["Applied AI company"], "Picks model vendors", ["PyTorch", "Claude"], ["ai", "data"], ["ML teams"], "contributor"],
  ["quiet_quinn", "Retired VP of operations", "Freight and logistics", "executive", "freight-ops", ["Former top-50 3PL"], "Board seats", ["—"], ["logistics", "freight"], ["3PL executives", "Shippers"], "trusted"],
  ["roofer_rita", "Owner", "Roofing", "executive", "construction-sales", ["Roofing company, Tampa"], "Signs everything", ["JobNimbus"], ["roofing"], ["Roofing owners in Florida"], "new"],
];

export const LATE_ARRIVALS: Record<string, { joinedAt: string; source: string }> = {
  growth_gus: { joinedAt: "2026-08-12T15:00:00.000Z", source: "rfe-v0-gtm-launch" },
  permitpro: { joinedAt: "2026-10-28T22:00:00.000Z", source: "rfe-permit-pulse-gtm-launch" },
  roofer_rita: { joinedAt: "2026-10-29T14:00:00.000Z", source: "rfe-permit-pulse-gtm-launch" },
  bidboard: { joinedAt: "2026-10-29T20:00:00.000Z", source: "rfe-permit-pulse-gtm-launch" },
};

/** Members still waiting on the steward, so the verification queue has work in it. */
export const PENDING_MEMBERS: Record<string, { linkedin?: string; x?: string }> = {
  roofer_rita: { linkedin: "https://www.linkedin.com/in/example-roofing-owner" },
  bidboard: { linkedin: "https://www.linkedin.com/in/example-gc-bizdev", x: "bidboard" },
};

/** Members who linked only X, so their profile shows a partial verified share. */
const X_ONLY = new Set(["growth_gus", "maker_mo", "ratecon"]);
const NO_X = new Set(["quiet_quinn", "hygienist_hal", "counsel_kemi", "llc_lena", "ops_odile"]);

const LINKEDIN_ATTRS: MemberAttribute[] = ["role", "company", "seniority", "industry"];
const X_ATTRS: MemberAttribute[] = ["handle", "reach"];

function verificationsFor(handle: string, at: string, stewardHandle: string): Verification[] {
  const out: Verification[] = [];
  const pending = PENDING_MEMBERS[handle];
  if (pending) {
    if (pending.linkedin) {
      out.push({ id: `ver-${handle}-li`, source: "linkedin", ref: pending.linkedin, attributes: LINKEDIN_ATTRS, status: "pending", requestedAt: at });
    }
    if (pending.x) out.push({ id: `ver-${handle}-x`, source: "x", ref: `@${pending.x}`, attributes: X_ATTRS, status: "pending", requestedAt: at });
    return out;
  }
  const done = { status: "confirmed" as const, requestedAt: at, decidedAt: at, decidedBy: stewardHandle };
  if (!X_ONLY.has(handle)) {
    out.push({ id: `ver-${handle}-li`, source: "linkedin", ref: `https://www.linkedin.com/in/example-${handle}`, attributes: LINKEDIN_ATTRS, ...done });
  }
  if (!NO_X.has(handle)) out.push({ id: `ver-${handle}-x`, source: "x", ref: `@${handle}`, attributes: X_ATTRS, ...done });
  if (X_ONLY.has(handle)) {
    out.push({ id: `ver-${handle}-st`, source: "steward", ref: "Interview reviewed by the steward", attributes: ["role", "company", "industry"], ...done });
  }
  return out;
}

export function seedMembers(stewardHandle: string, start: string): Member[] {
  const steward: Member = {
    handle: stewardHandle,
    role: "Founding Steward",
    industry: "Venture building",
    seniority: "executive",
    reputationTier: "trusted",
    cluster: "steward",
    profile: {
      companies: ["Shoalyard"],
      buyingAuthority: "Steward sign-off on gated decisions",
      tools: ["Claude", "Cursor"],
      verticals: ["venture building", "governance"],
      canReach: ["Founders", "Counsel", "Early members"],
    },
    dailyPushCap: 10,
    onboardedAt: start,
    qualification: "qualified",
    qualifiedAt: start,
    verifications: verificationsFor(stewardHandle, start, stewardHandle),
    joinedAt: start,
  };
  const members = ROWS.map(([handle, role, industry, seniority, cluster, companies, buyingAuthority, tools, verticals, canReach, tier]) => {
    const late = LATE_ARRIVALS[handle];
    const joinedAt = late?.joinedAt ?? start;
    return {
      handle,
      role,
      industry,
      seniority,
      reputationTier: tier,
      cluster,
      profile: { companies, buyingAuthority, tools, verticals, canReach },
      dailyPushCap: 3,
      onboardedAt: joinedAt,
      qualification: PENDING_MEMBERS[handle] ? ("pending" as const) : ("qualified" as const),
      qualifiedAt: PENDING_MEMBERS[handle] ? undefined : joinedAt,
      verifications: verificationsFor(handle, joinedAt, stewardHandle),
      joinedAt,
      source: late?.source,
      simulated: true,
    } satisfies Member;
  });
  return [steward, ...members];
}

export const EARLY_HANDLES = ROWS.map((r) => r[0]).filter((h) => !LATE_ARRIVALS[h]);
