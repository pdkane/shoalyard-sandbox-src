import { UserRound } from "lucide-react";

/** Marks a page as being about the person viewing, not the site. */
export function AccountLabel() {
  return (
    <p className="mb-1 inline-flex items-center gap-1 text-xs font-medium tracking-wide text-zinc-500 uppercase">
      <UserRound className="size-3.5" aria-hidden />
      Your account
    </p>
  );
}
