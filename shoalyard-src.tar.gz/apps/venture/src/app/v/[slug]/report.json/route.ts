import { buildReport, decisionTier, decisionViews, isRevealed, lookupVenture } from "@av/protocol";
import { getData } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: RouteContext<"/v/[slug]/report.json">) {
  const { slug } = await ctx.params;
  const { store, params, member } = await getData();
  const found = lookupVenture(store, slug);
  if (!found || !isRevealed(store, found.venture)) return Response.json({ error: "Venture not found" }, { status: 404 });
  const { venture } = found;
  if (found.canonical !== slug) return Response.redirect(new URL(`/v/${found.canonical}/report.json`, req.url), 307);
  const tier = decisionTier(store, venture, member, params);
  const entries = decisionViews(store, venture, tier, params).map((d) => ({
    id: d.id,
    at: d.at,
    bin: d.bin,
    status: d.status,
    redacted: d.redacted,
    private: d.private,
    title: d.title,
    decidedBy: d.decidedBy,
    outcome: d.outcome,
    spendUsd: d.spendUsd,
    summary: d.summary,
    reasoning: d.reasoning,
    confidence: d.confidence,
    lessonIds: d.lessonIds,
    answers: d.answers,
  }));
  const report = { ...buildReport(store, venture, params), decisionLog: { viewerTier: tier, entries } };
  const quarter = report.quarter.replace(/[^\w-]/g, "") || "pre-revenue";
  return Response.json(report, {
    headers: { "Content-Disposition": `attachment; filename="${venture.slug}-${quarter}.json"` },
  });
}
