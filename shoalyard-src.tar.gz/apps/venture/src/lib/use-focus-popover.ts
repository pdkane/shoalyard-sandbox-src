import { useRef, useState, type FocusEvent } from "react";

/**
 * Open state for a popover that also opens on keyboard focus. When it closes
 * (Escape, outside tap) focus returns to the trigger; that return must not
 * reopen it, or Escape would appear to do nothing.
 */
export function useFocusPopover() {
  const [open, setOpen] = useState(false);
  const closedAt = useRef(0);
  return {
    open,
    onOpenChange: (next: boolean) => {
      if (!next) closedAt.current = Date.now();
      setOpen(next);
    },
    onFocus: (e: FocusEvent<HTMLElement>) => {
      if (Date.now() - closedAt.current < 400) return;
      if (e.currentTarget.matches(":focus-visible")) setOpen(true);
    },
  };
}
