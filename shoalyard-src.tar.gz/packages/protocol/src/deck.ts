import type { Claim, ClaimBasis, ParamValues, PitchDeck, ProofPlan, RosterRoleKey, SeatPlan, Slide, SlideKey, Store, Venture } from "@av/schema";
import { SLIDE_TITLES } from "@av/schema";
import { quotedLessons, screenText } from "./conduct";
import { activeSeats, logDecision, notify, ProtocolError, seatHolders } from "./ops";
import { resolveParams } from "./params";
import { checkPriceProposal, heuristicSeatPrice } from "./seat-price";
import { legacySeatPlan, priceBand, rosterPlan, seatPlanFor, type RoleHint } from "./sizing";
import { classificationOf } from "./tags";
import { checkOperability, operableProof, proofRosterErrors } from "./proof";
import { proofPlanFor } from "./proof-plans";

/** What the operating agent (or the script) writes. Code adds the seat plan, the roster and the ask. */
export interface DeckDraft {
  purpose: string;
  slides: Slide[];
  market?: PitchDeck["market"];
  alternatives: PitchDeck["alternatives"];
  pricing: PitchDeck["pricing"];
  budget: PitchDeck["budget"];
  plan?: PitchDeck["plan"];
  contractors: PitchDeck["contractors"];
  requestPlan: PitchDeck["requestPlan"];
  milestones: PitchDeck["milestones"];
  killCriteria: PitchDeck["killCriteria"];
  premortem: PitchDeck["premortem"];
  primaryMetric: PitchDeck["primaryMetric"];
  motions: string[];
  needsIntegration: boolean;
  hints: Partial<Record<RosterRoleKey, RoleHint>>;
  /** The agent's proposed seat price and why. Code keeps it inside the band, or falls back to the pricing rule. */
  seatPrice?: { priceUsd: number; claims: Claim[] };
  /** Who runs each proof task. Absent: the plan written for this venture, if there is one. */
  proof?: ProofPlan;
}

/**
 * The office-hours questions every deck answers before it asks for seats:
 * what buyers do today, who exactly buys, the job, what anyone has
 * committed, the narrowest wedge, and what changed since others tried.
 */
export const OFFICE_HOURS: { claimId: string; slide: SlideKey; question: string }[] = [
  { claimId: "c-status-quo", slide: "problem", question: "What do buyers do today, and what does it cost them?" },
  { claimId: "c-named-buyer", slide: "problem", question: "Who exactly buys: their role, and what happens to them if this goes wrong?" },
  { claimId: "c-job-story", slide: "problem", question: "When ___, I want to ___, so I can ___." },
  { claimId: "c-demand", slide: "demand", question: "What has anyone committed: money, time or a workflow? Interest doesn't count." },
  { claimId: "c-wedge", slide: "solution", question: "What's the smallest thing someone pays for, soon after formation?" },
  { claimId: "c-cannot-do", slide: "solution", question: "What can't the agent do, and which person does it?" },
  { claimId: "c-prior-attempts", slide: "whyNow", question: "Who tried this before, and why did they stop?" },
  { claimId: "c-what-changed", slide: "whyNow", question: "What changed since then?" },
];

const ROLE_WORDS = /\b(owner|lead|manager|director|head|officer|coordinator|dispatcher|estimator|clerk|founder|operator|builder|controller|partner|engineer|administrator|buyer)s?\b/i;
const INTEREST_ONLY = /\b(waitlist|sign-?ups?|interested|excited|enthusias\w*|seats? (sold|taken)|members? (liked|loved))\b/i;
const LESSON_ID = /\bL-\d{3}\b/;

export function allClaims(deck: Pick<PitchDeck, "slides">): Claim[] {
  return deck.slides.flatMap((s) => s.claims);
}

export function claimById(deck: Pick<PitchDeck, "slides">, id: string): Claim | undefined {
  return allClaims(deck).find((c) => c.id === id);
}

export function slideOf(deck: Pick<PitchDeck, "slides">, claimId: string): SlideKey | undefined {
  return deck.slides.find((s) => s.claims.some((c) => c.id === claimId))?.key;
}

export function basisCounts(deck: Pick<PitchDeck, "slides">): Record<ClaimBasis | "disproved", number> {
  const out = { evidence: 0, estimate: 0, assumption: 0, disproved: 0 };
  for (const c of allClaims(deck)) {
    if (c.disproved) out.disproved++;
    else out[c.basis]++;
  }
  return out;
}

/** Every text field a deck shows, for the conduct and banned-word screens. */
export function deckText(deck: Pick<DeckDraft, "purpose" | "slides" | "alternatives" | "killCriteria" | "premortem" | "milestones" | "budget" | "contractors">): string[] {
  return [
    deck.purpose,
    ...deck.slides.flatMap((s) => [s.headline, ...s.claims.flatMap((c) => [c.text, c.method ?? "", c.test?.how ?? ""])]),
    ...deck.alternatives.map((a) => a.name),
    ...deck.killCriteria.map((k) => k.condition),
    ...deck.premortem.map((p) => p.way),
    ...deck.milestones.map((m) => `${m.label} ${m.metric}`),
    ...deck.budget.map((b) => b.label),
    ...deck.contractors.map((c) => `${c.job} ${c.per}`),
  ].filter(Boolean);
}

/** Regulated activities the deck touches; each one adds counsel to the roster. */
export function regulatedIn(draft: DeckDraft, params: ParamValues): string[] {
  return [...new Set(deckText(draft).flatMap((t) => screenText({ text: t }, params).regulated))];
}

/**
 * The claim rules. Deterministic: a deck that fails is not published.
 * Returns plain sentences, one per problem.
 */
export function validateDeck(store: Store, venture: Venture, draft: DeckDraft, params: ParamValues = resolveParams(store)): string[] {
  const errors: string[] = [];
  const claims = allClaims(draft);
  const ids = new Set<string>();
  const exists: Record<string, (ref: string) => boolean> = {
    rfe: (r) => store.rfes.some((x) => x.id === r),
    decision: (r) => store.decisions.some((x) => x.id === r),
    ledger: (r) => store.ledger.some((x) => x.id === r),
    lesson: (r) => store.lessons.some((x) => x.id === r),
    "member-answer": (r) => store.rfes.some((x) => x.id === r),
  };
  for (const c of claims) {
    if (ids.has(c.id)) errors.push(`Claim ${c.id} appears twice.`);
    ids.add(c.id);
    if (c.basis === "evidence") {
      if (!c.sources.length) errors.push(`${c.id}: evidence needs a source.`);
      for (const s of c.sources) {
        if (s.kind === "public-data" && !s.verified) errors.push(`${c.id}: unchecked public data can back an estimate, not evidence.`);
      }
    }
    for (const s of c.sources) {
      if (s.kind !== "public-data" && !exists[s.kind]?.(s.ref)) errors.push(`${c.id}: source ${s.ref} isn't on the record.`);
    }
    const rows = c.sources.filter((s) => s.kind === "ledger").map((s) => store.ledger.find((l) => l.id === s.ref));
    if (c.value?.unit === "usd" && rows.length === 1 && rows[0]?.usd !== undefined && Math.abs(rows[0].usd) !== c.value.n) {
      errors.push(`${c.id}: says $${c.value.n} but the ledger row shows $${Math.abs(rows[0].usd)}.`);
    }
    if (c.basis === "estimate" && !c.method) errors.push(`${c.id}: an estimate needs its method.`);
    if (c.basis === "assumption" && !c.test?.how) errors.push(`${c.id}: an assumption needs a test.`);
    if (LESSON_ID.test(c.text)) errors.push(`${c.id}: cite lessons as sources, not in the text; lesson text is for members.`);
  }
  for (const q of OFFICE_HOURS) {
    if (!draft.slides.find((s) => s.key === q.slide)?.claims.some((c) => c.id === q.claimId)) errors.push(`Missing ${q.claimId} on ${SLIDE_TITLES[q.slide]}: ${q.question}`);
  }
  const buyer = claimById(draft, "c-named-buyer");
  if (buyer && !ROLE_WORDS.test(buyer.text)) errors.push("c-named-buyer names a category, not a person's role. You can't email a category.");
  const demand = claimById(draft, "c-demand");
  if (demand) {
    if (INTEREST_ONLY.test(demand.text)) errors.push("c-demand counts interest. Only commitments count as demand: money paid, time given or a workflow built.");
    if (demand.basis === "evidence" && !demand.sources.some((s) => s.kind === "ledger" || s.kind === "rfe" || s.kind === "decision")) {
      errors.push("c-demand: demand evidence must point at a commitment on the record.");
    }
  }
  if (draft.slides.some((s) => s.key === "ask")) errors.push("The ask is computed from the seat plan and roster; the draft can't write it.");
  if (draft.market) {
    const v = (id: string) => claimById(draft, id)?.value?.n;
    const [tam, sam, som] = [v(draft.market.tam), v(draft.market.sam), v(draft.market.som)];
    if (tam === undefined || sam === undefined || som === undefined) errors.push("Market: TAM, SAM and SOM each need a claim with a value.");
    else if (!(som <= sam && sam <= tam)) errors.push("Market: the obtainable share must fit inside the serviceable market, and that inside the total.");
    for (const id of draft.market.steps) if (!ids.has(id)) errors.push(`Market step ${id} has no claim.`);
  }
  if (draft.alternatives.length < 2) errors.push("Alternatives: name at least two, including what buyers do instead.");
  if (!draft.alternatives.some((a) => a.kind === "do-nothing" || a.kind === "workaround")) errors.push("Alternatives: include the workaround or doing nothing; the status quo is the real competitor.");
  if (!ids.has(draft.pricing.claimId)) errors.push("Pricing needs its claim.");
  for (const b of draft.budget) if (!ids.has(b.claimId)) errors.push(`Budget line ${b.key} needs its claim.`);
  for (const b of draft.budget) {
    if (b.monthlyUsd !== undefined && draft.plan && b.usd !== b.monthlyUsd * draft.plan.proofMonths) errors.push(`Budget line ${b.key}: $${b.monthlyUsd} a month for ${draft.plan.proofMonths} months isn't $${b.usd}.`);
  }
  if (draft.plan) {
    const p = draft.plan;
    for (const [what, id] of Object.entries(p.claims)) if (id && !ids.has(id)) errors.push(`The business plan's ${what} input needs its claim (${id}).`);
    if (!(p.proofMonths >= 1 && p.proofMonths <= p.horizonMonths)) errors.push("The proof phase has to fit inside the plan.");
    if (p.leadToPaid !== undefined && !p.claims.conversion) errors.push("A plan that sets its own conversion needs a claim for it.");
  }
  const level2 = classificationOf(venture).workDelivery === "Agent plus contractors";
  if (level2 && !draft.contractors.length) errors.push("A venture that pays contractors shows its labour costs and contractor plan.");
  if (!level2 && draft.contractors.length) errors.push("An agent-only venture has no contractor plan.");
  const paid = draft.contractors.filter((c) => c.paidFrom === "seat money").reduce((s, c) => s + c.rateUsd * c.count, 0);
  const lines = draft.budget.filter((b) => b.category === "contractors" && !b.stretch).reduce((s, b) => s + b.usd, 0);
  if (paid !== lines) errors.push(`Contractor plan pays $${paid} from seat money but the budget lists $${lines}.`);
  if (!draft.killCriteria.length) errors.push("Write at least one kill rule as a condition and a date.");
  for (const k of draft.killCriteria) {
    if (Number.isNaN(Date.parse(k.by))) errors.push(`Kill rule ${k.key} needs a date.`);
    if (k.condition.trim().length < 8) errors.push(`Kill rule ${k.key} needs a measurable condition.`);
  }
  if (draft.premortem.length < 3) errors.push("The pre-mortem names the top three ways this dies.");
  if (!draft.milestones.some((m) => m.key === draft.primaryMetric.by)) errors.push("The primary metric's target date must be a milestone.");
  const customers = store.ventures.find((x) => x.id === venture.id)?.customers.count ?? 0;
  for (const s of draft.slides) {
    for (const c of s.claims) {
      const r = screenText({ text: c.text, nearSeats: true, customers: s.key === "demand" ? customers : Number.MAX_SAFE_INTEGER }, params);
      if (r.result === "stop" || r.findings.length) errors.push(`${c.id}: ${r.findings.join(" ")}`);
    }
  }
  const quoted = quotedLessons(deckText(draft).join(" \n "), store.lessons);
  if (quoted.length) errors.push(`The deck is public; it quotes members-only lesson text (${quoted.map((l) => l.id).join(", ")}).`);
  const regulated = regulatedIn(draft, params);
  if (regulated.length && !draft.slides.find((s) => s.key === "risks")?.claims.some((c) => /counsel|lawyer/i.test(c.text))) {
    errors.push(`The deck touches ${regulated.join(", ")}; its risks need a line on what counsel checks.`);
  }
  const proof = proofOf(store, venture, draft, params);
  if (!proof) errors.push("The deck needs a proof plan: each task run by the agent, a member request or a contractor.");
  else for (const i of checkOperability(proof, params)) errors.push(`Proof: ${i.message} Reshape the proof.`);
  return errors;
}

/** A draft without a proof keeps the venture's current one, or else the plan written for it, sent back until it passes. */
export function proofOf(store: Store, venture: Venture, draft: DeckDraft, params: ParamValues): ProofPlan | undefined {
  if (draft.proof) return draft.proof;
  const current = latestDeck(store, venture.id)?.proof;
  if (current) return current;
  const written = proofPlanFor(venture.slug);
  return written && operableProof(written, params).plan;
}

export function decksFor(store: Store, ventureId: string): PitchDeck[] {
  return store.decks.filter((d) => d.ventureId === ventureId).sort((a, b) => a.version - b.version);
}

/** The deck members see now: the newest published version. */
export function latestDeck(store: Store, ventureId: string): PitchDeck | undefined {
  return decksFor(store, ventureId)
    .filter((d) => d.status !== "proposed")
    .at(-1);
}

export function deckVersion(store: Store, ventureId: string, version: number): PitchDeck | undefined {
  return decksFor(store, ventureId).find((d) => d.version === version && d.status !== "proposed");
}

function draftOf(deck: PitchDeck): DeckDraft {
  return {
    purpose: deck.purpose,
    slides: deck.slides.filter((s) => s.key !== "ask"),
    market: deck.market,
    alternatives: deck.alternatives,
    pricing: deck.pricing,
    budget: deck.budget,
    plan: deck.plan,
    contractors: deck.contractors,
    requestPlan: deck.requestPlan,
    milestones: deck.milestones,
    killCriteria: deck.killCriteria,
    premortem: deck.premortem,
    primaryMetric: deck.primaryMetric,
    motions: deck.rosterInput.motions,
    needsIntegration: deck.rosterInput.needsIntegration,
    hints: deck.rosterInput.hints as DeckDraft["hints"],
    proof: deck.proof,
  };
}

export interface BuildOptions {
  author: string;
  cause: PitchDeck["cause"];
  /** Keep a venture's old minimum (Article 6) and show the current rule beside it. */
  legacy?: boolean;
  banner?: string;
  /** An amendment keeps the price the venture was pitched at, and its sign-off. */
  keepPrice?: { priceUsd: number; price: NonNullable<SeatPlan["price"]> };
}

/** Turn a draft into a deck. Code computes the seat plan, the roster and the ask; nothing in the draft can set them. */
export function buildDeck(store: Store, venture: Venture, draft: DeckDraft, opts: BuildOptions, params: ParamValues = resolveParams(store)): PitchDeck {
  const proof = proofOf(store, venture, draft, params);
  const errors = validateDeck(store, venture, { ...draft, proof }, params);
  if (errors.length) throw new ProtocolError(`${venture.name}'s deck doesn't pass the claim rules: ${errors.join(" ")}`);
  const c = classificationOf(venture);
  const regulated = regulatedIn(draft, params);
  const roster = rosterPlan(
    { customer: c.customer ?? "Small business", endMarket: c.endMarket ?? "", motions: draft.motions, requestPlan: draft.requestPlan, needsIntegration: draft.needsIntegration, regulated, hints: draft.hints },
    params,
  ).roles;
  const unanswered = proof ? proofRosterErrors(proof, roster) : [];
  if (unanswered.length) throw new ProtocolError(`${venture.name}'s proof plan doesn't match its roster: ${unanswered.join(" ")}`);
  const band = priceBand({ budget: draft.budget, requestPlan: draft.requestPlan, roster }, params);
  const agentPrice = draft.seatPrice && !checkPriceProposal(draft.seatPrice, band).length ? draft.seatPrice : undefined;
  const proposal = opts.keepPrice
    ? { priceUsd: opts.keepPrice.priceUsd, claims: opts.keepPrice.price.claims }
    : (agentPrice ?? heuristicSeatPrice({ customer: c.customer, endMarket: c.endMarket, roster, regulated, deck: draft }, band));
  const proposedBy = opts.keepPrice?.price.proposedBy ?? (agentPrice ? "agent" : "script");
  const derived = seatPlanFor(
    { budget: draft.budget, requestPlan: draft.requestPlan, roster, priceUsd: proposal.priceUsd, price: { proposedBy, claims: proposal.claims, decisionId: opts.keepPrice?.price.decisionId } },
    params,
    store.meta.protocolVersion,
  );
  const seatPlan: SeatPlan = opts.legacy ? legacySeatPlan(venture, params, store.meta.protocolVersion, draft.budget) : derived;
  const version = (decksFor(store, venture.id).at(-1)?.version ?? 0) + 1;
  const order = params.DECK_SLIDES as SlideKey[];
  const slides = [...draft.slides, { key: "ask" as const, headline: "The ask", claims: [] }].sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key));
  return {
    id: `deck-${venture.slug}-v${version}`,
    ventureId: venture.id,
    version,
    status: "published",
    publishedAt: store.meta.clock,
    author: opts.author,
    protocolVersion: store.meta.protocolVersion,
    purpose: draft.purpose,
    slides,
    market: draft.market,
    alternatives: draft.alternatives,
    pricing: draft.pricing,
    budget: draft.budget,
    plan: draft.plan,
    contractors: draft.contractors,
    requestPlan: draft.requestPlan,
    milestones: draft.milestones,
    killCriteria: draft.killCriteria,
    premortem: draft.premortem,
    primaryMetric: draft.primaryMetric,
    seatPlan,
    currentRule: opts.legacy ? derived : undefined,
    roster,
    proof,
    rosterInput: { motions: draft.motions, needsIntegration: draft.needsIntegration, regulated, hints: draft.hints as Record<string, RoleHint> },
    changes: [],
    cause: opts.cause,
    banner: opts.banner,
  };
}

const killRuleText = (k: PitchDeck["killCriteria"][number]) => `${k.condition[0].toUpperCase()}${k.condition.slice(1)} by ${k.by.slice(0, 10)}`;

/** Publish a deck: supersede the last one and write the fields older readers use. */
export function activateDeck(store: Store, deck: PitchDeck) {
  const venture = store.ventures.find((v) => v.id === deck.ventureId)!;
  for (const d of store.decks) if (d.ventureId === deck.ventureId && d.status === "published" && d.id !== deck.id) d.status = "superseded";
  deck.status = "published";
  deck.publishedAt = store.meta.clock;
  if (!store.decks.includes(deck)) store.decks.push(deck);
  venture.roster = deck.roster.map((r) => ({ type: r.key, label: r.label, count: r.count, clusters: r.clusters, keywords: r.keywords }));
  venture.minRaiseUsd = deck.seatPlan.minRaiseUsd;
  if (deck.seatPlan.rule === "derived") venture.seatPriceUsd = deck.seatPlan.priceUsd;
  venture.budget = [
    ...deck.budget.filter((b) => !b.stretch && b.category !== "contingency").map((b) => ({ label: b.label, usd: b.usd })),
    ...(deck.seatPlan.contingencyUsd > 0 ? [{ label: "Contingency", usd: deck.seatPlan.contingencyUsd }] : []),
  ];
  // Dated rules come from the deck; rules without a date (a runway floor, the steward's switch) stay.
  const kept = venture.killRules.filter((r) => !/Minimum not met/i.test(r) && !/ by \d{4}-\d{2}-\d{2}$/.test(r));
  const steward = (r: string) => /steward shuts it down/i.test(r);
  venture.killRules = [
    ...venture.killRules.filter((r) => /Minimum not met/i.test(r)),
    ...deck.killCriteria.map(killRuleText),
    ...kept.filter((r) => !steward(r)),
    ...kept.filter(steward),
  ];
  const last = deck.killCriteria.map((k) => k.by).sort().at(-1);
  if (last) venture.killDate = last;
}

/** Publish the first deck at pitch, or a reconstructed one at migration. */
export function publishDeck(store: Store, venture: Venture, draft: DeckDraft, opts: BuildOptions): PitchDeck {
  if (venture.isProtocol) throw new ProtocolError("The Protocol has no deck; its open questions are votes.");
  const deck = buildDeck(store, venture, draft, opts);
  activateDeck(store, deck);
  return deck;
}

const GOALPOSTS = ["killCriteria", "milestones", "primaryMetric"];

function same(a: unknown, b: unknown) {
  return JSON.stringify(a) === JSON.stringify(b);
}

/** Claim-level and field-level differences between two decks. */
export function deckDiff(before: PitchDeck, after: PitchDeck, params: ParamValues): PitchDeck["changes"] {
  const material = new Set(params.DECK_MATERIAL_FIELDS as string[]);
  const out: PitchDeck["changes"] = [];
  for (const key of ["purpose", "market", "alternatives", "pricing", "budget", "plan", "contractors", "requestPlan", "milestones", "killCriteria", "premortem", "primaryMetric", "proof"] as const) {
    if (!same(before[key], after[key])) out.push({ path: key, before: before[key], after: after[key], material: material.has(key) });
  }
  if (before.seatPlan.min !== after.seatPlan.min) out.push({ path: "seatPlan.min", before: before.seatPlan.min, after: after.seatPlan.min, material: material.has("seatPlan.min") });
  for (const s of after.slides) {
    const old = before.slides.find((x) => x.key === s.key)?.headline;
    if (old !== undefined && old !== s.headline) out.push({ path: `slides.${s.key}.headline`, before: old, after: s.headline, material: false });
  }
  const was = new Map(allClaims(before).map((c) => [c.id, c]));
  const now = new Map(allClaims(after).map((c) => [c.id, c]));
  for (const [id, c] of now) {
    const old = was.get(id);
    if (!old || !same(old, c)) out.push({ path: `claims.${id}`, before: old, after: c, material: false });
  }
  for (const [id, c] of was) if (!now.has(id)) out.push({ path: `claims.${id}`, before: c, after: undefined, material: false });
  return out;
}

export interface AmendInput {
  /** Fields to replace. Claims are patched by id; a claim is never deleted, only marked disproved. */
  patch?: Partial<Omit<DeckDraft, "slides">>;
  claims?: (Partial<Claim> & { id: string; slide?: SlideKey })[];
  headlines?: Partial<Record<SlideKey, string>>;
  title: string;
  reason: string;
  cause: PitchDeck["cause"];
  model?: string;
}

/**
 * Write version n+1. A change to anything holders relied on (DECK_MATERIAL_FIELDS) is a
 * steward decision, and moving a kill rule, a target or the primary metric is always
 * one: no quiet goalpost moves. Other changes publish at once. All go on the log.
 */
export function amendDeck(store: Store, venture: Venture, input: AmendInput): { deck: PitchDeck; decision: ReturnType<typeof logDecision>["decision"] } {
  const params = resolveParams(store);
  const prev = latestDeck(store, venture.id);
  if (!prev) throw new ProtocolError(`${venture.name} has no deck to amend.`);
  if (store.decks.some((d) => d.ventureId === venture.id && d.status === "proposed")) {
    throw new ProtocolError(`${venture.name} already has a deck change waiting for the steward.`);
  }
  const draft: DeckDraft = { ...draftOf(prev), ...input.patch, slides: structuredClone(draftOf(prev).slides) };
  for (const patch of input.claims ?? []) {
    const { slide, ...fields } = patch;
    const at = draft.slides.find((s) => s.claims.some((c) => c.id === patch.id));
    if (at) {
      const i = at.claims.findIndex((c) => c.id === patch.id);
      at.claims[i] = { ...at.claims[i], ...fields } as Claim;
    } else {
      const target = draft.slides.find((s) => s.key === slide);
      if (!target) throw new ProtocolError(`New claim ${patch.id} needs a slide.`);
      target.claims.push({ sources: [], ...fields } as Claim);
    }
  }
  for (const [key, headline] of Object.entries(input.headlines ?? {})) {
    const s = draft.slides.find((x) => x.key === key);
    if (s && headline) s.headline = headline;
  }
  const deck = buildDeck(
    store,
    venture,
    draft,
    {
      author: input.model ?? "script",
      cause: input.cause,
      legacy: prev.seatPlan.rule === "legacy-budget",
      banner: prev.banner,
      keepPrice: prev.seatPlan.rule === "derived" && prev.seatPlan.price ? { priceUsd: prev.seatPlan.priceUsd, price: prev.seatPlan.price } : undefined,
    },
    params,
  );
  if (prev.seatPlan.rule === "legacy-budget") deck.seatPlan = prev.seatPlan;
  deck.changes = deckDiff(prev, deck, params);
  if (!deck.changes.length) throw new ProtocolError("Nothing changed.");
  const material = deck.changes.some((c) => c.material);
  const goalposts = deck.changes.filter((c) => GOALPOSTS.includes(c.path));
  const moved = goalposts.map((c) => `${c.path}: ${describe(c.before)} → ${describe(c.after)}`);
  const { decision } = logDecision(store, {
    ventureId: venture.id,
    title: `Amend the deck: ${input.title}`,
    reasoning: `${input.reason}${moved.length ? ` Old and new values, on the record: ${moved.join("; ")}.` : ""} Version ${deck.version} replaces version ${prev.version}.`,
    summary: `${input.title} (deck v${deck.version}).`,
    confidence: 0.85,
    model: input.model ?? "script",
    facts: { goalpostMove: goalposts.length > 0, materialDeckChange: material, deckId: deck.id },
  });
  deck.decisionId = decision.id;
  if (decision.status === "taken") {
    activateDeck(store, deck);
  } else {
    deck.status = "proposed";
    store.decks.push(deck);
  }
  return { deck, decision };
}

function describe(v: unknown): string {
  if (Array.isArray(v)) return v.map((x) => (x && typeof x === "object" && "condition" in x ? `${(x as { condition: string }).condition} by ${String((x as { by: string }).by).slice(0, 10)}` : (x as { label?: string })?.label ?? JSON.stringify(x))).join(", ");
  if (v && typeof v === "object" && "name" in v) return `${(v as { name: string }).name} ${(v as { target?: number }).target ?? ""}`.trim();
  return JSON.stringify(v);
}

/** The steward signed a material deck change: publish it and tell every holder. */
export function applyDeckDecision(store: Store, decisionId: string, approved: boolean) {
  const deck = store.decks.find((d) => d.decisionId === decisionId && d.status === "proposed");
  if (!deck) return;
  if (!approved) {
    store.decks.splice(store.decks.indexOf(deck), 1);
    return;
  }
  activateDeck(store, deck);
  const venture = store.ventures.find((v) => v.id === deck.ventureId)!;
  const params = resolveParams(store);
  const withdraw = venture.status === "pitched" && params.DECK_AMEND_WITHDRAW ? " You took your seat under an earlier version, so you can withdraw it for a full refund while seats are still selling." : "";
  for (const h of seatHolders(store, venture.id)) notify(store, venture.id, h, `${venture.name}'s deck changed (v${deck.version}): ${deck.changes.filter((c) => c.material).map((c) => c.path).join(", ")}.${withdraw}`);
}

/** The deck version a seat was taken under, from the seat's ledger row. */
export function seatDeckVersion(store: Store, ventureId: string, handle: string): number | undefined {
  const seat = activeSeats(store, ventureId).find((l) => l.handle === handle);
  return seat?.deckId ? store.decks.find((d) => d.id === seat.deckId)?.version : undefined;
}

/** A holder may withdraw after a material change they didn't buy under (DECK_AMEND_WITHDRAW). */
export function canWithdrawForDeck(store: Store, venture: Venture, handle: string): boolean {
  const params = resolveParams(store);
  if (!params.DECK_AMEND_WITHDRAW || venture.status !== "pitched") return false;
  const bought = seatDeckVersion(store, venture.id, handle);
  const deck = latestDeck(store, venture.id);
  if (bought === undefined || !deck || bought >= deck.version) return false;
  return decksFor(store, venture.id).some((d) => d.version > bought && d.status !== "proposed" && d.changes.some((c) => c.material));
}

/**
 * A request settled a claim's test. A supported claim becomes evidence that cites the request;
 * a disproved one is struck through with the request linked, never deleted.
 */
export function settleClaim(store: Store, venture: Venture, input: { claimId: string; rfeId: string; result: "supported" | "disproved"; text?: string; label: string }) {
  const deck = latestDeck(store, venture.id);
  const claim = deck && claimById(deck, input.claimId);
  if (!claim) throw new ProtocolError(`No claim ${input.claimId} in ${venture.name}'s deck.`);
  const source = { kind: "rfe" as const, ref: input.rfeId, label: input.label, verified: true };
  const patch: Partial<Claim> & { id: string } =
    input.result === "supported"
      ? { id: claim.id, basis: "evidence", text: input.text ?? claim.text, sources: [...claim.sources.filter((s) => s.kind !== "public-data" || s.verified), source], method: undefined, test: undefined }
      : { id: claim.id, disproved: { at: store.meta.clock, by: input.rfeId }, sources: [...claim.sources, source] };
  return amendDeck(store, venture, {
    claims: [patch],
    title: input.result === "supported" ? `a request backed “${shorten(claim.text)}”` : `a request disproved “${shorten(claim.text)}”`,
    reason: `The request settled the claim's test.`,
    cause: { kind: "rfe", ref: input.rfeId },
  });
}

const shorten = (t: string) => (t.length > 60 ? `${t.slice(0, 57).replace(/\s+\S*$/, "")}…` : t);

/** One line per slide for a summary card. */
export function deckHeadlines(deck: PitchDeck, keys: SlideKey[] = ["problem", "solution", "customer"]): { key: SlideKey; title: string; headline: string }[] {
  return keys.map((k) => ({ key: k, title: SLIDE_TITLES[k], headline: deck.slides.find((s) => s.key === k)?.headline ?? "" })).filter((x) => x.headline);
}
/** The steward approved or rejected a deck decision; wired from stewardDecide. */
export function onStewardDeckDecision(store: Store, d: { id: string; ventureId: string; facts: { deckId?: string; seatPriceDeckId?: string } }, approved: boolean) {
  if (d.facts.deckId) applyDeckDecision(store, d.id, approved);
  if (d.facts.seatPriceDeckId && !approved) {
    const venture = store.ventures.find((v) => v.id === d.ventureId);
    if (venture) notify(store, venture.id, venture.stewardHandle, `the seat price for ${venture.name} was declined; seats stay closed until a new price is proposed and signed off`);
  }
}

/** Record which deck a seat was taken under, for seats taken before decks existed. */
export function stampSeatDeck(store: Store, ventureId: string, handle: string, deckId = latestDeck(store, ventureId)?.id) {
  const seat = activeSeats(store, ventureId).find((l) => l.handle === handle);
  if (deckId && seat && !seat.deckId) seat.deckId = deckId;
}
/* ---------- seat money is spent only on the published plan ---------- */

const LINE_WORDS: Record<string, RegExp> = {
  formation: /\b(form|formation|series|filings?)\b/i,
  domain: /\b(domain|mailbox)\b/i,
  tools: /\b(tools?|tooling|email sending|sms|text messag\w*|postage|storage|bookkeep\w*|checks?)\b/i,
  api: /\b(compute|model calls?|api|parsing)\b/i,
  data: /\b(prox(y|ies)|portals?|data access)\b/i,
  hosting: /\b(hosting|server|scraper hosting)\b/i,
  contractors: /\b(contractors?|pilot package|trial shift)\b/i,
  "ads-test": /\b(ads?|paid post)\b/i,
  outreach: /\b(outreach|list of)\b/i,
  insurance: /\b(insurance|policy|premium)\b/i,
  legal: /\b(counsel|lawyer|legal|terms of service|privacy policy|templates?)\b/i,
  "shared-services": /\bshared services?\b/i,
};

const PAID_GROWTH = new Set(["ads-test", "outreach"]);
const BEFORE_CUSTOMER = new Set(["funded", "formed", "operating"]);

export type SpendVerdict = { verdict: "ok"; line?: string } | { verdict: "gate"; line: string; reason: string } | { verdict: "reject"; reason: string };

/** The budget line a spend belongs to: named in the facts, or matched from the title. */
export function budgetLineFor(deck: PitchDeck, facts: { budgetLine?: string }, title: string) {
  if (facts.budgetLine) return deck.budget.find((b) => b.key === facts.budgetLine);
  return (
    deck.budget.find((b) => title.toLowerCase().includes(b.label.toLowerCase())) ??
    deck.budget.find((b) => b.category !== "contingency" && LINE_WORDS[b.category]?.test(title))
  );
}

/**
 * Before the first customer, seat money pays only for lines in the published budget
 * (SEAT_MONEY_ON_PLAN, protected). Running over a line draws on contingency and needs
 * the steward; past that, or off the plan, the deck has to be amended first. Paid growth
 * waits for a paying customer unless it's a channel test written down as an experiment.
 */
export function spendCheck(
  store: Store,
  venture: Venture,
  input: { title: string; facts: { spendUsd: number; budgetLine?: string; channelTest?: boolean; experimentId?: string } },
  params: ParamValues = resolveParams(store),
): SpendVerdict {
  const spend = input.facts.spendUsd;
  if (!(spend > 0)) return { verdict: "ok" };
  const deck = latestDeck(store, venture.id);
  if (input.facts.channelTest) {
    const exp = store.experiments.find((e) => e.id === input.facts.experimentId && e.ventureId === venture.id);
    if (!exp) return { verdict: "reject", reason: "A channel test is written down as an experiment before any money is spent: the premise, what counts as success and when to stop." };
    if (exp.status !== "running") return { verdict: "reject", reason: `Experiment ${exp.id} is ${exp.status}; spend only on a running test.` };
  }
  if (!deck || !params.SEAT_MONEY_ON_PLAN || !BEFORE_CUSTOMER.has(venture.status)) return { verdict: "ok" };
  if (venture.status === "funded" && deck.seatPlan.rule === "derived" && !venture.liftoff?.passedAt) {
    return { verdict: "reject", reason: "Formation money waits until the roster is filled; the venture's own plan needs those people first." };
  }
  const line = budgetLineFor(deck, input.facts, input.title);
  if (!line) {
    return { verdict: "reject", reason: `Off plan: seat money is spent only on the published budget, and no line covers this. Amend the deck first (a steward decision).` };
  }
  if (PAID_GROWTH.has(line.category) && !input.facts.channelTest) {
    return { verdict: "reject", reason: "No paid growth before the first paying customer. A small channel test can run once it's written down as an experiment." };
  }
  const taken = store.decisions.filter((d) => d.ventureId === venture.id && (d.status === "taken" || d.status === "awaiting_steward") && d.facts.spendUsd > 0);
  const spentOn = (key: string) => taken.filter((d) => d.facts.budgetLine === key).reduce((s, d) => s + d.facts.spendUsd, 0);
  if (line.stretch) {
    const extra = (seatHolders(store, venture.id).length - deck.seatPlan.min) * deck.seatPlan.priceUsd;
    const stretchSpent = deck.budget.filter((b) => b.stretch).reduce((s, b) => s + spentOn(b.key), 0);
    if (stretchSpent + spend > Math.max(0, extra)) return { verdict: "reject", reason: `“${line.label}” is a stretch line, paid only by seats past the minimum; those seats cover $${Math.max(0, extra - stretchSpent)}.` };
  }
  if (deck.seatPlan.shortfallUsd > 0) {
    const raised = seatHolders(store, venture.id).length * deck.seatPlan.priceUsd;
    const spentAll = taken.reduce((s, d) => s + d.facts.spendUsd, 0);
    if (spentAll + spend > raised) {
      return {
        verdict: "reject",
        reason: `Seats raised $${raised} and $${spentAll} is spent; the proof budget is $${deck.seatPlan.proofBudgetUsd}, so $${deck.seatPlan.shortfallUsd} of it was never raised. Close the gap first: a smaller wedge in an amended deck, or a vote on the seat price.`,
      };
    }
  }
  const after = spentOn(line.key) + spend;
  if (after <= line.usd) return { verdict: "ok", line: line.key };
  const over = after - line.usd;
  const drawn = deck.budget.reduce((s, b) => s + Math.max(0, spentOn(b.key) - b.usd), 0);
  const left = deck.seatPlan.contingencyUsd - drawn;
  if (over <= left) return { verdict: "gate", line: line.key, reason: `Runs $${over} over the “${line.label}” line, drawn from the $${left} of contingency left, so the steward signs` };
  return { verdict: "reject", reason: `Runs $${over} over the “${line.label}” line and only $${Math.max(0, left)} of contingency is left. Amend the deck first (a steward decision).` };
}

/* ---------- the seat price: proposed by the agent, signed off by the steward ---------- */

export type SeatPriceStatus = "kept" | "awaiting" | "signed" | "declined";

/** Log the proposed seat price as a pricing decision, so the steward signs it off before seats sell. */
export function logSeatPriceDecision(store: Store, venture: Venture, deck: PitchDeck, model = "script") {
  const plan = deck.seatPlan;
  if (plan.rule !== "derived" || !plan.price) return undefined;
  const p = plan.price;
  const why = p.claims.map((c) => c.text).join(" ");
  const { decision } = logDecision(store, {
    ventureId: venture.id,
    title: `Seat price for ${venture.name}: $${plan.priceUsd}`,
    reasoning: `${p.proposedBy === "agent" ? "The agent" : "The agent's pricing rule"} proposes $${plan.priceUsd} a seat, inside the $${p.minUsd}–$${p.upperUsd} band (the top is the proof budget ÷ the ${plan.headcount} people it runs on, at most $${p.maxUsd}). ${why} At $${plan.priceUsd}, the $${plan.proofBudgetUsd.toLocaleString("en-US")} proof needs ${plan.min} seats. A seat is not a share and pays nothing back.`,
    summary: `$${plan.priceUsd} a seat: ${plan.min} seats for a $${plan.proofBudgetUsd.toLocaleString("en-US")} proof.`,
    confidence: 0.75,
    model,
    facts: { pricingChange: true, seatPriceDeckId: deck.id },
  });
  p.decisionId = decision.id;
  return decision;
}

export function seatPriceStatus(store: Pick<Store, "decisions">, deck: Pick<PitchDeck, "seatPlan"> | undefined): SeatPriceStatus {
  const p = deck?.seatPlan.price;
  if (!deck || deck.seatPlan.rule !== "derived" || !p?.decisionId) return "kept";
  const d = store.decisions.find((x) => x.id === p.decisionId);
  if (!d || d.status === "taken") return "signed";
  return d.status === "rejected" ? "declined" : "awaiting";
}

export { seatPriceOf } from "./sizing";

/** Why seats can't sell yet because of the price, or undefined once it's signed off or kept. */
export function seatPriceHold(store: Store, venture: Pick<Venture, "id" | "name">): string | undefined {
  const status = seatPriceStatus(store, latestDeck(store, venture.id));
  if (status === "awaiting") return `${venture.name}'s seat price waits for the steward's sign-off. Seats open once that's done.`;
  if (status === "declined") return `The steward declined ${venture.name}'s seat price; seats open once a new one is signed off.`;
  return undefined;
}
