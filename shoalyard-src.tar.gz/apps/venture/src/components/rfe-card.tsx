import Link from "next/link";
import { ArrowRight, Clock, Megaphone, UserCheck } from "lucide-react";
import { whyAPerson, type NStatus, type VoteTally } from "@av/protocol";
import type { Rfe, Venture } from "@av/schema";
import { RfeTypeBadge, Pill } from "@/components/badges";
import { NProgress } from "@/components/n-progress";
import { formatAgo, formatUnits, formatPct } from "@/lib/format";
import { cn } from "@/lib/utils";

export function RfeCard({
  rfe,
  venture,
  n,
  vote,
  clock,
  showVenture = false,
  highlight = false,
}: {
  rfe: Rfe;
  venture: Venture;
  n?: NStatus;
  vote?: VoteTally;
  clock: string;
  showVenture?: boolean;
  highlight?: boolean;
}) {
  return (
    <Link
      href={`/rfe/${rfe.id}`}
      style={{ "--accent-color": venture.accent } as React.CSSProperties}
      className={cn(
        "group flex flex-col gap-3 rounded-xl border bg-white p-4 shadow-xs transition hover:border-zinc-300 hover:shadow-sm",
        highlight ? "border-[var(--accent-color)] ring-2 ring-[color-mix(in_oklch,var(--accent-color),transparent_80%)]" : "border-zinc-200",
      )}
    >
      <div className="flex flex-wrap items-center gap-1.5">
        <RfeTypeBadge type={rfe.type} governance={rfe.kind === "governance"} explain={false} />
        {showVenture && <Pill>{venture.name}</Pill>}
        {rfe.stakes === "high" && <Pill className="border-rose-200 bg-rose-50 text-rose-800">High stakes</Pill>}
        {rfe.assignedTo && (
          <Pill>
            <UserCheck className="size-3" /> @{rfe.assignedTo}
          </Pill>
        )}
        {rfe.gtm && (
          <Pill>
            <Megaphone className="size-3" /> {rfe.gtm.postedAt ? "Posted" : "Draft"}
          </Pill>
        )}
        <span className="ml-auto flex items-center gap-1 text-xs text-zinc-500">
          <Clock className="size-3" /> {formatAgo(rfe.postedAt, clock)}
        </span>
      </div>
      <div>
        <h3 className="font-medium text-zinc-900 group-hover:underline group-hover:underline-offset-2">{rfe.title}</h3>
        <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{rfe.question}</p>
        <p className="mt-1.5 line-clamp-2 text-xs text-zinc-500">
          <span className="font-medium text-zinc-700">Why a person: </span>
          {whyAPerson(rfe)}
        </p>
      </div>
      {vote ? (
        <div className="space-y-1.5 text-xs text-zinc-600">
          <div className="h-1.5 overflow-hidden rounded-full bg-zinc-100">
            <div className="h-full bg-fuchsia-500" style={{ width: `${Math.round(vote.yesShare * 100)}%` }} />
          </div>
          <p>
            {formatPct(vote.yesShare * 100, 0)} yes of {formatUnits(vote.votedWeight)} voted · {formatPct(vote.turnout * 100, 0)} of units have voted
            {rfe.governance && <> · closes {formatAgo(rfe.governance.windowEndsAt, clock)}</>}
          </p>
        </div>
      ) : n ? (
        <NProgress n={n} compact />
      ) : null}
      <div className="flex items-center justify-between text-sm">
        <span className="text-zinc-600">
          {rfe.offerUnits > 0 ? (
            <>
              <strong className="text-zinc-900">{formatUnits(rfe.offerUnits)}</strong> share each
            </>
          ) : rfe.kind === "governance" ? (
            "Vote: counts by vested units"
          ) : rfe.gtm ? (
            "For the steward: the agent never posts publicly"
          ) : (
            "For the steward"
          )}
        </span>
        <ArrowRight className="size-4 text-zinc-400 transition group-hover:translate-x-0.5 group-hover:text-zinc-700" />
      </div>
    </Link>
  );
}
