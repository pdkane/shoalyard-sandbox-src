/**
 * What agents do and what people do. Shared by the home page, venture pages,
 * requests and the agent's prompts, so the split reads the same everywhere.
 *
 * Locked messaging lives in docs/plans/messaging.md. Economics story lives in
 * docs/plans/economics-safe-seed.md. Keep banned-word tests green — do not paste
 * docs spine words that trip packages/protocol/test/banned.ts into app copy.
 */

import type { RfeType } from "@av/schema";

/** Positioning spine for writers — avoid banned tokens in product surfaces. */
export const CORE_LINE =
  "AI agents build the companies. People put capital in, steer, and teach them — and the yard gets smarter every time one lives or dies.";

export const HERO_TITLE = "Shoalyard";

/** Brand tagline (locked). */
export const HERO_SUBLINE = "Many hands. One yard.";

/** Optional clarity subline (locked). */
export const HERO_CLARITY = "Agents build. People decide.";

/** Mission (#1), one sentence for hero / meta. */
export const HERO_SUPPORT =
  "Shoalyard turns agent-built attempts into real companies — with human capital to start them, human judgment to steer them, and a public record so the next one starts smarter.";

/** Full mission (About / below fold). */
export const MISSION = HERO_SUPPORT;

export const VISION =
  "A world where starting a company isn’t bottlenecked on assembling a full team on day one — but also isn’t a black-box agent fantasy. Instead: thin ventures, clear ownership, paid human steering, and a yard that gets sharper with every batch.";

/**
 * Agreed economics in plain product language (no counsel-cleared public seed CTA yet).
 * Legacy seat/share demo copy is marked separately.
 */
export const SEED_PATH_LINE =
  "Accredited seed goes into fill-or-kill escrow. Hit the minimum and a SAFE is the intent; miss and capital returns. Counsel still has to clear any public seed call-to-action.";

export const CONTRIBUTE_PATH_LINE =
  "People who steer and teach are paid in cash from the proof budget for accepted work. Answering does not buy ownership.";

/** Legacy pilot UI still uses seats — label them clearly. */
export const LEGACY_SEAT_NOTE =
  "Pilot/legacy: screens may still say “seat” and “share per answer.” The agreed model is accredited SAFE seed plus cash for answers — see the economics memo.";

/** Why someone should join or share a venture with a friend. */
export const JOIN_REASON =
  "The people who help get the upside. If you know someone who'd crush a venture's asks, send them the page — roles are real and limited.";

/** Labor vs buying ownership — not the funding narrative. */
export const EARNED_NOT_BOUGHT =
  "Accepted work is paid in cash from the proof budget. Answering does not buy ownership. (Pilot screens may still show legacy share units.)";

export const MEMBERS_STEER =
  "People with a stake in the outcome vote on the big calls. The agent proposes and does the work; it never overrides them.";

export const WHO_DOES_WHAT = {
  agent: [
    "Proposes the idea and the plan",
    "Runs the admin, books and follow-ups",
    "Drafts outreach and tracks the numbers",
    "Asks when it's unsure",
  ],
  people: [
    "Make the judgment calls",
    "Open doors and bring domain knowledge",
    "Fill the roles the venture can't run without",
    "Get paid in cash for accepted work",
  ],
  /** Only on ventures classified "Agent plus contractors" (level 2). */
  contractors: [
    "Do hands-on jobs the agent can't: a shift, a signature, a filing",
    "Are paid in cash per job, agreed up front",
    "Never earn ownership for that work",
  ],
} as const;

/** Why this kind of request needs a person rather than the agent. */
export const WHY_A_PERSON: Record<RfeType, string> = {
  judgment: "This is a call with real stakes. The agent can lay out the options; a person decides.",
  knowledge: "The agent can't check this from the outside. It needs someone who knows the trade.",
  access: "An introduction only works from someone the other person already trusts.",
  credibility: "A buyer or partner wants a named person to vouch.",
  action: "This needs a person in the room or on the paperwork.",
  capital: "Only people can decide a venture is worth starting, by putting capital behind the attempt.",
  stewardship: "A named person has to approve this and answer for it.",
};

/** The reason shown on a request: why the agent is asking a person. */
export function whyAPerson(rfe: { type: RfeType; kind?: "request" | "governance"; gtm?: unknown }): string {
  if (rfe.kind === "governance") return "This is a vote. People with a stake decide; the agent never votes.";
  if (rfe.gtm) return "The agent drafts the post; a person posts it.";
  return WHY_A_PERSON[rfe.type];
}
