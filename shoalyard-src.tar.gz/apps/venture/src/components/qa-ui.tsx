import Link from "next/link";
import { CornerDownRight, EyeOff, FileClock, Hourglass } from "lucide-react";
import { askerLabel, claimById, decksFor, hiddenPlaceholder, qaWindow, type AskerLabel } from "@av/protocol";
import { SLIDE_TITLES, type Answer, type Citation, type Member, type ParamValues, type PitchDeck, type Question, type Store, type Venture } from "@av/schema";
import { BasisBadge } from "@/components/deck-ui";
import { ApproveQuestionForm, HideQuestionForm, UpvoteButton } from "@/components/qa-forms";
import { formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";

const STATUS: Record<Answer["status"], { word: string; className: string }> = {
  answered: { word: "Answered", className: "border-emerald-200 bg-emerald-50 text-emerald-800" },
  partial: { word: "Partly answered", className: "border-amber-200 bg-amber-50 text-amber-900" },
  unknown: { word: "“I don't know”", className: "border-zinc-300 bg-zinc-50 text-zinc-700" },
};

const ASKER: Record<AskerLabel, string> = { "seat holder": "seat holder", qualified: "verified member", candidate: "candidate" };

export function CitationChip({ c, slug, deck }: { c: Citation; slug: string; deck?: PitchDeck }) {
  const claim = deck ? claimById(deck, c.claimId) : undefined;
  return (
    <Link
      href={`/v/${slug}/deck?v=${c.deckVersion}#${c.claimId}`}
      title={claim?.text}
      className="inline-flex items-center gap-1 rounded-md border border-zinc-200 bg-white px-1.5 py-0.5 text-[11px] text-zinc-700 hover:border-zinc-400"
    >
      v{c.deckVersion} · {SLIDE_TITLES[c.slideKey]}
    </Link>
  );
}

export function AnswerBody({ answer, slug, decks, rfeTitle }: { answer: Answer; slug: string; decks: PitchDeck[]; rfeTitle?: string }) {
  const deckOf = (v: number) => decks.find((d) => d.version === v);
  const cited = answer.citations[0] ? deckOf(answer.citations[0].deckVersion) : undefined;
  return (
    <div className="space-y-2 rounded-lg bg-zinc-50 p-3 text-sm">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className={cn("rounded-full border px-2 py-0.5 text-[11px] font-medium", STATUS[answer.status].className)}>{STATUS[answer.status].word}</span>
        <span className="text-xs text-zinc-500">
          The agent · {formatDate(answer.at)}
        </span>
      </div>
      <p className="whitespace-pre-line text-pretty text-zinc-800">{answer.text}</p>
      {answer.citations.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {answer.citations.map((c) => (
            <CitationChip key={`${c.deckVersion}-${c.claimId}`} c={c} slug={slug} deck={deckOf(c.deckVersion)} />
          ))}
        </div>
      )}
      {answer.restsOn.length > 0 && cited && (
        <div className="text-xs text-zinc-600">
          <p className="font-medium text-zinc-800">This rests on</p>
          <ul className="mt-1 space-y-1">
            {answer.restsOn.map((id) => {
              const claim = claimById(cited, id);
              if (!claim) return null;
              return (
                <li key={id} className="flex items-start gap-1.5">
                  <BasisBadge basis={claim.disproved ? "disproved" : claim.basis} />
                  <span>{claim.text}</span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      {(answer.routed?.rfeId || answer.routed?.deckVersion) && (
        <div className="space-y-0.5 text-xs">
          {answer.routed.rfeId && (
            <p className="flex items-center gap-1 text-zinc-700">
              <CornerDownRight className="size-3.5 shrink-0" /> Sent to members:{" "}
              <Link href={`/rfe/${answer.routed.rfeId}`} className="underline underline-offset-2">
                {rfeTitle ?? "the request"}
              </Link>
            </p>
          )}
          {answer.routed.deckVersion && (
            <p className="flex items-center gap-1 text-zinc-700">
              <FileClock className="size-3.5 shrink-0" /> The deck changed because of this question:{" "}
              <Link href={`/v/${slug}/deck?v=${answer.routed.deckVersion}`} className="underline underline-offset-2">
                v{answer.routed.deckVersion}
              </Link>
            </p>
          )}
        </div>
      )}
      {answer.updates.length > 0 && (
        <ul className="space-y-1 border-t border-zinc-200 pt-2 text-xs text-zinc-600">
          {answer.updates.map((u, i) => (
            <li key={i}>
              <span className="text-zinc-400">{formatDate(u.at)}:</span> {u.text}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export interface QuestionCardProps {
  q: Question;
  slug: string;
  decks: PitchDeck[];
  asker: AskerLabel;
  viewer?: string;
  isSteward: boolean;
  canUpvote: boolean;
  readOnly: boolean;
  hideReasons: string[];
  rfeTitle?: string;
}

/** Card props for a venture's questions, as one viewer sees them. */
export function questionCards(
  data: { store: Store; params: ParamValues; viewer: string; member?: Member },
  venture: Venture,
  questions: Question[],
): QuestionCardProps[] {
  const { store, params, viewer, member } = data;
  const decks = decksFor(store, venture.id);
  const w = qaWindow(store, venture, params);
  const readOnly = w.state === "read-only" || w.state === "none";
  return questions.map((q) => ({
    q,
    slug: venture.slug,
    decks,
    asker: askerLabel(store, venture, q.handle),
    viewer: member ? viewer : undefined,
    isSteward: viewer === venture.stewardHandle,
    canUpvote: !!member && !readOnly,
    readOnly,
    hideReasons: params.QA_HIDE_REASONS as string[],
    rfeTitle: q.answer?.routed?.rfeId ? store.rfes.find((r) => r.id === q.answer!.routed!.rfeId)?.title : undefined,
  }));
}

export function QuestionCard({ q, slug, decks, asker, viewer, isSteward, canUpvote, readOnly, hideReasons, rfeTitle }: QuestionCardProps) {
  const placeholder = hiddenPlaceholder(q);
  if (placeholder) {
    return (
      <article id={q.id} className="flex scroll-mt-24 items-start gap-2 rounded-xl border border-dashed border-zinc-300 p-4 text-sm text-zinc-500">
        <EyeOff className="mt-0.5 size-4 shrink-0" /> {placeholder}
      </article>
    );
  }
  const mine = viewer === q.handle;
  const held = q.status === "held";
  const why = mine ? "You can't upvote your own question." : !canUpvote ? "Ask a question or claim a role first, so your upvote has a handle." : readOnly ? "Q&A is closed." : undefined;
  return (
    <article id={q.id} className={cn("scroll-mt-24 space-y-3 rounded-xl border border-zinc-200 bg-white p-4", held && "border-amber-200")}>
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1 space-y-1">
          <p className="text-xs text-zinc-500">
            <Link href={`/m/${q.handle}`} className="font-medium text-zinc-800 hover:underline">
              @{q.handle}
            </Link>{" "}
            · {ASKER[asker]} · {formatDate(q.at)} · asked about{" "}
            <Link href={`/v/${slug}/deck?v=${q.deckVersion}`} className="underline underline-offset-2">
              v{q.deckVersion}
            </Link>
          </p>
          <p className="text-pretty text-zinc-900">{q.text}</p>
        </div>
        {!held && <UpvoteButton id={q.id} count={q.upvotes.length} active={!!viewer && q.upvotes.includes(viewer)} disabled={!!why} why={why} />}
      </div>
      {held ? (
        <p className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          <Hourglass className="mt-0.5 size-4 shrink-0" />
          {q.answer ? "The answer is waiting for the steward's conduct check." : "Waiting for the steward's conduct check."} Only you and the steward can see this until then.
        </p>
      ) : q.answer ? (
        <AnswerBody answer={q.answer} slug={slug} decks={decks} rfeTitle={rfeTitle} />
      ) : (
        <p className="text-sm text-zinc-500">The agent hasn&apos;t answered yet. It answers on its next step.</p>
      )}
      {q.stewardNote && !held && <p className="text-xs text-zinc-500">Steward&apos;s note: {q.stewardNote}</p>}
      {isSteward && (
        <div className="flex flex-wrap items-center gap-3 border-t border-zinc-100 pt-3">
          {held && <ApproveQuestionForm id={q.id} />}
          <HideQuestionForm id={q.id} reasons={hideReasons} />
        </div>
      )}
    </article>
  );
}
