import type { Grant, ParamValues, Response, Rfe, Store, Venture } from "@av/schema";
import { round } from "./util";

export const ACTIVE_GRANT = ["accepted", "vested", "distributing"] as const;
export const VESTED_GRANT = ["vested", "distributing"] as const;

const isActive = (g: Grant) => (ACTIVE_GRANT as readonly string[]).includes(g.status);
const isVested = (g: Grant) => (VESTED_GRANT as readonly string[]).includes(g.status);

export type SliceKey = "steward" | "cohort" | "reserve";

export interface SliceRow {
  key: SliceKey;
  label: string;
  allocated: number;
  granted: number;
  remaining: number;
}

export interface HolderRow {
  handle: string;
  offered: number;
  accepted: number;
  vested: number;
  forfeited: number;
  /** Accepted plus vested. */
  units: number;
  pctOfPool: number;
  /** Share of all profits interests in the venture, after the protocol fee. */
  pctOfInterests: number;
}

export interface CapTable {
  protocolPct: number;
  contributorPct: number;
  /** Percent of the venture's profits interests that one unit represents. */
  unitPct: number;
  poolUnits: number;
  slices: SliceRow[];
  reserveRemaining: number;
  holders: HolderRow[];
  holderCount: number;
  grantedUnits: number;
  cohortUnits: number;
  treasuryUnits: number;
  topHolderPctOfPool: number;
}

type EconParams = Pick<
  ParamValues,
  | "PROTOCOL_FEE_PCT"
  | "POOL_UNITS_TOTAL"
  | "POOL_STEWARD_UNITS"
  | "POOL_COHORT_UNITS"
  | "POOL_RFE_RESERVE_UNITS"
  | "MAX_UNITS_PER_RFE"
>;

/** The protocol fee goes to the Protocol, so it pays none to itself. */
export function protocolPctFor(venture: Pick<Venture, "isProtocol">, params: EconParams): number {
  return venture.isProtocol ? 0 : params.PROTOCOL_FEE_PCT;
}

/** Units are earned by work only. Buying a seat never earns any. */
function sliceOf(g: Grant): SliceKey {
  if (g.slice === "rfe" || g.slice === "founder") return "reserve";
  return g.slice;
}

export function capTable(store: Pick<Store, "grants">, venture: Venture, params: EconParams): CapTable {
  const grants = store.grants.filter((g) => g.ventureId === venture.id);
  const protocolPct = protocolPctFor(venture, params);
  const contributorPct = 100 - protocolPct;
  const poolUnits = params.POOL_UNITS_TOTAL;
  const unitPct = contributorPct / poolUnits;

  const allocated: Record<SliceKey, number> = {
    steward: params.POOL_STEWARD_UNITS,
    cohort: params.POOL_COHORT_UNITS,
    reserve: params.POOL_RFE_RESERVE_UNITS,
  };
  const granted: Record<SliceKey, number> = { steward: 0, cohort: params.POOL_COHORT_UNITS, reserve: 0 };
  for (const g of grants) if (isActive(g) || g.status === "offered") granted[sliceOf(g)] += g.units;

  const labels: Record<SliceKey, string> = {
    steward: "Steward",
    cohort: "Batch-wide share",
    reserve: "Accepted answers",
  };
  const slices = (Object.keys(allocated) as SliceKey[]).map((key) => ({
    key,
    label: labels[key],
    allocated: allocated[key],
    granted: round(granted[key]),
    remaining: round(Math.max(0, allocated[key] - granted[key])),
  }));

  const byHandle = new Map<string, HolderRow>();
  for (const g of grants) {
    const row =
      byHandle.get(g.handle) ??
      ({ handle: g.handle, offered: 0, accepted: 0, vested: 0, forfeited: 0, units: 0, pctOfPool: 0, pctOfInterests: 0 } as HolderRow);
    if (g.status === "offered") row.offered += g.units;
    else if (g.status === "accepted") row.accepted += g.units;
    else if (isVested(g)) row.vested += g.units;
    else if (g.status === "forfeited") row.forfeited += g.units;
    byHandle.set(g.handle, row);
  }
  const holders = [...byHandle.values()]
    .map((r) => {
      const units = r.accepted + r.vested;
      return {
        ...r,
        offered: round(r.offered),
        accepted: round(r.accepted),
        vested: round(r.vested),
        forfeited: round(r.forfeited),
        units: round(units),
        pctOfPool: round((units / poolUnits) * 100),
        pctOfInterests: round(units * unitPct, 3),
      };
    })
    .filter((r) => r.units > 0 || r.offered > 0 || r.forfeited > 0)
    .sort((a, b) => b.units - a.units);

  const grantedUnits = round(grants.filter(isActive).reduce((s, g) => s + g.units, 0));
  const cohortUnits = params.POOL_COHORT_UNITS;
  return {
    protocolPct,
    contributorPct,
    unitPct,
    poolUnits,
    slices,
    reserveRemaining: slices.find((s) => s.key === "reserve")!.remaining,
    holders,
    holderCount: holders.filter((h) => h.units > 0).length,
    grantedUnits,
    cohortUnits,
    treasuryUnits: round(poolUnits - grantedUnits - cohortUnits),
    topHolderPctOfPool: holders[0]?.pctOfPool ?? 0,
  };
}

export function vestedUnits(store: Pick<Store, "grants">, ventureId: string, handle: string): number {
  return round(
    store.grants.filter((g) => g.ventureId === ventureId && g.handle === handle && isVested(g)).reduce((s, g) => s + g.units, 0),
    4,
  );
}

/** Voting interest: vested units held by members. The cohort vehicle is not a grant, so it never votes here. */
export function totalVestedUnits(store: Pick<Store, "grants">, ventureId: string): number {
  return round(store.grants.filter((g) => g.ventureId === ventureId && isVested(g)).reduce((s, g) => s + g.units, 0), 4);
}

/** Units still grantable from the request reserve. */
export function reserveRemaining(store: Pick<Store, "grants">, venture: Venture, params: EconParams): number {
  return capTable(store, venture, params).reserveRemaining;
}

export interface DistributionCalc {
  distributableUsd: number;
  protocolUsd: number;
  contributorUsd: number;
  perUnitUsd: number;
  holderUsd: number;
  cohortUsd: number;
  treasuryUsd: number;
  payouts: { handle: string; units: number; usd: number }[];
}

/**
 * Pass-through costs come off the top. The protocol fee is pari passu with
 * contributors. Contributor money is split per pool unit: vested holders and
 * the cohort vehicle are paid; ungranted and unvested units stay in treasury.
 */
export function computeDistribution(input: {
  profitUsd: number;
  passThroughUsd: number;
  protocolPct: number;
  poolUnits: number;
  cohortUnits: number;
  vestedByHandle: Record<string, number>;
}): DistributionCalc {
  const distributableUsd = Math.max(0, input.profitUsd - input.passThroughUsd);
  const protocolUsd = round(distributableUsd * (input.protocolPct / 100));
  const contributorUsd = round(distributableUsd - protocolUsd);
  const perUnitUsd = contributorUsd / input.poolUnits;
  const payouts = Object.entries(input.vestedByHandle)
    .filter(([, units]) => units > 0)
    .map(([handle, units]) => ({ handle, units, usd: round(units * perUnitUsd) }));
  const holderUsd = round(payouts.reduce((s, p) => s + p.usd, 0));
  const cohortUsd = round(input.cohortUnits * perUnitUsd);
  return {
    distributableUsd: round(distributableUsd),
    protocolUsd,
    contributorUsd,
    perUnitUsd: round(perUnitUsd, 4),
    holderUsd,
    cohortUsd,
    treasuryUsd: round(contributorUsd - holderUsd - cohortUsd),
    payouts,
  };
}

export function vestedByHandle(store: Pick<Store, "grants">, ventureId: string): Record<string, number> {
  const out: Record<string, number> = {};
  for (const g of store.grants) {
    if (g.ventureId === ventureId && isVested(g)) out[g.handle] = round((out[g.handle] ?? 0) + g.units, 4);
  }
  return out;
}

export interface VoteTally {
  yesWeight: number;
  noWeight: number;
  votedWeight: number;
  eligibleWeight: number;
  turnout: number;
  quorumMet: boolean;
  yesShare: number;
  threshold: number;
  passes: boolean;
  voters: number;
}

/** Votes weighted by vested interest (Article 5). The first option is "yes". */
export function tallyVote(
  rfe: Pick<Rfe, "options" | "governance">,
  votes: Pick<Response, "choice" | "weight">[],
  eligibleWeight: number,
  params: Pick<ParamValues, "SIMPLE_MAJORITY" | "SUPERMAJORITY" | "QUORUM_PCT">,
): VoteTally {
  const yesOption = rfe.options?.[0];
  let yesWeight = 0;
  let noWeight = 0;
  for (const v of votes) {
    const w = v.weight ?? 0;
    if (v.choice === yesOption) yesWeight += w;
    else noWeight += w;
  }
  const votedWeight = yesWeight + noWeight;
  const threshold = rfe.governance?.threshold === "super" ? params.SUPERMAJORITY : params.SIMPLE_MAJORITY;
  const turnout = eligibleWeight > 0 ? votedWeight / eligibleWeight : 0;
  const quorumMet = turnout >= params.QUORUM_PCT;
  const yesShare = votedWeight > 0 ? yesWeight / votedWeight : 0;
  const passes = quorumMet && (threshold === params.SIMPLE_MAJORITY ? yesShare > threshold : yesShare >= threshold);
  return {
    yesWeight: round(yesWeight, 3),
    noWeight: round(noWeight, 3),
    votedWeight: round(votedWeight, 3),
    eligibleWeight: round(eligibleWeight, 3),
    turnout: round(turnout, 4),
    quorumMet,
    yesShare: round(yesShare, 4),
    threshold,
    passes,
    voters: votes.length,
  };
}
