import type { Cohort, Member, ParamValues, Store, Venture } from "@av/schema";
import type { DeckDraft } from "./deck";
import type { IdeaTemplate } from "./ideas";
import { allocateBatchSlots, runLearningPass, segmentKey, type Segment } from "./learning";
import { isOpen, ledger, logDecision, pitchVenture, ProtocolError, refundSeats, protocolVenture, type RfeDraft } from "./ops";
import { checkLiftoff, checkRaise, raiseShortfall } from "./roster";
import { resolveParams } from "./params";
import { candidateIdeas, spawnVenture } from "./spawn";
import { addDays, addHours } from "./util";
import { onBatchAnnounced, onBatchLive, settleVentureWaitlists } from "./waitlist";

/** Cohorts are stored as `Cohort` and shown as numbered batches. */
export function batchLabel(n: number): string {
  return `Batch ${String(n).padStart(3, "0")}`;
}

export function cohortById(store: Store, id: string | undefined): Cohort | undefined {
  return id ? store.cohorts.find((c) => c.id === id) : undefined;
}

export function cohortByNumber(store: Store, n: number): Cohort | undefined {
  return store.cohorts.find((c) => c.number === n);
}

export function cohortFor(store: Store, venture: Pick<Venture, "cohortId">): Cohort | undefined {
  return cohortById(store, venture.cohortId);
}

export function earlyAccessAt(cohort: Cohort, params: ParamValues): string {
  return addHours(cohort.opensAt, -params.EARLY_ACCESS_HOURS);
}

/** The batch the home page leads with: live first, then the next announced, then the latest closed. */
export function currentBatch(store: Store): Cohort | undefined {
  const by = (s: Cohort["status"]) => store.cohorts.filter((c) => c.status === s).sort((a, b) => a.number - b.number);
  return by("live")[0] ?? by("announced")[0] ?? by("closed").at(-1);
}

export function batchVentures(store: Store, cohort: Cohort): Venture[] {
  return cohort.ventureIds.map((id) => store.ventures.find((v) => v.id === id)).filter((v): v is Venture => !!v);
}

/** Pitches and budgets stay hidden while a venture's batch is only announced. */
export function isRevealed(store: Store, venture: Venture): boolean {
  return cohortFor(store, venture)?.status !== "announced";
}

/** An announced venture is addressed by its codename so its URL can't give away the name. */
export function codenameSlug(venture: Pick<Venture, "codename" | "id">): string {
  if (venture.codename) return venture.codename.toLowerCase();
  let h = 0;
  for (const ch of venture.id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return `announced-${h.toString(36)}`;
}

/** The slug a venture is reachable at right now: the codename while announced, the real slug once live. */
export function publicSlug(store: Store, venture: Venture): string {
  return isRevealed(store, venture) ? venture.slug : codenameSlug(venture);
}

export function ventureHref(store: Store, venture: Venture): string {
  return `/v/${publicSlug(store, venture)}`;
}

/**
 * Resolve a public `/v/[slug]`. The real slug of an announced venture does not resolve;
 * a codename slug resolves both before and after reveal, with `canonical` pointing at the slug to use.
 */
export function lookupVenture(store: Store, slug: string): { venture: Venture; canonical: string } | undefined {
  const real = store.ventures.find((v) => v.slug === slug && isRevealed(store, v));
  if (real) return { venture: real, canonical: real.slug };
  const coded = store.ventures.find((v) => !!v.codename && codenameSlug(v) === slug);
  if (coded) return { venture: coded, canonical: publicSlug(store, coded) };
  return undefined;
}

export type WindowState = "none" | "announced" | "early" | "open" | "ended";

export interface SeatWindow {
  state: WindowState;
  earlyAt?: string;
  opensAt?: string;
  closesAt?: string;
  cohort?: Cohort;
}

export function seatWindow(store: Store, venture: Venture, params = resolveParams(store)): SeatWindow {
  const cohort = cohortFor(store, venture);
  if (!cohort) return { state: "none" };
  const clock = store.meta.clock;
  const earlyAt = earlyAccessAt(cohort, params);
  const base = { earlyAt, opensAt: cohort.opensAt, closesAt: cohort.closesAt, cohort };
  if (cohort.status === "announced" || clock < earlyAt) return { state: "announced", ...base };
  if (cohort.status === "closed" || clock >= cohort.closesAt) return { state: "ended", ...base };
  if (clock < cohort.opensAt) return { state: "early", ...base };
  return { state: "open", ...base };
}

/** Exclusivity comes from timing: qualified members can buy in the early window, everyone in the public one. */
export function assertSeatWindow(store: Store, venture: Venture, member: Pick<Member, "qualification"> | undefined) {
  if (venture.status !== "pitched") return;
  const w = seatWindow(store, venture);
  if (w.state === "announced") throw new ProtocolError(`${venture.codename ?? venture.name} isn't open yet; seats open ${w.earlyAt?.slice(0, 16).replace("T", " ")} UTC.`);
  if (w.state === "ended") throw new ProtocolError(`Seats for ${venture.name} have closed.`);
  if (w.state === "early" && member?.qualification !== "qualified") {
    throw new ProtocolError("Only verified members can take a seat this early. Everyone else can soon.");
  }
}

/** A batch can close only once every venture that died in it has published its post-mortem. */
export function unpublishedPostMortems(store: Store, cohort: Cohort): Venture[] {
  return batchVentures(store, cohort).filter((v) => v.status === "killed" && !v.postMortem?.publishedAt);
}

export interface BatchEvent {
  cohortId: string;
  message: string;
}

/** Move batches along on the simulated clock: announced → live → closed. */
export function advanceBatches(store: Store): BatchEvent[] {
  const params = resolveParams(store);
  const events: BatchEvent[] = [];
  for (const cohort of [...store.cohorts].sort((a, b) => a.number - b.number)) {
    if (cohort.status === "announced" && store.meta.clock >= earlyAccessAt(cohort, params)) {
      cohort.status = "live";
      for (const v of batchVentures(store, cohort)) {
        if (v.status !== "generated") continue;
        try {
          const d = pitchVenture(store, v);
          if (d.status === "awaiting_steward") events.push({ cohortId: cohort.id, message: `${v.name} pays contractors, so its pitch waits for the steward's sign-off` });
        } catch (err) {
          if (!(err instanceof ProtocolError)) throw err;
          events.push({ cohortId: cohort.id, message: err.message });
        }
      }
      onBatchLive(store, cohort);
      events.push({ cohortId: cohort.id, message: `${batchLabel(cohort.number)} is live: early access for verified members, public at ${cohort.opensAt.slice(0, 16).replace("T", " ")} UTC` });
    }
    if (cohort.status === "live" && store.meta.clock >= cohort.closesAt) {
      for (const v of batchVentures(store, cohort)) {
        if (v.status !== "pitched" || checkRaise(store, v)) continue;
        const short = raiseShortfall(store, v, params);
        const r = windowKill(store, v, short);
        const refunded = `${r.count} ${r.count === 1 ? "seat" : "seats"} refunded in full ($${r.totalUsd})`;
        const roles = short.some((x) => x.startsWith("a verified claim"));
        events.push({
          cohortId: cohort.id,
          message: roles
            ? `${v.name} ended at the window's close, still needing ${short.join(" and ")}; ${refunded}`
            : `${v.name} missed its minimum; ${refunded}`,
        });
      }
      const waiting = unpublishedPostMortems(store, cohort);
      if (waiting.length) continue;
      closeCohort(store, cohort);
      events.push({ cohortId: cohort.id, message: `${batchLabel(cohort.number)} closed; batch notes published` });
    }
  }
  for (const v of store.ventures.filter((x) => x.status === "funded")) {
    const r = checkLiftoff(store, v);
    if (r === "asked") events.push({ cohortId: v.cohortId ?? "", message: `${v.name}'s roster is short at the deadline; the steward extends once or ends it` });
    if (r === "ended") events.push({ cohortId: v.cohortId ?? "", message: `${v.name} ended before forming: its roster wasn't filled; every seat refunded in full` });
  }
  settleVentureWaitlists(store);
  return events;
}

/** A venture that misses its seat minimum or its critical roles in the window ends and refunds every seat in full (Article 2). */
function windowKill(store: Store, v: Venture, short: string[] = []): { count: number; totalUsd: number } {
  for (const r of store.rfes.filter((x) => x.ventureId === v.id && isOpen(x))) {
    if (r.status === "posted") r.status = "quorum";
    r.status = "resolved";
    r.resolvedAt = store.meta.clock;
    r.resolution = "Closed: the seat window ended before the raise succeeded.";
  }
  const missing = short.length ? short.join(" and ") : "seats";
  const roles = short.some((x) => x.startsWith("a verified claim"));
  const refund = refundSeats(store, v, roles ? `the seat window ended still needing ${missing}` : "the seat window ended below the minimum");
  const refunded = refund.count
    ? `${refund.count} ${refund.count === 1 ? "seat was" : "seats were"} refunded in full ($${refund.totalUsd})`
    : "there were no seats to refund";
  const pitchedAt = v.statusHistory.find((h) => h.status === "pitched")?.at ?? v.createdAt;
  v.postMortem = {
    summary: roles
      ? `${v.name} ended when its seat window closed, still needing ${missing}. ${refunded}.`
      : `${v.name} did not sell its minimum number of seats in the window. ${refunded}.`,
    whatWeTried: ["Published the memo and the 'Before you take a seat' checks", "Opened seats with the rest of the batch"],
    whyItEnded: roles ? `The raise needs the minimum and a verified claim on each critical role; it was short ${missing}.` : "Members did not take enough seats in the window.",
    costUsd: 0,
    lessons: [roles ? "The critical roles weren't claimed in time. Recruit for them from the first day of the window." : "Not enough people took seats in the window. See the 'Before you take a seat' panel for what looked weak."],
    killReason: roles ? "could not reach buyer" : "no demand",
    stageReached: "Selling seats",
    daysToKillSignal: Math.round((Date.parse(store.meta.clock) - Date.parse(pitchedAt)) / 86_400_000),
    publishedAt: store.meta.clock,
  };
  logDecision(store, {
    ventureId: v.id,
    title: roles ? "End the venture: the raise didn't succeed in the window" : "End the venture: minimum not met in the window",
    reasoning: roles
      ? `The window closed still needing ${missing}. The raise succeeds only with the seat minimum and a verified claim on every critical role, so the venture ends and ${refunded} (Article 2).`
      : `Seats closed below the $${v.minRaiseUsd} minimum. Seat money is held until the minimum is met, so the venture ends and ${refunded} (Article 2).`,
    confidence: 1,
    model: "rule",
    transition: "killed",
    outcome: `Ended; ${refunded}`,
  });
  return refund;
}

export function closeCohort(store: Store, cohort: Cohort) {
  if (cohort.status === "closed") return;
  const pending = unpublishedPostMortems(store, cohort);
  if (pending.length) {
    throw new ProtocolError(`${batchLabel(cohort.number)} can't close until ${pending.map((v) => v.name).join(", ")} publish a post-mortem.`);
  }
  cohort.status = "closed";
  cohort.closedAt = store.meta.clock;
  runLearningPass(store, { kind: "cohort-close", cohortId: cohort.id });
  const anchor = cohort.ventureIds[0] ?? store.ventures.find((v) => v.isProtocol)!.id;
  ledger(store, { ventureId: anchor, kind: "status", note: `${batchLabel(cohort.number)} closed. Batch notes are on the batch page.` });
}

/** The X teaser for an announced batch, which needs sign-off: code names and one line each, never the pitch or budget. */
export function teaserDraft(store: Store, cohort: Cohort, params: ParamValues = resolveParams(store)): RfeDraft {
  const ventures = batchVentures(store, cohort);
  const opens = new Date(cohort.opensAt).toLocaleDateString("en-GB", { day: "numeric", month: "long", timeZone: "UTC" });
  return {
    id: `rfe-batch-${String(cohort.number).padStart(3, "0")}-teaser`,
    type: "action",
    title: `Draft an X teaser for ${batchLabel(cohort.number)}`,
    question: "Review this thread and post it from your own account. The agent never posts or sends DMs.",
    recommendation: "Post as drafted",
    stakes: "low",
    format: "action",
    offerUnits: 0,
    audience: "Steward",
    assignedTo: protocolVenture(store).stewardHandle,
    gtm: {
      channel: "x_post",
      purpose: "teaser",
      cohortId: cohort.id,
      posts: [
        `${batchLabel(cohort.number)} opens ${opens}. ${ventures.length} new ventures, each run by an AI agent, each needing people who know its buyers.`,
        ...ventures.map((v) => `${v.codename}: ${v.teaser}`),
        `Verified members get ${params.EARLY_ACCESS_HOURS} hours early. A seat gets you a venture's requests. It is not a share and pays nothing back.`,
      ],
    },
  };
}

/**
 * Announce the next batch: allocate slots across end markets and business
 * models, spawn one venture per slot, and draft the teaser for the steward.
 * `ideas` lets the operator supply its own idea per slot, keyed by
 * `segmentKey` (Claude); otherwise the library is used.
 */
export function announceBatch(
  store: Store,
  opts: { ideas?: Record<string, IdeaTemplate>; decks?: Record<string, DeckDraft>; model?: string } = {},
): { cohort: Cohort; ventures: Venture[] } {
  const params = resolveParams(store);
  const has = (seg: Segment) => !!opts.ideas?.[segmentKey(seg)] || candidateIdeas(store, seg).length > 0;
  const picks = allocateBatchSlots(store, params, params.VENTURES_PER_BATCH, has);
  if (!picks.length) throw new ProtocolError("No end market and business model has an idea left to spawn.");
  const number = Math.max(0, ...store.cohorts.map((c) => c.number)) + 1;
  const latestClose = store.cohorts.map((c) => c.closesAt).sort().at(-1);
  const earliest = addDays(store.meta.clock, params.BATCH_ANNOUNCE_LEAD_DAYS);
  const opensAt = latestClose && latestClose > earliest ? latestClose : earliest;
  const cohort: Cohort = {
    id: `cohort-${number}`,
    number,
    status: "announced",
    announcedAt: store.meta.clock,
    opensAt,
    closesAt: addHours(opensAt, params.BATCH_WINDOW_HOURS),
    ventureIds: [],
    notes: [],
    slotPlan: picks,
  };
  store.cohorts.push(cohort);
  const ventures = picks.map((p) => spawnVenture(store, cohort, p, { idea: opts.ideas?.[segmentKey(p)], deck: opts.decks?.[segmentKey(p)], model: opts.model }));
  const draft = teaserDraft(store, cohort, params);
  logDecision(store, {
    ventureId: protocolVenture(store).id,
    id: `dec-${draft.id}`,
    title: draft.title,
    reasoning: `${batchLabel(number)} is announced; plans and budgets stay hidden until it opens. Code names and one line each give verified members a reason to come back for early access.`,
    confidence: 0.8,
    model: opts.model ?? "script",
    facts: { publicPost: true },
    rfe: draft,
  });
  ledger(store, { ventureId: protocolVenture(store).id, kind: "status", note: `${batchLabel(number)} announced: ${ventures.map((v) => v.codename).join(", ")}` });
  onBatchAnnounced(store, cohort, ventures.map((v) => v.codename ?? "a new venture"));
  return { cohort, ventures };
}
