import type { ShareCard } from "@av/protocol";

export const OG_SIZE = { width: 1200, height: 630 };

/** Share card layout — Shoalyard brand tokens (ink / seaglass / mist / metal). */
export function OgCard({ card, brand }: { card: ShareCard; brand: string }) {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        background: "#F2F5F4",
        padding: 64,
        fontFamily: "sans-serif",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: 10,
            background: "#0B2128",
            color: "#DCE6E3",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 18,
            fontWeight: 700,
          }}
        >
          SY
        </div>
        <div style={{ fontSize: 26, color: "#0B2128", fontWeight: 600 }}>{brand}</div>
        <div style={{ marginLeft: "auto", fontSize: 22, color: "#4B575B" }}>{card.eyebrow}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", marginTop: 56, flexGrow: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ width: 18, height: 72, borderRadius: 6, background: card.accent || "#2F6F6A" }} />
          <div style={{ fontSize: 76, fontWeight: 700, color: "#0B2128", letterSpacing: -2 }}>{card.title}</div>
        </div>
        <div style={{ fontSize: 36, color: "#4B575B", marginTop: 24, lineHeight: 1.3, maxWidth: 1040 }}>{card.line}</div>
      </div>
      <div style={{ display: "flex", gap: 20 }}>
        {card.stats.map((s) => (
          <div
            key={s.label}
            style={{
              display: "flex",
              flexDirection: "column",
              border: "2px solid #D9E1DF",
              borderRadius: 16,
              background: "white",
              padding: "18px 26px",
            }}
          >
            <div style={{ fontSize: 40, fontWeight: 700, color: "#0B2128" }}>{s.value}</div>
            <div style={{ fontSize: 22, color: "#4B575B" }}>{s.label}</div>
          </div>
        ))}
      </div>
      <div style={{ fontSize: 20, color: "#4B575B", marginTop: 28 }}>
        Many hands. One yard. · Pilot seat UI may still show; agreed path is SAFE seed + cash answers.
      </div>
    </div>
  );
}
