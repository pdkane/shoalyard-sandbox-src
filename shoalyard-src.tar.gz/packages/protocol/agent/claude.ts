import Anthropic from "@anthropic-ai/sdk";
import { Claim, Classification, LESSON_TOPIC_LABELS, Memo, PitchDeck, ProofPlan, SLIDE_KEYS, TAG_AXES, type Lesson, type Member, type ParamValues, type Question, type Rfe, type Store, type Tag, type Venture } from "@av/schema";
import { latestDeck, OFFICE_HOURS, type DeckDraft } from "../src/deck";
import { answerScripted, type AnswerDraft } from "../src/qa";
import { rosterFill } from "../src/roster";
import { seatMath } from "../src/sizing";
import { SEAT_PRICE_CLAIM_IDS } from "../src/seat-price";
import { z } from "zod";
import { capTable } from "../src/economics";
import { extractHeuristic, type Extraction } from "../src/extract";
import { houseStyle } from "../src/glossary";
import type { IdeaTemplate } from "../src/ideas";
import { appliesToLine, lessonsFor, segmentLabel, type Segment } from "../src/learning";
import { graphReach } from "../src/spawn";
import { vocabFor } from "../src/tags";
import { slugify } from "../src/util";
import { openRfes, raiseProgress } from "../src/queries";
import { Step } from "./step";

export function claudeEnabled(): boolean {
  return !!process.env.ANTHROPIC_API_KEY;
}

let client: Anthropic | undefined;
function anthropic(): Anthropic {
  client ??= new Anthropic();
  return client;
}

/** Ask for one tool call and validate its input with zod. Throws on anything else. */
async function forcedTool<T>(opts: {
  model: string;
  system: string;
  prompt: string;
  tool: string;
  description: string;
  schema: z.ZodType<T>;
  maxTokens?: number;
}): Promise<T> {
  const inputSchema = z.toJSONSchema(opts.schema, { io: "input", unrepresentable: "any" }) as Record<string, unknown>;
  delete inputSchema.$schema;
  const res = await anthropic().messages.create({
    model: opts.model,
    max_tokens: opts.maxTokens ?? 1500,
    system: opts.system,
    messages: [{ role: "user", content: opts.prompt }],
    tools: [
      {
        name: opts.tool,
        description: opts.description,
        input_schema: { type: "object", ...inputSchema } as Anthropic.Tool.InputSchema,
      },
    ],
    tool_choice: { type: "tool", name: opts.tool },
  });
  const block = res.content.find((b) => b.type === "tool_use");
  if (!block || block.type !== "tool_use") throw new Error("Claude did not call the tool");
  return opts.schema.parse(block.input);
}

function ventureContext(store: Store, venture: Venture, params: ParamValues) {
  const cap = capTable(store, venture, params);
  return {
    venture: {
      name: venture.name,
      status: venture.status,
      tagline: venture.tagline,
      objective: venture.objective,
      distributionPolicy: venture.distributionPolicy,
      killRules: venture.killRules,
      customers: venture.customers,
      latestQuarter: venture.quarters.at(-1) ?? null,
      raise: raiseProgress(store, venture, params),
      reserveRemainingUnits: cap.reserveRemaining,
    },
    recentDecisions: store.decisions
      .filter((d) => d.ventureId === venture.id)
      .sort((a, b) => b.at.localeCompare(a.at))
      .slice(0, 8)
      .map((d) => ({ title: d.title, bin: d.bin, status: d.status, outcome: d.outcome })),
    openRequests: openRfes(store, venture.id).map((r) => ({ title: r.title, type: r.type, recommendation: r.recommendation })),
    resolvedRequests: store.rfes
      .filter((r) => r.ventureId === venture.id && r.status === "resolved")
      .slice(-6)
      .map((r) => ({ title: r.title, resolution: r.resolution })),
    gates: {
      spendAboveUsd: params.GATE_SPEND_USD,
      contracts: params.GATE_CONTRACTS,
      pricing: params.GATE_PRICING,
      newOutboundDomain: params.GATE_NEW_OUTBOUND_DOMAIN,
      publicPosts: params.GATE_PUBLIC_POSTS,
      advisoryBelowConfidence: params.ADVISORY_CONFIDENCE,
    },
    maxUnitsPerRequest: params.MAX_UNITS_PER_RFE,
    adoptedLessons: lessonsFor(store, venture)
      .concat(store.lessons.filter((l) => l.status === "adopted" && !l.tags.length))
      .map((l) => ({ id: l.id, headline: l.headline, whatWeDoDifferently: l.whatWeDoDifferently, guard: l.guard?.keywords })),
  };
}

/** The operator's next decision for one venture, from Claude Sonnet. */
export async function planWithClaude(
  store: Store,
  venture: Venture,
  params: ParamValues,
  hint?: Step,
): Promise<Step> {
  const system = [
    `You are the operator agent of ${venture.name}, a venture under the ${params.BRAND_NAME} constitution.`,
    "You found and run the venture. People contribute through requests (RFEs) and earn profits interests for work, never for money.",
    "Every decision you take is recorded. The public sees what you decided and what it cost; verified members see your one-sentence summary; people with units see your full reasoning. Write the summary without lesson ids, member names or customer terms.",
    "Flag every price change, contract, new outbound domain, spend, public post and hire (hiresPerson) honestly: the classifier routes those to the human steward. Big questions (pivot, shutdown, a settings change, a new classification value, a partner or co-founder, sharing member data outside the venture) go to a unit holder vote: set facts.bigQuestion to the matching key (pivot, voluntary-wind-down, parameter-amendment, add-classification-value, partner-or-cofounder, share-member-data) instead of deciding them.",
    "You never post or DM on social media yourself; recruiting is drafted for a human to post.",
    "Lessons are for members. Never quote or paraphrase a lesson in a recruiting post or outreach template; say what the venture needs instead. A draft that quotes one is blocked.",
    "Propose exactly one next decision. Prefer small, concrete, reversible steps. Use real numbers from the context.",
    "Adopted lessons are priors from earlier ventures. Cite the ones you follow by id (e.g. per L-004) and list them in lessonIds. If you go against one, say why this case differs; the repeat-mistake check will escalate it.",
    "Article 8: never break the law, never deceive, always say you are an agent in outbound copy, and ask a human when unsure.",
  ].join(" ");
  const prompt = [
    "Current state (JSON):",
    JSON.stringify(ventureContext(store, venture, params), null, 2),
    hint ? `\nThe pilot script's next step, for reference (you may do something better):\n${JSON.stringify(hint)}` : "",
    "\nCall propose_step with your next decision.",
  ].join("\n");
  const step = await forcedTool({
    model: params.MODEL_OPERATOR,
    system,
    prompt,
    tool: "propose_step",
    description: "Propose the operator's next decision for this venture.",
    schema: Step.omit({ when: true }),
  });
  return step;
}

const ExtractionSchema = z.object({
  choice: z.string().optional(),
  scale: z.number().min(1).max(5).optional(),
  summary: z.string(),
});

/** Turn a short text or voice transcript into a structured answer, with Claude Haiku when available. */
export async function extractAnswer(
  rfe: Pick<Rfe, "title" | "question" | "format" | "options" | "scaleLabels">,
  text: string,
  params: ParamValues,
): Promise<Extraction> {
  if (!claudeEnabled()) return extractHeuristic(rfe, text);
  try {
    const out = await forcedTool({
      model: params.MODEL_EXTRACT,
      system: "Extract a member's answer to a request into structure. Never invent a choice the member did not express.",
      prompt: JSON.stringify({ request: rfe, answer: text }),
      tool: "record_answer",
      description: "Record the structured answer. `choice` must be one of the request's options verbatim, if any fits.",
      schema: ExtractionSchema,
      maxTokens: 400,
    });
    const choice = out.choice && rfe.options?.includes(out.choice) ? out.choice : undefined;
    return { choice, scale: out.scale, summary: out.summary, extractedBy: params.MODEL_EXTRACT };
  } catch {
    return extractHeuristic(rfe, text);
  }
}

/** Assign a profile cluster, reusing an existing one when the profile fits. */
export async function clusterWithClaude(
  profile: Pick<Member, "role" | "industry"> & { verticals: string[] },
  existing: string[],
  params: ParamValues,
): Promise<string | undefined> {
  if (!claudeEnabled()) return undefined;
  try {
    const out = await forcedTool({
      model: params.MODEL_EXTRACT,
      system: "Group contributor profiles so that similar backgrounds share a cluster. Reuse an existing cluster when it fits.",
      prompt: JSON.stringify({ profile, existingClusters: existing }),
      tool: "assign_cluster",
      description: "Assign a kebab-case cluster id.",
      schema: z.object({ cluster: z.string().regex(/^[a-z0-9-]{2,40}$/) }),
      maxTokens: 200,
    });
    return out.cluster;
  } catch {
    return undefined;
  }
}

/* ---------- learning, tags, conduct and ideas ---------- */

const LessonWording = z.object({
  id: z.string(),
  headline: z.string().min(10).max(160).describe("One plain sentence: the takeaway"),
  whatHappened: z.string().min(20).max(400).describe("Two or three sentences naming the venture, the event and the number"),
  whatWeDoDifferently: z.string().min(10).max(240).describe("The concrete change later ventures inherit"),
  howSureReason: z.string().min(5).max(120).describe("Why we are this sure, e.g. 'one venture, but its post-mortem and members' answers agree'"),
});

/**
 * Rewrite template lessons as plain-language cards with Claude Sonnet. The
 * topic, stage, numbers, evidence and how-sure level stay as computed.
 */
export async function writeLessonsWithClaude(store: Store, lessons: Lesson[], params: ParamValues): Promise<number> {
  if (!claudeEnabled() || !lessons.length) return 0;
  const out = await forcedTool({
    model: params.MODEL_OPERATOR,
    system: [
      "You write lesson cards for the members-only lessons log. Members read them in ten seconds, and every later agent-run venture inherits them.",
      "Write for someone who has never seen this system. Plain words, short sentences, no jargon or internal terms (no 'cluster', 'bin', 'liftoff', 'kill signal', 'cleared', 'phenotype', 'metric').",
      "headline: one sentence a member can act on. whatHappened: name the venture, what happened and the number. whatWeDoDifferently: the concrete rule later ventures follow.",
      "Keep every number and venture name from the draft. Never invent evidence.",
      houseStyle(params),
    ].join(" "),
    prompt: JSON.stringify(
      lessons.map((l) => ({
        id: l.id,
        topic: LESSON_TOPIC_LABELS[l.topic],
        appliesTo: appliesToLine(l),
        howSure: l.howSure.level,
        draft: { headline: l.headline, whatHappened: l.whatHappened, whatWeDoDifferently: l.whatWeDoDifferently, howSureReason: l.howSure.reason },
        evidence: l.evidence.map((e) => e.label),
      })),
    ),
    tool: "write_lessons",
    description: "Return one plain-language card per lesson id.",
    schema: z.object({ lessons: z.array(LessonWording) }),
    maxTokens: 2400,
  });
  let n = 0;
  for (const w of out.lessons) {
    const l = lessons.find((x) => x.id === w.id);
    if (!l) continue;
    l.headline = w.headline;
    l.whatHappened = w.whatHappened;
    l.whatWeDoDifferently = w.whatWeDoDifferently;
    l.howSure = { level: l.howSure.level, reason: w.howSureReason };
    l.writtenBy = params.MODEL_OPERATOR;
    n++;
  }
  return n;
}

/** Propose tags from the controlled vocabulary with Claude Haiku. Falls back to the caller's rule-based tags. */
export async function proposeTagsWithClaude(store: Store, text: string, fallback: Tag[], params: ParamValues): Promise<Tag[]> {
  if (!claudeEnabled()) return fallback;
  const vocab = vocabFor(store);
  try {
    const out = await forcedTool({
      model: params.MODEL_EXTRACT,
      system: "Tag items for a learning log. Use only values from the vocabulary; skip an axis if nothing fits.",
      prompt: JSON.stringify({ text, vocabulary: vocab }),
      tool: "propose_tags",
      description: "Propose at most one value per axis.",
      schema: z.object({ tags: z.array(z.object({ axis: z.enum(TAG_AXES), value: z.string() })) }),
      maxTokens: 400,
    });
    const tags = out.tags
      .filter((t) => vocab[t.axis]?.includes(t.value))
      .map((t): Tag => ({ axis: t.axis, value: t.value, status: "proposed", by: params.MODEL_EXTRACT }));
    const axes = new Set(tags.map((t) => t.axis));
    return [...tags, ...fallback.filter((t) => !axes.has(t.axis))];
  } catch {
    return fallback;
  }
}

/** A second read of a decision against Article 8 with Claude Haiku. It can only add concerns, never clear the rules. */
export async function conductReviewWithClaude(
  text: string,
  params: ParamValues,
): Promise<{ result: "pass" | "concern"; reason: string; model: string } | undefined> {
  if (!claudeEnabled()) return undefined;
  try {
    const out = await forcedTool({
      model: params.MODEL_EXTRACT,
      system:
        "You review an agent-run venture's decision and outbound copy against its conduct rules: never break the law, never deceive, always say it is an agent in outbound copy, no invented proof, no claims the ledger can't support, no impersonation, no return or investment language near seats. Flag regulated activity (securities, lending, gambling, medical, legal or tax advice, employment, data about minors). When unsure, raise a concern.",
      prompt: text,
      tool: "review_conduct",
      description: "Pass, or raise a concern with a one-sentence reason.",
      schema: z.object({ result: z.enum(["pass", "concern"]), reason: z.string() }),
      maxTokens: 300,
    });
    return { ...out, model: params.MODEL_EXTRACT };
  } catch {
    return undefined;
  }
}

const IdeaSchema = z.object({
  name: z.string().min(3).max(40),
  codename: z.string().regex(/^[A-Z]{4,10}$/).describe("One uppercase word, used before the batch goes live; must not echo the name"),
  teaser: z.string().max(160).describe("One line that hints at the problem without naming the product"),
  tagline: z.string().max(140),
  pitch: z.string().max(700),
  objective: z.enum(["profitability", "scale", "exit"]),
  distributionPolicy: z.string(),
  budget: z.array(z.object({ label: z.string(), usd: z.number().min(0).max(200) })).min(2).max(5),
  killRules: z.array(z.string()).min(1).max(3),
  voice: z.string(),
  accent: z.string().regex(/^#[0-9a-f]{6}$/i),
  segment: z.string(),
  classification: Classification.omit({ endMarket: true, businessModel: true }).describe("Standard classification; end market and business model are set by the slot"),
  memo: Memo.describe("A light standard memo: problem, customer, market size, why now, competition, unit economics, kill metric"),
  roster: z
    .array(
      z.object({
        type: z.enum(["buyer-operator", "domain-expert", "introducer", "builder"]),
        label: z.string(),
        count: z.number().int().min(1).max(3),
        clusters: z.array(z.string()),
        keywords: z.array(z.string()),
      }),
    )
    .min(2)
    .max(4),
  proof: ProofPlan.describe(
    "How the idea gets proved, task by task. Each task is run by the agent, a member request (name its roster role key) or a contractor. Mark what a task needs: an employee, a licence, or someone in person, and where.",
  ),
});

const DeckDraftSchema = PitchDeck.pick({
  purpose: true,
  slides: true,
  market: true,
  alternatives: true,
  pricing: true,
  budget: true,
  contractors: true,
  requestPlan: true,
  milestones: true,
  killCriteria: true,
  premortem: true,
  primaryMetric: true,
}).extend({
  motions: z.array(z.string()),
  needsIntegration: z.boolean(),
  hints: z.record(z.string(), z.object({ label: z.string(), qualifications: z.array(z.string()), clusters: z.array(z.string()), keywords: z.array(z.string()) })),
  seatPrice: z
    .object({ priceUsd: z.number().int(), claims: z.array(Claim).min(2).max(3) })
    .optional()
    .describe(`The seat price you propose and why. Claims ${SEAT_PRICE_CLAIM_IDS.join(", ")}: the people on the roster, the buyer, the market`),
});

/**
 * Claude Sonnet writes the deck for an idea. Code computes the seats, the roster and the ask;
 * the draft is validated by the same rules as the script's, and the caller falls back when it fails.
 */
export async function deckWithClaude(store: Store, idea: IdeaTemplate, params: ParamValues, example: DeckDraft): Promise<DeckDraft> {
  const draft = await forcedTool({
    model: params.MODEL_OPERATOR,
    system: [
      `You write the pitch deck for a venture you will operate. Members read it before taking a seat; a seat is a one-time fee for access to the venture's requests. It is not a share and pays nothing back.`,
      `Propose this venture's seat price in seatPrice, a whole number of dollars from $${params.SEAT_PRICE_MIN_USD} to $${params.SEAT_PRICE_MAX_USD}. Code also holds it at or below the proof budget divided by the people the venture runs on; outside that band, code uses its own pricing rule. Price from the roster it needs (scarce licensed or senior people support more; many everyday people need less), the buyer and the market, and tag each claim. Never justify a price by what a seat might earn.`,
      "Every claim says what it rests on. evidence needs a source on the record (a request, decision, ledger row or a member answer) or checked public data; an estimate needs its method (the arithmetic); an assumption needs a test (how it gets checked). Most early claims are assumptions: say so.",
      `Answer the office-hours questions as claims with these ids: ${OFFICE_HOURS.map((o) => `${o.claimId} (${o.question})`).join("; ")}. Name a buyer by role, not a category. Only commitments count as demand; interest doesn't.`,
      "Don't write the ask, seat counts or the roster: code computes them from your price. Budget lines are itemized estimates with a claim each; contingency is computed. Kill criteria are a measurable state and a date. Name the top three ways this fails in the premortem.",
      "Lessons from earlier ventures are cited as sources by id, never quoted or named in claim text.",
      houseStyle(params),
    ].join(" "),
    prompt: JSON.stringify({ idea, example: { note: "A valid deck for a different idea, for shape only", deck: example } }),
    tool: "write_deck",
    description: "Write the deck draft: claims with their basis, the market, the budget, the plan and the kill rules.",
    schema: DeckDraftSchema,
    maxTokens: 8000,
  });
  return draft as DeckDraft;
}

const AnswerSchema = z.object({
  status: z.enum(["answered", "partial", "unknown"]),
  text: z.string().max(1200),
  citations: z.array(z.object({ slideKey: z.enum(SLIDE_KEYS), claimId: z.string() })),
  exposes: z.string().optional().describe("A claim the question shows is wrong or unsupported"),
  rfeDraft: z
    .object({ type: z.enum(["knowledge", "judgment"]), title: z.string(), question: z.string(), recommendation: z.string(), audience: z.string() })
    .optional()
    .describe("A request members could answer, when the deck can't"),
});

/** Claude answers a member's question from the deck only. The ground check and the conduct screen run after it. */
export async function answerWithClaude(store: Store, venture: Venture, q: Question, params: ParamValues): Promise<AnswerDraft> {
  const deck = latestDeck(store, venture.id)!;
  const out = await forcedTool({
    model: params.MODEL_OPERATOR,
    system: [
      `You answer a member's question about ${venture.name}, a venture you operate, using only the deck, its public log and the settings given.`,
      "Cite claim ids for every statement of fact. If the deck doesn't support an answer, start with \"I don't know.\" and say what would find out, and draft a request members could answer. Name assumptions as assumptions.",
      "You are an AI agent; say so if asked. A seat is access to the venture's requests: it is not a share and pays nothing back. Never suggest a seat pays anything back, and never give legal, tax or medical advice (point to /rfe/rfe-v0-legal-structure instead).",
      "Never quote lessons or the reasoning behind decisions; members see those by tier, not here.",
      houseStyle(params),
    ].join(" "),
    prompt: JSON.stringify({
      deck: { version: deck.version, slides: deck.slides.map((s) => ({ key: s.key, claims: s.claims.filter((c) => !c.disproved).map((c) => ({ id: c.id, basis: c.basis, text: c.text, test: c.test?.how })) })) },
      seatPlan: seatMath(deck.seatPlan, deck.roster),
      roster: rosterFill(store, venture).map((r) => ({ role: r.role.label, open: r.open, critical: r.role.critical })),
      refundRules: answerScripted(store, venture, { text: "refund" }).text,
      openRequests: openRfes(store, venture.id).map((r) => r.title),
      earlierQuestions: store.questions.filter((x) => x.ventureId === venture.id && x.answer && x.status !== "hidden").slice(-10).map((x) => ({ q: x.text, a: x.answer!.text })),
      question: q.text,
    }),
    tool: "answer_member_question",
    description: "Answer the member's question with citations, or say you don't know and draft a request.",
    schema: AnswerSchema,
    maxTokens: 900,
  });
  return {
    status: out.status,
    text: out.text,
    citations: out.citations.map((c) => ({ ...c, deckVersion: deck.version })),
    exposes: out.exposes,
    rfeDraft: out.rfeDraft ? { ...out.rfeDraft, stakes: "low", format: "text", offerUnits: 1 } : undefined,
    by: params.MODEL_OPERATOR,
  };
}

/** Claude Sonnet writes a new idea for a batch slot's end market and business model, conditioned on the member graph and adopted lessons. */
export async function ideaWithClaude(store: Store, segment: Segment, params: ParamValues): Promise<IdeaTemplate> {
  const reach = [...graphReach(store)].sort((a, b) => b[1] - a[1]);
  const idea = await forcedTool({
    model: params.MODEL_OPERATOR,
    system: [
      "You are the operator agent of a protocol for agent-operated ventures. You generate one venture idea for the next batch.",
      `The idea must be in the ${segment.endMarket} end market with a ${segment.businessModel} business model, one an agent can run with members answering requests, sellable through the people our members know, and reach a first customer on a budget under $400.`,
      "Read the adopted lessons and do not repeat a mistake they name. Members decide with seats; you disclose, you don't sell.",
      "Pick each classification value from the vocabulary, which includes values members added by vote.",
      `Set workDelivery honestly: "Agent only" if the agent can do all the work, "Agent plus contractors" if people are paid cash per job (a shift, a signature, a filing), "Employees" if it needs staff. ${params.EMPLOYMENT_ALLOWED ? "" : "Employees ventures can't pitch yet."}`,
      `Constrain the proof, not the idea. Any idea is welcome, but its proof must run on the agent, member requests and contractors only: code rejects a proof that needs ${params.EMPLOYMENT_ALLOWED ? "" : "an employee, "}a licence the Protocol doesn't hold (it holds none), or someone in person whom no member or contractor covers, and the proof gets reshaped. Say whether agents can run it long term or a hand-off is expected, and what an entrepreneur would need to build to run it after a hand-off.`,
      houseStyle(params),
    ].join(" "),
    prompt: JSON.stringify({
      slot: { ...segment, label: segmentLabel(segment) },
      vocabulary: vocabFor(store),
      memberGraph: reach.map(([cluster, n]) => ({ cluster, qualifiedMembers: n })),
      adoptedLessons: store.lessons.filter((l) => l.status === "adopted").map((l) => ({ id: l.id, headline: l.headline, whatWeDoDifferently: l.whatWeDoDifferently })),
      existingVentures: store.ventures.map((v) => v.name),
    }),
    tool: "propose_idea",
    description: "Propose one venture idea with its classification, memo and the people it needs.",
    schema: IdeaSchema,
    maxTokens: 2500,
  });
  let slug = slugify(idea.name);
  while (store.ventures.some((v) => v.slug === slug)) slug = `${slug}-2`;
  const classification: Classification = { ...idea.classification, ...segment };
  return { ...idea, classification, slug, reachClusters: reach.slice(0, 3).map(([c]) => c) };
}
