/**
 * Every number and policy in the pilot. Nothing numeric is hard-coded elsewhere.
 *
 * These are defaults, not rules. Each one can be changed by a holder vote
 * (Constitution, Article 6), which is recorded as an Amendment. `governedBy`
 * names the Protocol request where the question is open or was decided.
 */

import { BUSINESS_MODELS, CUSTOMER_TYPES, END_MARKETS, GEOGRAPHIES, GO_TO_MARKETS, KILL_REASONS, MARKET_TYPES, SLIDE_KEYS, WORK_DELIVERIES } from "./primitives";

export type ParamValue = number | string | boolean | string[] | number[] | Record<string, unknown>;

export interface ParamDef<T extends ParamValue = ParamValue> {
  value: T;
  label: string;
  reason: string;
  governedBy: string;
  group: ParamGroup;
  unit?: string;
}

export type ParamGroup =
  | "identity"
  | "economics"
  | "decisions"
  | "requests"
  | "governance"
  | "reporting"
  | "members"
  | "conduct"
  | "learning"
  | "batches"
  | "pitch"
  | "roster"
  | "qa"
  | "operating"
  | "services"
  | "handoff"
  | "agent";

function p<T extends ParamValue>(def: ParamDef<T>): ParamDef<T> {
  return def;
}

export const PARAMS = {
  BRAND_NAME: p({
    value: "Shoalyard",
    label: "Brand name",
    reason: "The one brand: the yard that builds ventures, and the name in the mark. Trademark not yet checked.",
    governedBy: "rfe-v0-name",
    group: "identity",
  }),
  MARK_TEMPLATE: p({
    value: "{name}, a Shoalyard venture",
    label: "Mark wording",
    reason: "The label only ventures the Protocol builds may use. It ends at hand-off and is lost after too many confirmed breaches (Article 7).",
    governedBy: "rfe-v0-name",
    group: "identity",
  }),
  FOUNDING_STEWARD_HANDLE: p({
    value: "MP",
    label: "Founding steward handle",
    reason: "A public name, not a real one, by default. Overridable with the FOUNDING_STEWARD_HANDLE env var.",
    governedBy: "rfe-v0-role",
    group: "identity",
  }),
  FOUNDING_STEWARD_TITLE: p({
    value: "Founding Steward",
    label: "Founding steward title",
    reason: "A display title only. It gives the steward's powers (Article 4) and nothing more.",
    governedBy: "rfe-v0-role",
    group: "identity",
  }),

  SEAT_PRICE_USD: p({
    value: 10,
    label: "Seat price before per-venture pricing",
    reason: "The one price every venture pitched before Oct 31, 2026 was sold at. Those ventures keep it (Article 6); newer ventures get their own price between the minimum and maximum.",
    governedBy: "rfe-v0-seat-vs-subscription",
    group: "economics",
    unit: "USD",
  }),
  SEAT_PRICE_MIN_USD: p({
    value: 10,
    label: "Lowest seat price",
    reason: "A seat is paid once and gets you one venture's requests. Below $10, card fees eat the seat and the price stops filtering for people who mean to answer.",
    governedBy: "rfe-v0-seat-price",
    group: "economics",
    unit: "USD",
  }),
  SEAT_PRICE_MAX_USD: p({
    value: 100,
    label: "Highest seat price",
    reason:
      "Protected: a vote can lower it, but raising it waits for counsel. At a high price a seat starts to look like paying for a share of the profit rather than buying access, and it never pays anything back.",
    governedBy: "rfe-v0-legal-structure",
    group: "economics",
    unit: "USD",
  }),
  REFUND_IN_FULL: p({
    value: true,
    label: "Refund below the minimum",
    reason:
      "Seat money is held, unspent, until the minimum is met. A venture that misses it refunds every seat in full, and the Protocol pays the card fees (Article 2).",
    governedBy: "rfe-v0-seat-vs-subscription",
    group: "economics",
  }),
  EMPLOYMENT_ALLOWED: p({
    value: false,
    label: "Ventures can employ people",
    reason:
      "Off. A venture may use the agent alone or the agent plus paid contractors; one that needs employees can't pitch. Turning it on needs an employer of record, payroll and insurance first, so a settings vote alone can't do it.",
    governedBy: "rfe-v0-employment",
    group: "economics",
  }),
  SEAT_MONEY_ON_PLAN: p({
    value: true,
    label: "Seat money is spent only on the published plan",
    reason:
      "It's not the agent's money. Before the first customer, seat money pays only for lines in the venture's published budget; anything else needs the deck amended first. Protected: a settings vote can't turn it off.",
    governedBy: "rfe-v0-seat-vs-subscription",
    group: "economics",
  }),
  PROTOCOL_FEE_PCT: p({
    value: 10,
    label: "Protocol fee",
    reason:
      "Chosen by the steward for the pilot (other drafts said 5–8%). The Protocol's units don't vote and are paid the same per unit as everyone's.",
    governedBy: "rfe-v0-cohort-ratio",
    group: "economics",
    unit: "% of units",
  }),
  PASS_THROUGH_COSTS: p({
    value: ["payment processing", "bookkeeping", "formation"],
    label: "Fixed costs",
    reason: "Paid before profit is shared out.",
    governedBy: "rfe-v0-cohort-ratio",
    group: "economics",
  }),
  POOL_UNITS_TOTAL: p({
    value: 100,
    label: "Contributor pool",
    reason: "The units in every venture that go to the people who work on it, after the protocol fee.",
    governedBy: "rfe-v0-cohort-ratio",
    group: "economics",
    unit: "units",
  }),
  POOL_STEWARD_UNITS: p({
    value: 5,
    label: "Steward's units",
    reason: "Stewarding a venture is work, so it earns units like answering a request does.",
    governedBy: "rfe-v0-steward-capacity",
    group: "economics",
    unit: "units",
  }),
  POOL_COHORT_UNITS: p({
    value: 0,
    label: "Batch-wide share",
    reason:
      "Folded into the request reserve. Ownership comes from accepted answers on a venture, not from a batch-wide slice. Kept at 0 so older code paths stay safe.",
    governedBy: "rfe-v0-cohort-ratio",
    group: "economics",
    unit: "units",
  }),
  POOL_RFE_RESERVE_UNITS: p({
    value: 95,
    label: "Units for answering requests",
    reason:
      "Paid one equal share per accepted answer. Buying a seat never earns any. Units nobody earns stay unclaimed; if the venture closes, they're shared among holders by how many units each has.",
    governedBy: "rfe-v0-cohort-ratio",
    group: "economics",
    unit: "units",
  }),
  SHARE_PER_ANSWER: p({
    value: 1,
    label: "Shares per accepted answer",
    reason:
      "Every accepted answer earns the same number of units. The agent does not price one request higher than another; it only decides what to ask and whether to accept.",
    governedBy: "rfe-v0-manipulation",
    group: "economics",
    unit: "units",
  }),
  REFERRAL_UNITS: p({
    value: 0.5,
    label: "Units for a referral that does the work",
    reason:
      "Bringing in someone who fills a roster role and answers its requests is an access contribution, paid once per person per venture. Seat sales never earn units: that would tie money to earnings.",
    governedBy: "rfe-v0-sharing",
    group: "members",
    unit: "units",
  }),
  MAX_UNITS_PER_RFE: p({
    value: 1,
    label: "Most units one person can earn from one request",
    reason: "Equal shares: one accepted answer pays SHARE_PER_ANSWER, never more per person per request.",
    governedBy: "rfe-v0-manipulation",
    group: "economics",
    unit: "units",
  }),
  VESTING_DAYS: p({
    value: 14,
    label: "Vesting delay",
    reason: "Units become fully yours this many days after you earn them.",
    governedBy: "rfe-v0-manipulation",
    group: "economics",
    unit: "days",
  }),

  GATE_SPEND_USD: p({
    value: 100,
    label: "Spending that needs sign-off",
    reason: "Any spend above this needs the steward's sign-off.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
    unit: "USD",
  }),
  GATE_CONTRACTS: p({
    value: true,
    label: "Contracts need sign-off",
    reason: "Any contract needs the steward's sign-off.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
  }),
  GATE_PRICING: p({
    value: true,
    label: "Price changes need sign-off",
    reason: "Project Vend lost money to discounts, so a person signs off on price.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
  }),
  GATE_NEW_OUTBOUND_DOMAIN: p({
    value: true,
    label: "Email from a new domain needs sign-off",
    reason: "Protects the mark from a venture spamming from a fresh domain.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
  }),
  GATE_PUBLIC_POSTS: p({
    value: true,
    label: "Public posts need sign-off",
    reason: "The agent writes the post and the steward posts it. Keeps recruiting inside X's rules.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
  }),
  GATE_HIRING: p({
    value: true,
    label: "Hiring or contracting a person needs sign-off",
    reason: "Paying a person to do work is a commitment to someone outside the venture, so a named person approves it first.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
  }),
  GATE_GOALPOST_MOVES: p({
    value: true,
    label: "Moving a kill rule or target needs sign-off",
    reason:
      "No quiet goalpost moves. Changing a kill rule, its date, a milestone target or the primary metric is a steward decision on the log, with the old value, the new one and the reason.",
    governedBy: "rfe-v0-operating",
    group: "decisions",
  }),
  ADVISORY_CONFIDENCE: p({
    value: 0.7,
    label: "When the agent asks first",
    reason: "Below this confidence in its own answer, the agent asks members before acting. To be tuned from results.",
    governedBy: "rfe-v0-steward-capacity",
    group: "decisions",
  }),

  N_BASELINE: p({
    value: {
      judgment: [3, 7],
      knowledge: [2, 3],
      access: [1, 1],
      credibility: [1, 2],
      action: [1, 1],
      capital: [0, 0],
      stewardship: [1, 1],
    },
    label: "Answers needed, by type",
    reason: "Starting values. Seat requests use the venture's minimum instead.",
    governedBy: "rfe-v0-manipulation",
    group: "requests",
  }),
  STAKES_MULTIPLIER: p({
    value: { low: 1, medium: 1.3, high: 1.6 },
    label: "More answers when more rides on it",
    reason: "The more a decision matters, the more answers it waits for.",
    governedBy: "rfe-v0-manipulation",
    group: "requests",
  }),
  AGREEMENT_STOP: p({
    value: 0.75,
    label: "Close early at agreement",
    reason: "Once enough answers are in and this share agrees, stop asking.",
    governedBy: "rfe-v0-manipulation",
    group: "requests",
  }),
  DIVERGENCE_EXTEND: p({
    value: 0.5,
    label: "Ask more when answers split",
    reason: "If enough answers are in but agreement is below this, ask more people.",
    governedBy: "rfe-v0-manipulation",
    group: "requests",
  }),
  EXTEND_BY: p({
    value: 2,
    label: "Extension size",
    reason: "How many more answers to ask for when answers split.",
    governedBy: "rfe-v0-manipulation",
    group: "requests",
    unit: "answers",
  }),
  QUORUM_GAP_DAYS: p({
    value: 3,
    label: "Days before recruiting",
    reason: "A request still short of answers after this long means no member fits, so the agent writes a recruiting post for it.",
    governedBy: "rfe-v0-fulfilment",
    group: "requests",
    unit: "days",
  }),
  DAILY_PUSH_CAP_DEFAULT: p({
    value: 3,
    label: "Requests sent per day",
    reason: "Too many irrelevant requests make people leave. Members can change their own limit.",
    governedBy: "rfe-v0-fulfilment",
    group: "requests",
    unit: "requests/day",
  }),

  RESERVED_MATTERS: p({
    value: {
      "additional-capital": "simple",
      "objective-or-distribution": "super",
      sale: "super",
      "voluntary-wind-down": "simple",
      "replace-steward": "simple",
      "material-plan-amendment": "simple",
      "parameter-amendment": "simple",
      pivot: "super",
      "add-classification-value": "simple",
      "partner-or-cofounder": "super",
      "share-member-data": "super",
    },
    label: "Big questions (unit holders vote)",
    reason:
      "What unit holders decide instead of the agent (Article 5), and the share of votes each needs: pivoting or shutting down, changing settings, adding a category, taking on a partner or co-founder, sharing member data outside the venture, and the rest of this list.",
    governedBy: "rfe-v0-thresholds",
    group: "governance",
  }),
  SIMPLE_MAJORITY: p({
    value: 0.5,
    label: "Simple majority",
    reason: "Share of the units voted that a change needs to pass, strictly above.",
    governedBy: "rfe-v0-thresholds",
    group: "governance",
  }),
  SUPERMAJORITY: p({
    value: 0.667,
    label: "Supermajority",
    reason: "For changing a venture's goal, selling it, and changing the rules themselves.",
    governedBy: "rfe-v0-thresholds",
    group: "governance",
  }),
  QUORUM_PCT: p({
    value: 0.3,
    label: "Quorum",
    reason: "Share of vested units that must vote for a result to count.",
    governedBy: "rfe-v0-thresholds",
    group: "governance",
  }),
  VOTE_WINDOW_DAYS: p({
    value: 7,
    label: "Voting window",
    reason: "How long a vote stays open.",
    governedBy: "rfe-v0-thresholds",
    group: "governance",
    unit: "days",
  }),
  CONSTITUTION_NOTICE_DAYS: p({
    value: 30,
    label: "Notice before a rule change",
    reason: "A change to the rules is announced this long before the vote opens.",
    governedBy: "rfe-v0-thresholds",
    group: "governance",
    unit: "days",
  }),
  COHORT_VEHICLE_VOTES: p({
    value: false,
    label: "Batch-wide share votes",
    reason: "The batch-wide share sits out every unit-holder vote.",
    governedBy: "rfe-v0-cohort-votes",
    group: "governance",
  }),

  DECISION_DETAIL_VISIBLE_TO: p({
    value: "unit holders",
    label: "Who reads the reasoning",
    reason:
      "\"unit holders\", \"verified members\" or \"public\". The public sees what was decided, by whom and what it cost; verified members also see a short reason; people with units in the venture, or in the Protocol, see the full reasoning (Article 3).",
    governedBy: "rfe-v0-embargo",
    group: "reporting",
  }),
  PRIVATE_DECISION_MAX_DAYS: p({
    value: 90,
    label: "Longest a decision can stay private",
    reason: "A private decision publishes on its own once this many days pass, whatever delay it was given (Article 3).",
    governedBy: "rfe-v0-embargo",
    group: "reporting",
    unit: "days",
  }),
  DEFAULT_EMBARGO_DAYS: p({
    value: 60,
    label: "Days before a private decision is published",
    reason: "Sensitive decisions are published after this delay. The reason is public right away.",
    governedBy: "rfe-v0-embargo",
    group: "reporting",
    unit: "days",
  }),
  REDACTION_REASONS: p({
    value: ["third-party confidentiality", "member privacy", "competitive timing", "legal"],
    label: "Allowed reasons to withhold",
    reason: "Every withheld decision is recorded with one of these.",
    governedBy: "rfe-v0-embargo",
    group: "reporting",
  }),

  VERIFICATION_WEIGHTS: p({
    value: { linkedin: 0.5, x: 0.3, steward: 0.2 },
    label: "How much each check counts",
    reason:
      "Per detail. LinkedIn confirms role, company, seniority and industry; X confirms handle and reach; the steward can confirm any one detail.",
    governedBy: "rfe-v0-qualification",
    group: "members",
  }),
  QUALIFY_MIN_SCORE: p({
    value: 0.2,
    label: "Score needed to be verified",
    reason:
      "Average of the checks across six details, each capped at 1. A confirmed LinkedIn link is enough on its own; without LinkedIn, X plus the steward checking three details is.",
    governedBy: "rfe-v0-qualification",
    group: "members",
  }),

  CONDUCT_CHECKLIST: p({
    value: ["agent-disclosure", "no-invented-proof", "no-unsupported-claims", "no-impersonation", "no-return-language"],
    label: "Conduct checklist",
    reason: "Run on every outgoing message and decision. Unit holders can add checks but can't remove the Article 8 minimum.",
    governedBy: "rfe-v0-conduct",
    group: "conduct",
  }),
  REGULATED_ACTIVITIES: p({
    value: ["securities", "lending", "gambling", "medical advice", "legal advice", "tax advice", "employment", "data about minors"],
    label: "Regulated activities",
    reason: "Touching any of these means the decision needs sign-off and gets a note for lawyers. The list needs a lawyer's review.",
    governedBy: "rfe-v0-legal-structure",
    group: "conduct",
  }),
  MARK_WITHDRAW_BREACHES: p({
    value: 3,
    label: "Breaches before the mark is lost",
    reason: "Confirmed rule breaches after which a venture loses the mark (Article 7).",
    governedBy: "rfe-v0-conduct",
    group: "conduct",
    unit: "breaches",
  }),

  LESSONS_VISIBLE_TO: p({
    value: "qualified members",
    label: "Who can read the lessons",
    reason:
      "The lessons are what members build by doing the work, so they are for members: \"qualified members\" or \"public\". The public still sees every decision and that lessons exist; only the lesson text is kept back.",
    governedBy: "rfe-v0-learning",
    group: "learning",
  }),
  LESSON_ADOPT_CONFIDENCE: p({
    value: 0.7,
    label: "When a lesson is kept",
    reason: "Lessons at or above this confidence are kept automatically, unless they would change a setting; those go to a vote.",
    governedBy: "rfe-v0-learning",
    group: "learning",
  }),
  TAG_VOCAB: p({
    value: {
      endMarket: [...END_MARKETS],
      subVertical: [],
      customer: [...CUSTOMER_TYPES],
      businessModel: [...BUSINESS_MODELS],
      goToMarket: [...GO_TO_MARKETS],
      marketType: [...MARKET_TYPES],
      geography: [...GEOGRAPHIES],
      workDelivery: [...WORK_DELIVERIES],
      stage: ["generated", "pitched", "funded", "formed", "operating", "first customer", "distributing"],
      killReason: [...KILL_REASONS],
    },
    label: "Categories for ventures",
    reason:
      "The standard categories every result and lesson is compared by. Sub-verticals are free text; a new end market, customer, business model, go-to-market or market type is added only by a Protocol vote. Renames and merges are recorded.",
    governedBy: "rfe-v0-learning",
    group: "learning",
  }),

  VENTURES_PER_BATCH: p({
    value: 3,
    label: "Ventures per batch",
    reason: "Small enough that members can read every pitch in one sitting.",
    governedBy: "rfe-v0-batches",
    group: "batches",
    unit: "ventures",
  }),
  BATCH_ANNOUNCE_LEAD_DAYS: p({
    value: 7,
    label: "Announcement lead",
    reason: "Code names and one-line teasers go up this long before seats open.",
    governedBy: "rfe-v0-batches",
    group: "batches",
    unit: "days",
  }),
  BATCH_WINDOW_HOURS: p({
    value: 120,
    label: "Seat window",
    reason: "Every venture in a batch sells seats in the same window. A venture that misses its minimum in the window ends, and every seat is refunded in full.",
    governedBy: "rfe-v0-batches",
    group: "batches",
    unit: "hours",
  }),
  EARLY_ACCESS_HOURS: p({
    value: 24,
    label: "Early access",
    reason: "Verified members can take seats this long before everyone else. They get a head start; nobody is shut out.",
    governedBy: "rfe-v0-batches",
    group: "batches",
    unit: "hours",
  }),
  BATCH_MIN_SLOTS_PER_SEGMENT: p({
    value: 1,
    label: "Turns per end market and business model",
    reason:
      "Every end market and every business model with an idea ready gets at least this many spots per rotation (enough batches to try each one once).",
    governedBy: "rfe-v0-batches",
    group: "batches",
    unit: "spots",
  }),
  BATCH_EXPLORATION_SHARE: p({
    value: 0.34,
    label: "Share kept for untried kinds",
    reason: "Share of each batch kept for the least-tried kinds of venture, whatever the results say.",
    governedBy: "rfe-v0-batches",
    group: "batches",
  }),

  SEAT_BUFFER_PCT: p({
    value: 20,
    label: "Seat buffer",
    reason: "Both Batch 001 ventures spent 97–100% of their budget before the first customer or the end; 20% covers one overrun. It is one setting for every venture, so no idea hides its own buffer line.",
    governedBy: "rfe-v0-seat-sizing",
    group: "pitch",
    unit: "%",
  }),
  SEAT_MAX_MULTIPLE: p({
    value: 1.5,
    label: "Most seats, as a multiple of the minimum",
    reason: "Seats past the minimum add reach and answers, but a venture shouldn't hold seat money it has no listed use for.",
    governedBy: "rfe-v0-seat-sizing",
    group: "pitch",
  }),
  PLAN_HORIZON_MONTHS: p({
    value: 12,
    label: "Business plan length",
    reason: "Long enough to see whether a proof turns into a business that pays its own costs; short enough that the ramp is still a guess you can check against the record.",
    governedBy: "rfe-v0-proof-budget",
    group: "pitch",
    unit: "months",
  }),
  PAYMENT_FEES: p({
    value: { pct: 2.9, fixedUsd: 0.3 },
    label: "Card fees in the plan",
    reason: "List card pricing in 2026 for online payments. The plan counts it as a cost of every sale.",
    governedBy: "rfe-v0-proof-budget",
    group: "pitch",
  }),
  SEAT_FLOOR: p({
    value: 10,
    label: "Seat floor",
    reason: "Below 10 holders, a medium-stakes Judgment request can't reach its target across different kinds of people.",
    governedBy: "rfe-v0-seat-sizing",
    group: "pitch",
    unit: "seats",
  }),
  RESPONSE_RATE: p({
    value: { judgment: 0.2, knowledge: 0.2 },
    label: "Share of holders who answer",
    reason: "Share of seat holders whose answer counts as a distinct response. Dockside's pricing request got 3 of 20 (0.15) before closing early, so 0.2 is a pilot guess, not evidence.",
    governedBy: "rfe-v0-manipulation",
    group: "pitch",
  }),
  READINESS_PLAUSIBLE_SHARE: p({
    value: 0.25,
    label: "Share of other members assumed to take a seat",
    reason: "Used only in the 'Before you take a seat' estimate, never to size anything.",
    governedBy: "rfe-v0-seat-sizing",
    group: "pitch",
  }),
  DECK_SLIDES: p({
    value: [...SLIDE_KEYS],
    label: "Deck slides, in order",
    reason: "The office-hours questions come first: who hurts, what they do today and what anyone has committed. The ask comes last and is computed, not written.",
    governedBy: "rfe-v0-pitch-deck",
    group: "pitch",
  }),
  DECK_MATERIAL_FIELDS: p({
    value: ["seatPlan.min", "budget", "pricing", "killCriteria", "milestones", "primaryMetric"],
    label: "Deck changes that need sign-off",
    reason: "What holders relied on when they took a seat. Changing any of these is a steward decision, and every holder is told.",
    governedBy: "rfe-v0-pitch-deck",
    group: "pitch",
  }),
  DECK_AMEND_WITHDRAW: p({
    value: true,
    label: "Withdraw after a material change",
    reason: "A holder who took a seat under an earlier deck can withdraw for a full refund while seats are still selling.",
    governedBy: "rfe-v0-seat-vs-subscription",
    group: "pitch",
  }),

  FIRST_CUSTOMERS_TARGET: p({
    value: 1,
    label: "Paying customers the roster is sized for",
    reason: "The first-customer stage.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "customers",
  }),
  FUNNEL_RATES: p({
    value: {
      "Small business": { introToCall: 0.5, callToPartner: 0.4, partnerToPaid: 0.34 },
      "Mid-market": { introToCall: 0.4, callToPartner: 0.3, partnerToPaid: 0.3 },
      Enterprise: { introToCall: 0.3, callToPartner: 0.25, partnerToPaid: 0.25 },
      Government: { introToCall: 0.25, callToPartner: 0.2, partnerToPaid: 0.2 },
      Consumer: { testUsers: 20 },
    },
    label: "Intro funnel, by customer",
    reason: "Pilot guesses. Dockside's single intro converted, a sample of one, so the defaults are deliberately cautious.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
  }),
  INTROS_PER_INTRODUCER: p({
    value: 3,
    label: "Intros per introducer",
    reason: "A member can make about three warm intros before formation without spending their reputation.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "intros",
  }),
  INTROS_PER_ICP_OPERATOR: p({
    value: 1,
    label: "Intros per buyer-side member",
    reason: "A buyer-side member can usually introduce one peer.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "intros",
  }),
  ROSTER_ICP_OPERATORS: p({
    value: 3,
    label: "Buyer-side members",
    reason: "Buyer-side dissent proved right in Batch 001; three allows a two-of-three buyer view.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "people",
  }),
  ROSTER_DOMAIN_MIN: p({
    value: 2,
    label: "Domain experts, at least",
    reason: "Two different kinds of expert let the answer rule see disagreement.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "people",
  }),
  ROSTER_ROLE_RULES: p({
    value: { builderIfIntegration: 1, channelPerMotion: 1, legalSectors: ["Fintech", "Healthcare", "Education", "Public sector"], credibilityIfPlanned: 1 },
    label: "Roles the plan calls for",
    reason: "A builder when the product integrates with another system, a channel member per partner or community motion, counsel in regulated sectors, and a vouching member when the plan asks for one.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
  }),
  USERS_PER_CHANNEL_MEMBER: p({
    value: 10,
    label: "Test users per community member",
    reason: "Consumer ventures recruit test users through community members instead of intros.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "users",
  }),
  ROSTER_MAX: p({
    value: 25,
    label: "Largest roster",
    reason: "Larger than this, the venture is a recruiting project, not a launch; the arithmetic tells the agent to pick a narrower buyer.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "people",
  }),
  CRITICAL_ROLES_AT_RAISE: p({
    value: ["icp-operator", "domain-expert", "legal"],
    label: "Roles claimed before the raise succeeds",
    reason:
      "One buyer-side member and one domain expert, plus counsel where the plan needs it, must claim a role before seat money counts. Without them nothing is learned, so the minimum alone isn't enough: otherwise every seat is refunded. Nobody needs a seat to claim a role.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
  }),
  ROSTER_FILL_AT_FORMATION: p({
    value: 50,
    label: "Roster filled before formation",
    reason: "A pilot-friendly bar for a small network: half the roster must be claimed by verified members before formation money is spent. It should rise by Protocol vote as the network grows.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "%",
  }),
  LIFTOFF_WINDOW_DAYS: p({
    value: 21,
    label: "Days to fill the roster",
    reason: "Time after the raise succeeds to reach the formation bar. Then the steward extends once, or the venture ends before forming and every seat is refunded.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "days",
  }),
  LIFTOFF_EXTENSION_DAYS: p({
    value: 14,
    label: "One extension",
    reason: "The steward can extend once. A second miss ends the venture before it forms.",
    governedBy: "rfe-v0-roster-sizing",
    group: "roster",
    unit: "days",
  }),

  QA_DAILY_PER_HANDLE: p({
    value: 3,
    label: "Questions per day, per venture",
    reason: "Enough to probe an idea; stops one handle flooding a page.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "questions",
  }),
  QA_PENDING_DAILY: p({
    value: 1,
    label: "Questions per day before you're verified",
    reason: "New handles are cheap to make.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "questions",
  }),
  QA_OPEN_PER_HANDLE: p({
    value: 5,
    label: "Unanswered questions per handle",
    reason: "Unanswered questions queue on the agent; this caps one handle's share.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "questions",
  }),
  QA_MAX_CHARS: p({
    value: 500,
    label: "Longest question",
    reason: "One question, not an essay.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "characters",
  }),
  QA_PRIORITY_UPVOTES: p({
    value: 5,
    label: "Upvotes for priority",
    reason: "At this many upvotes a question is answered on the next step and reviewed for a deck change.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "upvotes",
  }),
  QA_MATERIAL_UNITS: p({
    value: 1,
    label: "Shares for a question that changes the deck",
    reason: "Same as any other accepted contribution: one equal share. Paid only to verified members, from the request reserve.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "units",
  }),
  QA_UNITS_CAP_PER_VENTURE: p({
    value: 3,
    label: "Most Q&A shares per venture",
    reason: "Keeps asking questions from becoming a way to farm shares.",
    governedBy: "rfe-v0-qa",
    group: "qa",
    unit: "units",
  }),
  QA_HIDE_REASONS: p({
    value: ["personal data about a person", "harassment", "spam or ads", "illegal content", "impersonation"],
    label: "Reasons a question can be hidden",
    reason: "The steward may hide a question only for one of these. A hard or unflattering question isn't on the list.",
    governedBy: "rfe-v0-qa",
    group: "qa",
  }),

  PRIMARY_METRIC_MAX: p({
    value: 1,
    label: "Primary metrics per venture",
    reason: "One number, fixed at formation and changed only by a logged steward decision.",
    governedBy: "rfe-v0-operating",
    group: "operating",
  }),
  GROWTH_TARGET_WEEKLY_PCT: p({
    value: 5,
    label: "Weekly growth target",
    reason: "5–7% a week is good in a startup batch. The low end, because the bases are tiny.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "%/week",
  }),
  GROWTH_FLOOR_WEEKLY_PCT: p({
    value: 1,
    label: "Weekly growth floor",
    reason: "Below 1% a week the venture hasn't yet found what works.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "%/week",
  }),
  GROWTH_MIN_BASE: p({
    value: 10,
    label: "Smallest base for a growth rate",
    reason: "Weekly percentages are reported only once the number is at least 10. Below that, counts only: a rate on a tiny base is noise.",
    governedBy: "rfe-v0-operating",
    group: "operating",
  }),
  FLAT_WEEKS_TO_REVIEW: p({
    value: 4,
    label: "Flat weeks before an early review",
    reason: "Four weeks in a row below the floor bring the monthly review forward.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "weeks",
  }),
  FLAT_REVIEWS_TO_KILL_PROPOSAL: p({
    value: 2,
    label: "Flat reviews before a shutdown proposal",
    reason: "Two 'persevere' reviews in a row with no change send a shutdown proposal to the steward. The kill rules still apply.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "reviews",
  }),
  DEFAULT_ALIVE_CHECK: p({
    value: "weekly",
    label: "Default-alive check",
    reason: "With costs held flat and revenue growing as it has, does the venture reach break-even before cash runs out? Shown in every weekly update.",
    governedBy: "rfe-v0-operating",
    group: "operating",
  }),
  DEFAULT_DEAD_GRACE_WEEKS: p({
    value: 2,
    label: "Default-dead weeks before a Plan B",
    reason: "Two default-dead readings in a row need a written Plan B and the date to switch to it.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "weeks",
  }),
  FIRST_OFFER_DAYS: p({
    value: 14,
    label: "Days to a first offer",
    reason: "From formation to the first offer a customer can pay for: the narrowest wedge, this week, not after the platform.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "days",
  }),
  UNSCALABLE_FIRST_N: p({
    value: 10,
    label: "Customers onboarded by hand",
    reason: "The first 10 customers are onboarded by hand, by the agent and by members' Task requests.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "customers",
  }),
  USER_CONVERSATIONS_PER_WEEK: p({
    value: 5,
    label: "User conversations a week",
    reason: "Real conversations about what buyers did, not whether they'd use it. Only commitments count as demand.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "conversations",
  }),
  UPDATE_CADENCE_DAYS: p({
    value: 7,
    label: "Member update cadence",
    reason: "Weekly during a batch and early operation; ventures move fast at this size.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "days",
  }),
  UPDATE_MAX_ASKS: p({
    value: 3,
    label: "Asks per update",
    reason: "At most three. Each becomes a request; more would dilute members' attention.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "asks",
  }),
  STEWARD_REVIEW_DAYS: p({
    value: 30,
    label: "Steward review cadence",
    reason: "Monthly: the agent recommends persevere, pivot or shut down, and the steward signs.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "days",
  }),
  PREMISE_FAILURES_BEFORE_TEST: p({
    value: 2,
    label: "Failures before testing the premise",
    reason: "Two failures that share a premise are evidence about the premise. The next step is a cheap test of it, not a third attempt.",
    governedBy: "rfe-v0-operating",
    group: "operating",
    unit: "failures",
  }),
  ACQUISITION_SPEND_REQUIRES: p({
    value: { stage: "customer1", contributionMarginPositive: true, paybackMonthsMax: 3 },
    label: "Before paying for growth",
    reason: "No paid growth before a paying customer and a positive margin per customer.",
    governedBy: "rfe-v0-operating",
    group: "operating",
  }),
  TARPIT_PATTERNS: p({
    value: [] as string[],
    label: "Ideas that keep failing",
    reason: "Grows from post-mortems and the prior-attempt search. An idea that matches one must say what changed.",
    governedBy: "rfe-v0-operating",
    group: "operating",
  }),

  MODEL_OPERATOR: p({
    value: "claude-sonnet-5-5",
    label: "Operator model",
    reason: "Runs the venture loop and drafts recruiting copy.",
    governedBy: "rfe-v0-generation",
    group: "agent",
  }),
  MODEL_EXTRACT: p({
    value: "claude-haiku-5-5",
    label: "Extraction model",
    reason: "Turns typed and spoken answers into structured data, and groups similar profiles.",
    governedBy: "rfe-v0-generation",
    group: "agent",
  }),
  SIM_TICK_HOURS: p({
    value: 18,
    label: "Demo hours per step",
    reason: "How far demo time moves each time the agent runs.",
    governedBy: "rfe-v0-fulfilment",
    group: "agent",
    unit: "hours",
  }),
  SERVICES_SHARED_BY: p({
    value: 8,
    label: "Ventures sharing the back office",
    reason: "The pooled back-office costs are split evenly across this many ventures: the eight in the first pilot. Until that many are live, the Protocol covers the difference from its own share, and publishes it.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "ventures",
  }),
  SVC_ENTITY_USD: p({
    value: 150,
    label: "Umbrella entity upkeep, a month (shared)",
    reason: "Annual state filings, registered agent and franchise tax for one umbrella entity, about $1,800 a year at 2026 rates. Each venture is a series under it, so none pays to set up its own company. The legal form is still a question for counsel.",
    governedBy: "rfe-v0-legal-form",
    group: "services",
    unit: "USD",
  }),
  SVC_SERIES_SETUP_USD: p({
    value: 100,
    label: "Opening a venture's series (each, once)",
    reason: "The filing and paperwork to add one series under the umbrella, at cost. A standalone company would cost about $400 plus its own registered agent.",
    governedBy: "rfe-v0-legal-form",
    group: "services",
    unit: "USD",
  }),
  SVC_TEMPLATES_USD: p({
    value: 100,
    label: "Template library, a month (shared)",
    reason: "Customer terms, privacy notice, contractor agreement and NDA, reviewed once by counsel for about $2,400 and spread over 24 months. Every venture uses the same set.",
    governedBy: "rfe-v0-legal-form",
    group: "services",
    unit: "USD",
  }),
  SVC_PAYMENTS_USD: p({
    value: 100,
    label: "Bank and payments, a month (shared)",
    reason: "One business bank account and one payments account, with the Protocol as merchant of record for every venture, plus a sales-tax service. Card fees per sale are counted separately in each plan.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_BOOKS_USD: p({
    value: 240,
    label: "Master books, a month (shared)",
    reason: "Accounting software and a bookkeeper's monthly close for the whole umbrella, with each venture kept as its own class so its books stand alone.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_BOOKS_PER_VENTURE_USD: p({
    value: 40,
    label: "Each venture's books, a month",
    reason: "About 40 minutes of the bookkeeper's time a month per venture at about $60 an hour, reconciling its class.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_CONTRACTOR_PAY_USD: p({
    value: 60,
    label: "Contractor payments and tax forms, a month (shared)",
    reason: "One contractor-payments service that collects tax details, pays contractors and files the year-end forms for every venture.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_INSURANCE_USD: p({
    value: 320,
    label: "Master insurance policy, a month (shared)",
    reason: "General liability plus technology errors and omissions and a cyber rider on one policy, with each venture named. A venture with a risk the policy doesn't cover buys its own top-up.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_MAILBOX_USD: p({
    value: 12,
    label: "Each venture's mailboxes, a month",
    reason: "Two mailboxes on the shared email setup at the volume rate. The venture's own domain stays in its own budget.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_TOOLS_USD: p({
    value: 120,
    label: "Shared tools, a month (shared)",
    reason: "One set of seats for the CRM, forms, analytics and status page, used by every venture instead of each buying its own.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  SVC_HOSTING_USD: p({
    value: 60,
    label: "Shared hosting and logs, a month (shared)",
    reason: "The servers the agents run on, their logs and backups. Each venture's model use is metered and stays in its own budget as agent compute.",
    governedBy: "rfe-v0-services-rates",
    group: "services",
    unit: "USD",
  }),
  HANDOFF_MIN_CUSTOMERS: p({
    value: 10,
    label: "Paying customers before a hand-off",
    reason: "Ten paying customers is enough to show a named buyer pays, which is what the experiment set out to prove. Fewer, and an adopter is buying a guess.",
    governedBy: "rfe-v0-handoff-ready",
    group: "handoff",
    unit: "customers",
  }),
  HANDOFF_GROWTH_WEEKS: p({
    value: 8,
    label: "Weeks at the growth floor before a hand-off",
    reason: "Two months at or above the weekly growth floor shows the demand isn't a one-off. Before weekly updates began, the quarterly revenue record counts, at its weekly rate.",
    governedBy: "rfe-v0-handoff-ready",
    group: "handoff",
    unit: "weeks",
  }),
  HANDOFF_BOOKS_RECONCILED: p({
    value: true,
    label: "Books closed before a hand-off",
    reason: "The shared bookkeeper has to have closed the venture's books for this month or last, so the price and the payout rest on numbers that reconcile.",
    governedBy: "rfe-v0-handoff-ready",
    group: "handoff",
  }),
  HANDOFF_ROSTER_AT_FORMATION: p({
    value: true,
    label: "Roster still at the formation bar",
    reason: "The people who made the proof work should still be in place when it's handed off, so the adopter takes on a working venture and contributors are around to vote.",
    governedBy: "rfe-v0-handoff-ready",
    group: "handoff",
  }),
  HANDOFF_MAX_BREACHES: p({
    value: 0,
    label: "Confirmed breaches allowed before a hand-off",
    reason: "A venture leaves the Protocol with a clean conduct record or not at all; an adopter shouldn't inherit an open problem with the rules.",
    governedBy: "rfe-v0-handoff-ready",
    group: "handoff",
    unit: "breaches",
  }),
} as const;

export type ParamKey = keyof typeof PARAMS;
type Widen<T> = T extends boolean
  ? boolean
  : T extends number
    ? number
    : T extends string
      ? string
      : T extends readonly (infer U)[]
        ? Widen<U>[]
        : T extends object
          ? { -readonly [K in keyof T]: Widen<T[K]> }
          : T;
/** Resolved values: defaults with amendments applied, so literal default types are widened. */
export type ParamValues = { -readonly [K in ParamKey]: Widen<(typeof PARAMS)[K]["value"]> };

export const PARAM_GROUP_LABELS: Record<ParamGroup, string> = {
  identity: "Identity",
  economics: "Money and units",
  decisions: "Decisions the steward signs",
  requests: "Requests and answers",
  governance: "Voting",
  reporting: "Reporting",
  members: "Getting verified",
  conduct: "Conduct (Article 8)",
  learning: "Lessons",
  batches: "Batches",
  pitch: "Pitch deck and seats",
  roster: "Liftoff roster",
  qa: "Member Q&A",
  operating: "Operating the venture",
  services: "Shared back office",
  handoff: "Handing a venture off",
  agent: "Agent",
};

export function defaultParams(): ParamValues {
  const out = {} as Record<string, ParamValue>;
  for (const [key, def] of Object.entries(PARAMS)) {
    out[key] = structuredClone(def.value) as ParamValue;
  }
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  const envHandle = env?.FOUNDING_STEWARD_HANDLE;
  if (envHandle) out.FOUNDING_STEWARD_HANDLE = envHandle;
  return out as ParamValues;
}

export function formatParamValue(value: ParamValue): string {
  if (Array.isArray(value)) return value.join(", ");
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "object") {
    return Object.entries(value)
      .map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(v.every((x) => typeof x === "number") ? "–" : ", ") : String(v)}`)
      .join(" · ");
  }
  return String(value);
}
