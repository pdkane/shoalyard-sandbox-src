import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import {
  SERVICE_AREA_LABELS,
  SERVICE_AREAS,
  servicesAccount,
  protocolCoveringLine,
  sharedServicesCharge,
  STANDALONE_MONTHLY_USD,
  STANDALONE_ONCE_USD,
  rfeById,
  type ServiceItem,
} from "@av/protocol";
import type { ParamValues } from "@av/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { formatUsd } from "@/lib/format";

export const metadata: Metadata = { title: "Shared services" };

const monthName = (m: string) => new Date(`${m}-01T00:00:00Z`).toLocaleString("en-US", { month: "long", year: "numeric", timeZone: "UTC" });

function basisText(item: ServiceItem, params: ParamValues, eachUsd: number): string {
  const rate = params[item.param] as number;
  if (item.basis === "shared") return `${formatUsd(rate)} a month in total, split ${params.SERVICES_SHARED_BY} ways: ${formatUsd(eachUsd, true)} each`;
  if (item.basis === "each") return `${formatUsd(rate)} a month for each venture`;
  return `${formatUsd(rate)} once, when the venture's series opens`;
}

export default async function ServicesPage() {
  const { store, params } = await getData();
  const charge = sharedServicesCharge(params);
  const account = servicesAccount(store);
  const covering = protocolCoveringLine(account);
  const proofMonths = 4;
  const shared = charge.setupUsd + proofMonths * charge.monthlyUsd;
  const alone = STANDALONE_ONCE_USD.formation + STANDALONE_ONCE_USD.templates + proofMonths * (STANDALONE_MONTHLY_USD.books + STANDALONE_MONTHLY_USD.insurance + STANDALONE_MONTHLY_USD.mailboxes);
  const names = new Map(store.ventures.map((v) => [v.id, v]));
  const legal = rfeById(store, "rfe-v0-legal-form");
  const rates = rfeById(store, "rfe-v0-services-rates");

  return (
    <div className="space-y-10">
      <header className="max-w-3xl space-y-3">
        <Link href="/protocol" className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
          <ArrowLeft className="size-4" /> Rules
        </Link>
        <h1 className="text-3xl font-semibold tracking-tight text-balance">One back office behind every venture</h1>
        <p className="text-pretty text-zinc-600">
          No venture sets up its own company, bank, books or insurance. The Protocol runs one legal, finance and operations setup and bills each venture a
          flat <TermServer id="shared-services">shared-services</TermServer> charge, at cost. Each rate below is a setting with its reason, so members can
          vote to change it.
        </p>
      </header>

      <section className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-zinc-200 bg-white p-4">
          <p className="text-xs font-medium tracking-wide text-zinc-500 uppercase">Each venture pays</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{formatUsd(charge.monthlyUsd)} a month</p>
          <p className="text-sm text-zinc-500">plus {formatUsd(charge.setupUsd)} once when its series opens</p>
        </div>
        <div className="rounded-xl border border-zinc-200 bg-white p-4">
          <p className="text-xs font-medium tracking-wide text-zinc-500 uppercase">Over a {proofMonths}-month proof</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{formatUsd(shared)}</p>
          <p className="text-sm text-zinc-500">instead of about {formatUsd(alone)} bought separately</p>
        </div>
        <div className="rounded-xl border border-zinc-200 bg-white p-4">
          <p className="text-xs font-medium tracking-wide text-zinc-500 uppercase">The Protocol pays</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{formatUsd(charge.pooledMonthlyUsd)} a month</p>
          <p className="text-sm text-zinc-500">for the shared items, split across {charge.sharedBy} ventures</p>
          {covering && <p className="mt-1 text-sm font-medium text-amber-800">{covering}.</p>}
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold tracking-tight">What it covers</h2>
        <div className="grid gap-4 lg:grid-cols-3">
          {SERVICE_AREAS.map((area) => (
            <Card key={area}>
              <CardHeader>
                <CardTitle className="flex items-baseline justify-between gap-2">
                  <span>{SERVICE_AREA_LABELS[area]}</span>
                  <span className="text-sm font-normal text-zinc-500 tabular-nums">{formatUsd(charge.byArea[area])} a month each</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="divide-y divide-zinc-100">
                  {charge.items
                    .filter((i) => i.item.area === area)
                    .map(({ item, usd }) => (
                      <li key={item.key} id={item.key} className="scroll-mt-20 py-3 first:pt-0 last:pb-0">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="mt-0.5 text-sm text-pretty text-zinc-600">{item.what}</p>
                        <p className="mt-1 text-xs text-zinc-500">
                          <Link href={`/protocol#${item.param}`} className="underline underline-offset-2 hover:text-zinc-900">
                            {basisText(item, params, usd)}
                          </Link>
                          {item.instead !== "—" ? `. Instead of ${item.instead}.` : "."}
                        </p>
                      </li>
                    ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
        <p className="max-w-3xl text-sm text-pretty text-zinc-500">
          A venture&apos;s own costs stay in its own proof budget: agent compute, its domain, paid tests, contractors, counsel on its specific questions, and
          an insurance top-up if it carries a risk the master policy doesn&apos;t.
        </p>
      </section>

      <section id="account" className="scroll-mt-20 space-y-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">What it cost against what it charged</h2>
          <p className="text-sm text-zinc-500">
            From the Protocol&apos;s public record. Until {charge.sharedBy} ventures use the back office, the charges don&apos;t cover the pooled bills.
            The Protocol absorbs the difference from its own share; no venture is billed more to make it up.
          </p>
        </div>
        <Card>
          <CardContent className="p-0">
            <Table className="text-sm">
              <TableHeader>
                <TableRow>
                  <TableHead>Month</TableHead>
                  <TableHead className="text-right">Charged</TableHead>
                  <TableHead className="text-right">Cost</TableHead>
                  <TableHead className="text-right">Protocol covering</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {account.months.map((m) => (
                  <TableRow key={m.month}>
                    <TableCell>{monthName(m.month)}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatUsd(m.chargedUsd)}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatUsd(m.costUsd)}</TableCell>
                    <TableCell className="text-right text-amber-800 tabular-nums">{m.costUsd > m.chargedUsd ? formatUsd(m.costUsd - m.chargedUsd) : "—"}</TableCell>
                  </TableRow>
                ))}
                <TableRow className="font-medium">
                  <TableCell>Total</TableCell>
                  <TableCell className="text-right tabular-nums">{formatUsd(account.chargedUsd)}</TableCell>
                  <TableCell className="text-right tabular-nums">{formatUsd(account.costUsd)}</TableCell>
                  <TableCell className="text-right text-amber-800 tabular-nums">{account.uncoveredUsd > 0 ? formatUsd(account.uncoveredUsd) : "—"}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        {account.ventures.length > 0 && (
          <p className="text-sm text-zinc-600">
            Charged so far:{" "}
            {account.ventures.map((v, i) => {
              const venture = names.get(v.ventureId);
              return (
                <span key={v.ventureId}>
                  {i > 0 && ", "}
                  <Link href={`/v/${venture?.slug}/ledger?kind=service-charge`} className="underline underline-offset-2">
                    {venture?.name ?? v.ventureId}
                  </Link>{" "}
                  {formatUsd(v.chargedUsd)}
                </span>
              );
            })}
            .{" "}
            <Link href={`/v/${store.ventures.find((v) => v.isProtocol)?.slug}/ledger?kind=service-cost`} className="underline underline-offset-2">
              Every bill the Protocol paid
            </Link>
            .
          </p>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold tracking-tight">Still open</h2>
        <Card>
          <CardHeader>
            <CardDescription>The legal form isn&apos;t decided. These questions are open to members.</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {[legal, rates].filter(Boolean).map((r) => (
                <li key={r!.id}>
                  <Link href={`/rfe/${r!.id}`} className="font-medium underline underline-offset-2">
                    {r!.title}
                  </Link>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
