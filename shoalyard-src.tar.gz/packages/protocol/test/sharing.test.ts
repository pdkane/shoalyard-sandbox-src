import assert from "node:assert/strict";
import { test } from "node:test";
import { MEMBER_ATTRIBUTES, defaultParams, type Store } from "@av/schema";
import { advanceBatches } from "../src/batches";
import { buySeat, completeOnboarding, ensureMember, issueGrant, memberByHandle, payReferrals, stewardVerifyAttribute, ventureBySlug } from "../src/ops";
import { claimRole } from "../src/roster";
import { batchShareCard, ventureShareCard } from "../src/scarcity";
import { ANON_CODE, HANK_CODE, buildSeed } from "../src/seed";
import { ensureShareCode, recordVisit, referralsDue, referrerFunnel, shareText } from "../src/sharing";

const seed = buildSeed();
const SLUG = "lumper-line";
const CODE = "testcode01";
const REFERRER = "tms_tara";

const profile = {
  role: "Dock supervisor",
  industry: "Freight warehousing",
  seniority: "mid" as const,
  companies: [],
  buyingAuthority: "Recommends",
  tools: [],
  verticals: ["freight"],
  canReach: [],
  cluster: "freight-ops",
};

/** Batch 003 live, Lumper Line selling seats, and a link from tms_tara visited once. */
function live(): Store {
  const s = structuredClone(seed) as Store;
  s.meta.clock = "2026-11-07T13:00:00.000Z";
  advanceBatches(s);
  assert.equal(ventureBySlug(s, SLUG)!.status, "pitched");
  ensureShareCode(s, CODE, REFERRER);
  recordVisit(s, { code: CODE, visitor: "vis1", ventureId: ventureBySlug(s, SLUG)!.id, channel: "linkedin" });
  return s;
}

function qualify(s: Store, handle: string) {
  completeOnboarding(s, handle, profile);
  const steward = ventureBySlug(s, "protocol")!.stewardHandle;
  for (const attribute of MEMBER_ATTRIBUTES) {
    if (memberByHandle(s, handle)!.qualification === "qualified") break;
    stewardVerifyAttribute(s, { by: steward, handle, attribute });
  }
  assert.equal(memberByHandle(s, handle)!.qualification, "qualified");
}

function work(s: Store, handle: string) {
  return issueGrant(s, { venture: ventureBySlug(s, SLUG)!, handle, slice: "rfe", units: 1, note: "Answered a request" });
}

const referralGrants = (s: Store) => s.grants.filter((g) => g.referred);

test("a seat never earns referral units, for the referrer or the person referred", () => {
  const s = live();
  buySeat(s, { slug: SLUG, handle: "dock_dee", referredBy: CODE });
  const m = memberByHandle(s, "dock_dee")!;
  assert.equal(m.referredBy, CODE);
  const stages = s.refEvents.filter((e) => e.handle === "dock_dee").map((e) => e.stage);
  assert.deepEqual(stages, ["candidate", "seat"]);
  qualify(s, "dock_dee");
  work(s, "dock_dee");
  assert.deepEqual(referralGrants(s), [], "a seat and paid work, but no roster role: nothing is due");
  assert.deepEqual(referralsDue(s), []);
});

test("a referral pays only once the referred member fills a roster role and does its work, and only once", () => {
  const s = live();
  claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "dock_dee", referredBy: CODE });
  assert.deepEqual(referralGrants(s), [], "an unverified claim pays nothing");
  qualify(s, "dock_dee");
  assert.deepEqual(referralGrants(s), [], "a verified role without work pays nothing");
  work(s, "dock_dee");
  const paid = referralGrants(s);
  assert.equal(paid.length, 1);
  assert.equal(paid[0].handle, REFERRER);
  assert.equal(paid[0].referred, "dock_dee");
  assert.equal(paid[0].units, defaultParams().REFERRAL_UNITS);
  assert.equal(paid[0].ventureId, ventureBySlug(s, SLUG)!.id);
  work(s, "dock_dee");
  payReferrals(s);
  assert.equal(referralGrants(s).length, 1, "paid once per person per venture");
  assert.ok(!s.grants.some((g) => g.handle === "dock_dee" && g.referred), "the referred member's own grants aren't referral grants");
});

test("an anonymous code is paid once its owner has a handle; nobody refers themselves", () => {
  const s = live();
  ensureShareCode(s, "anoncode77");
  claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "dock_dee", referredBy: "anoncode77" });
  qualify(s, "dock_dee");
  work(s, "dock_dee");
  assert.deepEqual(referralGrants(s), []);
  ensureShareCode(s, "anoncode77", "gis_greta");
  ensureShareCode(s, "anoncode77", "someone_else");
  assert.equal(s.shareCodes.find((c) => c.code === "anoncode77")!.handle, "gis_greta", "a code never moves to a second handle");
  payReferrals(s);
  assert.equal(referralGrants(s)[0]?.handle, "gis_greta");

  const self = ensureMember(s, "self_sal", undefined, "selfcode01");
  assert.equal(self.referredBy, undefined, "an unknown code is ignored");
  ensureShareCode(s, "selfcode02", "self_sal");
  const again = ensureMember(s, "self_sal", undefined, "selfcode02");
  assert.equal(again.referredBy, undefined, "an existing member keeps their first touch");
  ensureShareCode(s, "selfcode03", "new_nia");
  assert.equal(ensureMember(s, "new_nia", undefined, "selfcode03").referredBy, undefined, "nobody refers themselves");
});

test("the referrer funnel counts visits and people stage by stage", () => {
  const s = live();
  claimRole(s, { slug: SLUG, roleKey: "icp-operator", handle: "dock_dee", referredBy: CODE });
  buySeat(s, { slug: SLUG, handle: "dock_dee" });
  qualify(s, "dock_dee");
  work(s, "dock_dee");
  const f = referrerFunnel(s, [CODE], REFERRER);
  const count = Object.fromEntries(f.stages.map((r) => [r.stage, r.count]));
  assert.deepEqual(count, { visit: 1, candidate: 1, qualified: 1, seat: 1, role: 1 });
  assert.equal(f.byChannel.find((c) => c.channel === "linkedin")?.visits, 1);
  assert.equal(f.unitsEarned, defaultParams().REFERRAL_UNITS);
  assert.equal(f.referralsPaid, 1);
});

test("the seed has a member's share code with visits and a candidate, and an anonymous code", () => {
  const hank = referrerFunnel(seed, [HANK_CODE], "hvac_hank");
  assert.equal(hank.stages.find((r) => r.stage === "visit")!.count, 5);
  assert.equal(hank.stages.find((r) => r.stage === "candidate")!.count, 1);
  assert.equal(memberByHandle(seed, "shingle_sam")!.referredBy, HANK_CODE);
  const anon = seed.shareCodes.find((c) => c.code === ANON_CODE)!;
  assert.equal(anon.handle, undefined);
  assert.equal(seed.grants.filter((g) => g.referred).length, 0, "nothing in the seed has earned a referral yet");
});

test("codenamed ventures share without leaking their name, slug or tagline", () => {
  const announced = seed.cohorts.find((c) => c.status === "announced")!;
  const ventures = seed.ventures.filter((v) => v.cohortId === announced.id);
  assert.ok(ventures.length > 0);
  const batch = JSON.stringify(batchShareCard(seed, announced));
  for (const v of ventures) {
    const card = ventureShareCard(seed, v);
    assert.equal(card.teaser, true);
    assert.equal(card.title, v.codename);
    const text = JSON.stringify(card) + shareText({ kind: "venture", name: v.name, codename: v.codename, announced: true, line: v.teaser ?? "" });
    for (const secret of [v.name, v.slug, v.tagline]) {
      assert.ok(!text.includes(secret), `${v.codename}'s card leaks “${secret}”`);
      assert.ok(!batch.includes(secret), `the batch card leaks “${secret}”`);
    }
    assert.ok(batch.includes(v.codename!));
  }
});

test("a revealed venture's card shows true seats left, roles claimed and the window", () => {
  const s = live();
  const v = ventureBySlug(s, SLUG)!;
  buySeat(s, { slug: SLUG, handle: "dock_dee" });
  const card = ventureShareCard(s, v);
  assert.equal(card.title, v.name);
  const seats = card.stats.find((x) => x.label === "Seats left")!;
  const max = s.decks.filter((d) => d.ventureId === v.id).at(-1)!.seatPlan.max;
  const sold = s.ledger.filter((l) => l.kind === "seat" && l.ventureId === v.id).length;
  assert.equal(seats.value, `${max - sold} of ${max}`);
  assert.ok(card.stats.some((x) => x.label === "Roles claimed"));
  assert.ok(card.stats.some((x) => x.label === "Window closes"));
});
