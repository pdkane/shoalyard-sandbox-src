import type { Metadata } from "next";
import Link from "next/link";
import { Share2 } from "lucide-react";
import { batchLabel, codenameSlug, isRevealed, REFERRAL_RULE, referrerFunnel, SHARE_CHANNEL_LABELS, shareCodesFor, STAGE_LABELS } from "@av/protocol";
import { REF_STAGES } from "@av/schema";
import { AccountLabel } from "@/components/account-label";
import { EmptyState } from "@/components/empty-state";
import { buttonVariants } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData } from "@/lib/data";
import { formatUnits } from "@/lib/format";
import { readShareCookies } from "@/lib/share";

export const metadata: Metadata = { title: "Your shares" };


export default async function SharesPage() {
  const { store, params, viewer, member } = await getData();
  const { own } = await readShareCookies();
  const linked = member ? shareCodesFor(store, member.handle).map((c) => c.code) : [];
  const codes = [...new Set([...linked, ...(own && !member ? [own] : [])])];
  const funnel = referrerFunnel(store, codes, member?.handle);
  const anonymous = !member && codes.length > 0;
  const top = Math.max(1, funnel.stages[0]?.count ?? 0);
  const ventureName = (id: string) => {
    const v = store.ventures.find((x) => x.id === id);
    if (!v) return id;
    return isRevealed(store, v) ? v.name : (v.codename ?? codenameSlug(v).toUpperCase());
  };
  const referred = member
    ? store.members.filter((m) => m.referredBy && codes.includes(m.referredBy))
    : [];

  return (
    <div className="space-y-8">
      <div>
        <AccountLabel />
        <h1 className="text-2xl font-semibold tracking-tight">Your shares</h1>
        <p className="max-w-2xl text-sm text-zinc-600">
          What your share links brought in, from the first visit to a claimed role. {REFERRAL_RULE} Each one pays {params.REFERRAL_UNITS} units, once
          per person per venture.
        </p>
      </div>

      {codes.length === 0 ? (
        <EmptyState icon={Share2} title="You haven't shared anything yet">
          Every venture, batch, deck and Q&amp;A page has a Share button. You don&apos;t need an account to use it.
          <div className="mt-3">
            <Link href="/" className={buttonVariants({ size: "sm" })}>
              Find a venture to share
            </Link>
          </div>
        </EmptyState>
      ) : (
        <>
          {anonymous && (
            <p className="max-w-2xl rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
              You&apos;re sharing without a handle. Pick one when you take a seat, claim a role or ask a question, and this link becomes yours; any
              units it has earned are paid then.
            </p>
          )}
          <section className="space-y-3">
            <h2 className="text-lg font-semibold tracking-tight">Funnel</h2>
            <ol className="space-y-2">
              {funnel.stages.map((s) => (
                <li key={s.stage} className="grid grid-cols-[8rem_1fr_3rem] items-center gap-3 text-sm">
                  <span className="text-zinc-700">{s.label}</span>
                  <span className="h-2 overflow-hidden rounded-full bg-zinc-100">
                    <span className="block h-full rounded-full bg-zinc-800" style={{ width: `${Math.round((s.count / top) * 100)}%` }} />
                  </span>
                  <span className="text-right font-medium tabular-nums">{s.count}</span>
                </li>
              ))}
            </ol>
            <p className="text-xs text-zinc-500">Visits count visitors once per page. Later stages count people.</p>
            <div className="grid grid-cols-2 gap-3 sm:max-w-md">
              <div className="rounded-xl border border-zinc-200 bg-white p-4">
                <p className="text-2xl font-semibold tabular-nums">{formatUnits(funnel.unitsEarned)}</p>
                <p className="text-xs text-zinc-500">Units from referrals</p>
              </div>
              <div className="rounded-xl border border-zinc-200 bg-white p-4">
                <p className="text-2xl font-semibold tabular-nums">{funnel.referralsPaid}</p>
                <p className="text-xs text-zinc-500">Referrals that did the work</p>
              </div>
            </div>
          </section>

          {funnel.byVenture.length > 0 && (
            <section className="space-y-3">
              <h2 className="text-lg font-semibold tracking-tight">By venture</h2>
              <div className="overflow-x-auto rounded-xl border border-zinc-200 bg-white">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Venture</TableHead>
                      {REF_STAGES.map((s) => (
                        <TableHead key={s} className="text-right">
                          {STAGE_LABELS[s]}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {funnel.byVenture.map((r) => (
                      <TableRow key={r.ventureId}>
                        <TableCell className="font-medium">{ventureName(r.ventureId)}</TableCell>
                        {REF_STAGES.map((s) => (
                          <TableCell key={s} className="text-right tabular-nums">
                            {r.stages[s]}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </section>
          )}

          <section className="space-y-3">
            <h2 className="text-lg font-semibold tracking-tight">By channel</h2>
            <ul className="grid gap-2 sm:grid-cols-3">
              {funnel.byChannel.map((c) => (
                <li key={c.channel} className="rounded-lg border border-zinc-200 bg-white p-3 text-sm">
                  <p className="font-medium text-zinc-900">{(SHARE_CHANNEL_LABELS as Record<string, string>)[c.channel] ?? c.channel}</p>
                  <p className="text-zinc-600">
                    {c.visits} {c.visits === 1 ? "visit" : "visits"} · {c.candidates} signed up
                  </p>
                </li>
              ))}
            </ul>
            {store.cohorts.some((c) => store.refEvents.some((e) => codes.includes(e.code) && e.cohortId === c.id)) && (
              <p className="text-xs text-zinc-500">
                Batch pages shared:{" "}
                {store.cohorts
                  .filter((c) => store.refEvents.some((e) => codes.includes(e.code) && e.cohortId === c.id))
                  .map((c) => batchLabel(c.number))
                  .join(", ")}
              </p>
            )}
          </section>

          {referred.length > 0 && (
            <section className="space-y-2">
              <h2 className="text-lg font-semibold tracking-tight">People you brought in</h2>
              <ul className="space-y-1 text-sm text-zinc-700">
                {referred.map((m) => {
                  const paid = store.grants.some((g) => g.handle === viewer && g.referred === m.handle);
                  return (
                    <li key={m.handle}>
                      <Link href={`/m/${m.handle}`} className="font-medium text-zinc-900 underline-offset-2 hover:underline">
                        @{m.handle}
                      </Link>{" "}
                      · {paid ? "filled a role and did its work" : m.qualification === "qualified" ? "verified; earns once they fill a role and answer its requests" : "signed up; not verified yet"}
                    </li>
                  );
                })}
              </ul>
            </section>
          )}
        </>
      )}
    </div>
  );
}
