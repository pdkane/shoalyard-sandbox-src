import { notFound, redirect } from "next/navigation";
import { awaitingRoster, isLive, isRevealed, liftoffDeadline, lookupVenture, rosterFill, underCurrentRule, type RosterRow } from "@av/protocol";
import type { Store, Venture } from "@av/schema";
import type { RosterClaimContext } from "@/components/protocol-ui";
import type { Data } from "@/lib/data";
import { formatDate } from "@/lib/format";

/**
 * Resolve `/v/[slug]{suffix}` to a venture. The real slug of an announced venture 404s,
 * a codename slug redirects to the real one after reveal, and sub-pages of an announced
 * venture send the visitor back to its teaser.
 */
export function resolveVenture(store: Store, slug: string, suffix = ""): Venture {
  const found = lookupVenture(store, slug);
  if (!found) notFound();
  const { venture, canonical } = found;
  if (suffix && !isRevealed(store, venture)) redirect(`/v/${canonical}`);
  if (canonical !== slug) redirect(`/v/${canonical}${suffix}`);
  return venture;
}

const CLAIMING = new Set<Venture["status"]>(["pitched", "funded", "formed", "operating"]);

export interface RosterView {
  rows: RosterRow[];
  gate?: string;
  claim: RosterClaimContext;
}

/** The roster, the gate it currently faces, and whether the viewer can claim a role. */
export function rosterView(data: Pick<Data, "store" | "params" | "viewer" | "member">, venture: Venture): RosterView {
  const { store, params, viewer, member } = data;
  const rows = rosterFill(store, venture);
  const derived = underCurrentRule(store, venture);
  const critical = rows.filter((r) => r.role.critical).map((r) => r.role.label.toLowerCase());
  let gate: string | undefined;
  if (venture.status === "pitched") {
    gate = derived
      ? `The raise succeeds only with the seat minimum met and a verified claim on ${critical.join(", ") || "its critical roles"}. Otherwise every seat is refunded in full.`
      : "Pitched under the earlier rule, so its raise needs only the seats. The roster still shows who it needs.";
  } else if (awaitingRoster(store, venture)) {
    const by = liftoffDeadline(venture, params);
    gate = `This venture's own plan needs these people before it spends formation money: ${params.ROSTER_FILL_AT_FORMATION}% of roles filled, with every critical role, by ${by ? formatDate(by) : "the deadline"}${venture.liftoff?.extendedUntil ? " (already extended once)" : ` (the steward can extend once by ${params.LIFTOFF_EXTENSION_DAYS} days)`}. Otherwise it ends before forming and every seat is refunded in full.`;
  }
  const mine = store.roleClaims.find((c) => c.ventureId === venture.id && c.handle === viewer && c.status === "claimed");
  return {
    rows,
    gate,
    claim: {
      open: isLive(venture) && !venture.isProtocol && CLAIMING.has(venture.status) && viewer !== venture.stewardHandle && member?.qualification !== "declined",
      visitor: !member,
      pendingViewer: member?.qualification === "pending",
      myRoleKey: mine?.roleKey,
    },
  };
}
