import { seatPriceOf } from "./sizing";
import {
  RFE_TYPES,
  VENTURE_STATUS_LABELS,
  type Decision,
  type ParamValues,
  type Report,
  type Rfe,
  type Store,
  type Venture,
} from "@av/schema";
import { capTable, tallyVote, totalVestedUnits, vestedUnits, type VoteTally } from "./economics";
import { seatsNeeded } from "./n-engine";
import { draftStat } from "./learning";
import { hasSeat, isOpen, responsesFor, rfeById, seatRefunds, seatsSold, ventureById } from "./ops";
import { resolveParams } from "./params";
import { addDays, round } from "./util";

/** When a private decision publishes: its own date, but never later than the maximum (Article 3). */
export function privateUntil(d: Pick<Decision, "embargo" | "at">, maxDays = Infinity): string {
  if (!d.embargo) return d.at;
  if (!Number.isFinite(maxDays)) return d.embargo.until;
  const cap = addDays(d.at, maxDays);
  return d.embargo.until < cap ? d.embargo.until : cap;
}

export function isEmbargoed(d: Pick<Decision, "embargo" | "at">, clock: string, maxDays = Infinity): boolean {
  return !!d.embargo && privateUntil(d, maxDays) > clock;
}

export type PublicDecision =
  | (Decision & { redacted: false })
  | (Pick<Decision, "id" | "ventureId" | "at" | "bin" | "status"> & {
      redacted: true;
      embargo: NonNullable<Decision["embargo"]>;
    });

/** What the public log shows: embargoed items keep only the reason and release date (Article 3). */
export function publicDecisions(store: Store, ventureId: string): PublicDecision[] {
  const max = resolveParams(store).PRIVATE_DECISION_MAX_DAYS;
  return store.decisions
    .filter((d) => d.ventureId === ventureId)
    .sort((a, b) => b.at.localeCompare(a.at))
    .map((d) =>
      isEmbargoed(d, store.meta.clock, max)
        ? { id: d.id, ventureId: d.ventureId, at: d.at, bin: d.bin, status: d.status, redacted: true as const, embargo: { ...d.embargo!, until: privateUntil(d, max) } }
        : { ...d, redacted: false as const },
    );
}

export function raiseProgress(store: Store, venture: Venture, params = resolveParams(store)) {
  const price = seatPriceOf(venture, params);
  const needed = seatsNeeded(venture.minRaiseUsd, price);
  const sold = seatsSold(store, venture.id);
  return { sold, needed, raisedUsd: sold * price, pct: Math.min(100, Math.round((sold / needed) * 100)) };
}

export function latestQuarter(venture: Venture) {
  return venture.quarters[venture.quarters.length - 1];
}

function median(xs: number[]): number {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

export function buildReport(store: Store, venture: Venture, params: ParamValues = resolveParams(store)): Report {
  const q = latestQuarter(venture) ?? { quarter: "—", revenueUsd: 0, costsUsd: 0, passThroughUsd: 0, runwayUsd: 0 };
  const cap = capTable(store, venture, params);
  const rfes = store.rfes.filter((r) => r.ventureId === venture.id && r.kind === "request");
  const decisions = store.decisions.filter((d) => d.ventureId === venture.id);
  const dist = store.distributions.filter((d) => d.ventureId === venture.id && d.quarter === q.quarter);
  const governance = store.rfes.filter((r) => r.ventureId === venture.id && r.kind === "governance" && r.resolvedAt);
  return {
    schema: "agent-ventures/report@1",
    venture: { slug: venture.slug, name: venture.name, status: venture.status, protocolVersion: venture.protocolVersion },
    quarter: q.quarter,
    generatedAt: store.meta.clock,
    attestation: {
      reconciledToLedger: true,
      statement: "Calculated from the public record. The Protocol takes customer payments for every venture, so revenue and costs aren't self-reported.",
    },
    financials: {
      revenueUsd: q.revenueUsd,
      costsUsd: q.costsUsd,
      passThroughUsd: q.passThroughUsd,
      profitUsd: q.revenueUsd - q.costsUsd - q.passThroughUsd,
      distributedUsd: round(dist.reduce((s, d) => s + d.protocolUsd + d.contributorUsd - d.treasuryUsd, 0)),
    },
    capTable: {
      protocolPct: cap.protocolPct,
      contributorPct: cap.contributorPct,
      holderCount: cap.holderCount,
      grantedUnits: cap.grantedUnits,
      treasuryUnits: cap.treasuryUnits,
      topHolderPctOfPool: cap.topHolderPctOfPool,
    },
    rfeFillRates: RFE_TYPES.map((type) => {
      const ofType = rfes.filter((r) => r.type === type);
      const resolved = ofType.filter((r) => r.status === "resolved" || r.status === "scored");
      return {
        type,
        posted: ofType.length,
        resolved: resolved.length,
        medianResponses: median(resolved.map((r) => responsesFor(store, r.id).length)),
      };
    }),
    customers: venture.customers,
    runwayUsd: q.runwayUsd,
    objective: { objective: venture.objective, status: VENTURE_STATUS_LABELS[venture.status] },
    reservedMatterChanges: governance.map((r) => ({ at: r.resolvedAt!, matter: r.governance?.matter ?? r.title, result: r.resolution ?? "" })),
    decisions: {
      auto: decisions.filter((d) => d.bin === "auto").length,
      advisory: decisions.filter((d) => d.bin === "advisory").length,
      gated: decisions.filter((d) => d.bin === "gated").length,
      embargoed: decisions.filter((d) => isEmbargoed(d, store.meta.clock, params.PRIVATE_DECISION_MAX_DAYS)).length,
    },
  };
}

export interface HoldingRow {
  venture: Venture;
  seat: boolean;
  /** Seat money returned because the venture ended before it formed. */
  refundedUsd: number;
  units: number;
  vested: number;
  accepted: number;
  forfeited: number;
  pctOfInterests: number;
  distributedUsd: number;
}

export function holdingsFor(store: Store, handle: string, params = resolveParams(store)): HoldingRow[] {
  return store.ventures
    .map((venture) => {
      const row = capTable(store, venture, params).holders.find((h) => h.handle === handle);
      const distributedUsd = round(
        store.ledger
          .filter((l) => l.ventureId === venture.id && l.kind === "distribution" && l.handle === handle)
          .reduce((s, l) => s + (l.usd ?? 0), 0),
      );
      return {
        venture,
        seat: hasSeat(store, venture.id, handle),
        refundedUsd: seatRefunds(store, venture.id, handle).totalUsd,
        units: row?.units ?? 0,
        vested: row?.vested ?? 0,
        accepted: row?.accepted ?? 0,
        forfeited: row?.forfeited ?? 0,
        pctOfInterests: row?.pctOfInterests ?? 0,
        distributedUsd,
      };
    })
    .filter((r) => r.seat || r.refundedUsd > 0 || r.units > 0 || r.forfeited > 0);
}

export interface GtmStats {
  arrivals: number;
  qualified: number;
  seats: number;
  responses: number;
  /** Answers by arrivals that the venture followed, and of those, how many stood. */
  followed: number;
  right: number;
  handles: string[];
}

/** Which recruiting drafts produced members, seats and answers. */
export function gtmStats(store: Store, rfeId: string): GtmStats {
  const rfe = rfeById(store, rfeId);
  if (!rfe) return { arrivals: 0, qualified: 0, seats: 0, responses: 0, followed: 0, right: 0, handles: [] };
  const { arrivals, qualified, seats, responses, followed, right, handles } = draftStat(store, rfe);
  return { arrivals, qualified, seats, responses, followed, right, handles };
}

export function voteStatus(store: Store, rfe: Rfe, params = resolveParams(store)): VoteTally {
  return tallyVote(rfe, responsesFor(store, rfe.id), totalVestedUnits(store, rfe.ventureId), params);
}

export function voteWeightFor(store: Store, rfe: Rfe, handle: string) {
  return vestedUnits(store, rfe.ventureId, handle);
}

export function openRfes(store: Store, ventureId: string): Rfe[] {
  return store.rfes.filter((r) => r.ventureId === ventureId && isOpen(r)).sort((a, b) => b.postedAt.localeCompare(a.postedAt));
}

export function stewardQueue(store: Store, handle: string) {
  const ventures = new Set(store.ventures.filter((v) => v.stewardHandle === handle).map((v) => v.id));
  return store.decisions
    .filter((d) => ventures.has(d.ventureId) && d.status === "awaiting_steward")
    .sort((a, b) => b.at.localeCompare(a.at))
    .map((d) => ({ decision: d, venture: ventureById(store, d.ventureId) }));
}

export interface PeopleDecision {
  at: string;
  who: "members" | "unit holders" | "steward";
  /** e.g. "5 members", "@MP" */
  whoLabel: string;
  title: string;
  decided: string;
  /** What happened afterwards, when the record says. */
  howItWent?: string;
  href: string;
}

/**
 * The calls people made for a venture, newest first: answered requests, unit-holder
 * votes and the steward's sign-offs. Decisions still withheld stay out (Article 3).
 */
/** Steward notes are reasoning, so only unit holders and the steward see them (Article 3). */
export function peopleDecisions(store: Store, venture: Venture, withNotes = false, limit = 6): PeopleDecision[] {
  const clock = store.meta.clock;
  const maxDays = resolveParams(store).PRIVATE_DECISION_MAX_DAYS;
  const decisionById = new Map(store.decisions.map((d) => [d.id, d]));
  const outcomeOf = (id?: string) => {
    const d = id ? decisionById.get(id) : undefined;
    return d && !isEmbargoed(d, clock, maxDays) ? d.outcome : undefined;
  };
  const out: PeopleDecision[] = [];
  for (const r of store.rfes) {
    if (r.ventureId !== venture.id || !r.resolvedAt || !r.resolution || r.gtm || r.type === "capital" || r.type === "stewardship") continue;
    const answers = responsesFor(store, r.id).length;
    const takenBack = store.grants.filter((g) => g.rfeId === r.id && g.status === "forfeited").length;
    const governance = r.kind === "governance";
    out.push({
      at: r.resolvedAt,
      who: governance ? "unit holders" : "members",
      whoLabel: governance ? "Unit holders" : `${answers} ${answers === 1 ? "member" : "members"}`,
      title: r.title,
      decided: r.resolution,
      howItWent:
        takenBack > 0
          ? `${takenBack} ${takenBack === 1 ? "answer was" : "answers were"} later proven wrong, and those units were taken back.`
          : outcomeOf(r.decisionId),
      href: `/rfe/${r.id}`,
    });
  }
  for (const d of store.decisions) {
    if (d.ventureId !== venture.id || d.bin !== "gated" || isEmbargoed(d, clock, maxDays)) continue;
    if (d.status !== "taken" && d.status !== "rejected") continue;
    out.push({
      at: d.takenAt ?? d.at,
      who: "steward",
      whoLabel: `@${venture.stewardHandle}, steward`,
      title: d.title,
      decided: `${d.status === "taken" ? "Approved" : "Turned down"}${withNotes && d.stewardNote ? `: ${d.stewardNote}` : ""}`,
      howItWent: d.status === "taken" ? d.outcome : undefined,
      href: `/v/${venture.slug}/decisions/${d.id}`,
    });
  }
  return out.sort((a, b) => b.at.localeCompare(a.at)).slice(0, limit);
}
