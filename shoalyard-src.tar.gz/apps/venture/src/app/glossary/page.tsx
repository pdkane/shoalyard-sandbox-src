import type { Metadata } from "next";
import Link from "next/link";
import { renderTerm, settingText, termById, type GlossaryTerm, type TermId } from "@av/protocol";
import { PARAMS } from "@av/schema";
import { HowItWorks } from "@/components/how-it-works";
import { getData } from "@/lib/data";
import { GLOSSARY_SORTED } from "@/lib/terms";

export const metadata: Metadata = { title: "Glossary" };

export default async function GlossaryPage() {
  const { params } = await getData();
  const terms: readonly GlossaryTerm[] = GLOSSARY_SORTED;
  const letters = [...new Set(terms.map((t) => t.term.replace(/^The /, "")[0].toUpperCase()))];

  return (
    <div className="space-y-10">
      <header className="max-w-3xl space-y-3">
        <h1 className="text-3xl font-semibold tracking-tight">Glossary</h1>
        <p className="text-pretty text-zinc-600">
          The {terms.length} words this site uses with a specific meaning. Wherever one appears with a dotted underline, tap or hover it for the
          short version. Numbers in the definitions are the current settings, so they change when members vote to change them.
        </p>
      </header>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold tracking-tight">How it works</h2>
        <HowItWorks params={params} />
      </section>

      <nav aria-label="Jump to letter" className="flex flex-wrap gap-1.5">
        {letters.map((l) => {
          const first = terms.find((t) => t.term.replace(/^The /, "")[0].toUpperCase() === l)!;
          return (
            <a
              key={l}
              href={`#${first.id}`}
              className="inline-flex size-8 items-center justify-center rounded-md border border-zinc-200 bg-white text-sm font-medium hover:bg-zinc-50"
            >
              {l}
            </a>
          );
        })}
      </nav>

      <div className="grid gap-3">
        {terms.map((t) => {
          const r = renderTerm(t, params);
          return (
            <section
              key={t.id}
              id={t.id}
              className="scroll-mt-20 rounded-xl border border-zinc-200 bg-white p-5 target:ring-2 target:ring-zinc-900"
            >
              <h2 className="font-semibold">{t.term}</h2>
              <p className="mt-1 text-pretty text-zinc-700">{r.short}</p>
              {r.long && <p className="mt-2 text-sm text-pretty text-zinc-600">{r.long}</p>}
              {r.example && <p className="mt-2 text-sm text-pretty text-zinc-500">Example: {r.example}</p>}
              {(t.params?.length || t.see?.length) && (
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-zinc-500">
                  {t.params && t.params.length > 0 && (
                    <span>
                      Current setting{t.params.length > 1 ? "s" : ""}:{" "}
                      {t.params.map((k, i) => (
                        <span key={k}>
                          {i > 0 && " · "}
                          <Link href="/protocol#params" className="underline underline-offset-2 hover:text-zinc-900">
                            {PARAMS[k].label}
                          </Link>{" "}
                          {k === "MARK_TEMPLATE" ? `“${settingText(k, params)}”` : settingText(k, params)}
                        </span>
                      ))}
                    </span>
                  )}
                  {t.see && t.see.length > 0 && (
                    <span>
                      Related:{" "}
                      {t.see.map((s, i) => (
                        <span key={s}>
                          {i > 0 && ", "}
                          <a href={`#${s}`} className="underline underline-offset-2 hover:text-zinc-900">
                            {termById(s as TermId).term}
                          </a>
                        </span>
                      ))}
                    </span>
                  )}
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
