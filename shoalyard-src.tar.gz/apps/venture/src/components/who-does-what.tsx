import Link from "next/link";
import { Bot, HandCoins, Users } from "lucide-react";
import { WHO_DOES_WHAT } from "@av/protocol";
import { cn } from "@/lib/utils";

export function WhoDoesWhat({
  className,
  intro,
  contractors,
  compact,
}: {
  className?: string;
  intro?: React.ReactNode;
  /** Level-2 ventures: a third column for the people paid in cash for the work, with what has been paid so far. */
  contractors?: { count: number; totalUsd: number; ledgerHref: string };
  /** Home hero: omit the section title; keep the two columns tight. */
  compact?: boolean;
}) {
  return (
    <section aria-labelledby="who-does-what" className={cn("space-y-3", className)}>
      {!compact && (
        <div>
          <h2 id="who-does-what" className="text-lg font-semibold tracking-tight">
            Who does what
          </h2>
          {intro && <p className="max-w-3xl text-sm text-pretty text-zinc-600">{intro}</p>}
        </div>
      )}
      {compact && intro && (
        <p id="who-does-what" className="text-sm text-pretty text-zinc-600">
          {intro}
        </p>
      )}
      <div className={cn("grid gap-3", contractors ? "md:grid-cols-3" : "md:grid-cols-2")}>
        <div className="rounded-xl border border-zinc-200 bg-white p-4">
          <p className="flex items-center gap-2 text-sm font-medium text-zinc-500">
            <Bot className="size-4" /> The agent does
          </p>
          <ul className="mt-2 space-y-1.5 text-sm text-zinc-700">
            {WHO_DOES_WHAT.agent.map((t) => (
              <li key={t} className="flex gap-2">
                <span aria-hidden className="mt-2 size-1 shrink-0 rounded-full bg-zinc-400" />
                {t}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-xl border-2 border-zinc-900 bg-white p-4">
          <p className="flex items-center gap-2 text-sm font-semibold text-zinc-900">
            <Users className="size-4" /> People do
          </p>
          <ul className="mt-2 space-y-1.5 text-sm font-medium text-zinc-900">
            {WHO_DOES_WHAT.people.map((t) => (
              <li key={t} className="flex gap-2">
                <span aria-hidden className="mt-2 size-1 shrink-0 rounded-full bg-zinc-900" />
                {t}
              </li>
            ))}
          </ul>
        </div>
        {contractors && (
          <div className="rounded-xl border border-zinc-200 bg-white p-4">
            <p className="flex items-center gap-2 text-sm font-medium text-zinc-500">
              <HandCoins className="size-4" /> Paid for the work
            </p>
            <ul className="mt-2 space-y-1.5 text-sm text-zinc-700">
              {WHO_DOES_WHAT.contractors.map((t) => (
                <li key={t} className="flex gap-2">
                  <span aria-hidden className="mt-2 size-1 shrink-0 rounded-full bg-zinc-400" />
                  {t}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-zinc-500">
              {contractors.count === 0 ? (
                "No contractor has been paid yet."
              ) : (
                <>
                  {contractors.count} {contractors.count === 1 ? "payment" : "payments"} so far, ${contractors.totalUsd.toLocaleString("en-US")} in all.{" "}
                  <Link href={contractors.ledgerHref} className="underline underline-offset-2 hover:text-zinc-800">
                    On the public record
                  </Link>
                </>
              )}
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
