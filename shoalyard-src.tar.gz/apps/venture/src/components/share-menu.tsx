"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { Check, Copy, ExternalLink, Share2 } from "lucide-react";
import { toast } from "sonner";
import { recordVisitAction, shareCodeAction } from "@/app/actions";
import { Popover, PopoverContent, PopoverDescription, PopoverTitle, PopoverTrigger } from "@/components/ui/popover";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Channel = "copy" | "native" | "x" | "linkedin";

const noSubscribe = () => () => {};

function linkFor(path: string, code: string, channel: Channel) {
  const url = new URL(path, window.location.origin);
  url.searchParams.set("r", code);
  url.searchParams.set("c", channel);
  return url.toString();
}

/**
 * Share anything public: copy a link, the phone's share sheet, or a prefilled X or LinkedIn post.
 * Anyone can share, signed in or not; the link carries an anonymous code so a referral can be credited
 * later, and only if the person it brings fills a roster role and does the work.
 */
export function ShareMenu({ path, text, label = "Share", className }: { path: string; text: string; label?: string; className?: string }) {
  const [code, setCode] = useState<string>();
  const canNative = useSyncExternalStore(noSubscribe, () => typeof navigator.share === "function", () => false);
  const [copied, setCopied] = useState(false);

  const getCode = async () => {
    if (code) return code;
    const r = await shareCodeAction();
    setCode(r.code);
    return r.code;
  };

  const copy = async () => {
    const url = linkFor(path, await getCode(), "copy");
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success("Link copied");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt("Copy this link", url);
    }
  };

  const native = async () => {
    const url = linkFor(path, await getCode(), "native");
    try {
      await navigator.share({ title: document.title, text, url });
    } catch {
      /* the person closed the share sheet */
    }
  };

  const open = async (channel: "x" | "linkedin") => {
    const win = window.open("about:blank", "_blank");
    if (win) win.opener = null;
    const url = linkFor(path, await getCode(), channel);
    const target =
      channel === "x"
        ? `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`
        : `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
    if (win) win.location.href = target;
    else window.location.href = target;
  };

  const item = "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-zinc-800 hover:bg-zinc-100 focus-visible:bg-zinc-100 focus-visible:outline-none";
  return (
    <Popover onOpenChange={(o) => o && void getCode()}>
      <PopoverTrigger className={cn(buttonVariants({ variant: "outline", size: "sm" }), className)} aria-label={`${label}: copy a link or post it`}>
        <Share2 /> {label}
      </PopoverTrigger>
      <PopoverContent align="end" side="bottom" className="w-64 p-2">
        <PopoverTitle className="px-2 pt-1 text-sm font-semibold text-zinc-900">Share this page</PopoverTitle>
        <PopoverDescription className="px-2 pb-2 text-xs text-zinc-500">
          No account needed. If someone you bring fills a roster role and does its work, you earn units. Seats never do.
        </PopoverDescription>
        <div className="flex flex-col">
          <button type="button" className={item} onClick={copy}>
            {copied ? <Check className="size-4 text-emerald-700" /> : <Copy className="size-4" />} Copy link
          </button>
          {canNative && (
            <button type="button" className={item} onClick={native}>
              <Share2 className="size-4" /> Share…
            </button>
          )}
          <button type="button" className={item} onClick={() => open("x")}>
            <ExternalLink className="size-4" /> Post on X
          </button>
          <button type="button" className={item} onClick={() => open("linkedin")}>
            <ExternalLink className="size-4" /> Post on LinkedIn
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

/** Records a visit that arrived through a share link, then tidies the code out of the address bar. */
export function RefCapture() {
  const params = useSearchParams();
  const pathname = usePathname();
  const done = useRef(false);
  useEffect(() => {
    const code = params.get("r");
    if (!code || done.current) return;
    done.current = true;
    void recordVisitAction({ code, path: pathname, channel: params.get("c") ?? undefined });
    const url = new URL(window.location.href);
    url.searchParams.delete("r");
    url.searchParams.delete("c");
    // A null state lets Next sync its router to the new URL; otherwise its next refresh restores the old one.
    window.history.replaceState(null, "", url.toString());
  }, [params, pathname]);
  return null;
}
