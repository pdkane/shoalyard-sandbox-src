import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams, type Store } from "@av/schema";
import { advanceBatches, announceBatch } from "../src/batches";
import { latestDeck } from "../src/deck";
import { buySeat, seatsSold, ventureBySlug } from "../src/ops";
import { claimRole, rosterFill } from "../src/roster";
import { scarcityFor, ventureShareCard } from "../src/scarcity";
import { buildSeed } from "../src/seed";
import { shareFunnelStats } from "../src/sharing";
import { isFull, joinWaitlist, nextAnnouncedBatch, onSeatsFreed } from "../src/waitlist";

const seed = buildSeed();
const SLUG = "lumper-line";
const EARLY = "2026-11-06T12:00:00.000Z";

function at(iso: string): Store {
  const s = structuredClone(seed) as Store;
  s.meta.clock = iso;
  advanceBatches(s);
  return s;
}

/** Article 8: the agent never misleads. Every scarcity number is recomputed from the store, never typed in. */
function expected(s: Store, slug: string) {
  const v = ventureBySlug(s, slug)!;
  const max = latestDeck(s, v.id)!.seatPlan.max;
  const sold = seatsSold(s, v.id);
  const rows = rosterFill(s, v);
  return {
    seats: `${max - sold} of ${max} seats left`,
    roles: `Roles: ${rows.reduce((n, r) => n + r.filled.length, 0)} of ${rows.reduce((n, r) => n + r.role.count, 0)} claimed`,
  };
}

test("Article 8: seats left, roles claimed and first look all derive from the store and move with it", () => {
  const s = at("2026-11-07T15:30:00.000Z");
  const v = ventureBySlug(s, SLUG)!;
  const before = scarcityFor(s, v);
  assert.deepEqual(before.lines.slice(0, 1), [expected(s, SLUG).seats]);
  assert.ok(before.lines.includes(expected(s, SLUG).roles));
  const hours = Math.floor((Date.parse(s.meta.clock) - Date.parse(EARLY)) / 3600e3);
  assert.equal(before.firstLook?.hoursAgo, hours);
  assert.equal(before.firstLook?.at, EARLY);
  assert.ok(before.lines.includes(`Members got first look ${hours}h ago`));

  for (let i = 0; i < 3; i++) buySeat(s, { slug: SLUG, handle: `buyer_${i}` });
  claimRole(s, { slug: SLUG, roleKey: "domain-expert", handle: "cfo_ines" });
  const after = scarcityFor(s, v);
  assert.equal(after.seats!.left, before.seats!.left - 3);
  assert.equal(after.roles.filled, before.roles.filled + 1);
  assert.ok(after.lines.includes(expected(s, SLUG).seats));
  assert.ok(after.lines.includes(expected(s, SLUG).roles));
  const card = ventureShareCard(s, v);
  assert.equal(card.stats.find((x) => x.label === "Seats left")!.value, `${after.seats!.left} of ${after.seats!.max}`);
});

test("no scarcity is claimed where there is none: announced, ended and the Protocol show no seat lines", () => {
  const s = at("2026-11-01T12:00:00.000Z");
  const announced = s.ventures.find((v) => v.cohortId === nextAnnouncedBatch(s)!.id)!;
  assert.deepEqual(scarcityFor(s, announced).lines, []);
  assert.deepEqual(scarcityFor(s, ventureBySlug(s, "protocol")!).lines, []);
  for (const v of s.ventures.filter((x) => x.status === "killed")) assert.equal(scarcityFor(s, v).seats, undefined);
});

test("the early window says members are in, and when everyone else gets in", () => {
  const s = at("2026-11-06T19:00:00.000Z");
  const sc = scarcityFor(s, ventureBySlug(s, SLUG)!);
  assert.equal(sc.firstLook?.hoursAgo, 7);
  assert.equal(sc.publicOpensAt, "2026-11-07T12:00:00.000Z");
});

test("a full venture is full only at the deck's maximum, and only then takes a waitlist", () => {
  const s = at("2026-11-07T13:00:00.000Z");
  const v = ventureBySlug(s, SLUG)!;
  const max = latestDeck(s, v.id)!.seatPlan.max;
  assert.throws(() => joinWaitlist(s, { handle: "late_lou", slug: SLUG }), /seats left, so there's no waitlist/);
  for (let i = seatsSold(s, v.id); i < max; i++) buySeat(s, { slug: SLUG, handle: `buyer_${i}` });
  assert.ok(isFull(s, v));
  assert.throws(() => buySeat(s, { slug: SLUG, handle: "late_lou" }), /are taken/);
  const sc = scarcityFor(s, v);
  assert.deepEqual([sc.seats!.left, sc.lines[0]], [0, `All ${max} seats taken`]);

  joinWaitlist(s, { handle: "late_lou", slug: SLUG });
  joinWaitlist(s, { handle: "late_lou", slug: SLUG });
  joinWaitlist(s, { handle: "later_liz", slug: SLUG });
  assert.equal(scarcityFor(s, v).waiting, 2, "joining twice holds one place");
  onSeatsFreed(s, v, 1);
  const lou = s.waitlist.find((w) => w.handle === "late_lou")!;
  assert.ok(lou.notifiedAt, "the longest waiting hears first");
  assert.equal(s.waitlist.find((w) => w.handle === "later_liz")!.notifiedAt, undefined);
  assert.ok(s.ledger.some((l) => l.kind === "notify" && l.handle === "late_lou" && /freed up/.test(l.note ?? "")));
});

test("a legacy deck's maximum holds too, so its seats-left number is true", () => {
  const s = at("2026-10-31T12:00:00.000Z");
  const pp = ventureBySlug(s, "permit-pulse")!;
  const max = latestDeck(s, pp.id)!.seatPlan.max;
  assert.ok(scarcityFor(s, pp).lines.includes(expected(s, "permit-pulse").seats));
  for (let i = seatsSold(s, pp.id); i < max; i++) buySeat(s, { slug: "permit-pulse", handle: `pp_${i}` });
  assert.throws(() => buySeat(s, { slug: "permit-pulse", handle: "pp_extra" }), /are taken/);
});

test("the next batch's waitlist hears when it opens; nobody waits on an open batch", () => {
  const s = at("2026-11-01T12:00:00.000Z");
  const next = nextAnnouncedBatch(s)!;
  const w = joinWaitlist(s, { handle: "curious_cy" });
  assert.equal(w.cohortId, next.id);
  s.meta.clock = EARLY;
  advanceBatches(s);
  const told = s.waitlist.find((x) => x.id === w.id)!;
  assert.ok(told.notifiedAt);
  assert.match(told.notice!, new RegExp(`Verified members can take seats today; everyone else from 2026-11-07 12:00 UTC`));
  assert.throws(() => joinWaitlist(s, { handle: "curious_cy", cohortNumber: next.number }), /open now/);
  assert.equal(defaultParams().EARLY_ACCESS_HOURS, 24);
});

test("waiting for a batch that isn't announced yet: told at the announcement, then again when it opens", () => {
  const s = at("2026-11-07T13:00:00.000Z");
  assert.equal(nextAnnouncedBatch(s), undefined);
  const w = joinWaitlist(s, { handle: "curious_cy" });
  assert.equal(w.cohortId, undefined);
  const { cohort, ventures } = announceBatch(s);
  assert.equal(w.cohortId, cohort.id);
  assert.equal(w.notifiedAt, undefined, "still waiting for it to open");
  const note = s.ledger.filter((l) => l.kind === "notify" && l.handle === "curious_cy").at(-1)!.note!;
  for (const v of ventures) {
    assert.ok(note.includes(v.codename!));
    assert.ok(!note.includes(v.name), "the announcement notice uses code names only");
  }
});

test("the learning loop tracks share funnels by channel and venture, including waitlists", () => {
  const f = shareFunnelStats(seed);
  const pp = ventureBySlug(seed, "permit-pulse")!;
  const row = f.byVenture.find((r) => r.key === pp.id)!;
  assert.equal(row.stages.visit, 5);
  assert.equal(row.stages.candidate, 1);
  assert.equal(f.byChannel.find((r) => r.key === "linkedin")!.stages.visit, 3);
  assert.equal(f.totals.visit, seed.refEvents.filter((e) => e.stage === "visit").length);
});
