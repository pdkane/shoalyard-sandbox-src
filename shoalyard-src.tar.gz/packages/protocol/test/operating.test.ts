import assert from "node:assert/strict";
import { test } from "node:test";
import type { Store, Venture } from "@av/schema";
import { tick } from "../agent";
import { advanceBatches } from "../src/batches";
import { allClaims, claimById, latestDeck } from "../src/deck";
import { buySeat, resolveRfe, stewardDecide, transitionVenture, ventureBySlug, type RfeDraft } from "../src/ops";
import {
  applyResolvedRequests,
  defaultAlive,
  publishUpdate,
  reviewDue,
  runReview,
  scoreExperiment,
  scriptedUpdate,
  startExperiment,
  updateDue,
  updatesFor,
} from "../src/operating";
import { answerQuestion, askQuestion } from "../src/qa";
import { claimRole } from "../src/roster";
import { buildSeed } from "../src/seed";

const seed = buildSeed();
const SLUG = "lumper-line";

/** Lumper Line raised, its roster filled, formed and operating. */
function operating(): { s: Store; v: Venture } {
  const s = structuredClone(seed) as Store;
  s.meta.clock = "2026-11-07T13:00:00.000Z";
  advanceBatches(s);
  for (const [roleKey, handle] of [["icp-operator", "dispatch_dana"], ["domain-expert", "cfo_ines"], ["icp-operator", "lanehauler"], ["domain-expert", "bookkeep_bo"], ["builder", "gis_greta"], ["channel", "tms_tara"]] as const) {
    claimRole(s, { slug: SLUG, roleKey, handle });
  }
  for (let i = 0; i < latestDeck(s, SLUG)!.seatPlan.min; i++) buySeat(s, { slug: SLUG, handle: `seat_${i}` });
  const v = ventureBySlug(s, SLUG)!;
  transitionVenture(s, v, "formed");
  transitionVenture(s, v, "operating");
  return { s, v };
}

const later = (s: Store, days: number) => {
  s.meta.clock = new Date(Date.parse(s.meta.clock) + days * 86_400_000).toISOString();
};

const ask = (title: string): RfeDraft => ({ type: "knowledge", title, question: `${title}?`, recommendation: "Unknown", stakes: "low", format: "text", offerUnits: 1, audience: "Any verified holder" });

test("the weekly update needs a lowlight, takes at most three asks, and posts each ask as a request", () => {
  const { s, v } = operating();
  assert.equal(updateDue(s, v), false, "not before a week has passed");
  later(s, 7);
  assert.equal(updateDue(s, v), true);
  assert.throws(() => publishUpdate(s, v, { highlights: ["Shipped"], lowlights: [], asks: [] }), /at least one lowlight/);
  assert.throws(() => publishUpdate(s, v, { highlights: [], lowlights: ["Slow week"], asks: [ask("a"), ask("b"), ask("c"), ask("d")] }), /at most 3 asks/);
  const u = publishUpdate(s, v, { highlights: ["First broker on a call"], lowlights: ["No paying broker yet"], asks: [ask("Intro to a lumper-heavy broker"), ask("Which brokers report lumper fees")] });
  assert.equal(u.asks.length, 2);
  for (const a of u.asks) assert.ok(s.rfes.some((r) => r.id === a.rfeId && r.title === a.text));
  assert.equal(u.metric.name, latestDeck(s, v.id)!.primaryMetric.name);
  assert.equal(u.defaultAlive.status, "too early");
  assert.equal(updateDue(s, v), false);
  later(s, 7);
  v.customers.count = 3;
  const next = publishUpdate(s, v, scriptedUpdate(s, v));
  assert.equal(next.metric.previous, 0);
  assert.equal(next.metric.changePct, undefined, "below a base of 10 only the count is shown");
  assert.ok(next.lowlights.length >= 1);
  assert.equal(updatesFor(s, v.id).length, 2);
});

test("default alive: revenue covering costs, growth reaching break-even, or cash running out first", () => {
  const base = { ...structuredClone(seed.ventures[0]), status: "operating" as const };
  const q = (revenueUsd: number, costsUsd: number, runwayUsd: number) => ({ quarter: "x", revenueUsd, costsUsd, passThroughUsd: 0, runwayUsd });
  assert.equal(defaultAlive({ ...base, quarters: [q(100, 500, 1000), q(600, 500, 1000)] }).status, "alive");
  assert.equal(defaultAlive({ ...base, quarters: [q(200, 500, 1000), q(300, 500, 1000)] }).status, "alive");
  assert.equal(defaultAlive({ ...base, quarters: [q(100, 900, 50), q(110, 900, 50)] }).status, "dead");
  assert.equal(defaultAlive({ ...base, quarters: [q(300, 500, 900), q(300, 500, 900)] }).status, "dead");
  assert.equal(defaultAlive({ ...base, quarters: [] }).status, "too early");
});

test("the monthly review is a steward decision; a kill rule that fired proposes shutdown", () => {
  const { s, v } = operating();
  later(s, 30);
  assert.equal(reviewDue(s, v), true);
  const r = runReview(s, v);
  assert.equal(r.call, "persevere");
  const d = s.decisions.find((x) => x.id === r.decisionId)!;
  assert.equal(d.status, "awaiting_steward");
  assert.ok(d.binReasons.some((x) => /the agent recommends, the steward signs/.test(x)));
  assert.equal(reviewDue(s, v), false, "one review waits at a time");
  stewardDecide(s, d.id, true, "Agreed.", v.stewardHandle);
  const kill = latestDeck(s, v.id)!.killCriteria[0];
  s.meta.clock = new Date(Date.parse(kill.by) + 86_400_000).toISOString();
  const fired = runReview(s, v);
  assert.equal(fired.call, "propose shutdown");
  assert.match(fired.reason, /A kill rule fired/);
  assert.ok(fired.killRules.some((k) => k.status === "fired"));
});

test("four flat weeks bring the review forward", () => {
  const { s, v } = operating();
  for (let i = 0; i < 5; i++) {
    later(s, 7);
    publishUpdate(s, v, scriptedUpdate(s, v));
  }
  const r = runReview(s, v);
  assert.match(r.reason, /flat/);
  stewardDecide(s, r.decisionId, true, "One more month.", v.stewardHandle);
  later(s, 7);
  publishUpdate(s, v, scriptedUpdate(s, v));
  assert.equal(reviewDue(s, v), true, "flat weeks trigger a review before 30 days");
  assert.equal(runReview(s, v).call, "propose shutdown", "a second flat review proposes shutdown");
});

test("experiments are written down first, scored once, and two failures on one premise test the premise", () => {
  const { s, v } = operating();
  const input = { premise: "Brokers reply to cold email", hypothesis: "A cold sequence books 3 calls", metric: "calls booked", successBar: "3 calls from 100 emails", stopRule: "Stop at 100 emails", budgetUsd: 20, days: 14 };
  assert.throws(() => startExperiment(s, v, { ...input, stopRule: "" }), /needs a stop rule/);
  const one = startExperiment(s, v, input);
  scoreExperiment(s, { id: one.id, passed: false, result: "0 calls from 100 emails" });
  assert.throws(() => scoreExperiment(s, { id: one.id, passed: true, result: "actually fine" }), /never re-described/);
  const two = startExperiment(s, v, { ...input, hypothesis: "A shorter cold email books 3 calls" });
  const scored = scoreExperiment(s, { id: two.id, passed: false, result: "1 call from 100 emails" });
  const test = s.rfes.find((r) => r.id === scored.premiseTestRfeId)!;
  assert.equal(test.type, "judgment");
  assert.match(test.title, /Is this premise wrong\? Brokers reply to cold email/);
  assert.throws(() => startExperiment(s, v, { ...input, premise: "brokers reply to cold email!" }), /2 tests that rest on .* failed\. Test the premise first/);
  assert.doesNotThrow(() => startExperiment(s, v, { ...input, premise: "Brokers answer a member intro" }), "a different premise is fine");
  resolveRfe(s, test, undefined, "The premise is wrong; change the approach");
  assert.doesNotThrow(() => startExperiment(s, v, input), "after the premise test resolves, the agent may try again");
});

test("a resolved request goes back on the question it came from and can upgrade a claim to evidence", () => {
  const { s, v } = operating();
  const q = askQuestion(s, { slug: SLUG, handle: "hvac_hank", text: "Will you support Spanish-language dispatchers in Miami next spring?" });
  answerQuestion(s, q);
  assert.equal(q.status, "routed");
  const rfe = s.rfes.find((r) => r.id === q.answer!.routed!.rfeId)!;
  resolveRfe(s, rfe, undefined, "Yes; two members know Miami dispatch desks");
  const deck = latestDeck(s, v.id)!;
  const claim = allClaims(deck).find((c) => c.basis === "assumption")!;
  const testRfe = s.rfes.find((r) => r.ventureId === v.id && r.recommendation && r.id !== rfe.id)!;
  claim.test = { how: claim.test!.how, rfeId: testRfe.id };
  resolveRfe(s, testRfe, undefined, `${testRfe.recommendation}, from four answers`);
  const lines = applyResolvedRequests(s, v);
  assert.ok(q.answer!.updates.some((u) => u.ref === rfe.id && /Miami dispatch desks/.test(u.text)));
  assert.ok(lines.some((l) => l.includes(claim.id)));
  assert.equal(claimById(latestDeck(s, v.id)!, claim.id)?.basis, "evidence");
  assert.equal(applyResolvedRequests(s, v).length, 0, "applied once");
});

test("the agent's step answers open questions on the script", async () => {
  const s = structuredClone(seed) as Store;
  const q = askQuestion(s, { slug: "lien-clock", handle: "hvac_hank", text: "Who would actually buy this?" });
  await tick(s, { venture: "lien-clock", mode: "script" });
  assert.equal(q.status, "answered");
  assert.equal(q.answer?.by, "script");
});
