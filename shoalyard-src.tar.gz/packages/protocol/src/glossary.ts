import { formatParamValue, PARAMS, TAG_AXIS_LABELS, VENTURE_STATUS_LABELS, type ParamKey, type ParamValue, type ParamValues, type TagAxis } from "@av/schema";

/**
 * The house vocabulary: the only terms the UI links and defines. `{KEY}`
 * placeholders are filled from live settings, so a definition stays true after
 * a vote. Keep it to about two dozen terms; adding one should mean retiring one.
 */
export interface GlossaryTerm {
  id: string;
  term: string;
  /** Other forms of the word, for auto-linking. */
  aka?: string[];
  /** One sentence, at most 200 characters, ending with a period. */
  short: string;
  long?: string;
  example?: string;
  see?: string[];
  /** Settings the definition depends on, linked on /glossary. */
  params?: ParamKey[];
}

export const GLOSSARY = [
  {
    id: "agent",
    term: "Agent",
    aka: ["agents", "AI agent"],
    short: "The AI that proposes, runs and keeps the books for each venture.",
    long: "It writes the plan, posts requests, decides small things itself and asks people about the rest. It always says it is an AI.",
    example: "The agent decided to build the permit scraper first, then asked members which counties publish usable data.",
    see: ["venture", "request", "steward"],
  },
  {
    id: "venture",
    term: "Venture",
    aka: ["ventures"],
    short: "A zero-to-one experiment, started and run by the agent under these rules, to prove that a named buyer will pay.",
    long: "Each one has its own seats, shares, steward, proof budget and public ledger. A venture the Protocol builds may use the mark “{MARK_TEMPLATE}”. It ends one of three ways: it shuts down and its post-mortem stays, it keeps running with the agent operating it and profit going to the people with units, or it is handed off to an entrepreneur who adopts it with their own money.",
    example: "Permit Pulse is testing whether contractor sales teams will pay for new building permits every Monday.",
    see: ["agent", "hand-off", "post-mortem", "mark"],
    params: ["MARK_TEMPLATE"],
  },
  {
    id: "seat",
    term: "Seat",
    aka: ["seats", "seat holder", "seat holders"],
    short: "A one-time payment, {SEAT_PRICE_MIN_USD} to {SEAT_PRICE_MAX_USD} set per venture, that lets you receive a venture's requests. It is not a share and pays nothing back.",
    long: "To answer requests you also get verified. A seat never earns units, and you can't sell it. If the venture misses its minimum, you get the full price back.",
    example: "You pay $10 for a seat in Permit Pulse, the price it was pitched at. It sells 17 of 30 seats by the deadline, so it ends and you get your $10 back.",
    see: ["minimum", "verified", "request"],
    params: ["SEAT_PRICE_MIN_USD", "SEAT_PRICE_MAX_USD", "REFUND_IN_FULL"],
  },
  {
    id: "minimum",
    term: "Minimum",
    aka: ["minimums"],
    short: "The number of seats a venture must sell by its deadline to go ahead. If it falls short, everyone is refunded.",
    long: "The minimum is the venture's proof budget divided by its seat price, never fewer than the people it runs on. There is no cap on the number of seats. Ventures pitched before the proof budget keep the minimum they were pitched with. Seat money is held, unspent, until the minimum is reached.",
    example: "$2,500 proof budget ÷ $25 a seat = a minimum of 100 seats.",
    see: ["seat", "batch"],
    params: ["SEAT_PRICE_MIN_USD", "BATCH_WINDOW_HOURS"],
  },
  {
    id: "request",
    term: "Request",
    aka: ["requests"],
    short: "A specific ask from the agent that needs a person: a judgment call, an introduction, a fact, a signature.",
    long: "Every request shows why it needs a person and how many answers it needs. Each accepted answer earns {SHARE_PER_ANSWER} equal share of the venture's profits.",
    example: "Which trade should Permit Pulse serve first: roofing or HVAC? One share per accepted answer.",
    see: ["unit", "verified", "agent"],
    params: ["SHARE_PER_ANSWER"],
  },
  {
    id: "unit",
    term: "Unit",
    aka: ["units", "share", "shares"],
    short: "An equal slice of a venture's profit share, earned only by accepted work. Each venture has {POOL_UNITS_TOTAL} for the people who work on it.",
    long: "Every accepted answer earns {SHARE_PER_ANSWER} unit. Stewarding earns a fixed allotment. Paying for a seat never earns any. When the venture pays out profit, each vested unit gets the same amount.",
    example: "Answer three requests, hold 3 vested units, and receive 3 × the per-unit payout.",
    see: ["contributor-pool", "vesting", "profit-share"],
    params: ["POOL_UNITS_TOTAL", "SHARE_PER_ANSWER"],
  },
  {
    id: "contributor-pool",
    term: "Contributor pool",
    short: "The {POOL_UNITS_TOTAL} units of each venture set aside for the people who work on it.",
    long: "{POOL_RFE_RESERVE_UNITS} units go to accepted answers; {POOL_STEWARD_UNITS} go to the steward. Units nobody earns stay unclaimed.",
    see: ["unit", "protocol-fee"],
    params: ["POOL_UNITS_TOTAL", "POOL_RFE_RESERVE_UNITS", "POOL_STEWARD_UNITS"],
  },
  {
    id: "profit-share",
    term: "Profit share",
    aka: ["profit shares", "share of the profit"],
    short: "Your units in a venture, which pay out part of its profit and give you a vote.",
    long: "Legally this is a profits interest: a share of future profit given for work, never sold. A seat is not one. Shares are equal: one accepted answer, one unit.",
    example: "Answer three requests in Dockside, earn 3 units, and receive 3 × the per-unit payout each quarter.",
    see: ["unit", "holder-vote"],
  },
  {
    id: "vesting",
    term: "Vesting",
    aka: ["vest", "vests", "vested"],
    short: "Earned units become fully yours {VESTING_DAYS} days after you earn them. Until then they can be taken back.",
    long: "All of a request's units vest at once on that day. Before then, units can be taken back if the answer they paid for proves wrong. Vested units vote and receive payouts.",
    example: "Earned Oct 1, vested Oct 15.",
    see: ["unit", "holder-vote"],
    params: ["VESTING_DAYS"],
  },
  {
    id: "steward",
    term: "Steward",
    aka: ["stewards"],
    short: "The named person who signs off on a venture's risky moves and can shut it down.",
    long: "The founding steward stewards every venture in the pilot and earns {POOL_STEWARD_UNITS} units per venture for it.",
    example: "The agent wanted to buy a $60 email list; the steward said no.",
    see: ["sign-off", "kill-rule"],
    params: ["POOL_STEWARD_UNITS"],
  },
  {
    id: "protocol",
    term: "The Protocol",
    aka: ["Protocol"],
    short: "The body behind {BRAND_NAME}: it builds the ventures, keeps the public record, receives the protocol fee, and its unit holders vote on the rules.",
    long: "Only ventures the Protocol builds may use the mark.",
    example: "Should a seat be a one-time payment or a subscription? That is a Protocol request.",
    see: ["constitution", "protocol-fee", "setting", "mark"],
    params: ["BRAND_NAME"],
  },
  {
    id: "protocol-fee",
    term: "Protocol fee",
    short: "The {PROTOCOL_FEE_PCT}% of each venture's profit share that goes to the Protocol.",
    long: "It is paid like units, so the Protocol only earns when a venture makes a profit. The Protocol's share doesn't vote.",
    see: ["protocol", "contributor-pool"],
    params: ["PROTOCOL_FEE_PCT"],
  },
  {
    id: "batch",
    term: "Batch",
    aka: ["batches"],
    short: "A group of about {VENTURES_PER_BATCH} ventures that open for seats in the same window.",
    long: "A batch is announced with code names only. Verified members get in {EARLY_ACCESS_HOURS} hours early, then seats stay open to everyone. The batch closes once every venture that ended has published its post-mortem.",
    see: ["minimum", "post-mortem"],
    params: ["VENTURES_PER_BATCH", "EARLY_ACCESS_HOURS", "BATCH_WINDOW_HOURS"],
  },
  {
    id: "sign-off",
    term: "Needs sign-off",
    aka: ["sign-off", "signs off"],
    short: "A decision the agent can't take until the steward approves it.",
    long: "Other decisions the agent takes on its own and records, or puts to members first when it is less than {ADVISORY_CONFIDENCE} sure.",
    example: "Posting on X needs sign-off: the agent writes the post, and the steward posts it.",
    see: ["steward", "ledger"],
    params: ["GATE_SPEND_USD", "ADVISORY_CONFIDENCE"],
  },
  {
    id: "contractor",
    term: "Contractor",
    aka: ["contractors", "paid contractor"],
    short: "A person paid in cash for a hands-on job, such as a shift or a filing; contractors never earn units for it.",
    long: "Ventures say who does the work: the agent alone, the agent plus contractors, or employees. Contractors need the steward's sign-off for each hire. Employees aren't allowed yet. The ledger shows each payment, never the person's name.",
    example: "Chairside paid Contractor 1 $240 for a same-day trial shift.",
    see: ["unit", "sign-off", "ledger"],
    params: ["EMPLOYMENT_ALLOWED", "GATE_HIRING"],
  },
  {
    id: "ledger",
    term: "Ledger",
    aka: ["public record"],
    short: "The public, add-only record of every seat, refund, unit, payout and decision for a venture.",
    long: "Nothing is edited or deleted. Anyone can see what was decided, by whom and what it cost; the reasoning is for people with units. The report and the units table are calculated from it.",
    example: "Oct 5: payout, 0.5 vested units × $51.75 = $25.88.",
    see: ["venture"],
  },
  {
    id: "shared-services",
    term: "Shared services",
    aka: ["shared back office", "back office", "shared-services charge"],
    short: "The one back office every venture uses: a legal umbrella, one bank and payments setup, shared books, insurance and tools, billed to each venture at cost.",
    long: "Each venture pays a flat monthly charge worked out from the at-cost rates, with pooled costs split across {SERVICES_SHARED_BY} ventures. The Protocol publishes what it pays against what it collects.",
    example: "Dockside pays one monthly charge instead of buying its own company filing, books, insurance and mailboxes.",
    see: ["protocol", "ledger"],
    params: ["SERVICES_SHARED_BY", "SVC_ENTITY_USD", "SVC_INSURANCE_USD"],
  },
  {
    id: "kill-rule",
    term: "Kill rule",
    aka: ["kill rules", "shut-down rules"],
    short: "A condition, set before launch, that ends the venture if it happens.",
    long: "The steward can also shut a venture down at any time, and the reason is published.",
    example: "No paying contractor by March 31, 2027.",
    see: ["steward", "post-mortem"],
  },
  {
    id: "hand-off",
    term: "Hand-off",
    aka: ["hand off", "handed off", "handing off"],
    short: "When an entrepreneur adopts a venture that has proved a buyer pays and takes it forward with their own money.",
    long: "The venture must meet the hand-off checklist first. The entrepreneur makes an offer, the agent summarises it, the steward checks it follows the rules and the people with units vote. The cash for contributors is paid to vested units; seats never share in a hand-off. Its mark ends with it.",
    example: "An operator offers $15,000 to adopt Dockside, with $12,000 paid to contributors and 10% of the profit kept for them.",
    see: ["venture", "unit", "steward"],
    params: ["HANDOFF_MIN_CUSTOMERS", "HANDOFF_GROWTH_WEEKS"],
  },
  {
    id: "post-mortem",
    term: "Post-mortem",
    aka: ["post-mortems"],
    short: "The public write-up a venture publishes when it ends: what it tried, why it stopped, what it cost.",
    example: "Chairside Shifts ended because dental practices only trust hygienists they already know.",
    see: ["lesson", "kill-rule"],
  },
  {
    id: "lesson",
    term: "Lesson",
    aka: ["lessons"],
    short: "A short, evidence-backed takeaway from a past venture that later ventures must follow or explain why not.",
    long: "Each lesson says what happened, what we'll do differently, how sure we are and what it applies to. If the agent plans something a lesson warns against, the decision needs more review.",
    example: "With small-business buyers, ask a member for an intro instead of cold email.",
    see: ["post-mortem"],
    params: ["LESSON_ADOPT_CONFIDENCE"],
  },
  {
    id: "verified",
    term: "Verified",
    aka: ["qualified", "verification", "get verified"],
    short: "A member whose interview is done and whose profile has been checked, so they can answer requests.",
    long: "Link LinkedIn or X and the steward checks it matches what you told the agent. Others see only a badge, never your account.",
    see: ["seat", "request"],
    params: ["QUALIFY_MIN_SCORE"],
  },
  {
    id: "holder-vote",
    term: "Holder vote",
    aka: ["holder votes", "unit holders", "unit-holder vote"],
    short: "A vote by people with vested units, each counting by how many units they hold.",
    long: "A vote counts only if {QUORUM_PCT} of vested units take part. Most pass with more than {SIMPLE_MAJORITY}; big ones need {SUPERMAJORITY}.",
    see: ["vesting", "setting"],
    params: ["QUORUM_PCT", "SIMPLE_MAJORITY", "SUPERMAJORITY", "VOTE_WINDOW_DAYS"],
  },
  {
    id: "setting",
    term: "Setting",
    aka: ["settings"],
    short: "One of the numbers or lists the rules rely on, like the seat price. It changes only by a vote.",
    long: "Each one lists its reason and the Protocol request where people discuss it.",
    example: "Seat price: $10.",
    see: ["holder-vote", "protocol"],
  },
  {
    id: "constitution",
    term: "Constitution",
    aka: ["rules", "the 8 rules", "articles"],
    short: "The eight articles every venture must follow.",
    long: "Changing an article takes {CONSTITUTION_NOTICE_DAYS} days' notice and a {SUPERMAJORITY} vote of the Protocol's unit holders.",
    see: ["setting", "mark"],
    params: ["CONSTITUTION_NOTICE_DAYS", "SUPERMAJORITY"],
  },
  {
    id: "mark",
    term: "The mark",
    aka: ["mark"],
    short: "The label “{MARK_TEMPLATE}”, used only by ventures the Protocol builds. A venture loses it for good after {MARK_WITHDRAW_BREACHES} confirmed rule breaches.",
    long: "A venture handed off to an entrepreneur stops showing it. Any verified member can report a breach. Members vote on it and the Protocol's steward confirms the result, unless they run that venture; then the vote stands on its own.",
    see: ["constitution"],
    params: ["MARK_TEMPLATE", "MARK_WITHDRAW_BREACHES"],
  },
] as const satisfies readonly GlossaryTerm[];

export type TermId = (typeof GLOSSARY)[number]["id"];

export function termById(id: TermId): GlossaryTerm {
  return GLOSSARY.find((t) => t.id === id)!;
}

/** Words replaced by plain language. The copy test keeps them out of UI text, the rules, settings and seeded text. */
export const RETIRED_WORDS: { word: RegExp; use: string }[] = [
  { word: /\bphenotypes?\b/i, use: "the classification labels" },
  { word: /\bliftoff\b/i, use: "people this venture needs" },
  { word: /\bcap table\b/i, use: "who holds units" },
  { word: /\bminimum raise\b/i, use: "minimum" },
  { word: /\bfunded\b/i, use: "minimum met" },
  { word: /\bembargo(e[sd])?\b/i, use: "published later" },
  { word: /\bpari passu\b/i, use: "paid the same per unit" },
  { word: /\bpro rata\b/i, use: "by how many units each has" },
  { word: /\btreasury\b/i, use: "unclaimed units" },
  { word: /\bcohort vehicle\b/i, use: "batch-wide share" },
  { word: /\bseat slice\b/i, use: "(no such thing: seats never earn units)" },
  { word: /\breserved matters?\b/i, use: "decisions only unit holders can make" },
  { word: /\bkill signal\b/i, use: "sign it isn't working" },
  { word: /\bkill switch\b/i, use: "the steward can shut it down" },
  { word: /\bmember graph\b/i, use: "the members we have" },
  { word: /\bcode-?names?\b/i, use: "code name" },
  { word: /\bprofits interests?\b/i, use: "profit share" },
  { word: /\bdistributions?\b/i, use: "payout" },
  { word: /\bbins?\b/i, use: "who had to approve it" },
  { word: /\bRFEs?\b/, use: "request" },
  { word: /\btick\b/i, use: "step" },
  { word: /\bpass-through\b/i, use: "fixed costs" },
  { word: /\bnetwork gap\b/i, use: "no member fits" },
];

function formatSettingValue(key: ParamKey, params: ParamValues): string {
  return settingValueText(key, params[key]);
}

const MATTER_LABELS: Record<string, string> = {
  "additional-capital": "asking members for more seat money",
  "objective-or-distribution": "changing the goal or how profit is paid out",
  sale: "handing the venture off to an entrepreneur",
  "voluntary-wind-down": "closing the venture",
  "replace-steward": "replacing the steward",
  "material-plan-amendment": "a major change to the plan",
  "parameter-amendment": "changing a setting",
  "conduct-flag": "a reported concern",
  "add-classification-value": "adding a category",
};

/** A vote matter key as people read it: "parameter-amendment" → "changing a setting". */
export function matterLabel(matter: string): string {
  return MATTER_LABELS[matter] ?? matter.replace(/-/g, " ");
}

/** Any value of a setting as people read it: 0.7 → "70%", 10 USD → "$10". */
export function settingValueText(key: ParamKey, value: unknown): string {
  const unit = (PARAMS[key] as { unit?: string }).unit;
  if (key === "RESERVED_MATTERS" && value && typeof value === "object") {
    return Object.entries(value as Record<string, string>)
      .map(([m, t]) => `${matterLabel(m)}: ${t === "super" ? "two-thirds" : "more than half"}`)
      .join(" · ");
  }
  if (key === "TAG_VOCAB" && value && typeof value === "object") {
    const status = VENTURE_STATUS_LABELS as Record<string, string>;
    return Object.entries(value as Record<string, string[]>)
      .filter(([, vs]) => vs.length > 0)
      .map(([axis, vs]) => `${TAG_AXIS_LABELS[axis as TagAxis] ?? axis}: ${vs.map((v) => (axis === "stage" ? (status[v]?.toLowerCase() ?? v) : v)).join(", ")}`)
      .join(" · ");
  }
  if (typeof value !== "number") return formatParamValue(value as ParamValue);
  if (unit === "USD") return `$${value}`;
  if (unit?.startsWith("%")) return `${value}%`;
  if (value > 0 && value < 1) return `${Math.round(value * 1000) / 10}%`;
  return String(value);
}

/** A vote title for changing a setting, by its label rather than its key. */
export function settingChangeTitle(key: ParamKey, from: unknown, to: unknown): string {
  const unit = (PARAMS[key] as { unit?: string }).unit;
  const tail = unit && unit !== "USD" && !unit.startsWith("%") && typeof to === "number" ? ` ${unit}` : "";
  return `Change “${PARAMS[key].label}” from ${settingValueText(key, from)} to ${settingValueText(key, to)}${tail}?`;
}

/** A setting's live value as people read it, with its unit: "$10", "30%", "14 days". */
export function settingText(key: ParamKey, params: ParamValues): string {
  const text = formatSettingValue(key, params);
  const unit = (PARAMS[key] as { unit?: string }).unit;
  return unit && unit !== "USD" && !unit.startsWith("%") ? `${text} ${unit}` : text;
}

/** Fills `{SETTING_KEY}` placeholders with live values, and the mark's `{name}` with [Name]. */
export function fillSettings(text: string, params: ParamValues): string {
  return text.replace(/\{([A-Z_]+)\}/g, (whole, key: string) => {
    if (key === "CONTRIBUTOR_PCT") return String(100 - params.PROTOCOL_FEE_PCT);
    return key in PARAMS ? formatSettingValue(key as ParamKey, params) : whole;
  }).replace("{name}", "[Name]");
}

/** Placeholders a definition may use besides setting keys. */
export const DERIVED_PLACEHOLDERS = ["CONTRIBUTOR_PCT"] as const;

export function renderTerm(t: GlossaryTerm, params: ParamValues): { short: string; long?: string; example?: string } {
  return {
    short: fillSettings(t.short, params),
    long: t.long && fillSettings(t.long, params),
    example: t.example && fillSettings(t.example, params),
  };
}

/** House vocabulary for agent prompts: the glossary terms to use and the retired words to avoid. */
export function houseStyle(params: ParamValues): string {
  const terms = GLOSSARY.map((t) => `${t.term}: ${renderTerm(t, params).short}`).join("\n");
  const avoid = RETIRED_WORDS.map((r) => `${r.word.source.replace(/\\b/g, "").replace(/\([^)]*\)\?/g, "").replace(/.\?/g, "").split("|")[0]} (say "${r.use}")`).join("; ");
  return [
    "Use these terms with these meanings, and no other jargon:",
    terms,
    `Never use these words: ${avoid}. Never describe a seat as something that earns or pays money back; only work earns units. Write 'the Protocol' mid-sentence, not 'The Protocol'.`,
  ].join("\n");
}
