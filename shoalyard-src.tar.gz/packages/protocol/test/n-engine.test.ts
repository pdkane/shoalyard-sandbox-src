import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams, type Response, type Rfe } from "@av/schema";
import { evaluateN, nBounds } from "../src/n-engine";

const params = defaultParams();
const cluster: Record<string, string> = { a: "c1", b: "c2", c: "c3", d: "c4", e: "c5", a2: "c1", a3: "c1" };
const clusterOf = (h: string) => cluster[h] ?? h;

function rfe(over: Partial<Rfe> = {}): Rfe {
  return {
    id: "r",
    ventureId: "v",
    type: "judgment",
    kind: "request",
    title: "t",
    question: "q",
    recommendation: "Yes",
    confidence: 0.5,
    stakes: "low",
    format: "choice",
    options: ["Yes", "No"],
    offerUnits: 1,
    audience: "x",
    status: "posted",
    postedAt: "2026-01-01T00:00:00.000Z",
    ...over,
  };
}
const ans = (handle: string, choice: string): Response => ({ id: handle, rfeId: "r", handle, via: "structured", choice, at: "2026-01-01T00:00:00.000Z" });

test("baselines by type and stakes", () => {
  assert.deepEqual(nBounds(rfe({ type: "judgment", stakes: "low" }), params), { minimum: 3, target: 3 });
  assert.deepEqual(nBounds(rfe({ type: "judgment", stakes: "high" }), params), { minimum: 3, target: 5 });
  assert.deepEqual(nBounds(rfe({ type: "knowledge", stakes: "medium" }), params), { minimum: 2, target: 3 });
  assert.deepEqual(nBounds(rfe({ type: "access" }), params), { minimum: 1, target: 1 });
  assert.deepEqual(nBounds(rfe({ type: "capital" }), params, 300), { minimum: 30, target: 30 });
});

test("an explicit N is both minimum and target", () => {
  assert.deepEqual(nBounds(rfe({ type: "knowledge", targetOverride: 20 }), params), { minimum: 20, target: 20 });
});

test("collects below the minimum", () => {
  const n = evaluateN(rfe(), [ans("a", "Yes"), ans("b", "Yes")], clusterOf, params);
  assert.equal(n.state, "collecting");
});

test("closes early when the minimum agrees", () => {
  const n = evaluateN(rfe({ stakes: "high" }), [ans("a", "Yes"), ans("b", "Yes"), ans("c", "Yes")], clusterOf, params);
  assert.equal(n.state, "close");
  assert.equal(n.leading, "Yes");
  assert.match(n.reason, /early/);
});

test("keeps going between minimum and target when responses split", () => {
  const n = evaluateN(rfe({ stakes: "high" }), [ans("a", "Yes"), ans("b", "No"), ans("c", "Yes")], clusterOf, params);
  assert.equal(n.state, "collecting");
});

test("extends once at the target when responses diverge, then closes", () => {
  const three = rfe({ type: "judgment", stakes: "high", options: ["Yes", "No", "Maybe"] });
  const rs = [ans("a", "Yes"), ans("b", "No"), ans("c", "Maybe"), ans("d", "Yes"), ans("e", "No")];
  const first = evaluateN(three, rs, clusterOf, params);
  assert.equal(first.state, "extend");
  const extended = evaluateN({ ...three, extended: true }, rs, clusterOf, params);
  assert.equal(extended.target, 5 + params.EXTEND_BY);
  assert.equal(extended.state, "collecting");
});

test("responses from one profile cluster count once", () => {
  const n = evaluateN(rfe(), [ans("a", "Yes"), ans("a2", "Yes"), ans("a3", "Yes")], clusterOf, params);
  assert.equal(n.raw, 3);
  assert.equal(n.effective, 1);
  assert.equal(n.state, "collecting");
});

test("capital requests count seats against the minimum raise", () => {
  const n = evaluateN(rfe({ type: "capital" }), [], clusterOf, params, { minRaiseUsd: 300, seatsSold: 30 });
  assert.equal(n.state, "close");
  const m = evaluateN(rfe({ type: "capital" }), [], clusterOf, params, { minRaiseUsd: 300, seatsSold: 12 });
  assert.equal(m.state, "collecting");
});
