/**
 * Specialized holdco (platform) agent roles — stub map for future agents.
 * Operating detail: docs/plans/holdco-agents.md and economics-safe-seed.md.
 * Not wired into runtime yet.
 */

export const HOLDCO_AGENT_ROLES = [
  "capital_formation",
  "marketing",
  "sourcing",
  "thesis_dd",
  "value_creation",
  "governance",
  "exit",
  "back_office",
  "ir",
] as const;

export type HoldcoAgentRole = (typeof HOLDCO_AGENT_ROLES)[number];

/** Short labels for docs / future UI. */
export const HOLDCO_AGENT_ROLE_LABEL: Record<HoldcoAgentRole, string> = {
  capital_formation: "Capital formation",
  marketing: "Marketing",
  sourcing: "Sourcing",
  thesis_dd: "Thesis / diligence",
  value_creation: "Value creation",
  governance: "Governance",
  exit: "Exit prep",
  back_office: "Back office",
  ir: "IR",
};
