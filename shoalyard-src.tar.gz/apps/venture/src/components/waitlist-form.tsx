"use client";

import { Bell } from "lucide-react";
import { joinWaitlistAction } from "@/app/actions";
import { useToastAction } from "@/components/protocol-forms";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

/**
 * Get notified: a full venture's waitlist, or the next batch's. Members join in one click;
 * anyone else picks a handle, which is all an account is here.
 */
export function WaitlistForm({
  slug,
  batch,
  handle,
  joined,
  label = "Get notified",
  className,
}: {
  slug?: string;
  batch?: number;
  handle?: string;
  joined?: boolean;
  label?: string;
  className?: string;
}) {
  const [state, action] = useToastAction(joinWaitlistAction);
  if (joined || (state.ok && state.message)) {
    return (
      <p className={cn("inline-flex items-center gap-1.5 text-sm text-emerald-800", className)}>
        <Bell className="size-4" /> {slug ? "You're on the waitlist. You'll hear if a seat frees up." : "You're on the list. You'll hear when it opens."}
      </p>
    );
  }
  return (
    <form action={action} className={cn("space-y-1.5", className)}>
      {slug && <input type="hidden" name="slug" value={slug} />}
      {batch !== undefined && <input type="hidden" name="batch" value={batch} />}
      <div className="flex flex-col gap-2 sm:flex-row">
        {!handle && (
          <Input name="handle" required placeholder="Pick a handle" aria-label="Your handle" autoComplete="nickname" pattern="@?[A-Za-z0-9_]{2,24}" className="h-9 sm:w-44" />
        )}
        <SubmitButton className="h-9" variant={handle ? "outline" : "default"} pendingText="Adding you…">
          <Bell /> {label}
        </SubmitButton>
      </div>
      <FormMessage state={state} />
    </form>
  );
}
