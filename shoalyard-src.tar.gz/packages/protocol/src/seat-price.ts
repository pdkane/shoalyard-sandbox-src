import type { Claim, PitchDeck, RosterRole } from "@av/schema";
import { revenuePerCustomerMonth } from "./plan";
import { clampPrice, type PriceBand } from "./sizing";

/**
 * The agent's pricing rule for seats, used when the model doesn't propose a price (or isn't running).
 * Serious, scarce rosters (enterprise or government buyers, licensed professionals, a narrow
 * high-value niche) support a higher price; ideas that need many everyday people get a lower one.
 * Code keeps whatever it picks inside the band, and the steward signs it off.
 */
export interface PriceContext {
  customer?: string;
  endMarket?: string;
  roster: Pick<RosterRole, "key" | "count" | "label">[];
  regulated: string[];
  deck: Pick<PitchDeck, "market" | "pricing" | "plan" | "slides">;
}

export const SEAT_PRICE_CLAIM_IDS = ["c-seat-people", "c-seat-buyer", "c-seat-market"] as const;

const BASE_BY_CUSTOMER: Record<string, number> = { Consumer: 10, "Small business": 25, "Mid-market": 40, Enterprise: 60, Government: 60 };
const HIGH_TRUST_MARKETS = ["Public sector", "Healthcare", "Financial services", "Legal"];
/** A market this size or smaller, where each customer is worth this much a month, is a narrow high-value niche. */
const NICHE_TAM_USD = 100_000_000;
const NICHE_VALUE_MONTH_USD = 80;
const BROAD_VALUE_MONTH_USD = 20;

const usd = (n: number) => `$${Math.round(n).toLocaleString("en-US")}`;
const roundTo5 = (n: number) => Math.max(5, Math.round(n / 5) * 5);

function claimValue(deck: PriceContext["deck"], id?: string): number | undefined {
  if (!id) return undefined;
  for (const s of deck.slides) for (const c of s.claims) if (c.id === id) return c.value?.n;
  return undefined;
}

export interface PriceProposal {
  priceUsd: number;
  claims: Claim[];
}

export function heuristicSeatPrice(ctx: PriceContext, band: PriceBand): PriceProposal {
  const customer = ctx.customer ?? "Small business";
  const licensed = ctx.roster.some((r) => r.key === "legal") || ctx.regulated.length > 0;
  const highTrust = HIGH_TRUST_MARKETS.includes(ctx.endMarket ?? "");
  const tam = claimValue(ctx.deck, ctx.deck.market?.tam);
  const perMonth = ctx.deck.plan ? revenuePerCustomerMonth(ctx.deck.pricing, ctx.deck.plan) : ctx.deck.pricing.cadence === "month" ? ctx.deck.pricing.price : undefined;
  const niche = tam !== undefined && perMonth !== undefined && tam <= NICHE_TAM_USD && perMonth >= NICHE_VALUE_MONTH_USD;
  const broad = customer === "Consumer" || (perMonth !== undefined && perMonth < BROAD_VALUE_MONTH_USD);

  let raw = BASE_BY_CUSTOMER[customer] ?? 25;
  if (licensed) raw += 15;
  if (highTrust) raw += 15;
  if (niche) raw += 10;
  if (broad) raw -= 10;
  const priceUsd = clampPrice(roundTo5(raw), band);
  const held = priceUsd < roundTo5(raw) ? ` It would be ${usd(roundTo5(raw))}, but the band stops at ${usd(band.upperUsd)}.` : "";

  const roles = ctx.roster.map((r) => `${r.count} ${r.label.toLowerCase()}`).join(", ");
  const buyerWords = [
    customer === "Consumer" ? "everyday consumers" : `${customer.toLowerCase()} buyers`,
    highTrust ? `in ${ctx.endMarket?.toLowerCase()}` : "",
    licensed ? "with licensed counsel on the roster" : "",
  ]
    .filter(Boolean)
    .join(" ");
  const claims: Claim[] = [
    {
      id: "c-seat-people",
      text: `The proof runs on at least ${band.headcount} people (${roles || "no roster yet"}), so a seat can cost at most ${usd(band.upperUsd)} and still leave room for everyone it needs.`,
      basis: "estimate",
      sources: [],
      method: `max(${band.rosterSeats} on the roster, ${band.coverageSeats} holders for answer coverage) = ${band.headcount}; ${usd(band.proofUsd)} ÷ ${band.headcount} = ${usd(band.fromPeopleUsd)}, inside the ${usd(band.minUsd)}–${usd(band.maxUsd)} bounds`,
      value: { n: band.upperUsd, unit: "usd" },
    },
    {
      id: "c-seat-buyer",
      text: `Its people are ${buyerWords}. ${
        licensed || highTrust || BASE_BY_CUSTOMER[customer] >= 40
          ? "A higher seat filters for people serious enough to answer and to vouch to a buyer."
          : broad
            ? "It needs many everyday people, so the seat stays low."
            : "A mid-range seat filters for people who mean to answer without pricing out working operators."
      }`,
      basis: "assumption",
      sources: [],
      test: { how: "Seat sell-through by price, customer type and channel, tracked in the learning loop. A missed minimum refunds every seat." },
    },
    {
      id: "c-seat-market",
      text: niche
        ? `A narrow, high-value niche: about ${usd(tam!)} a year, with each customer worth about ${usd(perMonth!)} a month. It needs a small, committed roster rather than a crowd.${held}`
        : broad
          ? `A broad market where each customer is worth about ${perMonth !== undefined ? usd(perMonth) : "little"} a month: it needs a wide, cheaper roster.${held}`
          : `A market of about ${tam !== undefined ? `${usd(tam)} a year` : "unknown size"}${perMonth !== undefined ? `, with each customer worth about ${usd(perMonth)} a month` : ""}: neither a narrow niche nor a mass market.${held}`,
      basis: "estimate",
      sources: [],
      method: `TAM from the market slide (${ctx.deck.market?.tam ?? "none"}); revenue per customer-month from the pricing and plan; niche at ${usd(NICHE_TAM_USD)} a year or less and ${usd(NICHE_VALUE_MONTH_USD)} a month or more`,
      value: { n: priceUsd, unit: "usd" },
    },
  ];
  return { priceUsd, claims };
}

/** A model's proposal must sit in the band and justify itself with tagged claims. */
export function checkPriceProposal(p: { priceUsd: number; claims: Claim[] } | undefined, band: PriceBand): string[] {
  if (!p) return [];
  const errors: string[] = [];
  if (!(p.priceUsd >= band.minUsd && p.priceUsd <= band.upperUsd)) errors.push(`The seat price ${usd(p.priceUsd)} is outside the band: ${usd(band.minUsd)} to ${usd(band.upperUsd)}.`);
  if (p.claims.length < 2) errors.push("Justify the seat price with at least two claims: the roster and the buyer or market.");
  for (const c of p.claims) {
    if (c.basis === "estimate" && !c.method) errors.push(`${c.id}: an estimate needs its method.`);
    if (c.basis === "assumption" && !c.test?.how) errors.push(`${c.id}: an assumption needs a test.`);
  }
  return errors;
}
