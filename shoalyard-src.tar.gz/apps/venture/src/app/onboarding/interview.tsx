"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { Bot, CornerDownLeft, Undo2 } from "lucide-react";
import { completeOnboardingAction, type ActionState } from "@/app/actions";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type Key = "role" | "industry" | "seniority" | "companies" | "buyingAuthority" | "tools" | "verticals" | "canReach" | "dailyPushCap";

interface Question {
  key: Key;
  ask: string;
  placeholder?: string;
  options?: { value: string; label: string }[];
  list?: boolean;
  optional?: boolean;
}

const QUESTIONS: Question[] = [
  { key: "role", ask: "What do you do day to day? Your role is enough.", placeholder: "e.g. Freight broker, estimator, practice manager" },
  { key: "industry", ask: "Which industry is that in?", placeholder: "e.g. Logistics, construction, dental" },
  {
    key: "seniority",
    ask: "How senior are you? It helps me weigh judgment calls.",
    options: [
      { value: "early", label: "Early career" },
      { value: "mid", label: "Mid-level" },
      { value: "senior", label: "Senior" },
      { value: "executive", label: "Executive / owner" },
    ],
  },
  { key: "companies", ask: "Which companies have you worked at? Comma-separated; skip if you'd rather not.", placeholder: "Acme Freight, Coyote", list: true, optional: true },
  { key: "buyingAuthority", ask: "Do you buy software or services for your team? What can you sign off on?", placeholder: "e.g. Tools under $500/mo", optional: true },
  { key: "tools", ask: "Which tools do you use every week?", placeholder: "e.g. McLeod, DAT, QuickBooks", list: true, optional: true },
  { key: "verticals", ask: "Which markets do you know well enough to answer questions about?", placeholder: "e.g. Reefer, Texas permits, dental staffing", list: true, optional: true },
  { key: "canReach", ask: "Who could you introduce us to, if a venture asked?", placeholder: "e.g. Small brokerages in Ohio, two roofing owners", list: true, optional: true },
  {
    key: "dailyPushCap",
    ask: "Last one. How many requests a day should I send you at most?",
    options: [
      { value: "1", label: "1 a day" },
      { value: "3", label: "Up to 3" },
      { value: "5", label: "Up to 5" },
    ],
  },
];

const GRAPH: { key: Key; label: string }[] = [
  { key: "role", label: "Role" },
  { key: "industry", label: "Industry" },
  { key: "seniority", label: "Seniority" },
  { key: "companies", label: "Companies" },
  { key: "buyingAuthority", label: "Buying authority" },
  { key: "tools", label: "Tools" },
  { key: "verticals", label: "Knows" },
  { key: "canReach", label: "Can reach" },
];

function split(v: string) {
  return v
    .split(/[,;\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function Interview({ handle, ventureName }: { handle: string; ventureName?: string }) {
  const [answers, setAnswers] = useState<Partial<Record<Key, string>>>({});
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState("");
  const [state, action] = useActionState<ActionState, FormData>(completeOnboardingAction, { ok: true });
  const bottom = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const done = step >= QUESTIONS.length;
  const q = QUESTIONS[step];

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    input.current?.focus();
  }, [step]);

  function answer(value: string) {
    if (!q) return;
    if (!value.trim() && !q.optional) return;
    setAnswers((a) => ({ ...a, [q.key]: value.trim() }));
    setDraft("");
    setStep((s) => s + 1);
  }

  function back() {
    if (step === 0) return;
    const prev = QUESTIONS[step - 1];
    setDraft(prev.options ? "" : (answers[prev.key] ?? ""));
    setStep(step - 1);
  }

  const labelFor = (qq: Question, v?: string) => (qq.options ? qq.options.find((o) => o.value === v)?.label : v) || "Skipped";

  return (
    <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
      <div className="flex min-h-[28rem] flex-col rounded-xl border border-zinc-200 bg-white">
        <div className="flex-1 space-y-4 overflow-y-auto p-4 sm:p-5">
          <AgentBubble>
            Welcome, @{handle}.{ventureName ? ` Your seat in ${ventureName} is on the ledger.` : ""} I&apos;m the operating agent. A few
            questions so I only send you requests you can answer well. Nothing here is public except your handle.
          </AgentBubble>
          {QUESTIONS.slice(0, step).map((qq) => (
            <div key={qq.key} className="space-y-3">
              <AgentBubble>{qq.ask}</AgentBubble>
              <div className="flex justify-end">
                <p className={cn("max-w-[85%] rounded-2xl rounded-br-sm bg-zinc-900 px-3.5 py-2 text-sm text-white", !answers[qq.key] && "bg-zinc-200 text-zinc-500")}>
                  {labelFor(qq, answers[qq.key])}
                </p>
              </div>
            </div>
          ))}
          {q && <AgentBubble>{q.ask}</AgentBubble>}
          {done && (
            <AgentBubble>
              Thanks. That&apos;s your profile. When you finish, I&apos;ll put the request that fits you best at the
              top of your inbox.
            </AgentBubble>
          )}
          <div ref={bottom} />
        </div>
        <div className="border-t border-zinc-100 p-3 sm:p-4">
          {q ? (
            q.options ? (
              <div className="flex flex-wrap gap-2">
                {q.options.map((o) => (
                  <Button key={o.value} type="button" variant="outline" onClick={() => answer(o.value)}>
                    {o.label}
                  </Button>
                ))}
                {step > 0 && (
                  <Button type="button" variant="ghost" onClick={back} className="ml-auto">
                    <Undo2 /> Back
                  </Button>
                )}
              </div>
            ) : (
              <form
                className="flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  answer(draft);
                }}
              >
                <Input
                  ref={input}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={q.placeholder}
                  aria-label={q.ask}
                  className="h-10"
                />
                <Button type="submit" size="lg" className="h-10" disabled={!draft.trim() && !q.optional}>
                  {draft.trim() || !q.optional ? (
                    <>
                      Send <CornerDownLeft />
                    </>
                  ) : (
                    "Skip"
                  )}
                </Button>
                {step > 0 && (
                  <Button type="button" variant="ghost" size="lg" className="h-10" onClick={back} aria-label="Back">
                    <Undo2 />
                  </Button>
                )}
              </form>
            )
          ) : (
            <form action={action} className="flex flex-col gap-2 sm:flex-row sm:items-center">
              {QUESTIONS.map((qq) => (
                <input key={qq.key} type="hidden" name={qq.key} value={answers[qq.key] ?? ""} />
              ))}
              <SubmitButton size="lg" className="h-10" pendingText="Building your profile…">
                Finish the interview
              </SubmitButton>
              <Button type="button" variant="ghost" size="lg" className="h-10" onClick={back}>
                <Undo2 /> Change an answer
              </Button>
              <FormMessage state={state} />
            </form>
          )}
        </div>
      </div>

      <aside className="space-y-3">
        <p className="text-sm font-medium text-zinc-900">What the agent knows about you</p>
        <div className="rounded-xl border border-zinc-200 bg-white p-4">
          <div className="flex flex-col items-center">
            <span className="rounded-full bg-zinc-900 px-3 py-1.5 text-sm font-semibold text-white">@{handle}</span>
            <span className="h-4 w-px bg-zinc-300" />
          </div>
          <ul className="space-y-2.5 border-t border-zinc-200 pt-3">
            {GRAPH.map((g) => {
              const qq = QUESTIONS.find((x) => x.key === g.key)!;
              const v = answers[g.key];
              const values = v ? (qq.list ? split(v) : [labelFor(qq, v)]) : [];
              return (
                <li key={g.key} className="flex items-start gap-3">
                  <span className="w-28 shrink-0 pt-0.5 text-xs text-zinc-500">{g.label}</span>
                  <span className="flex flex-wrap gap-1">
                    {values.length ? (
                      values.map((x) => (
                        <span key={x} className="rounded-full border border-zinc-200 bg-zinc-50 px-2 py-0.5 text-xs text-zinc-800 animate-in fade-in zoom-in-95">
                          {x}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-zinc-300">—</span>
                    )}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
        <p className="text-xs text-zinc-500">
          The agent uses this to send you the right questions. If several people from one company answer, they count as one, so no single company can outvote everyone.
        </p>
      </aside>
    </div>
  );
}

function AgentBubble({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex gap-2.5">
      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-zinc-600">
        <Bot className="size-4" />
      </span>
      <p className="max-w-[85%] rounded-2xl rounded-tl-sm bg-zinc-100 px-3.5 py-2 text-sm text-zinc-800">{children}</p>
    </div>
  );
}
