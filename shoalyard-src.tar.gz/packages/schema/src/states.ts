/** State machines from docs/working-model.md ("System design"). */

export const VENTURE_STATUSES = [
  "generated",
  "pitched",
  "funded",
  "formed",
  "operating",
  "customer1",
  "distributing",
  "dormant",
  "killed",
  "handed-off",
] as const;
export type VentureStatus = (typeof VENTURE_STATUSES)[number];

export const VENTURE_TRANSITIONS: Record<VentureStatus, readonly VentureStatus[]> = {
  generated: ["pitched", "killed"],
  pitched: ["funded", "killed"],
  funded: ["formed", "killed"],
  formed: ["operating", "killed"],
  operating: ["customer1", "dormant", "killed"],
  customer1: ["distributing", "dormant", "killed", "handed-off"],
  distributing: ["dormant", "killed", "handed-off"],
  dormant: ["operating", "killed"],
  killed: [],
  "handed-off": [],
};

export const VENTURE_STATUS_LABELS: Record<VentureStatus, string> = {
  generated: "Idea",
  pitched: "Selling seats",
  funded: "Minimum met",
  formed: "Company set up",
  operating: "Operating",
  customer1: "First customer",
  distributing: "Paying out profit",
  dormant: "Paused",
  killed: "Ended",
  "handed-off": "Handed off",
};

/** The main path, used to draw the lifecycle. Dormant, killed and handed off are exits. */
export const VENTURE_MAIN_PATH: readonly VentureStatus[] = [
  "pitched",
  "funded",
  "formed",
  "operating",
  "customer1",
  "distributing",
];

export const RFE_STATUSES = ["drafted", "posted", "quorum", "resolved", "scored"] as const;
export type RfeStatus = (typeof RFE_STATUSES)[number];

export const RFE_TRANSITIONS: Record<RfeStatus, readonly RfeStatus[]> = {
  drafted: ["posted"],
  posted: ["quorum"],
  quorum: ["resolved", "posted"],
  resolved: ["scored"],
  scored: [],
};

export const GRANT_STATUSES = ["offered", "accepted", "vested", "distributing", "forfeited"] as const;
export type GrantStatus = (typeof GRANT_STATUSES)[number];

export const GRANT_STATUS_LABELS: Record<GrantStatus, string> = {
  offered: "Offered",
  accepted: "Earned, not yet vested",
  vested: "Vested",
  distributing: "Vested, paying out",
  forfeited: "Taken back",
};

export const GRANT_TRANSITIONS: Record<GrantStatus, readonly GrantStatus[]> = {
  offered: ["accepted", "forfeited"],
  accepted: ["vested", "forfeited"],
  vested: ["distributing", "forfeited"],
  distributing: [],
  forfeited: [],
};

export const DECISION_BINS = ["auto", "advisory", "gated"] as const;
export type DecisionBin = (typeof DECISION_BINS)[number];

/** Classified → bin → taken → logged → outcome. Gated and advisory wait on people first. */
export const DECISION_STATUSES = [
  "awaiting_members",
  "awaiting_steward",
  "taken",
  "rejected",
] as const;
export type DecisionStatus = (typeof DECISION_STATUSES)[number];

export const DECISION_TRANSITIONS: Record<DecisionStatus, readonly DecisionStatus[]> = {
  awaiting_members: ["taken", "rejected"],
  awaiting_steward: ["taken", "rejected"],
  taken: [],
  rejected: [],
};

export function canTransition<S extends string>(
  table: Record<S, readonly S[]>,
  from: S,
  to: S,
): boolean {
  return table[from].includes(to);
}

export function assertTransition<S extends string>(
  table: Record<S, readonly S[]>,
  from: S,
  to: S,
  what: string,
): void {
  if (!canTransition(table, from, to)) {
    throw new Error(`${what} cannot move from ${from} to ${to}`);
  }
}
