import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams } from "@av/schema";
import { classify } from "../src/classifier";
import { decidedBy, decisionTier, decisionView, decisionViews, postMortemView } from "../src/decision-access";
import { breachCount, markForVenture, markWithdrawn } from "../src/flags";
import { closeGovernance, decisionSummary, logDecision, memberByHandle, respond, rfeById, shortReason, ventureBySlug } from "../src/ops";
import { resolveParams } from "../src/params";
import { isEmbargoed, peopleDecisions, privateUntil, publicDecisions } from "../src/queries";
import { buildSeed } from "../src/seed";
import { addDays } from "../src/util";

function amend(s: ReturnType<typeof buildSeed>, paramKey: string, newValue: unknown) {
  s.amendments.push({ id: `amd-t-${paramKey}`, paramKey, oldValue: null, newValue, rfeId: "rfe-test", version: "9.9", at: s.meta.clock });
}

/* Seed viewers, one per tier, for Dockside. */
const VISITOR = undefined;
const UNVERIFIED = "bidboard";
const VERIFIED = "detention_dave";
const HOLDER = "dispatch_dana";
const PROTOCOL_HOLDER = "llc_lena";
const STEWARD = "MP";

function setup() {
  const s = buildSeed();
  const params = resolveParams(s);
  const dock = ventureBySlug(s, "dockside")!;
  const tier = (handle?: string, p = params) => decisionTier(s, dock, handle ? memberByHandle(s, handle) : undefined, p);
  return { s, params, dock, tier };
}

test("each viewer gets the decision tier Article 3 gives them", () => {
  const { tier } = setup();
  assert.equal(tier(VISITOR), "public");
  assert.equal(tier(UNVERIFIED), "public", "an unverified seat holder gets the public view");
  assert.equal(tier(VERIFIED), "verified");
  assert.equal(tier(HOLDER), "unit holder");
  assert.equal(tier(PROTOCOL_HOLDER), "unit holder", "Protocol units see every venture's reasoning");
  assert.equal(tier(STEWARD), "steward");
});

test("DECISION_DETAIL_VISIBLE_TO widens who sees the reasoning", () => {
  const { tier, params } = setup();
  assert.equal(tier(VERIFIED, { ...params, DECISION_DETAIL_VISIBLE_TO: "verified members" }), "unit holder");
  assert.equal(tier(UNVERIFIED, { ...params, DECISION_DETAIL_VISIBLE_TO: "verified members" }), "public");
  assert.equal(tier(VISITOR, { ...params, DECISION_DETAIL_VISIBLE_TO: "public" }), "unit holder");
});

test("the public sees what was decided, by whom and what it cost, but no reasoning", () => {
  const { s, params, dock } = setup();
  const views = decisionViews(s, dock, "public", params);
  assert.ok(views.length > 5);
  for (const v of views) {
    assert.ok(v.decidedBy);
    for (const k of ["summary", "reasoning", "binReasons", "confidence", "lessonIds", "contradicts", "conduct", "stewardNote", "model", "options", "answers"] as const) {
      assert.equal(v[k], undefined, `${v.id}.${k} leaked to the public`);
    }
    if (!v.redacted) assert.ok(v.title);
  }
  const spent = views.find((v) => v.spendUsd);
  assert.ok(spent, "money spent is public, with amounts");
});

test("verified members also see a short reason; unit holders see the reasoning, options and answers", () => {
  const { s, params, dock } = setup();
  const verified = decisionViews(s, dock, "verified", params).filter((v) => !v.redacted);
  assert.ok(verified.every((v) => v.summary && v.reasoning === undefined && v.answers === undefined));
  const full = decisionViews(s, dock, "unit holder", params).filter((v) => !v.redacted);
  assert.ok(full.every((v) => v.reasoning && v.confidence !== undefined));
  const asked = full.find((v) => v.answers?.length);
  assert.ok(asked, "unit holders see members' answers");
  assert.ok(asked.options?.length);
});

test("only the steward sees a decision while it is private", () => {
  const { s, params, dock } = setup();
  const held = s.decisions.find((d) => d.ventureId === dock.id && isEmbargoed(d, s.meta.clock, params.PRIVATE_DECISION_MAX_DAYS))!;
  assert.ok(held, "the seed holds one Dockside decision private");
  for (const t of ["public", "verified", "unit holder"] as const) {
    const v = decisionView(s, held, t, params);
    assert.equal(v.redacted, true);
    assert.equal(v.title, undefined);
    assert.equal(v.reasoning, undefined);
    assert.ok(v.private?.until && v.private.reason, "the record still shows it happened and when it will be published");
  }
  const steward = decisionView(s, held, "steward", params);
  assert.equal(steward.redacted, false);
  assert.equal(steward.reasoning, held.reasoning);
});

test("a private decision publishes itself once PRIVATE_DECISION_MAX_DAYS have passed", () => {
  const { s, params, dock } = setup();
  const d = s.decisions.find((x) => x.ventureId === dock.id && x.embargo)!;
  d.embargo!.until = addDays(d.at, 400);
  const cap = addDays(d.at, params.PRIVATE_DECISION_MAX_DAYS);
  assert.equal(privateUntil(d, params.PRIVATE_DECISION_MAX_DAYS), cap);
  s.meta.clock = addDays(cap, 1);
  assert.equal(isEmbargoed(d, s.meta.clock, params.PRIVATE_DECISION_MAX_DAYS), false);
  assert.equal(publicDecisions(s, dock.id).find((x) => x.id === d.id)?.redacted, false);
  assert.equal(decisionView(s, d, "unit holder", params).redacted, false);
});

test("a new private decision never asks for longer than the maximum", () => {
  const { s, dock } = setup();
  amend(s, "PRIVATE_DECISION_MAX_DAYS", 14);
  const { decision } = logDecision(s, {
    ventureId: dock.id,
    title: "Hold the pilot terms back",
    reasoning: "The customer's terms are confidential until signed.",
    confidence: 0.9,
    model: "script",
    embargoReason: "third-party confidentiality",
  });
  assert.equal(decision.embargo!.until, addDays(decision.at, 14));
});

test("every decision gets a short reason without lesson ids", () => {
  const { s } = setup();
  assert.ok(s.decisions.every((d) => d.summary && d.summary.length <= 161), "the seed backfills summaries");
  assert.ok(s.decisions.every((d) => !/L-\d{3}/.test(d.summary!)));
  assert.equal(shortReason("Brokers buy from people they know, per L-005. Another 200 emails won't help."), "Brokers buy from people they know.");
  assert.equal(decisionSummary({ reasoning: "One. Two.", summary: "  Given.  " }), "Given.");
  const long = shortReason(`${"word ".repeat(60)}end.`);
  assert.ok(long.length <= 160 && long.endsWith("…"));
});

test("steward notes stay with unit holders in the people panel", () => {
  const { s, dock } = setup();
  const d = s.decisions.find((x) => x.ventureId === dock.id && x.bin === "gated" && x.status === "taken" && !x.embargo)!;
  d.stewardNote = "Private aside about the broker";
  assert.ok(peopleDecisions(s, dock, false, 50).every((r) => !r.decided.includes("Private aside")));
  assert.ok(peopleDecisions(s, dock, true, 50).some((r) => r.decided.includes("Private aside")));
});

test("hiring or contracting a person needs sign-off", () => {
  const params = defaultParams();
  const c = classify({ hiresPerson: true }, 0.99, params);
  assert.equal(c.bin, "gated");
  assert.match(c.reasons.join(" "), /Hires or contracts a person/);
  assert.equal(classify({ hiresPerson: true }, 0.99, { ...params, GATE_HIRING: false }).bin, "auto");
});

test("big questions go to a unit holder vote, and the vote settles the decision", () => {
  const { s, dock } = setup();
  const { decision, rfe } = logDecision(s, {
    ventureId: dock.id,
    title: "Pivot Dockside to warehouse disputes",
    reasoning: "Brokers churn; warehouses pay for the same letters.",
    confidence: 0.95,
    model: "script",
    facts: { bigQuestion: "pivot" },
  });
  assert.equal(decision.bin, "advisory");
  assert.equal(decision.status, "awaiting_members");
  assert.ok(rfe && rfe.kind === "governance" && rfe.governance?.matter === "pivot");
  assert.equal(rfe.governance?.threshold, "super");
  assert.equal(decidedBy(s, decision), "Unit holders");
  for (const h of ["MP", "dispatch_dana", "lanehauler", "tms_tara", "coldcall_cass", "bookkeep_bo", "cfo_ines", "vc_scout_ray", "ux_uma", "quiet_quinn"]) {
    try {
      respond(s, { rfeId: rfe.id, handle: h, via: "structured", choice: "No" });
    } catch {
      /* not every holder may vote yet */
    }
  }
  s.meta.clock = addDays(rfe.governance!.windowEndsAt, 1);
  closeGovernance(s, rfeById(s, rfe.id)!);
  assert.equal(decision.status, "rejected");
  assert.match(decision.outcome ?? decision.stewardNote ?? "", /voted no/);
});

test("an unknown big question is not routed to a vote", () => {
  const { s, dock } = setup();
  const { decision, rfe } = logDecision(s, { ventureId: dock.id, title: "Rename a folder", reasoning: "Tidier.", confidence: 0.95, model: "script", facts: { bigQuestion: "folders" } });
  assert.equal(decision.bin, "auto");
  assert.equal(rfe, undefined);
});

test("the mark, once withdrawn, never comes back (Article 7)", () => {
  const { s, dock } = setup();
  const n = resolveParams(s).MARK_WITHDRAW_BREACHES;
  for (let i = breachCount(s, dock.id); i < n; i++) s.ledger.push({ id: `led-b${i}`, ventureId: dock.id, at: s.meta.clock, kind: "breach", note: "test" });
  s.ledger.push({ id: "led-w", ventureId: dock.id, at: s.meta.clock, kind: "status", note: "Mark withdrawn for good after 3 confirmed breaches (Article 7)" });
  assert.equal(markWithdrawn(s, dock.id), true);
  amend(s, "MARK_WITHDRAW_BREACHES", 99);
  assert.equal(markWithdrawn(s, dock.id), true, "raising the setting later doesn't restore it");
});

test("a handed-off venture stops showing the mark (Article 7)", () => {
  const { s, dock } = setup();
  assert.ok(markForVenture(s, dock));
  assert.equal(markForVenture(s, { ...dock, status: "handed-off" }), undefined);
});

test("a fired kill rule is decided by a fixed rule; an applied vote by unit holders", () => {
  const { s } = setup();
  const kill = s.decisions.find((d) => d.title.startsWith("Kill rule fired"))!;
  assert.equal(decidedBy(s, kill), "A fixed rule");
  const applied = s.decisions.find((d) => d.model === "rule" && d.reasoning.startsWith("Unit holders decided"));
  if (applied) assert.equal(decidedBy(s, applied), "Unit holders");
});

test("a shutdown shows its outcome, category and one-line summary to everyone; the full reason follows the tiers", () => {
  const { s, params } = setup();
  const ink = ventureBySlug(s, "wet-ink")!;
  const kill = s.decisions.find((d) => d.ventureId === ink.id && d.title === "Shut the venture down")!;
  const visitor = decisionTier(s, ink, undefined, params);
  const pub = decisionView(s, kill, visitor, params);
  assert.equal(visitor, "public");
  assert.ok(pub.summary && pub.outcome, "the public sees the summary and the outcome");
  assert.equal(pub.reasoning, undefined, "the public does not see the full reasoning");
  assert.ok(kill.reasoning.length > pub.summary!.length);
  for (const note of [...ink.statusHistory.map((h) => h.note ?? ""), ...s.ledger.filter((l) => l.ventureId === ink.id).map((l) => l.note)]) {
    assert.ok(!note.includes(kill.reasoning), `a public note copies the full reasoning: ${note}`);
  }
  const pm = postMortemView(ink.postMortem!, visitor);
  assert.ok(pm.summary && pm.killReason);
  assert.equal(pm.whyItEnded, undefined);
  assert.equal(pm.whatWeTried, undefined);
  assert.equal(pm.shortWhy, undefined);
  assert.ok(postMortemView(ink.postMortem!, "verified").shortWhy);
  assert.equal(postMortemView(ink.postMortem!, "verified").whyItEnded, undefined);
  assert.equal(postMortemView(ink.postMortem!, "unit holder").whyItEnded, ink.postMortem!.whyItEnded);
});
