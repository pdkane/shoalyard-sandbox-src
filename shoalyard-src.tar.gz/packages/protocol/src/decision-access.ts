import type { Decision, DecisionBin, Member, ParamValues, PostMortem, Store, Venture } from "@av/schema";
import { decisionSummary, protocolVenture, responsesFor, rfeById, shortReason } from "./ops";
import { isEmbargoed, privateUntil } from "./queries";

/**
 * Who sees what of a decision (Article 3). The public sees what was decided,
 * by whom and what it cost. Verified members also see a short reason. People
 * with units in the venture, or in the Protocol, see the full reasoning. The
 * steward sees everything, including decisions still held private.
 */
export const DECISION_TIERS = ["public", "verified", "unit holder", "steward"] as const;
export type DecisionTier = (typeof DECISION_TIERS)[number];

export const DECISION_DETAIL_AUDIENCES = ["unit holders", "verified members", "public"] as const;

const ACTIVE = new Set(["accepted", "vested", "distributing"]);

export function holdsUnits(store: Pick<Store, "grants">, ventureId: string, handle: string): boolean {
  return store.grants.some((g) => g.ventureId === ventureId && g.handle === handle && g.units > 0 && ACTIVE.has(g.status));
}

export function decisionTier(store: Store, venture: Venture, member: Member | undefined, params: ParamValues): DecisionTier {
  const protocol = protocolVenture(store);
  if (member && (member.handle === venture.stewardHandle || member.handle === protocol.stewardHandle)) return "steward";
  const audience = params.DECISION_DETAIL_VISIBLE_TO;
  if (audience === "public") return "unit holder";
  if (!member || member.qualification !== "qualified") return "public";
  if (audience === "verified members") return "unit holder";
  if (holdsUnits(store, venture.id, member.handle) || holdsUnits(store, protocol.id, member.handle)) return "unit holder";
  return "verified";
}

export const atLeast = (tier: DecisionTier, min: DecisionTier) => DECISION_TIERS.indexOf(tier) >= DECISION_TIERS.indexOf(min);

export interface DecisionAnswer {
  handle: string;
  at: string;
  answer: string;
}

/** One decision as a given tier may see it. Fields a tier can't see are absent, not blank. */
export interface DecisionView {
  id: string;
  ventureId: string;
  at: string;
  bin: DecisionBin;
  status: Decision["status"];
  /** Still private, and the viewer isn't the steward: only the reason and the publish date show. */
  redacted: boolean;
  private?: { until: string; reason: string };
  title?: string;
  decidedBy: string;
  outcome?: string;
  takenAt?: string;
  spendUsd?: number;
  rfeId?: string;
  /** Verified members and up. */
  summary?: string;
  /** People with units, and the steward. */
  reasoning?: string;
  binReasons?: string[];
  confidence?: number;
  lessonIds?: string[];
  contradicts?: string[];
  conduct?: Decision["conduct"];
  stewardNote?: string;
  model?: string;
  options?: string[];
  recommendation?: string;
  answers?: DecisionAnswer[];
}

export function decidedBy(store: Store, d: Decision): string {
  const rfe = d.rfeId ? rfeById(store, d.rfeId) : undefined;
  if (rfe?.kind === "governance" || (d.model === "rule" && d.reasoning.startsWith("Unit holders decided"))) return "Unit holders";
  if (d.model === "rule") return "A fixed rule";
  if (d.conduct?.result === "stop") return "The conduct check";
  if (d.bin === "gated") return "The steward";
  if (d.bin === "advisory") return "The agent, after asking members";
  return "The agent";
}

export function decisionView(store: Store, d: Decision, tier: DecisionTier, params: ParamValues): DecisionView {
  const clock = store.meta.clock;
  const held = isEmbargoed(d, clock, params.PRIVATE_DECISION_MAX_DAYS);
  const priv = d.embargo ? { until: privateUntil(d, params.PRIVATE_DECISION_MAX_DAYS), reason: d.embargo.reason } : undefined;
  const base = { id: d.id, ventureId: d.ventureId, at: d.at, bin: d.bin, status: d.status, private: priv };
  if (held && tier !== "steward") return { ...base, redacted: true, decidedBy: decidedBy(store, d) };
  const view: DecisionView = {
    ...base,
    redacted: false,
    title: d.title,
    decidedBy: decidedBy(store, d),
    outcome: d.outcome,
    takenAt: d.takenAt,
    spendUsd: d.facts.spendUsd > 0 ? d.facts.spendUsd : undefined,
    rfeId: d.rfeId,
  };
  // A shutdown's one-line summary is public: everyone sees why a venture ended, not the full reasoning.
  if (atLeast(tier, "verified") || d.transition === "killed") view.summary = decisionSummary(d);
  if (atLeast(tier, "unit holder")) {
    const rfe = d.rfeId ? rfeById(store, d.rfeId) : undefined;
    Object.assign(view, {
      reasoning: d.reasoning,
      binReasons: d.binReasons,
      confidence: d.confidence,
      lessonIds: d.lessonIds,
      contradicts: d.contradicts,
      conduct: d.conduct,
      stewardNote: d.stewardNote,
      model: d.model,
      options: rfe?.options,
      recommendation: rfe?.recommendation,
      answers: rfe
        ? responsesFor(store, rfe.id).map((r) => ({
            handle: r.handle,
            at: r.at,
            answer: r.choice ?? (r.scale ? `${r.scale}/5` : (r.text ?? r.transcript ?? "")),
          }))
        : undefined,
    });
  }
  return view;
}

/** A venture's decisions, newest first, as the tier may see them. */
export function decisionViews(store: Store, venture: Venture, tier: DecisionTier, params: ParamValues): DecisionView[] {
  return store.decisions
    .filter((d) => d.ventureId === venture.id)
    .sort((a, b) => b.at.localeCompare(a.at))
    .map((d) => decisionView(store, d, tier, params));
}

/**
 * A post-mortem as a tier may see it, split like a decision. Everyone sees the
 * outcome, the kill-rule category and the summary. Verified members also see a
 * short reason; people with units see why it ended in full and what was tried.
 * Lessons follow the lessons setting and are not decided here.
 */
export interface PostMortemView {
  summary: string;
  killReason?: PostMortem["killReason"];
  stageReached?: string;
  daysToKillSignal?: number;
  costUsd: number;
  publishedAt?: string;
  lessonCount: number;
  shortWhy?: string;
  whyItEnded?: string;
  whatWeTried?: string[];
}

export function postMortemView(pm: PostMortem, tier: DecisionTier): PostMortemView {
  const view: PostMortemView = {
    summary: pm.summary,
    killReason: pm.killReason,
    stageReached: pm.stageReached,
    daysToKillSignal: pm.daysToKillSignal,
    costUsd: pm.costUsd,
    publishedAt: pm.publishedAt,
    lessonCount: pm.lessons.length,
  };
  if (atLeast(tier, "verified")) view.shortWhy = shortReason(pm.whyItEnded);
  if (atLeast(tier, "unit holder")) Object.assign(view, { whyItEnded: pm.whyItEnded, whatWeTried: pm.whatWeTried });
  return view;
}

/** What each tier reads, for page copy. */
export const TIER_NOTE: Record<DecisionTier, string> = {
  public: "You see what was decided, who decided it and what it cost. Verified members also see a short reason; people with units see the reasoning.",
  verified: "You see a short reason for each decision. People with units in this venture, or in the Protocol, see the full reasoning.",
  "unit holder": "You hold units, so you see the full reasoning, the options, members' answers and the lessons followed.",
  steward: "You're the steward, so you see everything, including decisions still held private.",
};
