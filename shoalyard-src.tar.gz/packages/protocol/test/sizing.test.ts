import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams, type BudgetLine, type RequestPlanItem } from "@av/schema";
import { legacySeatPlan, rosterPlan, seatMath, seatPlanFor, type RosterInput } from "../src/sizing";

const params = defaultParams();
const line = (key: string, usd: number, category: BudgetLine["category"] = "api", stretch = false): BudgetLine => ({ key, label: key, category, usd, claimId: `c-budget-${key}`, stretch });
const item = (key: string, type: RequestPlanItem["type"], stakes: RequestPlanItem["stakes"], audience = "any-holder"): RequestPlanItem => ({ key, title: key, type, stakes, audience });

const permitBudget = [line("api", 70), line("hosting", 40, "hosting"), line("portals", 50, "data"), line("domain", 15, "domain"), line("email", 25, "tools"), line("formation", 60, "formation"), line("ads", 100, "ads-test", true), line("metro", 60, "data", true)];
const permitPlan = [item("launch-price", "judgment", "high"), item("trade", "judgment", "medium"), item("metros", "knowledge", "medium", "domain-expert")];
const permitRoster: RosterInput = {
  customer: "Small business",
  endMarket: "Real estate and construction",
  motions: ["Partner or channel", "Sales-led"],
  requestPlan: permitPlan,
  needsIntegration: true,
  regulated: [],
  hints: {},
};

test("Permit Pulse: a $312 proof over 25 people caps the price at $12; at $10 it needs 32 seats, 48 at most", () => {
  const roster = rosterPlan(permitRoster, params);
  const plan = seatPlanFor({ budget: permitBudget, requestPlan: permitPlan, roster: roster.roles }, params, "1.10");
  assert.equal(plan.budgetUsd, 260);
  assert.equal(plan.proofBudgetUsd, 312);
  assert.equal(plan.coverageSeats, 25);
  assert.equal(plan.rosterSeats, 12);
  assert.equal(plan.headcount, 25, "the larger of the roster and the holders its requests need");
  assert.equal(plan.price!.upperUsd, 12, "$312 ÷ 25 people");
  assert.equal(plan.budgetSeats, 32);
  assert.equal(plan.binding, "budget");
  assert.equal(plan.min, 32);
  assert.equal(plan.max, 48);
  assert.equal(plan.minRaiseUsd, 320);
  assert.equal(plan.contingencyUsd, 60);
  assert.equal(plan.stretchUsd, 160);
  assert.deepEqual(plan.criticalRoles, ["icp-operator", "domain-expert"]);
  assert.deepEqual(plan.atPrices.map((a) => [a.priceUsd, a.min]), [[10, 32], [12, 26]]);
  const lines = seatMath(plan, roster.roles);
  assert.ok(lines.some((l) => l.total && /32 seats · \$320/.test(l.value)));
  assert.ok(lines.some((l) => l.label === "Highest price the people allow" && l.value === "$12"));
});

test("a proposed price above proof ÷ people is held to that bound, and inside the Protocol's minimum and maximum", () => {
  const budget = [line("api", 80), line("domain", 15, "domain"), line("email", 20, "tools"), line("formation", 55, "formation")];
  const plan = seatPlanFor({ budget, requestPlan: [item("pricing", "judgment", "medium")], roster: [], priceUsd: 25 }, params, "1.10");
  assert.equal(plan.headcount, 20);
  assert.equal(plan.priceUsd, 10, "$204 ÷ 20 people allows $10 at most");
  assert.equal(plan.min, 21);
  const rich = [line("api", 4000)];
  assert.equal(seatPlanFor({ budget: rich, requestPlan: [], roster: [], priceUsd: 500 }, params, "1.10").priceUsd, params.SEAT_PRICE_MAX_USD);
  assert.equal(seatPlanFor({ budget: rich, requestPlan: [], roster: [], priceUsd: 2 }, params, "1.10").priceUsd, params.SEAT_PRICE_MIN_USD);
  assert.equal(seatPlanFor({ budget: rich, requestPlan: [], roster: [], priceUsd: 60 }, { ...params, SEAT_PRICE_MAX_USD: 40 }, "1.10").priceUsd, 40, "a lower maximum by vote applies at once");
});

test("seats needed never fall below the people a venture runs on, and the floor still holds", () => {
  const input = { budget: [line("api", 100)], requestPlan: [item("p", "judgment", "high")], roster: [] };
  const base = seatPlanFor(input, params, "1.10");
  assert.equal(base.budgetSeats, 12);
  assert.equal(base.min, 25, "25 holders for the request to get its answers, though $120 needs only 12 seats");
  assert.equal(base.binding, "coverage");
  const roster = seatPlanFor({ budget: [line("api", 100)], requestPlan: [], roster: [{ key: "icp-operator", count: 14 }] }, params, "1.10");
  assert.equal(roster.min, 14);
  assert.equal(roster.binding, "roster");
  const tiny = seatPlanFor({ budget: [line("api", 30)], requestPlan: [], roster: [] }, params, "1.10");
  assert.equal(tiny.min, params.SEAT_FLOOR);
  assert.equal(tiny.binding, "floor");
  assert.equal(seatPlanFor(input, { ...params, RESPONSE_RATE: { judgment: 0.25, knowledge: 0.2 } }, "1.10").min, 20);
  assert.equal(seatPlanFor(input, { ...params, N_BASELINE: { ...params.N_BASELINE, judgment: [4, 7] } }, "1.10").min, 35);
});

test("nothing caps the seat count: a big proof at the lowest price asks for every seat it needs", () => {
  const huge = seatPlanFor({ budget: [line("api", 3000)], requestPlan: [], roster: [] }, params, "1.10");
  assert.equal(huge.proofBudgetUsd, 3600);
  assert.equal(huge.min, 360);
  assert.equal(huge.max, 540);
  assert.equal(huge.cap, undefined);
  assert.equal(huge.overCap, undefined);
  assert.equal(huge.shortfallUsd, 0);
  assert.equal(seatPlanFor({ budget: [line("api", 3000)], requestPlan: [], roster: [], priceUsd: 100 }, params, "1.10").min, 36);
});

test("a small-business funnel gives 3 partners, 15 intros, 4 introducers; enterprise reaches the roster cap", () => {
  const r = rosterPlan(permitRoster, params);
  assert.equal(r.partners, 3);
  assert.equal(r.intros, 15);
  assert.equal(r.roles.find((x) => x.key === "introducer")?.count, 4);
  assert.equal(r.total, 12);
  assert.match(r.roles.find((x) => x.key === "introducer")!.derivation, /15 intros for 3 design partners/);
  const ent = rosterPlan({ ...permitRoster, customer: "Enterprise" }, params);
  assert.equal(ent.partners, 4);
  assert.equal(ent.intros, 54);
  assert.equal(ent.roles.find((x) => x.key === "introducer")?.count, 17);
  assert.equal(ent.total, 25, "enterprise fills the roster cap on its own");
  assert.ok(rosterPlan({ ...permitRoster, customer: "Government" }, params).overMax, "government runs past it");
});

test("counsel joins the roster for a regulated sector or a regulated risk, and is critical", () => {
  const health = rosterPlan({ ...permitRoster, endMarket: "Healthcare", needsIntegration: false, motions: ["Sales-led"] }, params);
  const legal = health.roles.find((x) => x.key === "legal");
  assert.ok(legal?.critical);
  assert.equal(health.total, 11, "Chairside's shape: 3 + 4 + 3 + 1");
  const risk = rosterPlan({ ...permitRoster, regulated: ["legal advice"] }, params);
  assert.ok(risk.roles.some((x) => x.key === "legal"));
  assert.ok(!permitRoster.regulated.length && !rosterPlan(permitRoster, params).roles.some((x) => x.key === "legal"));
});

test("consumer ventures recruit test users through community members, with no introducers", () => {
  const r = rosterPlan({ ...permitRoster, customer: "Consumer" }, params);
  assert.ok(!r.roles.some((x) => x.key === "introducer"));
  assert.equal(r.roles.find((x) => x.key === "channel")?.count, 2);
});

test("a legacy venture keeps its minimum and shows the buffer as contingency", () => {
  const plan = legacySeatPlan({ minRaiseUsd: 300, budget: [{ label: "Compute", usd: 260 }, { label: "Buffer", usd: 40 }] }, params, "1.2");
  assert.equal(plan.rule, "legacy-budget");
  assert.equal(plan.min, 30);
  assert.equal(plan.contingencyUsd, 40);
  assert.equal(seatMath(plan).at(-1)?.value, "30 seats");
  assert.equal(plan.priceUsd, params.SEAT_PRICE_USD, "it keeps the one price it was pitched under");
  assert.equal(legacySeatPlan({ minRaiseUsd: 300, budget: [], seatPriceUsd: 25 }, params, "1.10").min, 12);
});
