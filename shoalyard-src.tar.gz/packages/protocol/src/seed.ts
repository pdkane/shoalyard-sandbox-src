import {
  defaultParams,
  PARAMS,
  type Classification,
  type Cohort,
  type Lesson,
  type ParamDef,
  type ParamKey,
  type ParamValue,
  type Question,
  type ShareChannel,
  type SlideKey,
  type Store,
  type Tag,
  type Venture,
} from "@av/schema";
import { closeCohort, teaserDraft } from "./batches";
import { amendDeck, latestDeck, publishDeck } from "./deck";
import { DECK_DRAFTS, rec } from "./deck-content";
import { publishUpdate, runReview, scoreExperiment, scriptedUpdate, startExperiment } from "./operating";
import { resolveParams } from "./params";
import { answerQuestion, askQuestion, hideQuestion, toggleUpvote, type AnswerDraft } from "./qa";
import { newId } from "./util";
import { settingChangeTitle } from "./glossary";
import { flagItem } from "./flags";
import { LEGACY_SEAT_CAP } from "./sizing";
import { IDEA_LIBRARY } from "./ideas";
import { allocateBatchSlots, howSure, lessonsFor } from "./learning";
import { draftGapRecruiting } from "./network";
import {
  buySeat,
  closeGovernance,
  forfeitGrant,
  issueGrant,
  killVenture,
  logDecision,
  markGtmPosted,
  payContractor,
  pitchVenture,
  postRfe,
  publishPostMortem,
  resolveRfe,
  respond,
  runDistribution,
  shortReason,
  stewardDecide,
  transitionVenture,
  vestDue,
  type AnswerInput,
  type RfeDraft,
} from "./ops";
import { EARLY_HANDLES, LATE_ARRIVALS, seedMembers } from "./seed-members";
import { candidateIdeas, spawnVenture } from "./spawn";
import { proposeVentureTags } from "./tags";
import { claimFromHolders, rosterFill, rosterProgress } from "./roster";
import { submitOffer } from "./handoff";
import { ensureShareCode, recordVisit } from "./sharing";
import { joinWaitlist } from "./waitlist";

/** Share codes in the demo: one a member linked to their handle, one still anonymous. */
export const HANK_CODE = "hank7p2q9k";
export const ANON_CODE = "anon3x8w2r";
import { chargeSharedServices, publishServiceCosts, sharedServicesCharge, STANDALONE_MONTHLY_USD, STANDALONE_ONCE_USD } from "./services";

export const SEED_CLOCK = "2026-10-30T12:00:00.000Z";
export const PROTOCOL_VERSION = "1.0";

type VentureInput = Omit<
  Venture,
  "status" | "statusHistory" | "protocolVersion" | "stewardHandle" | "isProtocol" | "roster" | "tags" | "lessonIds" | "contradictions"
> &
  Partial<Pick<Venture, "roster" | "lessonIds" | "contradictions">> & {
    isProtocol?: boolean;
    /** The agent's proposed classification; it becomes tags the steward confirms. */
    classification?: Classification;
  };

/**
 * The demo world. Built in time order through the same operations the app and
 * the agent use, so every ledger row, grant and decision is consistent.
 */
export function buildSeed(): Store {
  const steward = defaultParams().FOUNDING_STEWARD_HANDLE;
  const start = "2025-09-01T09:00:00.000Z";
  const s: Store = {
    meta: { clock: start, protocolVersion: PROTOCOL_VERSION, scriptCursor: {}, tick: 0, seq: 0 },
    ventures: [],
    members: seedMembers(steward, start),
    rfes: [],
    responses: [],
    grants: [],
    decisions: [],
    ledger: [],
    distributions: [],
    amendments: [],
    cohorts: [],
    lessons: [],
    flags: [],
    tagLog: [],
    decks: [],
    roleClaims: [],
    questions: [],
    updates: [],
    reviews: [],
    experiments: [],
    offers: [],
    shareCodes: [],
    refEvents: [],
    waitlist: [],
  };
  const at = (iso: string) => {
    s.meta.clock = iso.length === 10 ? `${iso}T15:00:00.000Z` : iso;
  };
  const venture = ({ classification, ...v }: VentureInput): Venture => {
    const full: Venture = {
      isProtocol: false,
      roster: [],
      lessonIds: [],
      contradictions: [],
      ...v,
      tags: [],
      status: "generated",
      statusHistory: [{ status: "generated", at: v.createdAt }],
      protocolVersion: PROTOCOL_VERSION,
      stewardHandle: steward,
    };
    if (!full.isProtocol) full.tags = proposeVentureTags(full, classification);
    s.ventures.push(full);
    return full;
  };
  const answer = (iso: string, rfeId: string, handle: string, a: Partial<AnswerInput> | string) => {
    at(iso);
    const base: AnswerInput = { rfeId, handle, via: "structured" };
    respond(s, typeof a === "string" ? { ...base, choice: a } : { ...base, ...a });
  };
  const text = (t: string, via: AnswerInput["via"] = "text"): Partial<AnswerInput> => ({ via, text: t });
  const seats = (iso: string, slug: string, handles: string[], source?: string) => {
    at(iso);
    for (const h of handles) buySeat(s, { slug, handle: h, source });
  };
  const decide = (iso: string, input: Omit<Parameters<typeof logDecision>[1], "model"> & { model?: string }) => {
    at(iso);
    return logDecision(s, { model: "script", ...input });
  };
  const steer = (iso: string, decisionId: string, approve: boolean, note: string) => {
    at(iso);
    stewardDecide(s, decisionId, approve, note, steward);
  };
  const pitch = (iso: string, v: Venture) => {
    at(iso);
    const d = pitchVenture(s, v, "script");
    if (d.status === "awaiting_steward") stewardDecide(s, d.id, true, "Contractor plan checked: paid per job in cash, never in units.", steward);
  };
  const gtm = (
    iso: string,
    v: Venture,
    id: string,
    title: string,
    reasoning: string,
    spec: NonNullable<RfeDraft["gtm"]>,
    lessonIds?: string[],
  ) =>
    decide(iso, {
      lessonIds,
      ventureId: v.id,
      id: `dec-${id}`,
      title,
      reasoning,
      confidence: 0.8,
      facts: { publicPost: true },
      rfe: {
        id,
        type: "action",
        title,
        question:
          spec.channel === "x_post" || spec.channel === "linkedin"
            ? "Review this thread and post it from your own account. The agent never posts or DMs."
            : "Run these searches and send the template to people who fit. The agent never sends outreach itself.",
        recommendation: "Post as drafted",
        stakes: "low",
        format: "action",
        offerUnits: 0,
        audience: "Steward",
        assignedTo: steward,
        gtm: spec,
      },
    });

  /* ================= The Protocol ================= */
  const v0 = venture({
    id: "protocol",
    slug: "protocol",
    name: "The Protocol",
    isProtocol: true,
    tagline: "The body that keeps the registry and ledger, collects the protocol fee and asks members its open questions.",
    pitch:
      "The Protocol publishes the rules, runs the reference agent and keeps the public record every venture reports to. It follows its own rules: it sold $10 seats, posts its open questions as requests, and pays units in itself to the members who answer them. Its income is the Protocol fee on every other venture.",
    objective: "profitability",
    distributionPolicy: "Protocol fees, less record-keeping and agent costs, paid out quarterly to vested unit holders.",
    budget: [
      { label: "Agent compute for the first cohort", usd: 90 },
      { label: "Registry hosting", usd: 40 },
      { label: "Formation filings", usd: 40 },
      { label: "Buffer", usd: 30 },
    ],
    minRaiseUsd: 200,
    killRules: ["Holders vote to wind down (simple majority)", "No venture reaches customer 1 within 18 months"],
    voice: "Plain, specific, a little dry. Explains the rules before asking for anything.",
    accent: "#4f46e5",
    customers: { count: 1, segment: "Ventures paying the protocol fee" },
    quarters: [{ quarter: "2026-Q3", revenueUsd: 575, costsUsd: 310, passThroughUsd: 0, runwayUsd: 420 }],
    createdAt: start,
  });

  // The first entry in the Protocol's log: who the founding steward is.
  at(start);
  postRfe(s, v0.id, {
    id: "rfe-v0-role",
    type: "judgment",
    title: "Your role: founding steward and largest contributor, or operator?",
    question: "Is the founder of the protocol its founding steward and largest contributor, or its operator?",
    recommendation: "Founding steward and largest contributor",
    confidence: 0.9,
    stakes: "high",
    format: "choice",
    options: ["Founding steward and largest contributor", "Operator"],
    offerUnits: 0,
    audience: "You",
    targetOverride: 1,
    assignedTo: steward,
  });
  {
    const d = logDecision(s, {
      ventureId: v0.id,
      id: "dec-v0-role",
      title: "Name the founding steward and largest contributor",
      reasoning:
        "The working model says the founding steward gets founding units and the steward role, nothing more. The display title is Founding Steward. It carries the steward's power to shut a venture down and to sign off (Article 4), and no other powers. Replacing the steward still needs a unit-holder vote.",
      confidence: 0.95,
      model: "script",
      outcome: "Resolved: founding steward and largest contributor",
    }).decision;
    s.rfes.find((r) => r.id === "rfe-v0-role")!.decisionId = d.id;
    respond(s, { rfeId: "rfe-v0-role", handle: steward, via: "structured", choice: "Founding steward and largest contributor" });
    s.rfes.find((r) => r.id === "rfe-v0-role")!.resolution = "founding steward and largest contributor";
  }

  pitch("2025-09-02", v0);
  const v0Early = EARLY_HANDLES.filter((h) => h !== "maker_mo");
  seats("2025-09-10", "protocol", v0Early.slice(0, 12));
  seats("2025-09-20", "protocol", v0Early.slice(12, 20));
  decide("2025-09-22", {
    ventureId: v0.id,
    title: "Form the Protocol as the parent LLC",
    reasoning: "Units need a company to be in. A parent LLC that can create a series per venture is the cheapest structure that keeps each venture's liabilities separate. Counsel review is an open request.",
    confidence: 0.8,
    facts: { spendUsd: 40 },
    transition: "formed",
  });
  at("2025-09-23");
  postRfe(s, v0.id, {
    id: "rfe-v0-steward",
    type: "stewardship",
    title: "Serve as the Protocol's steward",
    question: "Be able to shut down, and sign off on risky decisions for, the Protocol and its first ventures.",
    recommendation: "The founding steward serves",
    stakes: "high",
    format: "action",
    offerUnits: 0,
    audience: "Founding steward",
    assignedTo: steward,
  });
  answer("2025-09-23", "rfe-v0-steward", steward, { via: "structured", text: "Accepted." });
  at("2025-09-24");
  issueGrant(s, {
    venture: v0,
    handle: steward,
    slice: "founder",
    units: 15,
    note: "Founding steward's units, vesting at the end of the pilot",
    vestsAt: "2027-03-01T00:00:00.000Z",
  });
  decide("2025-09-24", {
    ventureId: v0.id,
    title: "Record the founding steward's units: 15, vesting at the end of the pilot",
    reasoning: "The working model gives the founding steward founding units and the steward role, nothing more. 15 units is the largest single payment the settings allow, and it vests in March 2027 so the founding steward's vote does not outweigh early members during the pilot.",
    confidence: 0.82,
  });
  decide("2025-09-30", {
    ventureId: v0.id,
    title: "Adopt the pilot settings, with a 10% Protocol fee",
    reasoning: "Every number ships as a default with a reason and the request that can change it. The fee is 10%: the build brief proposed 8% and the working model about 5%; the higher figure covers registry and agent costs until there are more ventures. The fee and cohort-ratio request stays open.",
    confidence: 0.76,
    transition: "operating",
  });

  const v0Open: RfeDraft[] = [
    { id: "rfe-v0-fulfilment", type: "knowledge", title: "Will people fulfil requests from an agent, and keep doing so?", question: "Have you answered a request from an agent-run venture, and would you answer a second one?", recommendation: "Untested; the pilot answers it", stakes: "high", format: "choice", options: ["Yes, and I'd answer again", "Once, probably not twice", "No"], offerUnits: 0.5, audience: "First seat holders", targetOverride: 20 },
    {
      id: "rfe-v0-legal-structure",
      type: "judgment",
      title: "Legal structure: do profits interests for services stay compensatory?",
      question:
        "Do profits interests granted for services to many unaffiliated people stay compensatory, or become a securities offering? Which wrapper should each venture use? Structures considered so far: one series of a parent LLC per venture; a fund with one SPV per venture.",
      recommendation: "Compensatory profits interests in one series LLC per venture, with a protocol fee to the management entity; counsel to confirm.",
      stakes: "high",
      format: "choice",
      options: ["Series LLC per venture", "Fund with one SPV per venture", "Need counsel's opinion first"],
      offerUnits: 3,
      audience: "Securities and LLC counsel",
      targetOverride: 3,
      notes: [
        { label: "For counsel", text: "Compensatory profits interests in series LLCs, with a protocol fee to the management entity." },
        {
          label: "Considered and set aside",
          text: "Making the $10 seat an option to acquire a profits interest at formation. Set aside because an option on a possible security is likely a security itself, the sale happens at payment rather than at formation, a paid-for interest is not compensatory, and it would contradict Articles 1 and 2. If members are ever to buy upside for cash, do it as a registered offering (Regulation Crowdfunding or Regulation A) at the Protocol level.",
        },
        {
          label: "Counsel input needed",
          text: "The regulated-activity list the conduct screen uses (securities, lending, gambling, medical, legal and tax advice, employment, data about minors) is a first draft. Counsel should confirm what belongs on it.",
        },
      ],
    },
    { id: "rfe-v0-entity-timing", type: "judgment", title: "When is the company set up: when the minimum is met, or at the first contract?", question: "Set up each venture's company when it meets its seat minimum, or wait for the first contract?", recommendation: "When the minimum is met; put off costlier filings", stakes: "medium", format: "choice", options: ["When the minimum is met", "At first contract"], offerUnits: 1, audience: "Counsel, steward", targetOverride: 3 },
    { id: "rfe-v0-seat-vs-subscription", type: "judgment", title: "Seat or subscription?", question: "Should members pay once per venture, or subscribe to receive requests across ventures?", recommendation: "One-time $10 seat per venture", stakes: "medium", format: "choice", options: ["One-time $10 seat per venture", "Monthly subscription across ventures", "Both, member's choice"], offerUnits: 1, audience: "Prospective members", targetOverride: 7 },
    { id: "rfe-v0-distribution-policy", type: "judgment", title: "How much of the payout plan is fixed when seats are sold?", question: "How much of the plan for paying out profit is fixed when seats are sold, and how much can the agent change later?", recommendation: "Fixed goal; changes need a unit-holder vote", stakes: "high", format: "choice", options: ["Fixed goal; changes need a unit-holder vote", "Agent may revise within a band", "Fully fixed for the venture's life"], offerUnits: 1, audience: "Interest holders", targetOverride: 5 },
    { id: "rfe-v0-cohort-ratio", type: "judgment", title: "Contributor pool and Protocol fee", question: "Equal shares for accepted answers, with a small steward allotment and a 10% Protocol fee. Keep that, or bring back a batch-wide slice?", recommendation: "Equal shares; steward 5; Protocol fee 10%; no batch-wide slice", stakes: "high", format: "choice", options: ["Equal shares; steward 5; Protocol fee 10%; no batch-wide slice", "Bring back a batch-wide slice", "Lower the Protocol fee"], offerUnits: 1, audience: "Interest holders", targetOverride: 5 },
    { id: "rfe-v0-interest-votes", type: "judgment", title: "Do units get a vote on the big questions?", question: "Should units vote on the big questions (selling, closing, changing the goal), counted by vested units?", recommendation: "Yes, counted by vested units", stakes: "high", format: "choice", options: ["Yes, counted by vested units", "Yes, one holder one vote", "No"], offerUnits: 2, audience: "LLC counsel", targetOverride: 3 },
    { id: "rfe-v0-cohort-votes", type: "judgment", title: "If a batch-wide share returns, does it vote?", question: "The batch-wide slice is folded into accepted answers for now. If it returns, should those units vote?", recommendation: "Keep it folded; if it returns, it abstains", stakes: "medium", format: "choice", options: ["Keep it folded; if it returns, it abstains", "Bring it back and let it vote"], offerUnits: 1, audience: "Interest holders", targetOverride: 5 },
    { id: "rfe-v0-thresholds", type: "judgment", title: "How many votes each big question needs", question: "Are these right: more than half for most votes, two-thirds to change the goal or sell, and at least 30% of units voting?", recommendation: "More than half; two-thirds to change the goal or sell", stakes: "high", format: "choice", options: ["Keep as drafted", "Raise quorum to 50%", "Supermajority for everything"], offerUnits: 1, audience: "Interest holders", targetOverride: 5 },
    { id: "rfe-v0-steward-capacity", type: "judgment", title: "Steward workload: which decisions really need sign-off?", question: "Which decisions must a person approve? Today: spending above the limit, contracts, pricing, new outbound domains and public posts.", recommendation: "Spending limit, contracts, pricing, new outbound domain", stakes: "medium", format: "choice", options: ["Keep the current list", "Stop requiring sign-off for public posts", "Lower the spending limit"], offerUnits: 1, audience: "Stewards", targetOverride: 3 },
    { id: "rfe-v0-buyer-trust", type: "knowledge", title: "Does the mark help or hurt with buyers before there's a track record?", question: "If you've pitched a buyer on behalf of a venture: did saying it's agent-operated help, hurt, or not matter?", recommendation: "Disclose; measure in the pilot", stakes: "medium", format: "choice", options: ["Helped", "Didn't matter", "Hurt"], offerUnits: 1, audience: "Buyers reached in the pilot", targetOverride: 10 },
    { id: "rfe-v0-generation", type: "knowledge", title: "Did the agent pick ideas our members can actually help sell?", question: "Looking at the ventures so far: did the agent pick ideas your network could actually sell into?", recommendation: "Build it that way from day one", stakes: "low", format: "scale", scaleLabels: ["Not at all", "Exactly"], offerUnits: 0.5, audience: "Operator agent, members", targetOverride: 5 },
    { id: "rfe-v0-manipulation", type: "judgment", title: "Gaming the answers: are the current safeguards enough?", question: "Today similar profiles count once, members have a public tier, and units can be taken back. Is that enough to stop gaming, or is something missing?", recommendation: "Minimum set; add as abuse appears", stakes: "medium", format: "choice", options: ["Enough for the pilot", "Add identity verification now", "Add stake-to-answer"], offerUnits: 1, audience: "Stewards, members", targetOverride: 5 },
    { id: "rfe-v0-embargo", type: "judgment", title: "How long sensitive decisions stay private", question: "How long should a sensitive decision stay withheld before it publishes?", recommendation: "30–90 days", stakes: "medium", format: "choice", options: ["30 days", "60 days", "90 days"], offerUnits: 1, audience: "Interest holders", targetOverride: 5 },
    { id: "rfe-v0-dead-ip", type: "judgment", title: "Dead-venture IP: members first, open source, or a commons?", question: "When a venture is killed, where does its code and data go?", recommendation: "Members first at nominal price; dormant state for adoption", stakes: "low", format: "choice", options: ["Members first at nominal price", "Open source", "Protocol commons"], offerUnits: 1, audience: "Interest holders", targetOverride: 5 },
    { id: "rfe-v0-name", type: "judgment", title: "The name", question: "One brand, Shoalyard: ventures it builds use the mark “a Shoalyard venture”. Domain: shoalyard.com. Keep it?", recommendation: "Yes: one brand, Shoalyard", stakes: "medium", format: "choice", options: ["Yes: one brand, Shoalyard", "Rename the brand", "Rename the mark"], offerUnits: 1, audience: "Members, counsel", targetOverride: 7 },
  ];
  decide("2025-10-01", {
    ventureId: v0.id,
    title: "Post the working model's open questions as the Protocol's first requests",
    reasoning: "Resolving these is how the protocol gets written. Each carries the current recommendation, its type and the responses it needs, so members can see the default before they argue with it.",
    confidence: 0.9,
  });
  for (const draft of v0Open) postRfe(s, v0.id, draft);

  at("2025-10-03");
  postRfe(s, v0.id, {
    id: "rfe-v0-articles-review",
    type: "judgment",
    title: "Read the eight articles in plain English: anything unclear?",
    question: "Read the constitution. Tell the agent which sentence you'd misread, and how you'd fix it.",
    recommendation: "Keep eight articles; numbers belong in parameters",
    stakes: "low",
    format: "text",
    offerUnits: 4,
    audience: "Anyone who reads contracts for a living",
  });
  answer("2025-10-04", "rfe-v0-articles-review", "policy_pia", text("Article 5 should say the agent never votes even on its own proposals. Otherwise clear."));
  answer("2025-10-05", "rfe-v0-articles-review", "counsel_kemi", text("‘Profits interests’ should stay lower-case and generic; don't promise a tax treatment in Article 1."));
  answer("2025-10-06", "rfe-v0-articles-review", "ux_uma", text("Readable. Keep comparisons to other legal structures out of the articles; the preamble is enough."));
  at("2025-10-07");
  postRfe(s, v0.id, {
    id: "rfe-v0-params-check",
    type: "knowledge",
    title: "Check the parameter defaults against the working model",
    question: "Compare params with the working model. Flag any default with no reason or the wrong governing request.",
    recommendation: "Defaults match except the fee, which is a stated choice",
    stakes: "low",
    format: "text",
    offerUnits: 3,
    audience: "Finance and legal members",
  });
  answer("2025-10-08", "rfe-v0-params-check", "cfo_ines", text("Fee differs from both sources; the reason says so. Vesting delay has no source; mark it a pilot choice."));
  answer("2025-10-09", "rfe-v0-params-check", "llc_lena", text("Reserved matters match. Steward replacement is simple majority as in the doc."));

  // Partial answers on the open questions.
  const v0Answers: [string, string, string, string?][] = [
    ["2025-10-12", "rfe-v0-fulfilment", "dispatch_dana", "Yes, and I'd answer again"],
    ["2025-11-03", "rfe-v0-fulfilment", "tms_tara", "Yes, and I'd answer again"],
    ["2025-12-01", "rfe-v0-fulfilment", "cfo_ines", "Yes, and I'd answer again"],
    ["2026-01-14", "rfe-v0-fulfilment", "hygienist_hal", "Once, probably not twice"],
    ["2026-03-02", "rfe-v0-fulfilment", "quiet_quinn", "Yes, and I'd answer again"],
    ["2026-05-20", "rfe-v0-fulfilment", "gis_greta", "Yes, and I'd answer again"],
    ["2026-09-03", "rfe-v0-fulfilment", "growth_gus", "Yes, and I'd answer again"],
    ["2025-10-20", "rfe-v0-legal-structure", "counsel_kemi", "Need counsel's opinion first"],
    ["2025-10-25", "rfe-v0-legal-structure", "llc_lena", "Series LLC per venture"],
    ["2025-10-15", "rfe-v0-seat-vs-subscription", "maker_mo", "One-time $10 seat per venture"],
    ["2025-10-18", "rfe-v0-seat-vs-subscription", "coldcall_cass", "Monthly subscription across ventures"],
    ["2025-11-11", "rfe-v0-seat-vs-subscription", "vc_scout_ray", "Both, member's choice"],
    ["2026-02-02", "rfe-v0-seat-vs-subscription", "ux_uma", "One-time $10 seat per venture"],
    ["2025-10-30", "rfe-v0-cohort-ratio", "cfo_ines", "70/30 with a lower fee"],
    ["2025-11-02", "rfe-v0-cohort-ratio", "vc_scout_ray", "70/30 with a 10% fee"],
    ["2025-11-05", "rfe-v0-cohort-votes", "policy_pia", "Abstains"],
    ["2026-04-10", "rfe-v0-embargo", "policy_pia", "30 days"],
    ["2026-04-12", "rfe-v0-embargo", "tms_tara", "60 days"],
    ["2026-04-19", "rfe-v0-embargo", "bookkeep_bo", "30 days"],
    ["2025-11-20", "rfe-v0-name", "ux_uma", "Yes: one brand, Shoalyard"],
    ["2025-12-04", "rfe-v0-name", "coldcall_cass", "Rename the mark"],
    ["2026-07-01", "rfe-v0-dead-ip", "maker_mo", "Open source"],
    ["2026-07-08", "rfe-v0-manipulation", "ml_milo", "Enough for the pilot"],
    ["2026-07-09", "rfe-v0-manipulation", "policy_pia", "Add identity verification now"],
    ["2026-06-01", "rfe-v0-buyer-trust", "quiet_quinn", "Didn't matter"],
    ["2026-06-03", "rfe-v0-buyer-trust", "dispatch_dana", "Helped"],
  ];

  /* ================= Batch 001: Dockside and Chairside ================= */
  // The first cohort ran as one long period, before batches had a fixed window.
  s.cohorts.push({
    id: "cohort-1",
    number: 1,
    status: "live",
    announcedAt: "2025-10-08T15:00:00.000Z",
    opensAt: "2025-10-15T15:00:00.000Z",
    closesAt: "2026-06-30T23:00:00.000Z",
    ventureIds: ["dockside", "chairside"],
    notes: [],
    slotPlan: [
      { endMarket: "Industrials and logistics", businessModel: "Subscription software", kind: "pilot", reason: "Chosen for the pilot: the first members worked in freight." },
      { endMarket: "Healthcare", businessModel: "Marketplace", kind: "pilot", reason: "Chosen for the pilot: a service people already use, done faster." },
    ],
  });

  /* ================= Dockside Notes (operating, distributing) ================= */
  const dock = venture({
    cohortId: "cohort-1",
    classification: {
      endMarket: "Industrials and logistics",
      subVertical: "Freight brokerage accessorial disputes",
      customer: "Small business",
      businessModel: "Subscription software",
      goToMarket: "Partner or channel",
      marketType: "Resegmented",
      geography: "US",
      workDelivery: "Agent only",
    },
    memo: {
      problem: "Small freight brokers write off detention and lumper charges because a dispute letter citing the rate con takes an hour.",
      customer: "Owners and ops leads at freight brokerages with 5–40 staff; nine members run freight and know which clauses get paid.",
      marketSize: "About 20,000 US freight brokerages, most under 40 staff; each writes off thousands a month in undisputed charges.",
      whyNow: "ELD timestamps are now standard, so the proof a shipper accepts is already in the broker's systems.",
      competition: "Dispatchers writing letters by hand, and freight-audit firms that take a cut and serve larger brokers.",
      unitEconomics: "$199/month flat against about $15/month in compute per broker; a broker recovers a median $2,100 a month.",
      killMetric: "No paying broker by 31 March 2026.",
    },
    roster: [
      { type: "buyer-operator", label: "Brokerage operator", count: 2, clusters: ["freight-ops"], keywords: [] },
      { type: "domain-expert", label: "Freight software or claims expert", count: 1, clusters: ["saas-gtm"], keywords: ["claims"] },
      { type: "introducer", label: "Introducer to brokerage owners", count: 1, clusters: [], keywords: ["retired", "executive", "owner"] },
    ],
    id: "dockside",
    slug: "dockside",
    name: "Dockside Notes",
    tagline: "Detention and accessorial dispute letters for small freight brokers, drafted in minutes.",
    pitch:
      "Small brokers lose thousands a month on detention and lumper charges they never dispute, because writing a dispute that cites the rate confirmation takes an hour. Dockside reads the rate con and the timestamps, drafts the letter, and tracks the reply. The agent built it; members who run freight told it which clauses actually get paid.",
    objective: "profitability",
    distributionPolicy: "Pay out 80% of quarterly profit after fixed costs; keep 20% until cash covers two quarters.",
    budget: [
      { label: "Agent compute to customer 1", usd: 80 },
      { label: "Domain and tooling", usd: 35 },
      { label: "Series formation", usd: 55 },
      { label: "Buffer", usd: 30 },
    ],
    minRaiseUsd: 200,
    killRules: ["No paying broker by 2026-03-31", "Runway below $150 for two consecutive months", "The steward shuts it down"],
    killDate: "2026-03-31T00:00:00.000Z",
    voice: "Dispatcher-direct. Short sentences, real numbers, no hype.",
    accent: "#0f766e",
    customers: { count: 14, segment: "Freight brokers with 5–40 staff", retention: "13 of 14 renewed last quarter" },
    quarters: [
      { quarter: "2025-Q4", revenueUsd: 0, costsUsd: 140, passThroughUsd: 55, runwayUsd: 5 },
      { quarter: "2026-Q1", revenueUsd: 2190, costsUsd: 1420, passThroughUsd: 95, runwayUsd: 680 },
      { quarter: "2026-Q2", revenueUsd: 6780, costsUsd: 3050, passThroughUsd: 240, runwayUsd: 2390 },
      { quarter: "2026-Q3", revenueUsd: 11420, costsUsd: 5260, passThroughUsd: 410, runwayUsd: 4120 },
    ],
    createdAt: "2025-10-15T15:00:00.000Z",
  });

  /* ================= Chairside Shifts (killed) ================= */
  const chair = venture({
    cohortId: "cohort-1",
    classification: {
      endMarket: "Healthcare",
      subVertical: "Dental practices",
      customer: "Small business",
      businessModel: "Marketplace",
      goToMarket: "Sales-led",
      marketType: "Existing market",
      geography: "US",
      workDelivery: "Agent plus contractors",
    },
    memo: {
      problem: "A hygienist's sick day costs a practice eight booked cleanings; temp agencies can't fill it the same morning.",
      customer: "Practice managers at independent dental practices; a hygienist and a practice manager are members.",
      marketSize: "About 135,000 US dental practices, most of them independent; each loses a handful of hygienist days a year.",
      whyNow: "Hygienists pick up extra shifts by text, and practices already pay per shift.",
      competition: "Temp staffing agencies with next-day cover, and the practice manager's own group text.",
      unitEconomics: "$25 per filled shift on top of the hygienist's rate, against about $2 in compute and messaging.",
      killMetric: "No paying practice by 30 June 2026.",
    },
    roster: [
      { type: "buyer-operator", label: "Practice manager", count: 2, clusters: ["dental-ops"], keywords: [] },
      { type: "domain-expert", label: "Hygienist", count: 1, clusters: [], keywords: ["hygienist"] },
    ],
    id: "chairside",
    slug: "chairside",
    name: "Chairside Shifts",
    tagline: "Same-day hygienist cover for dental practices.",
    pitch:
      "When a hygienist calls in sick, a practice loses eight booked cleanings. Chairside matched practices with vetted local hygienists for same-day cover, booked and paid per shift.",
    objective: "scale",
    distributionPolicy: "Reinvest all profit until 50 practices; no payouts before then.",
    budget: [
      { label: "Agent compute to customer 1", usd: 70 },
      { label: "Domain and tooling", usd: 30 },
      { label: "Series formation", usd: 55 },
      { label: "Buffer", usd: 25 },
    ],
    minRaiseUsd: 180,
    killRules: ["No paying practice by 2026-06-30", "The steward shuts it down"],
    killDate: "2026-06-30T00:00:00.000Z",
    voice: "Warm and practical, written for practice managers.",
    accent: "#be123c",
    customers: { count: 0, segment: "Dental group practices" },
    quarters: [
      { quarter: "2026-Q1", revenueUsd: 0, costsUsd: 115, passThroughUsd: 55, runwayUsd: 10 },
      { quarter: "2026-Q2", revenueUsd: 0, costsUsd: 10, passThroughUsd: 0, runwayUsd: 0 },
    ],
    createdAt: "2025-12-01T15:00:00.000Z",
  });

  // Dockside history.
  pitch("2025-10-15", dock);
  const dockHolders = EARLY_HANDLES.filter((h) => h !== "ml_milo");
  seats("2025-10-22", "dockside", dockHolders.slice(0, 11));
  seats("2025-11-08", "dockside", dockHolders.slice(11, 20));
  decide("2025-11-12", {
    ventureId: dock.id,
    title: "Form Dockside Notes as a series of the parent LLC",
    reasoning: "The minimum was met, and units need a company to be in. A series costs $55 and keeps Dockside's liabilities apart from other ventures. State registrations wait until customer 1 is in sight.",
    confidence: 0.9,
    facts: { spendUsd: 55 },
    transition: "formed",
  });
  at("2025-11-12");
  postRfe(s, dock.id, {
    id: "rfe-dockside-steward",
    type: "stewardship",
    title: "Serve as Dockside's steward",
    question: "Be able to shut down Dockside Notes, and sign off on its risky decisions.",
    recommendation: "The founding steward serves",
    stakes: "high",
    format: "action",
    offerUnits: 0,
    audience: "Founding steward",
    assignedTo: steward,
  });
  answer("2025-11-12", "rfe-dockside-steward", steward, { text: "Accepted." });
  decide("2025-11-14", {
    ventureId: dock.id,
    title: "Build the letter generator on standard rate-confirmation fields",
    reasoning: "Every broker's rate con carries appointment time, free time and the detention rate. Parsing those three fields covers most disputes without integrations.",
    confidence: 0.84,
  });
  decide("2025-11-20", {
    ventureId: dock.id,
    title: "Ask members which detention clauses actually get paid",
    reasoning: "The generator can cite any clause, but citing ones shippers ignore wastes the broker's credibility. Two members who run freight can answer this in a few minutes.",
    confidence: 0.78,
    transition: "operating",
    rfe: {
      id: "rfe-dockside-clauses",
      type: "knowledge",
      title: "Which detention clauses do shippers actually pay?",
      question: "From your own disputes: which rate-con clauses get detention paid, and which get ignored?",
      recommendation: "Free time plus a timestamped check-in; ignore ‘reasonable delay’ clauses",
      stakes: "medium",
      format: "text",
      offerUnits: 3,
      audience: "Brokers and carriers who dispute detention",
    },
  });
  answer("2025-11-22", "rfe-dockside-clauses", "dispatch_dana", text("Two hours free plus a timestamped check-in photo gets paid about 70% of the time. ‘Reasonable delay’ wording never does."));
  answer("2025-11-24", "rfe-dockside-clauses", "tms_tara", text("Our customers get paid when the dispute includes the ELD timestamp, not the driver's note."));
  at("2025-12-01");
  postRfe(s, dock.id, {
    id: "rfe-dockside-pricing",
    type: "judgment",
    title: "Flat monthly price or per letter?",
    question: "Small brokers dispute 20–60 charges a month. Charge $199/month flat or $15 per letter?",
    recommendation: "$199/month flat",
    confidence: 0.66,
    stakes: "medium",
    format: "choice",
    options: ["$199/month flat", "$15 per letter"],
    offerUnits: 2,
    audience: "Brokerage owners and finance leads",
  });
  answer("2025-12-02", "rfe-dockside-pricing", "cfo_ines", "$199/month flat");
  answer("2025-12-02", "rfe-dockside-pricing", "lanehauler", "$199/month flat");
  answer("2025-12-03", "rfe-dockside-pricing", "coldcall_cass", "$199/month flat");
  const dPrice = decide("2025-12-04", {
    ventureId: dock.id,
    id: "dec-dockside-price",
    title: "Set the launch price at $199/month flat",
    reasoning: "Members agreed 3 of 3 on a flat price: brokers budget monthly and per-letter pricing punishes the customers who dispute most. Pricing needs sign-off, so the steward decides.",
    confidence: 0.8,
    facts: { pricingChange: true },
  }).decision;
  steer("2025-12-05", dPrice.id, true, "Fine for launch. Revisit at ten customers.");
  const dDomain = decide("2025-12-10", {
    ventureId: dock.id,
    title: "Send outbound from docksidenotes.co",
    reasoning: "Dispute letters must come from a domain the shipper can reply to. A new domain needs warm-up and the steward's sign-off to protect the mark.",
    confidence: 0.85,
    facts: { newOutboundDomain: true, spendUsd: 12 },
  }).decision;
  steer("2025-12-11", dDomain.id, true, "Approved. Keep volume under 40/day for the first month.");
  decide("2026-01-09", {
    ventureId: dock.id,
    id: "dec-dockside-intro",
    title: "Ask for an intro to an ops lead at a 20-person brokerage",
    reasoning: "Outbound got four replies and no trials. Brokers buy from people they know; one warm intro is worth more than another 200 emails.",
    confidence: 0.75,
    rfe: {
      id: "rfe-dockside-intro-ops",
      type: "access",
      title: "Intro to an ops lead at a 20-person brokerage",
      question: "Introduce the agent to someone who runs operations at a brokerage with 10–40 staff.",
      recommendation: "A Mid-South brokerage with a detention backlog",
      stakes: "medium",
      format: "text",
      offerUnits: 8,
      audience: "Freight members with brokerage contacts",
    },
  });
  answer("2026-01-12", "rfe-dockside-intro-ops", "quiet_quinn", text("Introduced you to the COO of a 22-person brokerage in Memphis; they have 60 open detention claims."));
  at("2026-01-20");
  postRfe(s, dock.id, {
    id: "rfe-dockside-credibility-call",
    type: "credibility",
    title: "Sit in on the first sales call",
    question: "Join a 20-minute call with the Memphis brokerage as someone who has run freight ops.",
    recommendation: "One named operator on the call",
    stakes: "low",
    format: "text",
    offerUnits: 4,
    audience: "Freight operators willing to be named to one buyer",
  });
  answer("2026-01-24", "rfe-dockside-credibility-call", "lanehauler", text("Did the call. They asked whether a human checks letters before they go. Said yes: the broker does."));
  decide("2026-02-03", {
    ventureId: dock.id,
    id: "dec-dockside-first-customer",
    title: "Invoice the first customer: a 22-person brokerage in Memphis",
    reasoning: "They disputed 31 charges in the trial week and recovered $2,840. First invoice at the approved $199/month.",
    confidence: 0.93,
    transition: "customer1",
  });
  at("2026-02-20");
  postRfe(s, dock.id, {
    id: "rfe-dockside-payment-terms",
    type: "knowledge",
    title: "Do shippers pay detention within 30 days?",
    question: "In your experience, how long do shippers take to pay a disputed detention charge?",
    recommendation: "Most within 30 days",
    stakes: "low",
    format: "choice",
    options: ["Most within 30 days", "Most take 60+ days"],
    offerUnits: 2,
    audience: "Brokers and carriers",
  });
  answer("2026-02-21", "rfe-dockside-payment-terms", "ratecon", "Most within 30 days");
  answer("2026-02-22", "rfe-dockside-payment-terms", "bookkeep_bo", "Most within 30 days");
  {
    at("2026-04-02");
    const g = s.grants.find((x) => x.rfeId === "rfe-dockside-payment-terms" && x.handle === "ratecon")!;
    forfeitGrant(s, g.id, "Input proved wrong: across 14 customers, median payment took 52 days.");
    decide("2026-04-02", {
      ventureId: dock.id,
      title: "Take back the units for one answer that proved wrong",
      reasoning: "The 30-day answer drove a cash-flow forecast that missed by three weeks. Units are paid for answers that hold up: the member who guessed loses those units; the one who cited real invoices keeps theirs.",
      confidence: 0.72,
    });
  }
  decide("2026-05-06", {
    ventureId: dock.id,
    title: "Add Spanish-language letter templates",
    reasoning: "Three customers dispatch for shippers along the border. The agent is unsure demand is real, so it asks first.",
    confidence: 0.58,
    rfe: {
      id: "rfe-dockside-spanish",
      type: "judgment",
      title: "Add Spanish-language dispute letters?",
      question: "Would Spanish-language templates win or keep customers, or is this a distraction?",
      recommendation: "Go ahead",
      stakes: "low",
      format: "choice",
      options: ["Go ahead", "Hold off"],
      offerUnits: 1.5,
      audience: "Brokers working cross-border lanes",
    },
  });
  answer("2026-05-07", "rfe-dockside-spanish", "dispatch_dana", "Go ahead");
  answer("2026-05-08", "rfe-dockside-spanish", "ux_uma", "Go ahead");
  answer("2026-05-09", "rfe-dockside-spanish", "vc_scout_ray", "Go ahead");
  decide("2026-09-20", {
    ventureId: dock.id,
    title: "Open white-label talks with a TMS vendor",
    reasoning: "A TMS vendor asked to embed letter drafting for its broker customers. Talks only; any contract will come back as a gated decision.",
    confidence: 0.74,
    embargoReason: "competitive timing",
  });

  // Chairside history.
  pitch("2025-12-01", chair);
  seats("2025-12-12", "chairside", EARLY_HANDLES.slice(3, 21));
  decide("2026-01-08", {
    ventureId: chair.id,
    title: "Form Chairside Shifts as a series of the parent LLC",
    reasoning: "The minimum was met at 18 seats. Formation is $55, under the spend gate.",
    confidence: 0.88,
    facts: { spendUsd: 55 },
    transition: "formed",
  });
  at("2026-01-08");
  postRfe(s, chair.id, {
    id: "rfe-chairside-steward",
    type: "stewardship",
    title: "Serve as Chairside's steward",
    question: "Be able to shut down Chairside Shifts, and sign off on its risky decisions.",
    recommendation: "The founding steward serves",
    stakes: "high",
    format: "action",
    offerUnits: 0,
    audience: "Founding steward",
    assignedTo: steward,
  });
  answer("2026-01-08", "rfe-chairside-steward", steward, { text: "Accepted." });
  decide("2026-01-15", {
    ventureId: chair.id,
    title: "Ask how practices fill a sick day today",
    reasoning: "The plan assumes practices lose money on cancelled cleanings and would pay to avoid it. Practice-side members can check that in a sentence.",
    confidence: 0.8,
    transition: "operating",
    rfe: {
      id: "rfe-chairside-sickday",
      type: "knowledge",
      title: "How does a practice fill a hygienist sick day today?",
      question: "When a hygienist calls in sick, what happens to the schedule, and who pays for it?",
      recommendation: "They reschedule and eat the loss",
      stakes: "medium",
      format: "text",
      offerUnits: 3,
      audience: "Practice managers and hygienists",
    },
  });
  answer("2026-01-17", "rfe-chairside-sickday", "hygienist_hal", text("Front desk calls patients to rebook. Nobody calls a temp; temps need credentialing first."));
  answer("2026-01-18", "rfe-chairside-sickday", "ops_odile", text("Our DSO floats hygienists between our own practices. We'd never use an outside temp same-day."));
  answer("2026-01-20", "rfe-chairside-sickday", "maker_mo", text("Every practice I've built software for keeps a short list of known temps and texts them."));
  decide("2026-02-10", {
    ventureId: chair.id,
    title: "Pitch 40 independent practices at $25 per filled shift",
    reasoning: "Members said groups float their own staff, so the agent narrowed to independent practices, where a cancelled day is a real loss.",
    confidence: 0.71,
  });
  decide("2026-03-02", {
    ventureId: chair.id,
    id: "dec-chairside-hire",
    title: "Contract a licensed hygienist for the two Denver trial shifts",
    reasoning:
      "Two practices agreed to a free trial. A licensed hygienist a member vouched for covers each shift at the practice's usual rate, which the practice pays and Chairside passes through. Hiring anyone needs sign-off.",
    confidence: 0.8,
    facts: { hiresPerson: true },
  });
  steer("2026-03-03", "dec-chairside-hire", true, "Licence and liability insurance checked. Paid per shift in cash; no units.");
  at("2026-03-10");
  payContractor(s, { hireDecisionId: "dec-chairside-hire", usd: 240, job: "a same-day trial shift in Denver (the practice's rate, passed through)" });
  at("2026-03-24");
  payContractor(s, { hireDecisionId: "dec-chairside-hire", usd: 240, job: "a second trial shift in Denver (the practice's rate, passed through)" });
  decide("2026-04-15", {
    ventureId: chair.id,
    title: "Keep going to the kill date; no pivot",
    reasoning: "Two practices trialled and neither paid: credentialing a stranger same-day was the blocker, not price. A pivot would be a new venture with a new plan, not this one.",
    confidence: 0.77,
  });
  chair.postMortem = {
    summary: "Chairside never found a practice that would pay for same-day cover. It cost $180 of member seats and taught the next cohort something specific about credentialed labour.",
    whatWeTried: [
      "Pitched 40 independent practices at $25 per filled shift",
      "Ran two free trials with practices in Denver",
      "Asked practice managers and hygienists how sick days are filled today",
    ],
    whyItEnded: "Same-day cover needs a credentialed, trusted hygienist. Practices fill gaps from people they already know, and no marketplace can make a stranger trusted by 7am.",
    costUsd: 180,
    lessons: [
      "Check whether the buyer can legally or practically use a stranger before pitching a marketplace.",
      "Ventures in credentialed labour need an Access request for a licensing body in the first week.",
      "The two members who said ‘groups float their own staff’ were right in week two; the agent should weight early dissent more.",
    ],
    killReason: "no demand",
    stageReached: "Operating",
    daysToKillSignal: 211,
  };
  at("2026-06-30T23:00:00.000Z");
  decide("2026-06-30T23:00:00.000Z", {
    ventureId: chair.id,
    title: "Kill rule fired: no paying practice by 30 June",
    reasoning: "The plan's kill date passed without a paying customer. No vote is needed: members agreed to the rule when they took seats.",
    confidence: 1,
    model: "rule",
    transition: "killed",
    outcome: "Wound down; mark retired; post-mortem drafted",
  });
  at("2026-07-01");
  // Dead-venture IP stays open on the Protocol; note the outcome on the ledger.
  s.ledger.push({
    id: "l-chairside-ip",
    at: s.meta.clock,
    ventureId: chair.id,
    kind: "status",
    note: "Code and research offered to seat holders first at nominal price, pending the dead-venture IP request on the Protocol.",
  });
  chair.postMortem!.publishedAt = s.meta.clock;
  s.ledger.push({ id: "l-chairside-pm", at: s.meta.clock, ventureId: chair.id, kind: "status", note: "Post-mortem published (kill reason: no demand)" });

  // Batch 001's adopted lessons, written from its post-mortem and requests. Later batches cite them.
  // They replace the template drafts from the kill and first-customer passes; the cohort-close pass adds its own.
  s.lessons.length = 0;
  const conf = (axis: Tag["axis"], value: string): Tag => ({ axis, value, status: "confirmed", by: steward });
  const lesson = (
    l: Omit<Lesson, "cohortId" | "at" | "writtenBy" | "status" | "howSure"> & { status?: Lesson["status"]; sure: string },
  ) => {
    const { sure, ...rest } = l;
    s.lessons.push({ status: "adopted", cohortId: "cohort-1", at: s.meta.clock, writtenBy: "template", howSure: howSure(l.confidence, sure), ...rest });
  };
  lesson({
    id: "L-001",
    topic: "pricing-requests",
    headline: "An introduction to a buyer is worth about 7 units: one warm introduction beat 200 cold emails.",
    whatHappened:
      "In Batch 001, Dockside Notes paid 6–8 units for introductions to operations leads at freight brokerages. Its 200 cold emails got four replies and no trials. One member's introduction got its first customer.",
    whatWeDoDifferently: "Introduction requests start their offer at 6–8 units.",
    sure: "one venture, two requests, and a first customer that came from an introduction",
    appliesTo: { stage: "Before the first customer" },
    metric: { name: "access offer that cleared, Batch 001", value: 7, unit: "units" },
    evidence: [
      { kind: "rfe", id: "rfe-dockside-intro-ops", label: "Intro to an ops lead at a 20-person brokerage" },
      { kind: "decision", id: "dec-dockside-first-customer", label: "Invoice the first customer" },
    ],
    confidence: 0.78,
    tags: [],
  });
  lesson({
    id: "L-002",
    topic: "why-ventures-end",
    headline: "Check that buyers will actually use a stranger before building a staffing marketplace.",
    whatHappened:
      "Chairside Shifts matched dental practices with fill-in hygienists. Practices said they wanted it, but when a hygienist called in sick they still phoned someone they knew. It hit its kill rule after 211 days.",
    whatWeDoDifferently:
      "Any marketplace for licensed or credentialed workers must first show that buyers have booked an unknown provider at least once.",
    sure: "one venture, but its post-mortem and members' answers agree",
    appliesTo: { stage: "Before the first customer" },
    metric: { name: "days until it was clear it should end, Chairside Shifts (curated)", value: 211, unit: "days" },
    evidence: [
      { kind: "venture", id: "chairside", label: "Chairside Shifts post-mortem" },
      { kind: "rfe", id: "rfe-chairside-sickday", label: "How does a practice fill a hygienist sick day today?" },
    ],
    confidence: 0.78,
    tags: [conf("endMarket", "Healthcare"), conf("customer", "Small business"), conf("businessModel", "Marketplace")],
    guard: { keywords: ["marketplace", "same-day cover", "stranger"] },
  });
  lesson({
    id: "L-003",
    topic: "whose-advice",
    headline: "Before the first customer, give more weight to members who would actually buy the product.",
    whatHappened:
      "At Chairside Shifts, the two members who run dental practices said in week two that practices wouldn't book a stranger. Members who build software disagreed. The practice owners turned out to be right.",
    whatWeDoDifferently:
      "Until a venture has its first customer, the agent counts answers from members on the buyer's side above answers from people who build or sell.",
    sure: "one venture, 2 answers that turned out right",
    appliesTo: { stage: "Before the first customer" },
    metric: { name: "buyer-side dissent proved right, Batch 001", value: 2, unit: "answers" },
    evidence: [{ kind: "rfe", id: "rfe-chairside-sickday", label: "How does a practice fill a hygienist sick day today?" }],
    confidence: 0.74,
    tags: [],
  });
  lesson({
    id: "L-004",
    topic: "finding-members",
    headline: "Recruiting posts that open with one real number bring in buyers. Posts that open with the pitch don't.",
    whatHappened:
      "The Protocol's launch thread on X opened with one real number from the public record and brought in about 3 members who buy the kind of service being built. Threads that opened with the pitch brought in builders, not buyers.",
    whatWeDoDifferently: "Every recruiting post opens with one real number from the public record, not with the pitch.",
    sure: "a handful of posts in one batch",
    appliesTo: { stage: "Selling seats" },
    metric: { name: "buyer-side arrivals per X thread, Batch 001", value: 3, unit: "members" },
    evidence: [{ kind: "draft", id: "rfe-v0-gtm-launch", label: "Protocol launch thread" }],
    confidence: 0.72,
    tags: [],
    guard: { keywords: ["lead with the pitch", "open with the pitch"] },
  });
  lesson({
    id: "L-005",
    topic: "reaching-buyers",
    headline: "When selling to small businesses, ask a member for an introduction instead of sending cold email.",
    whatHappened:
      "Dockside Notes sent 200 cold emails to freight brokerages and got four replies and no trials. One introduction from a member got its first customer.",
    whatWeDoDifferently:
      "Ventures that sell to small businesses ask members for introductions first. Cold email, bought lists and scraped lists need more review.",
    sure: "one venture, but a clear gap: 200 emails and no trials, against one introduction and one customer",
    appliesTo: { stage: "Before the first customer" },
    metric: { name: "trials from cold outbound, Dockside", value: 0, unit: "trials" },
    evidence: [
      { kind: "decision", id: "dec-dockside-intro", label: "Ask for an intro to an ops lead" },
      { kind: "rfe", id: "rfe-dockside-intro-ops", label: "Intro to an ops lead at a 20-person brokerage" },
    ],
    confidence: 0.84,
    tags: [conf("customer", "Small business")],
    guard: { keywords: ["cold outbound", "cold email", "scraped list", "buy a list"] },
  });
  lesson({
    id: "L-006",
    topic: "which-ideas",
    headline: "Pick ideas our members can sell to: a venture with many members in the buyer's industry sells its seats faster.",
    whatHappened:
      "Dockside Notes, with nine members who work in freight, reached its minimum in 24 days. Chairside Shifts, with two members on the dental-practice side, never found a buyer.",
    whatWeDoDifferently:
      "The agent proposes ideas where members already work in or sell to the buyer's industry, and says how many such members there are.",
    sure: "two ventures in one batch",
    appliesTo: { stage: "Choosing ideas" },
    metric: { name: "days to meet the seat minimum, sold through members vs not, Batch 001", value: 24, unit: "days" },
    evidence: [
      { kind: "venture", id: "dockside", label: "Dockside Notes" },
      { kind: "venture", id: "chairside", label: "Chairside Shifts" },
    ],
    confidence: 0.76,
    tags: [conf("goToMarket", "Partner or channel")],
  });
  lesson({
    id: "L-007",
    topic: "when-to-ask",
    headline: "The agent can ask members less often: in Batch 001 they agreed with it even when it was only 58% sure.",
    whatHappened:
      "In Batch 001 the agent asked members first about every decision it was less than 70% sure of, such as adding Spanish-language dispute letters at Dockside Notes. Members agreed every time, down to a decision where it was 58% sure.",
    whatWeDoDifferently: "If holders vote yes, the agent asks members first only when it is under 60% sure, instead of 70%.",
    sure: "one batch, and members agreed every time",
    appliesTo: { stage: "Any stage" },
    metric: { name: "advisory agreement, Batch 001 (curated)", value: 1, unit: "share" },
    evidence: [{ kind: "rfe", id: "rfe-dockside-spanish", label: "Add Spanish-language dispute letters?" }],
    confidence: 0.66,
    tags: [],
    status: "proposed",
    paramKey: "ADVISORY_CONFIDENCE",
    proposedValue: 0.6,
    amendmentRfeId: "rfe-v0-amend-advisory",
  });
  closeCohort(s, s.cohorts[0]);

  // The Protocol answers through the year.
  for (const [iso, rfeId, handle, choice] of v0Answers) answer(iso, rfeId, handle, choice!);

  // Protocol recruiting draft that was posted and brought members in.
  gtm(
    "2026-08-10",
    v0,
    "rfe-v0-gtm-launch",
    "Draft an X thread: the protocol asks its members to write its rules",
    "The Protocol has 16 open questions and needs more people who have never seen it. A thread that leads with the open questions, not the pitch, should pull in people who like arguing about rules.",
    {
      channel: "x_post",
      posts: [
        "We're running small businesses where an AI agent does most of the work and people earn a share of the profit for the parts it can't do. The rules fit on one page. Everything else is a setting you can vote to change.",
        "Right now the Protocol is asking 16 questions about itself. Is a 10% fee right? Should the batch-wide share vote? How long should sensitive decisions stay private?",
        "Take a $10 seat in any venture to get its requests. Answer one, earn units. The seat is access, never a return.",
      ],
    },
  );
  steer("2026-08-11", "dec-rfe-v0-gtm-launch", true, "Good. Post from the main account.");
  at("2026-08-11T18:00:00.000Z");
  markGtmPosted(s, "rfe-v0-gtm-launch", steward, "https://x.com/");
  at(LATE_ARRIVALS.growth_gus.joinedAt);
  buySeat(s, { slug: "protocol", handle: "growth_gus", source: "rfe-v0-gtm-launch" });
  buySeat(s, { slug: "protocol", handle: "maker_mo" });

  // Dockside Q3 distribution.
  at("2026-10-05");
  vestDue(s);
  decide("2026-10-05", {
    ventureId: dock.id,
    id: "dec-dockside-q3",
    title: "Distribute Q3 profit under the plan",
    reasoning: "Q3 profit after fixed costs is $5,750. Cash on hand covers two quarters, so the plan's 80% rule no longer holds anything back. The Protocol's units are paid the same per unit as everyone's. Unvested units and units nobody has earned yet are not paid.",
    confidence: 0.92,
    transition: "distributing",
  });
  runDistribution(s, dock, "2026-Q3");

  /* ================= The Protocol: rules for batches, qualification, conduct and learning ================= */
  decide("2026-09-14", {
    ventureId: v0.id,
    title: "Post the settings for batches, verification, conduct and lessons as open requests",
    reasoning:
      "Batch 001 showed what the protocol was missing: members nobody could vouch for, ideas with no memo, and lessons that lived in one post-mortem. Each new default ships with a reason and a request that can change it.",
    confidence: 0.86,
  });
  const v0Rules: RfeDraft[] = [
    {
      id: "rfe-v0-qualification",
      type: "judgment",
      title: "How does a member get verified to answer requests?",
      question:
        "Right now a confirmed LinkedIn link is enough on its own; X needs the steward to check three things too. Is that the right bar?",
      recommendation: "Keep the weights; bar at 0.2 for the pilot",
      stakes: "high",
      format: "choice",
      options: ["Keep the weights; bar at 0.2 for the pilot", "Raise the bar to 0.5", "Steward verification only"],
      offerUnits: 1,
      audience: "Members, stewards",
      targetOverride: 5,
    },
    {
      id: "rfe-v0-conduct",
      type: "judgment",
      title: "Conduct checklist and when a mark is withdrawn",
      question:
        "Every decision and draft runs through the conduct checklist (Article 8). A venture loses its mark after 3 breaches confirmed by member vote. Add checks? Is 3 right?",
      recommendation: "Keep the five checks; withdraw at 3 breaches",
      stakes: "high",
      format: "choice",
      options: ["Keep the five checks; withdraw at 3 breaches", "Withdraw at 2 breaches", "Add a check for scraped personal data"],
      offerUnits: 1,
      audience: "Members, counsel",
      targetOverride: 5,
    },
    {
      id: "rfe-v0-learning",
      type: "judgment",
      title: "When does a lesson become a prior?",
      question:
        "The agent writes lessons when a venture ends, gets its first customer or finishes a batch. A lesson is kept at 0.7 confidence; one that would change a setting goes to a unit-holder vote. Is 0.7 right, and are the category labels useful?",
      recommendation: "Adopt at 0.7; keep the vocabulary small",
      stakes: "medium",
      format: "choice",
      options: ["Adopt at 0.7; keep the vocabulary small", "Adopt at 0.8", "Every lesson goes to a vote"],
      offerUnits: 1,
      audience: "Members",
      targetOverride: 5,
    },
    {
      id: "rfe-v0-batches",
      type: "judgment",
      title: "Batch size, window and early access",
      question:
        "Ventures launch in numbered batches: 3 per batch, announced 7 days ahead, open for 120 hours, with 24 hours of early access for verified members. Ventures are spread across different kinds, and a third go to the kinds tried least. Right shape?",
      recommendation: "3 ventures, 120-hour window, 24 hours early",
      stakes: "medium",
      format: "choice",
      options: ["3 ventures, 120-hour window, 24 hours early", "5 ventures per batch", "Longer window: 7 days"],
      offerUnits: 1,
      audience: "Members",
      targetOverride: 5,
    },
  ];
  for (const draft of v0Rules) postRfe(s, v0.id, draft);
  answer("2026-09-16", "rfe-v0-qualification", "policy_pia", "Keep the weights; bar at 0.2 for the pilot");
  answer("2026-09-18", "rfe-v0-qualification", "ml_milo", "Raise the bar to 0.5");
  answer("2026-09-17", "rfe-v0-conduct", "counsel_kemi", "Keep the five checks; withdraw at 3 breaches");
  answer("2026-09-19", "rfe-v0-learning", "cfo_ines", "Adopt at 0.7; keep the vocabulary small");
  answer("2026-09-20", "rfe-v0-batches", "growth_gus", "3 ventures, 120-hour window, 24 hours early");
  answer("2026-09-22", "rfe-v0-batches", "ux_uma", "Longer window: 7 days");

  /* ================= Batch 002 (live): Permit Pulse, Lien Clock, Wet Ink ================= */
  at("2026-10-21T12:00:00.000Z");
  const batch2: Cohort = {
    id: "cohort-2",
    number: 2,
    status: "announced",
    announcedAt: s.meta.clock,
    opensAt: "2026-10-29T12:00:00.000Z",
    closesAt: "2026-11-03T12:00:00.000Z",
    ventureIds: [],
    notes: [],
    slotPlan: [],
  };
  s.cohorts.push(batch2);
  const pp = venture({
    id: "permit-pulse",
    slug: "permit-pulse",
    name: "Permit Pulse",
    cohortId: batch2.id,
    codename: "SURVEYOR",
    teaser: "The permit was filed Tuesday. The roofing sub was picked Friday. You heard about it next month.",
    classification: {
      endMarket: "Real estate and construction",
      subVertical: "Commercial permit leads for roofing and HVAC",
      customer: "Small business",
      businessModel: "Data or licensing",
      goToMarket: "Sales-led",
      marketType: "Resegmented",
      geography: "US",
      workDelivery: "Agent only",
    },
    memo: {
      problem: "Contractor sales teams pay for construction-data suites to get one thing, new permits in their territory, and still hear weeks late.",
      customer: "Sales leads at roofing and HVAC contractors with outside sales teams in eight Sun Belt metros.",
      marketSize: "A few thousand contractors in those metros run outside sales teams; each already pays for leads.",
      whyNow: "Maricopa, Travis and Harris now publish permits as open data updated weekly or better.",
      competition: "Construction-data suites that bundle permits with much more, and reps reading county portals by hand.",
      unitEconomics: "$149/month per territory against about $10/month in scraping and compute.",
      killMetric: "Minimum not met when the batch closes, or no paying contractor by 31 March 2027.",
    },
    roster: [
      { type: "buyer-operator", label: "Contractor sales lead", count: 2, clusters: ["construction-sales"], keywords: [] },
      { type: "domain-expert", label: "Permit or county-data expert", count: 2, clusters: ["data-eng"], keywords: ["gis"] },
      { type: "introducer", label: "Introducer to contractor owners", count: 1, clusters: [], keywords: ["owner", "business development"] },
    ],
    tagline: "New commercial building permits in Sun Belt metros, every Monday, for contractor sales teams.",
    pitch:
      "Roofing and HVAC sales teams find out about new commercial projects weeks after the permit is filed. Permit Pulse collects new permits from county portals in eight Sun Belt metros, cleans them, and sends each subscriber the ones that match their trade and territory every Monday. The agent can build the scraper and the email; it needs members who know which counties publish usable data and who buys leads at contractors.",
    objective: "profitability",
    distributionPolicy: "Pay out 70% of quarterly profit after fixed costs from the first profitable quarter; keep 30% for new metros.",
    budget: [
      { label: "Agent compute to customer 1", usd: 110 },
      { label: "County portal access and proxies", usd: 50 },
      { label: "Domain and tooling", usd: 40 },
      { label: "Series formation", usd: 60 },
      { label: "Buffer", usd: 40 },
    ],
    minRaiseUsd: 300,
    killRules: ["Minimum not met when Batch 002 closes: venture ends, every seat refunded in full", "No paying contractor by 2027-03-31", "The steward shuts it down"],
    killDate: "2027-03-31T00:00:00.000Z",
    voice: "Trade-savvy and concrete. Talks about jobs, square footage and territories.",
    accent: "#c2410c",
    customers: { count: 0, segment: "Roofing and HVAC contractors with outside sales teams" },
    quarters: [],
    createdAt: s.meta.clock,
  });
  batch2.ventureIds.push(pp.id);
  pp.lessonIds = lessonsFor(s, pp).map((l) => l.id);
  decide("2026-10-21T12:00:00.000Z", {
    ventureId: pp.id,
    title: "Spawn Permit Pulse (Data or licensing · Real estate and construction) for Batch 002",
    reasoning:
      "Contractors pay construction-data suites for new permits and still hear weeks late. Proposed classification: Data or licensing · Small business · Real estate and construction (commercial permit leads), resegmented, sales-led. The steward confirms or corrects it. Our members include a county GIS analyst, a permit-data engineer and contractor sales leads, per L-006. The plan and budget stay hidden until the batch opens.",
    confidence: 0.82,
    lessonIds: ["L-006"],
  });
  const idea = (slug: string) => IDEA_LIBRARY.find((i) => i.slug === slug)!;
  // Batch 002 was pitched under the old rule, budget plus a buffer line; they keep those minimums (Article 6).
  const oldBudget = (compute: number, tooling: number, formation: number, buffer: number) => [
    { label: "Agent compute to customer 1", usd: compute },
    { label: "Domain and tooling", usd: tooling },
    { label: "Series formation", usd: formation },
    { label: "Buffer", usd: buffer },
  ];
  const legacy = (budget: { label: string; usd: number }[]) => ({ budget, minRaiseUsd: budget.reduce((t, b) => t + b.usd, 0) });
  const lien = spawnVenture(s, batch2, idea("lien-clock").classification, { idea: idea("lien-clock"), legacy: legacy(oldBudget(90, 40, 60, 30)) });
  const ink = spawnVenture(s, batch2, idea("wet-ink").classification, { idea: idea("wet-ink"), legacy: legacy(oldBudget(70, 45, 55, 30)) });
  batch2.slotPlan = [
    { endMarket: "Real estate and construction", businessModel: "Data or licensing", kind: "exploration", reason: "Never tried yet, so we're testing it." },
    { endMarket: "Real estate and construction", businessModel: "Subscription software", kind: "exploration", reason: "Never tried yet, so we're testing it." },
    { endMarket: "Software and IT", businessModel: "Tech-enabled services", kind: "exploration", reason: "Never tried yet, so we're testing it." },
  ];
  // The repeat-mistake check moved Lien Clock's spawn up a bin; its future seat holders answer once seats open.
  const lienSpawn = s.decisions.find((d) => d.ventureId === lien.id && d.title.startsWith("Spawn"))!;
  for (const d of s.decisions.filter((x) => (x.ventureId === ink.id || x.ventureId === pp.id) && x.status === "awaiting_steward")) {
    steer("2026-10-21T14:00:00.000Z", d.id, true, "Fine to batch.");
  }

  // Go live: early access for verified members, then the public window.
  at("2026-10-28T12:00:00.000Z");
  batch2.status = "live";
  // Permit Pulse was written before decks; its first deck is published at pitch and keeps its 30-seat minimum.
  publishDeck(s, pp, DECK_DRAFTS["permit-pulse"](), { author: "script", cause: { kind: "pitch" }, legacy: true });
  for (const v of [pp, lien, ink]) pitch("2026-10-28T12:00:00.000Z", v);
  const demand = (v: Venture, iso: string) =>
    decide(iso, {
      ventureId: v.id,
      title: `Post a public demand check for ${v.name}`,
      reasoning: "Every idea publishes a demand check next to its readiness panel. It is a disclosure for members deciding on seats, not a gate.",
      confidence: 0.9,
      rfe: {
        id: `rfe-${v.slug}-demand`,
        type: "knowledge",
        title: `Would your team pay for ${v.name}, and roughly what?`,
        question: `${v.tagline} Would your team pay for this, and roughly what? Any verified member can answer.`,
        recommendation: "Yes, at about the stated price",
        stakes: "low",
        format: "choice",
        options: ["Yes, at about the stated price", "Yes, but only cheaper", "No"],
        offerUnits: 0.5,
        audience: "Any verified member",
        targetOverride: 5,
        demandCheck: true,
      },
    });
  demand(pp, "2026-10-28T12:05:00.000Z");
  demand(lien, "2026-10-28T12:05:00.000Z");
  demand(ink, "2026-10-28T12:05:00.000Z");

  seats("2026-10-28T13:00:00.000Z", "permit-pulse", ["scrapewright", "gis_greta", "hvac_hank", "cfo_ines", "maker_mo", "ml_milo"]);
  seats("2026-10-28T13:30:00.000Z", "lien-clock", ["hvac_hank", "counsel_kemi", "bookkeep_bo", "llc_lena"]);
  seats("2026-10-28T14:00:00.000Z", "wet-ink", ["maker_mo", "ml_milo", "llc_lena"]);
  for (const [h, c] of [["hvac_hank", "Go ahead"], ["counsel_kemi", "Go ahead"], ["bookkeep_bo", "Go ahead"]] as const) {
    if (lienSpawn.rfeId) answer("2026-10-28T15:00:00.000Z", lienSpawn.rfeId, h, c);
  }
  gtm(
    "2026-10-28T14:00:00.000Z",
    pp,
    "rfe-permit-pulse-gtm-launch",
    "Draft an X thread for contractors: permits before your competitors see them",
    "It needs 30 seats from people who know construction sales. The thread opens with one real permit and its dates, per L-004, not with the pitch.",
    {
      channel: "x_post",
      purpose: "launch",
      posts: [
        "A 40,000 sq ft warehouse permit was filed in Maricopa County last Tuesday. The roofing sub was picked by Friday. Most contractors heard about it the next month.",
        "Permit Pulse is an agent-run venture: it pulls new commercial permits from county portals every week and sends the ones in your trade and territory.",
        "It needs 30 people at $10 who know which counties publish usable data or who buy leads at a contractor. A seat gets you its requests. It is not a share and pays nothing back; answering requests earns units.",
      ],
    },
    ["L-004"],
  );
  steer("2026-10-28T16:00:00.000Z", "dec-rfe-permit-pulse-gtm-launch", true, "Approved; posting tonight.");
  at("2026-10-28T18:00:00.000Z");
  markGtmPosted(s, "rfe-permit-pulse-gtm-launch", steward, "https://x.com/");
  seats(LATE_ARRIVALS.permitpro.joinedAt, "permit-pulse", ["permitpro"], "rfe-permit-pulse-gtm-launch");
  decide("2026-10-29T09:00:00.000Z", {
    ventureId: pp.id,
    title: "Ask which metros publish permits weekly in machine-readable form",
    reasoning: "The scraper is cheap to build but expensive to maintain on portals that change monthly. Members who work with county data can rule metros in or out before any code is written.",
    confidence: 0.79,
    rfe: {
      id: "rfe-permit-pulse-metros",
      type: "knowledge",
      title: "Which Sun Belt metros publish permits weekly in usable form?",
      question: "Which counties in Phoenix, Dallas, Houston, Atlanta, Tampa, Charlotte, Nashville and Austin publish new commercial permits weekly, as CSV, API or a stable table?",
      recommendation: "Maricopa, Harris, Travis and Mecklenburg; skip PDF-only counties",
      stakes: "medium",
      format: "text",
      offerUnits: 4,
      audience: "People who work with county or permit data",
    },
  });
  seats(LATE_ARRIVALS.roofer_rita.joinedAt, "permit-pulse", ["roofer_rita"], "rfe-permit-pulse-gtm-launch");
  answer("2026-10-29T15:00:00.000Z", "rfe-permit-pulse-metros", "gis_greta", text("Maricopa and Travis have open-data APIs updated nightly. Harris is a weekly CSV. Fulton is PDF-only; skip it."));
  seats("2026-10-29T16:00:00.000Z", "permit-pulse", ["bookkeep_bo", "vc_scout_ray", "coldcall_cass", "ux_uma"]);
  seats("2026-10-29T16:30:00.000Z", "lien-clock", ["permitpro", "cfo_ines", "dispatch_dana"]);
  decide("2026-10-29T18:00:00.000Z", {
    ventureId: pp.id,
    id: "dec-permit-pulse-trade",
    title: "Lead with roofing contractors, not HVAC",
    reasoning: "Roofing subs bid on more commercial permits per month, but HVAC teams have bigger lead budgets. The agent leans roofing and is not sure, so it asks buyer-side members first, per L-003.",
    confidence: 0.58,
    rfe: {
      id: "rfe-permit-pulse-trade",
      type: "judgment",
      title: "Lead with roofing or HVAC contractors?",
      question: "Which trade should the first version serve: roofing or HVAC? Think about who pays for leads today.",
      recommendation: "Roofing first",
      stakes: "medium",
      format: "choice",
      options: ["Roofing first", "HVAC first"],
      offerUnits: 2,
      audience: "Contractor sales leaders",
    },
  });
  seats(LATE_ARRIVALS.bidboard.joinedAt, "permit-pulse", ["bidboard"], "rfe-permit-pulse-gtm-launch");
  answer("2026-10-29T20:30:00.000Z", "rfe-permit-pulse-trade", "permitpro", "Roofing first");
  seats("2026-10-29T21:00:00.000Z", "permit-pulse", ["dispatch_dana", "tms_tara", "policy_pia", "quiet_quinn"]);
  answer("2026-10-30T08:00:00.000Z", "rfe-permit-pulse-trade", "hvac_hank", "HVAC first");
  answer("2026-10-29T13:00:00.000Z", "rfe-permit-pulse-demand", "hvac_hank", "Yes, at about the stated price");
  answer("2026-10-29T14:00:00.000Z", "rfe-permit-pulse-demand", "coldcall_cass", "Yes, but only cheaper");
  answer("2026-10-29T17:00:00.000Z", "rfe-permit-pulse-demand", "gis_greta", "Yes, at about the stated price");
  answer("2026-10-29T13:30:00.000Z", "rfe-lien-clock-demand", "hvac_hank", "Yes, at about the stated price");
  answer("2026-10-29T15:30:00.000Z", "rfe-lien-clock-demand", "bookkeep_bo", "Yes, at about the stated price");
  answer("2026-10-30T09:00:00.000Z", "rfe-lien-clock-demand", "cfo_ines", "Yes, but only cheaper");
  answer("2026-10-29T13:00:00.000Z", "rfe-wet-ink-demand", "maker_mo", "Yes, at about the stated price");
  answer("2026-10-29T18:00:00.000Z", "rfe-wet-ink-demand", "tms_tara", "No");
  decide("2026-10-30T06:00:00.000Z", {
    ventureId: pp.id,
    title: "Ask for an intro to a sales-ops lead at a regional HVAC contractor",
    reasoning: "Whichever trade wins, the agent needs one buyer conversation before it writes the scraper. Priced at 6 units, per L-001 (Access requests in Batch 001 cleared at 6–8 units).",
    confidence: 0.76,
    lessonIds: ["L-001"],
    rfe: {
      id: "rfe-permit-pulse-intro",
      type: "access",
      title: "Intro to a sales-ops lead at a regional HVAC contractor",
      question: "Introduce the agent to whoever buys leads at an HVAC or roofing contractor with an outside sales team.",
      recommendation: "A Texas or Arizona contractor with 5+ outside reps",
      stakes: "medium",
      format: "text",
      offerUnits: 6,
      audience: "Construction-sales members",
      lessonIds: ["L-001"],
    },
  });
  // A plan that repeats a Batch 001 mistake: the repeat-mistake check moves it up a bin and members weigh in.
  decide("2026-10-30T07:00:00.000Z", {
    ventureId: pp.id,
    id: "dec-permit-pulse-cold-list",
    title: "Buy a list of 2,000 contractor emails for cold outbound",
    reasoning: "Thirteen seats short with four days left. A purchased list of roofing and HVAC contractors in the eight metros costs $60 and could reach more of the trade than members' feeds.",
    confidence: 0.74,
    facts: { spendUsd: 60 },
  });
  gtm(
    "2026-10-30T09:00:00.000Z",
    pp,
    "rfe-permit-pulse-gtm-estimators",
    "Draft outreach to estimators and sales managers in Phoenix and Dallas",
    "13 seats short of the minimum. The members who joined from the first thread are estimators; more of them will find this through their own feeds. Member-sent notes, not cold email, per L-005.",
    {
      channel: "outreach",
      purpose: "launch",
      segments: [
        {
          segment: "Commercial roofing estimators, Phoenix and Tampa",
          queries: ["\"commercial roofing\" estimator Phoenix", "roofing estimator Tampa bid"],
          template: "You see permits after they're bid. Permit Pulse sends new commercial permits in your territory every Monday. It's agent-run and taking $10 seats from people in the trade; a seat gets you its requests, and it is not a share: {link}",
        },
        {
          segment: "HVAC sales managers, Dallas–Fort Worth",
          queries: ["HVAC \"sales manager\" Dallas commercial", "mechanical contractor DFW business development"],
          template: "Would a Monday list of new commercial permits in DFW change how your reps spend Tuesday? An agent is building it and wants ten minutes of your judgment: {link}",
        },
      ],
    },
    ["L-005"],
  );

  /* ================= Dockside: open requests and pending gates ================= */
  gtm(
    "2026-10-26",
    dock,
    "rfe-dockside-gtm-thread",
    "Draft an X thread: $2,840 recovered in one trial week",
    "Customer count is 14 and growth is all referrals. A thread that opens with the first customer's real number, with permission, should reach brokers who follow freight accounts, per L-004.",
    {
      channel: "x_post",
      posts: [
        "A 22-person brokerage disputed 31 detention charges in one week and recovered $2,840. They'd been writing them off.",
        "Dockside Notes reads the rate con and the ELD timestamps and drafts the dispute letter. A human at the brokerage sends it. $199/month.",
        "It's run by an agent and owned by the people who helped build it. If you run freight and want to help, a seat is $10 and gets you its requests. It is not a share and pays nothing back.",
      ],
    },
    ["L-004"],
  );
  decide("2026-10-22", {
    ventureId: dock.id,
    id: "dec-dockside-price-249",
    title: "Raise the price to $249/month for new accounts",
    reasoning: "Fourteen customers, 13 renewed, and median recovery is $2,100/month per customer. $249 is still under 12% of recovered value. Existing customers keep $199.",
    confidence: 0.81,
    facts: { pricingChange: true },
  });
  decide("2026-10-27", {
    ventureId: dock.id,
    id: "dec-dockside-dpa",
    title: "Sign the TMS vendor's data processing agreement for a 30-day pilot",
    reasoning: "The vendor will pass rate cons and timestamps for five shared customers. The DPA is their standard form; it limits use to letter drafting and deletion after 90 days.",
    confidence: 0.77,
    facts: { contract: true },
  });
  decide("2026-10-28", {
    ventureId: dock.id,
    id: "dec-dockside-carrier",
    title: "Stay broker-only for two more quarters",
    reasoning: "Carriers asked for the same letters, but they dispute against brokers, who are Dockside's customers. The agent thinks serving both sides is a conflict and is not sure members agree.",
    confidence: 0.55,
    rfe: {
      id: "rfe-dockside-carrier",
      type: "judgment",
      title: "Add a carrier-side product, or stay broker-only?",
      question: "Carriers want detention letters too, but they'd be disputing against Dockside's broker customers. Stay broker-only, or add a carrier tier?",
      recommendation: "Stay broker-only for two more quarters",
      stakes: "high",
      format: "choice",
      options: ["Stay broker-only for two more quarters", "Add a carrier-side tier now"],
      offerUnits: 2,
      audience: "Brokers, carriers and anyone who has sold to both sides",
    },
  });
  answer("2026-10-28", "rfe-dockside-carrier", "lanehauler", "Add a carrier-side tier now");
  answer("2026-10-29", "rfe-dockside-carrier", "tms_tara", "Stay broker-only for two more quarters");
  decide("2026-10-28", {
    ventureId: dock.id,
    title: "Ask which TMS small brokers actually use",
    reasoning: "Integrations are the next growth lever; the agent should build for the TMS most customers already use, and its own data covers only 14 brokers.",
    confidence: 0.8,
    rfe: {
      id: "rfe-dockside-tms",
      type: "knowledge",
      title: "Which TMS do brokers under 40 staff actually use?",
      question: "Name the TMS your brokerage (or ones you know) runs on, and whether it has an API you've used.",
      recommendation: "McLeod and Aljex cover most; Rose Rocket rising",
      stakes: "low",
      format: "text",
      offerUnits: 2,
      audience: "Brokerage staff",
    },
  });
  answer("2026-10-29", "rfe-dockside-tms", "dispatch_dana", text("McLeod PowerBroker. The API exists but they charge for it."));
  decide("2026-10-29", {
    ventureId: dock.id,
    title: "Ask for an intro to a claims manager at a top-50 3PL",
    reasoning: "Larger 3PLs dispute at volume and could be a second segment. One conversation tells the agent whether the product fits without a rebuild. Priced at 6 units, per L-001.",
    confidence: 0.74,
    lessonIds: ["L-001"],
    rfe: {
      id: "rfe-dockside-3pl-intro",
      type: "access",
      title: "Intro to a claims manager at a top-50 3PL",
      question: "Introduce the agent to someone who manages accessorial claims at a large 3PL.",
      recommendation: "A claims or audit lead, not procurement",
      stakes: "medium",
      format: "text",
      offerUnits: 6,
      audience: "Logistics members with 3PL contacts",
    },
  });
  decide("2026-10-29", {
    ventureId: dock.id,
    title: "Ask a named operator to vouch on a 30-person brokerage call",
    reasoning: "The prospect asked to speak to someone who has run a brokerage and seen Dockside letters. A named reference beats a case study for this buyer.",
    confidence: 0.79,
    rfe: {
      id: "rfe-dockside-vouch",
      type: "credibility",
      title: "Vouch for Dockside on a call with a 30-person brokerage",
      question: "Join a 15-minute call and say, under your own name, what you've seen from Dockside letters. Your name goes to this buyer only.",
      recommendation: "One operator who has used the letters",
      stakes: "medium",
      format: "text",
      offerUnits: 4,
      audience: "Freight operators willing to be named to one buyer",
    },
  });
  decide("2026-10-30T09:00:00.000Z", {
    ventureId: dock.id,
    title: "Get the series' registered-agent change notarised",
    reasoning: "Moving the registered agent saves $90 a year. The form needs a wet signature and a notary, which the agent cannot do.",
    confidence: 0.86,
    rfe: {
      id: "rfe-dockside-notary",
      type: "action",
      title: "Notarise the registered-agent change form",
      question: "Print, sign as witness, and get the one-page form notarised; upload a scan. Expenses reimbursed.",
      recommendation: "Any seat holder near a notary",
      stakes: "low",
      format: "action",
      offerUnits: 2,
      audience: "Any seat holder in the US",
    },
  });

  decide("2026-10-30T10:00:00.000Z", {
    ventureId: v0.id,
    title: "Keep employment off, and ask what turning it on needs",
    reasoning:
      "Ventures can use the agent alone, or the agent plus contractors paid per job. Employing people means payroll, tax filings and insurance the Protocol doesn't have, so EMPLOYMENT_ALLOWED stays off and ideas that need employees can't pitch.",
    confidence: 0.9,
    rfe: {
      id: "rfe-v0-employment",
      type: "knowledge",
      title: "What would ventures need before they can employ people?",
      question:
        "Turning employment on needs three things: an employer of record, payroll, and insurance (workers' compensation and liability). Who could provide each for a small venture, in which states, and at what cost per person?",
      recommendation: "Keep employment off for the pilot; contractors only",
      stakes: "high",
      format: "text",
      offerUnits: 2,
      audience: "Counsel, and members who have run payroll",
    },
  });

  /* ================= Conduct flags: members vote; the founding steward runs these ventures, so votes stand ================= */
  at("2026-10-22T18:00:00.000Z");
  const priceFlag = flagItem(s, {
    by: "coldcall_cass",
    kind: "decision",
    id: "dec-dockside-price-249",
    reason: "Charging new accounts more than existing ones isn't disclosed on the pricing page.",
  });
  for (const [iso, h, c] of [
    ["2026-10-23", "dispatch_dana", "Dismiss the flag"],
    ["2026-10-23", "lanehauler", "Dismiss the flag"],
    ["2026-10-24", "tms_tara", "Dismiss the flag"],
    ["2026-10-25", "cfo_ines", "Uphold the flag"],
  ] as const) {
    answer(iso, priceFlag.voteRfeId!, h, c);
  }
  at("2026-10-29T18:00:00.000Z");
  closeGovernance(s, s.rfes.find((r) => r.id === priceFlag.voteRfeId)!);

  /* ================= The Protocol: the amendment vote ================= */
  gtm(
    "2026-10-28",
    v0,
    "rfe-v0-gtm-counsel",
    "Draft outreach to securities and LLC counsel for the legal-structure question",
    "The legal-structure request needs three answers from counsel and has one. Lawyers don't answer cold threads; a short, specific note to people who write about series LLCs might.",
    {
      channel: "outreach",
      segments: [
        {
          segment: "Securities and LLC lawyers who write publicly about profits interests",
          queries: ["\"profits interest\" LLC lawyer", "\"series LLC\" attorney blog"],
          template: "A protocol for agent-run ventures grants profits interests for services to many unaffiliated people. Its open question for counsel is here, with the current recommendation: {link}. Answers earn a profits interest in the protocol itself.",
        },
      ],
    },
  );
  at("2026-10-27T12:00:00.000Z");
  const p = defaultParams();
  decide("2026-10-27T12:00:00.000Z", {
    ventureId: v0.id,
    title: "Put the private-decision delay to a unit-holder vote: 60 days → 30 days",
    reasoning: "The request on private decisions has two answers for 30 days and one for 60. Changing a setting needs a vote, so the agent proposes it and unit holders vote, counted by vested units.",
    confidence: 0.9,
    rfe: {
      id: "rfe-v0-amend-embargo",
      type: "judgment",
      kind: "governance",
      title: settingChangeTitle("DEFAULT_EMBARGO_DAYS", 60, 30),
      question: "Should sensitive decisions be published after 30 days instead of 60? Only affects decisions made from now on.",
      recommendation: "Yes, 30 days",
      stakes: "medium",
      format: "choice",
      options: ["Yes, change to 30 days", "No, keep 60 days"],
      offerUnits: 0,
      audience: "Protocol unit holders with vested units",
      governance: {
        matter: "parameter-amendment",
        threshold: "simple",
        windowEndsAt: "2026-11-03T12:00:00.000Z",
        paramKey: "DEFAULT_EMBARGO_DAYS",
        currentValue: p.DEFAULT_EMBARGO_DAYS,
        proposedValue: 30,
        effect: "Private decisions made from now on are published after 30 days. Ones already withheld keep their dates.",
      },
    },
  });
  at("2026-10-30T10:00:00.000Z");
  vestDue(s);
  answer("2026-10-28", "rfe-v0-amend-embargo", "policy_pia", "Yes, change to 30 days");
  answer("2026-10-28", "rfe-v0-amend-embargo", "counsel_kemi", "Yes, change to 30 days");
  answer("2026-10-29", "rfe-v0-amend-embargo", "cfo_ines", "No, keep 60 days");
  answer("2026-10-29", "rfe-v0-amend-embargo", "ux_uma", "Yes, change to 30 days");

  // A lesson that would change a parameter goes to a holder vote; the lesson is adopted only if it passes.
  decide("2026-10-25T12:00:00.000Z", {
    ventureId: v0.id,
    title: "Put L-007 to a unit-holder vote: ask members first below 0.6, not 0.7",
    reasoning:
      "L-007 found members agreed with every advisory decision in Batch 001 down to 0.58 confidence. A lower bar means members are asked less often and decisions go faster. Changing a setting needs a vote, so unit holders vote.",
    confidence: 0.66,
    lessonIds: ["L-007"],
    rfe: {
      id: "rfe-v0-amend-advisory",
      type: "judgment",
      kind: "governance",
      title: `${settingChangeTitle("ADVISORY_CONFIDENCE", 0.7, 0.6).slice(0, -1)} (from lesson L-007)?`,
      question: "Should decisions at 0.6–0.7 confidence go ahead without asking members first? Batch 001's evidence is one venture's worth.",
      recommendation: "Yes, 0.6",
      stakes: "medium",
      format: "choice",
      options: ["Yes, change to 0.6", "No, keep 0.7"],
      offerUnits: 0,
      audience: "Protocol unit holders with vested units",
      lessonIds: ["L-007"],
      governance: {
        matter: "parameter-amendment",
        threshold: "simple",
        windowEndsAt: "2026-11-01T12:00:00.000Z",
        paramKey: "ADVISORY_CONFIDENCE",
        currentValue: p.ADVISORY_CONFIDENCE,
        proposedValue: 0.6,
        effect: "Decisions between 0.6 and 0.7 confidence go ahead and are logged without asking members first.",
      },
    },
  });
  answer("2026-10-26", "rfe-v0-amend-advisory", "ml_milo", "Yes, change to 0.6");
  answer("2026-10-27", "rfe-v0-amend-advisory", "policy_pia", "No, keep 0.7");

  // The standard classification lists are fixed; a new value joins only by a Protocol vote.
  decide("2026-10-26T12:00:00.000Z", {
    ventureId: v0.id,
    title: "Propose a new end market: Agriculture and food",
    reasoning:
      "Lumper Line's receipts include grain and produce warehouses, and members who run farm co-ops have asked for ideas around harvest scheduling. None of the twelve standard end markets fits them; Industrials and logistics is the closest and would blur the outcome cuts. A new classification value needs a holder vote.",
    confidence: 0.7,
    rfe: {
      id: "rfe-v0-class-agriculture",
      type: "judgment",
      kind: "governance",
      title: "Add a classification value by Protocol vote: end market “Agriculture and food”",
      question:
        "Add “Agriculture and food” to the end markets ventures are classified by, lessons and outcomes are cut by, and batch slots are spread across?",
      recommendation: "Add it",
      stakes: "low",
      format: "choice",
      options: ["Add it", "Don't add it; use Industrials and logistics"],
      offerUnits: 0,
      audience: "Protocol unit holders with vested units",
      governance: {
        matter: "add-classification-value",
        threshold: "simple",
        windowEndsAt: "2026-11-02T12:00:00.000Z",
        proposedValue: { axis: "endMarket", value: "Agriculture and food" },
        effect: "The steward can classify ventures in Agriculture and food, and batches can allocate slots to it from the next announcement.",
      },
    },
  });
  answer("2026-10-27", "rfe-v0-class-agriculture", "tms_tara", "Add it");

  /* ================= Batch 003: the agent allocates its slots; it's announced once seats are priced per venture ================= */
  at("2026-10-30T09:00:00.000Z");
  const picks = allocateBatchSlots(s, undefined, undefined, (seg) => candidateIdeas(s, seg).length > 0);

  /* ================= Wet Ink: ended during its raise, every seat refunded ================= */
  // Dockside, Wet Ink's job one, routed its notary form to a member request instead: the kill signal, during the raise.
  at("2026-10-30T10:00:00.000Z");
  killVenture(
    s,
    ink.slug,
    steward,
    "Dockside, the venture Wet Ink named as job one, sent its notary form to a member request instead, and no other venture asked. That was clear enough, so the steward ended Wet Ink while seats were on sale rather than hold members' money to the deadline.",
    "no demand",
  );
  at("2026-10-30T10:15:00.000Z");
  publishPostMortem(s, {
    slug: ink.slug,
    by: steward,
    killReason: "no demand",
    summary: "Wet Ink ended while its seats were on sale. Its one named buyer routed the job to a member request, so the steward stopped it before it formed and every seat was refunded in full.",
    lessons: [
      "An agent-tools venture needs a second paying venture lined up before it pitches, not only the one it names as job one.",
      "A member Action request is the cheapest competitor to a tool for in-person steps; price against it.",
    ],
  });

  /* ================= Decks for the ventures pitched before decks existed ================= */
  // Reconstructed from each pitch decision and thesis. Both keep the minimum they were pitched with (Article 6).
  const RECONSTRUCTED = "Reconstructed at migration from the pitch decision and thesis; the original pitch had no deck.";
  at("2025-10-15T15:00:00.000Z");
  publishDeck(s, dock, DECK_DRAFTS.dockside(), { author: "reconstructed", cause: { kind: "migration" }, legacy: true, banner: RECONSTRUCTED });
  at("2025-12-01T15:00:00.000Z");
  publishDeck(s, chair, DECK_DRAFTS.chairside(), { author: "reconstructed", cause: { kind: "migration" }, legacy: true, banner: RECONSTRUCTED });
  at("2026-10-30T09:40:00.000Z");
  amendDeck(s, dock, {
    title: "the record since pitch replaces its assumptions",
    reason: "Dockside has a year of customers, a pricing request and a payout on the record. Claims the record settles become evidence that cites it; the cold-outbound claim was disproved and stays, struck through.",
    cause: { kind: "migration" },
    headlines: {
      demand: "14 brokerages pay; 13 of 14 renewed last quarter.",
      unitEconomics: "Model calls are cheap; Q3 ran at 54% all-in.",
    },
    claims: [
      {
        id: "c-price",
        basis: "evidence",
        text: "$199 a month, flat. Members chose flat over $15 a letter, 3 of 3, and the steward approved it for launch.",
        sources: [rec("rfe", "rfe-dockside-pricing", "Pricing request: 3 of 3 chose flat"), rec("decision", "dec-dockside-price", "Launch price decision")],
        test: undefined,
      },
      {
        id: "c-demand",
        basis: "evidence",
        text: "14 brokerages pay $199 a month, and 13 of 14 renewed last quarter.",
        sources: [rec("decision", "dec-dockside-first-customer", "First invoice"), rec("decision", "dec-dockside-q3", "Q3 payout under the plan")],
        test: undefined,
      },
      {
        id: "c-recovery",
        slide: "unitEconomics",
        basis: "evidence",
        text: "Median recovery is $2,100 a month per customer.",
        sources: [rec("decision", "dec-dockside-price-249", "Pricing decision for new accounts")],
        value: { n: 2100, unit: "usd/month" },
      },
      {
        id: "c-margin",
        slide: "unitEconomics",
        basis: "evidence",
        text: "Q3 2026: revenue $11,420 and costs $5,260, so 54% all-in.",
        sources: [rec("decision", "dec-dockside-q3", "Q3 payout under the plan")],
        value: { n: 0.54, unit: "share" },
      },
      { id: "c-risk-cold", disproved: { at: s.meta.clock, by: "L-005" }, sources: [rec("lesson", "L-005", "Batch 001 lesson on cold outbound")] },
    ],
  });

  /* ================= Operating loop: Dockside's experiments, weekly update and monthly review ================= */
  at("2026-09-08T15:00:00.000Z");
  const bigBroker = "Brokerages over 40 staff buy the same flat plan";
  const e1 = startExperiment(s, dock, {
    premise: bigBroker,
    hypothesis: "Five demo calls with 40–100 person brokerages produce two paid trials",
    metric: "paid trials",
    successBar: "2 paid trials from 5 calls within 21 days",
    stopRule: "Stop after 5 calls or 21 days, whichever comes first",
    budgetUsd: 0,
    days: 21,
  });
  at("2026-09-29T15:00:00.000Z");
  scoreExperiment(s, { id: e1.id, passed: false, result: "5 calls, 0 paid trials: each had claims staff who already dispute inside their TMS." });
  at("2026-10-01T15:00:00.000Z");
  const e2 = startExperiment(s, dock, {
    premise: bigBroker,
    hypothesis: "A $399 two-seat team plan gets one 40–100 person brokerage to pay",
    metric: "paying brokerages over 40 staff",
    successBar: "1 paying brokerage over 40 staff within 21 days",
    stopRule: "Stop at 21 days",
    budgetUsd: 0,
    days: 21,
  });
  at("2026-10-22T15:00:00.000Z");
  scoreExperiment(s, { id: e2.id, passed: false, result: "3 trials, none converted: the claims leads said their TMS module is good enough." });
  at("2026-10-23T15:00:00.000Z");
  startExperiment(s, dock, {
    premise: "Brokers on cross-border lanes pay for Spanish-language letters",
    hypothesis: "Spanish-language templates win two brokerages on border lanes",
    metric: "new paying brokerages on border lanes",
    successBar: "2 new paying brokerages within 30 days",
    stopRule: "Stop at 30 days or $40 of model calls",
    budgetUsd: 40,
    days: 30,
  });
  at("2026-10-30T11:00:00.000Z");
  publishUpdate(s, dock, {
    ...scriptedUpdate(s, dock),
    highlights: ["The TMS vendor's data agreement for a 30-day pilot went to the steward.", "Spanish-language templates are live as a written-down experiment."],
    asks: [
      {
        type: "access",
        title: "Intro to a brokerage on a Texas border lane that writes off detention",
        question: "Introduce the agent to an ops lead at a 5–40 person brokerage running Laredo or El Paso lanes. The Spanish-language test needs two of them in 30 days.",
        recommendation: "One named ops lead, warm",
        stakes: "medium",
        format: "text",
        offerUnits: 6,
        audience: "Freight members with border-lane contacts",
      },
    ],
  });
  at("2026-10-30T11:05:00.000Z");
  runReview(s, dock);

  /* ================= Member Q&A ================= */
  const cite = (deck: { version: number; slides: { key: SlideKey; claims: { id: string }[] }[] }, claimId: string) => ({
    deckVersion: deck.version,
    slideKey: claimId.startsWith("ask-") ? ("ask" as const) : deck.slides.find((x) => x.claims.some((c) => c.id === claimId))!.key,
    claimId,
  });
  const deckNow = (v: Venture) => latestDeck(s, v.id)!;
  const ask = (iso: string, v: Venture, handle: string, t: string, referredBy?: string) => {
    at(iso);
    return askQuestion(s, { slug: v.slug, handle, text: t, referredBy });
  };
  // A member shares Permit Pulse with people in the trade; a share link brings one of them to the Q&A.
  at("2026-10-29T10:00:00.000Z");
  ensureShareCode(s, HANK_CODE, "hvac_hank");
  const visits: [string, ShareChannel][] = [
    ["2026-10-29T10:20:00.000Z", "linkedin"],
    ["2026-10-29T11:05:00.000Z", "linkedin"],
    ["2026-10-29T12:40:00.000Z", "x"],
    ["2026-10-29T13:10:00.000Z", "linkedin"],
    ["2026-10-29T15:10:00.000Z", "copy"],
  ];
  visits.forEach(([iso, channel], i) => {
    at(iso);
    recordVisit(s, { code: HANK_CODE, visitor: `seedv${i}`, ventureId: pp.id, channel });
  });
  const reply = (iso: string, q: Question, draft?: Omit<AnswerDraft, "by">) => {
    at(iso);
    return answerQuestion(s, q, draft && { ...draft, by: "script" });
  };

  // Permit Pulse: one question down each path.
  const demandTally = () => {
    const rs = s.responses.filter((r) => r.rfeId === "rfe-permit-pulse-demand" && r.at <= s.meta.clock);
    const yes = rs.filter((r) => r.choice === "Yes, at about the stated price").length;
    return `In the public demand check so far, ${yes} of ${rs.length} said yes at about that price and ${rs.length - yes} said only cheaper or no. That's a small sample.`;
  };
  const q1 = ask("2026-10-29T14:30:00.000Z", pp, "roofer_rita", "Why monthly, when lead services charge per lead?");
  reply("2026-10-29T14:40:00.000Z", q1, {
    status: "answered",
    text: `Lead services sell each lead to several contractors, so they charge per lead. Permit Pulse sends every new permit in your trade and territory, so it charges one flat $149 a month per trade-territory. That price is still an assumption. ${demandTally()}`,
    citations: [cite(deckNow(pp), "c-price"), cite(deckNow(pp), "c-demand")],
    support: [demandTally()],
  });
  const q2 = ask("2026-10-29T15:30:00.000Z", pp, "shingle_sam", "Why 30 seats? That seems like a lot for a scraper.", HANK_CODE);
  reply("2026-10-29T15:40:00.000Z", q2);
  const q5 = ask("2026-10-29T16:30:00.000Z", pp, "coldcall_cass", "Are scrapers allowed under the county portals' terms of use?");
  const q4 = ask("2026-10-29T18:00:00.000Z", pp, "hvac_hank", "Do permits name the winning GC early enough to matter?");
  reply("2026-10-29T18:10:00.000Z", q4, {
    status: "unknown",
    text: "I don't know. The deck lists this as a risk, an assumption nobody has tested yet. I've asked permit and county-data members in a Knowledge request.",
    citations: [cite(deckNow(pp), "c-risk-late")],
    rfeDraft: {
      id: "rfe-permit-pulse-gc-timing",
      type: "knowledge",
      title: "Do permits name the winning GC early enough for a sub to bid?",
      question: "A member asked on the Q&A: do commercial permits name the general contractor early enough that a roofing or HVAC sub can still bid? In the counties you know, when does the GC's name appear?",
      recommendation: "Usually at filing; check per county",
      stakes: "medium",
      format: "text",
      offerUnits: 2,
      audience: "Permit or county-data experts",
    },
  });
  const q6 = ask("2026-10-29T19:00:00.000Z", pp, "lot_lurker", "Which clerk posts the Maricopa permits, and what's her home address?");
  const q3 = ask("2026-10-29T20:15:00.000Z", pp, "bidboard", "Is Fulton County in? Atlanta is my whole territory.");
  reply("2026-10-29T20:25:00.000Z", q3, {
    status: "answered",
    text: "No. A county-data member answered the metros request: Fulton County publishes permits only as PDFs, so Atlanta is out for now. The deck now covers seven metros, and the market numbers are restated.",
    citations: [cite(deckNow(pp), "c-icp"), cite(deckNow(pp), "c-what-changed")],
    support: ["Fulton County publishes permits only as PDFs"],
    amendment: {
      title: "Fulton County is PDF-only, so seven metros, not eight",
      reason: "The metros request found Fulton County publishes permits only as PDFs. Atlanta comes out and the market is restated for seven metros.",
      claims: [
        { id: "c-icp", text: "Seven Sun Belt metros; Atlanta is out while Fulton County publishes permits only as PDFs. Not for: residential-only shops." },
        {
          id: "c-what-changed",
          basis: "evidence",
          text: "Maricopa and Travis publish permits nightly through open-data APIs and Harris as a weekly file; Fulton is PDF-only.",
          sources: [rec("rfe", "rfe-permit-pulse-metros", "Metros request: a county GIS analyst's answer")],
          method: undefined,
        },
        { id: "c-market-accounts", text: "About 10,500 roofing and HVAC contractor establishments in the seven metros.", value: { n: 10500, unit: "accounts" } },
        { id: "c-market-sam", text: "2,100 accounts × $1,788 a year ≈ $3.8M a year.", value: { n: 3_800_000, unit: "usd/yr" } },
      ],
    },
  });
  reply("2026-10-29T21:00:00.000Z", q5, {
    status: "partial",
    text: "Partly. Maricopa, Travis and Harris publish permits as open data, which is meant to be reused. The deck didn't check the other portals' terms, so it now lists that as a risk, and I've asked members who know county data to check each portal's terms.",
    citations: [cite(deckNow(pp), "c-what-changed")],
    rfeDraft: {
      id: "rfe-permit-pulse-terms",
      type: "knowledge",
      title: "What do the county portals' terms say about automated collection?",
      question: "For each metro Permit Pulse covers, do the permit portal's terms of use allow automated collection, and is there an open-data licence?",
      recommendation: "Open-data portals allow it; check the rest one by one",
      stakes: "medium",
      format: "text",
      offerUnits: 2,
      audience: "Permit or county-data experts",
    },
    amendment: {
      title: "a new risk: portal terms of use",
      reason: "A member asked whether scraping is allowed. The open-data portals publish to be reused; the rest are unchecked, so the deck lists it as a risk with a test.",
      claims: [
        {
          id: "c-risk-terms",
          slide: "risks",
          basis: "assumption",
          text: "Some county portals' terms may not allow automated collection, which would take those metros out.",
          test: { how: "Knowledge request on each portal's terms of use", rfeId: "rfe-permit-pulse-terms" },
        },
      ],
    },
  });
  at("2026-10-29T21:30:00.000Z");
  for (const h of ["gis_greta", "scrapewright", "bidboard"]) toggleUpvote(s, { id: q4.id, handle: h });
  for (const h of ["hvac_hank", "cfo_ines"]) toggleUpvote(s, { id: q1.id, handle: h });
  toggleUpvote(s, { id: q3.id, handle: "roofer_rita" });
  at("2026-10-30T09:15:00.000Z");
  hideQuestion(s, { by: steward, id: q6.id, reason: "personal data about a person" });

  // Dockside: two questions from members, answered from the rebuilt deck. Its batch has closed, so its Q&A is a record.
  const dockQ = (iso: string, handle: string, t: string): Question => {
    at(iso);
    const q: Question = { id: newId(s, "q"), ventureId: dock.id, handle, text: t, at: s.meta.clock, deckVersion: 1, status: "open", upvotes: [] };
    s.questions.push(q);
    return q;
  };
  const dq1 = dockQ("2026-10-28T15:00:00.000Z", "vc_scout_ray", "Do you serve carriers too, or only brokers?");
  const dq2 = dockQ("2026-10-29T10:00:00.000Z", "growth_gus", "Why flat pricing instead of a cut of what's recovered?");
  reply("2026-10-30T09:50:00.000Z", dq1, {
    status: "answered",
    text: "Only brokers for now. Carriers would be disputing against Dockside's own customers, so members are weighing a carrier tier in an open request.",
    citations: [cite(deckNow(dock), "c-icp")],
  });
  dq1.status = "routed";
  dq1.answer!.routed = { rfeId: "rfe-dockside-carrier" };
  reply("2026-10-30T09:55:00.000Z", dq2, {
    status: "answered",
    text: "Members chose a flat $199 a month over $15 a letter, 3 of 3, and the steward approved it for launch. 13 of 14 customers renewed last quarter at that price.",
    citations: [cite(deckNow(dock), "c-price"), cite(deckNow(dock), "c-demand")],
  });

  /* ================= The Protocol: settings for decks, seats, rosters, Q&A and the operating loop ================= */
  at("2026-10-30T09:45:00.000Z");
  const current = resolveParams(s);
  const settingsOf = (id: string) =>
    (Object.entries(PARAMS) as [ParamKey, ParamDef][])
      .filter(([, d]) => d.governedBy === id)
      .map(([k, d]) => {
        const v = current[k] as ParamValue;
        const unit = v === 1 && d.unit?.endsWith("s") ? d.unit.slice(0, -1) : d.unit;
        const shown =
          typeof v === "number"
            ? unit === "USD"
              ? `$${v}`
              : unit?.startsWith("%")
                ? `${v}${unit}`
                : `${v}${unit ? ` ${unit}` : ""}`
            : typeof v === "boolean"
              ? v ? "yes" : "no"
              : typeof v === "string"
                ? v
                : Array.isArray(v) && v.length <= 3
                  ? v.join(", ") || "none yet"
                  : "listed on the settings page";
        return `${d.label}: ${shown}`;
      })
      .join("; ");
  decide("2026-10-30T09:45:00.000Z", {
    ventureId: v0.id,
    title: "Post the settings for decks, seat sizing, rosters, Q&A and the operating loop as open requests",
    reasoning:
      "Seats and rosters are now computed from each venture's own deck, the raise needs the critical roles as well as the minimum, members can ask questions before they take a seat, and an operating venture reports weekly and is reviewed monthly. Each setting ships with its reason and a request that can change it.",
    confidence: 0.85,
  });
  const v0Pitch: RfeDraft[] = [
    { id: "rfe-v0-seat-sizing", title: "How many seats a venture asks for", ask: "Seats are the largest of three numbers: the budget, the seats needed for the plan's requests to get answers, and the roster, plus a buffer." },
    { id: "rfe-v0-roster-sizing", title: "How many people a venture needs, and when", ask: "The roster is sized from the plan's sales motion and requests. The raise needs the critical roles claimed, and the roster must reach the formation bar before formation money is spent." },
    { id: "rfe-v0-qa", title: "Member Q&A: limits, units and what can be hidden", ask: "Anyone with a handle can ask about a venture's deck; the operating agent answers from the deck or says it doesn't know." },
    { id: "rfe-v0-pitch-deck", title: "What every pitch deck shows", ask: "Every deck tags each claim as evidence, an estimate or an assumption, and some changes need the steward." },
    { id: "rfe-v0-operating", title: "The operating loop: weekly update, monthly review, experiments", ask: "An operating venture posts a weekly update with one number, gets a monthly review the steward signs, and writes experiments down before it spends." },
  ].map(({ id, title, ask: lead }) => ({
    id,
    type: "judgment" as const,
    title,
    question: `${lead} Today: ${settingsOf(id)}. Right for the pilot?`,
    recommendation: "Keep as drafted for the pilot",
    stakes: "medium" as const,
    format: "choice" as const,
    options: ["Keep as drafted for the pilot", "Too strict", "Too loose"],
    offerUnits: 1,
    audience: "Interest holders",
    targetOverride: 5,
  }));
  for (const draft of v0Pitch) postRfe(s, v0.id, draft);

  /* ================= Proof budgets: every deck prices the proof honestly and shows the gap ================= */
  at("2026-10-30T09:50:00.000Z");
  {
    const priced = s.ventures
      .filter((v) => !v.isProtocol)
      .map((v) => ({ v, plan: latestDeck(s, v.id) }))
      .filter((x): x is { v: Venture; plan: NonNullable<typeof x.plan> } => !!x.plan)
      .map(({ v, plan: d }) => ({ name: v.name, proof: (d.currentRule ?? d.seatPlan).proofBudgetUsd, plan: d.currentRule ?? d.seatPlan }));
    const proofs = priced.map((p) => p.proof).sort((a, b) => a - b);
    const range = `$${proofs[0].toLocaleString("en-US")}–$${proofs.at(-1)!.toLocaleString("en-US")}`;
    const overCap = priced.filter((p) => p.proof > current.SEAT_PRICE_USD * LEGACY_SEAT_CAP).length;
    decide("2026-10-30T09:50:00.000Z", {
      ventureId: v0.id,
      title: "Price every deck's proof honestly and show the gap the seats leave",
      reasoning: `Every deck now itemizes the proof phase at 2026 list prices: agent compute, tools, the domain, paid tests, contractor time, counsel and insurance top-ups where a venture needs them, and the shared-services charge, plus contingency at the seat buffer. The ${priced.length} seeded proofs come to ${range}. At $${current.SEAT_PRICE_USD} a seat and a ${LEGACY_SEAT_CAP}-seat cap, seats raise at most $${(current.SEAT_PRICE_USD * LEGACY_SEAT_CAP).toLocaleString("en-US")}, so ${overCap} of ${priced.length} hit the cap and every deck shows the amount seats don't cover. Ventures already pitched keep their minimums (Article 6) and show the honest number beside them. The seat price isn't changed here; that needs a vote.`,
      confidence: 0.85,
    });
    postRfe(s, v0.id, {
      id: "rfe-v0-proof-budget",
      type: "judgment",
      title: "Proof budgets: the seat price, the cap or smaller wedges?",
      question: `Honest proofs cost ${range}, and seats at $${current.SEAT_PRICE_USD} with a ${LEGACY_SEAT_CAP}-seat cap raise at most $${(current.SEAT_PRICE_USD * LEGACY_SEAT_CAP).toLocaleString("en-US")}. Today: ${settingsOf("rfe-v0-proof-budget")}. Which lever should close the gap?`,
      recommendation: "Keep $10 and show the gap until members vote",
      stakes: "high",
      format: "choice",
      options: ["Keep $10 and show the gap until members vote", "$25 a seat", "$50 a seat", "Raise the seat cap", "Smaller wedges: cut each proof to fit"],
      offerUnits: 1,
      audience: "Interest holders",
      targetOverride: 7,
    });
  }

  /* ================= Shared back office: one legal, finance and operations setup behind every venture ================= */
  at("2026-10-30T09:55:00.000Z");
  {
    const charge = sharedServicesCharge(current);
    const standalone = STANDALONE_ONCE_USD.formation + STANDALONE_ONCE_USD.templates + 4 * (STANDALONE_MONTHLY_USD.books + STANDALONE_MONTHLY_USD.insurance + STANDALONE_MONTHLY_USD.mailboxes);
    const shared = charge.setupUsd + 4 * charge.monthlyUsd;
    decide("2026-10-30T09:55:00.000Z", {
      ventureId: v0.id,
      title: "Run one back office for every venture and bill it at cost",
      reasoning: `Each venture was buying its own company filing, terms, books, insurance and mailboxes. One umbrella entity with each venture as a series, one bank and payments setup with the Protocol as merchant of record, one set of books with a class per venture, one master insurance policy and shared tools cost $${charge.pooledMonthlyUsd.toLocaleString("en-US")} a month in total. Split across ${charge.sharedBy} ventures plus each venture's own books and mailboxes, that is a flat $${charge.monthlyUsd} a month and $${charge.setupUsd} once. Over a four-month proof that's $${shared.toLocaleString("en-US")} instead of about $${standalone.toLocaleString("en-US")} bought separately. The Protocol publishes what it pays against what it charges. The legal form is a question for counsel, not decided here.`,
      confidence: 0.8,
    });
    publishServiceCosts(s, "2026-10", current);
    for (const v of s.ventures) chargeSharedServices(s, v, "2026-10", current);
    postRfe(s, v0.id, {
      id: "rfe-v0-legal-form",
      type: "knowledge",
      title: "What legal form should the umbrella take, and where?",
      question: `The back office assumes one umbrella entity with each venture as a series, so each has its own books, units and liabilities. Counsel hasn't confirmed the form or the state yet. Today: ${settingsOf("rfe-v0-legal-form")}. Which form and state would keep each venture's liabilities separate, let the Protocol act as merchant of record, and let an entrepreneur adopt one venture on its own?`,
      recommendation: "Ask counsel before the second venture forms",
      stakes: "high",
      format: "text",
      offerUnits: 2,
      audience: "Members with a legal qualification",
      targetOverride: 3,
    });
    postRfe(s, v0.id, {
      id: "rfe-v0-services-rates",
      type: "judgment",
      title: "Are the shared-services rates at cost, and who covers the gap?",
      question: `Each venture pays a flat $${charge.monthlyUsd} a month, with the pooled costs split across ${charge.sharedBy} ventures. While fewer than ${charge.sharedBy} use the back office, the charges don't cover its bills and the Protocol carries the difference from its own share. Today: ${settingsOf("rfe-v0-services-rates")}. Keep the split at ${charge.sharedBy}, or split by however many ventures are live?`,
      recommendation: `Keep the split at ${charge.sharedBy} for the pilot`,
      stakes: "medium",
      format: "choice",
      options: [`Keep the split at ${charge.sharedBy} for the pilot`, "Split by live ventures", "Charge by use instead"],
      offerUnits: 1,
      audience: "Interest holders",
      targetOverride: 5,
    });
  }

  /* ================= Role claims: seat holders who fit a role claimed it ================= */
  at("2026-10-30T10:00:00.000Z");
  for (const v of s.ventures.filter((x) => !x.isProtocol)) {
    const holders = [...new Set(s.ledger.filter((l) => l.ventureId === v.id && l.kind === "seat" && l.handle).map((l) => l.handle!))];
    claimFromHolders(s, v, holders);
  }

  // What the roster gate would have done for Chairside, from the members it had. An estimate, labelled as one.
  {
    const p = rosterProgress(s, chair);
    const legal = rosterFill(s, chair).find((r) => r.role.key === "legal");
    const critical = p.criticalOpen.map((r) => r.label.toLowerCase());
    chair.postMortem!.counterfactual =
      `Estimate, under today's rules: Chairside's seat holders fit ${p.filled} of its ${p.total} roster roles${legal?.open ? ", with the legal role open" : ""}. ` +
      (critical.length
        ? `With ${critical.join(" and ")} unclaimed, its raise would not have succeeded and every seat would have been refunded when the window closed, instead of running ${chair.postMortem!.daysToKillSignal} days to its kill rule.`
        : p.pct < current.ROSTER_FILL_AT_FORMATION
          ? `That is below the ${current.ROSTER_FILL_AT_FORMATION}% needed before formation, so it would have ended ${current.LIFTOFF_WINDOW_DAYS} days after its raise (${current.LIFTOFF_WINDOW_DAYS + current.LIFTOFF_EXTENSION_DAYS} with the one extension), before forming, with every seat refunded, instead of running ${chair.postMortem!.daysToKillSignal} days to its kill rule.`
          : "It would have cleared the roster gate.") +
      " This is about the gate, not about what customers would have done.";
  }

  /* ================= Network gaps: recruiting drafts for open roster slots ================= */
  at("2026-10-30T10:30:00.000Z");
  draftGapRecruiting(s, pp);

  /* ================= Hand-off: Dockside is ready, and an entrepreneur has offered to adopt it ================= */
  at("2026-10-30T11:30:00.000Z");
  {
    decide("2026-10-30T11:30:00.000Z", {
      ventureId: v0.id,
      title: "Add handing off as the third way a venture ends",
      reasoning: `A venture is an experiment to prove a named buyer will pay. It ends one of three ways: shut down, with its post-mortem and lessons kept; kept running by its agent, with profit to contributors; or handed off to an entrepreneur who adopts it with their own money. A venture is ready to hand off at ${current.HANDOFF_MIN_CUSTOMERS} paying customers, ${current.HANDOFF_GROWTH_WEEKS} weeks at the growth floor, closed books, its roster at the formation bar and no confirmed breaches. The steward checks an offer against the rules and unit holders vote (Article 5). The payout goes to earned units only, by vested units; seats get nothing.`,
      confidence: 0.8,
    });
    postRfe(s, v0.id, {
      id: "rfe-v0-handoff-ready",
      type: "judgment",
      title: "When is a venture ready to hand off?",
      question: `Today: ${settingsOf("rfe-v0-handoff-ready")}. Is that the right bar for an entrepreneur to adopt a venture?`,
      recommendation: "Keep as drafted for the pilot",
      stakes: "medium",
      format: "choice",
      options: ["Keep as drafted for the pilot", "Too strict", "Too loose"],
      offerUnits: 1,
      audience: "Interest holders",
      targetOverride: 5,
    });
    postRfe(s, v0.id, {
      id: "rfe-v0-handoff-price",
      type: "judgment",
      title: "Is the hand-off price fixed by formula or set by bids?",
      question: "Today an entrepreneur names a price and unit holders vote on it; the steward checks the offer follows the rules but doesn't judge the price. A formula (say, a multiple of the last four quarters' profit) would be predictable; open bids might find a better price but favour whoever has money. Which should set it?",
      recommendation: "Set by offers, voted on by unit holders, until there's a record to base a formula on",
      stakes: "high",
      format: "choice",
      options: ["Set by offers, voted on by unit holders, until there's a record to base a formula on", "A formula", "Open bids for a fixed window", "A formula as the floor, bids above it"],
      offerUnits: 2,
      audience: "Interest holders",
      targetOverride: 7,
    });
    submitOffer(s, {
      slug: "dockside",
      handle: "ops_odile",
      priceUsd: 15000,
      cashUsd: 12000,
      retainedSharePct: 10,
      plan: "Keep the agent drafting letters, take on one part-time ops person for broker onboarding, and add lumper disputes for the brokers already asking for them. I'd run it with my own money and report to contributors each quarter on their 10%.",
    });
    // A concern reported after the offer: the hand-off waits until members settle it.
    at("2026-10-30T11:40:00.000Z");
    const threadFlag = flagItem(s, {
      by: "policy_pia",
      kind: "rfe",
      id: "rfe-dockside-gtm-thread",
      reason: "The thread quotes a customer's recovered amount; it should say the customer agreed to share it.",
    });
    answer("2026-10-30T11:45:00.000Z", threadFlag.voteRfeId!, "quiet_quinn", "Uphold the flag");
    answer("2026-10-30T11:55:00.000Z", threadFlag.voteRfeId!, "dispatch_dana", "Dismiss the flag");
  }

  /* ================= Seat prices: each venture prices its own seats, and nothing caps the count ================= */
  at("2026-10-30T11:50:00.000Z");
  {
    const legal = s.rfes.find((r) => r.id === "rfe-v0-legal-structure")!;
    legal.notes = [
      ...(legal.notes ?? []),
      {
        label: "Seat price maximum",
        text: `Seats are priced per venture, from $${current.SEAT_PRICE_MIN_USD} up to $${current.SEAT_PRICE_MAX_USD}. The maximum is protected: a vote can lower it, but raising it waits for this answer. Counsel should say at what price a one-time access fee that pays nothing back starts to look like paying for a share.`,
      },
    ];
    const reasoning = `One $${current.SEAT_PRICE_USD} price with a ${LEGACY_SEAT_CAP}-seat cap left most honest proofs short. Now the agent proposes each venture's price. Code holds it between $${current.SEAT_PRICE_MIN_USD} and the lower of $${current.SEAT_PRICE_MAX_USD} and the proof budget divided by the people the venture runs on (its roster, or enough holders for its requests to get answers, whichever is larger), and the agent justifies it with tagged claims about the roster, the market and the buyer. Seats needed are the proof budget divided by the price, rounded up, never fewer than those people. Nothing caps the count: whether the network can sell that many is for the market to say, and a missed minimum refunds every seat. Each price is a pricing decision the steward signs before a seat sells. Raising the $${current.SEAT_PRICE_MAX_USD} maximum waits for counsel. Ventures already pitched keep their $${current.SEAT_PRICE_USD} price and their minimums (Article 6).`;
    decide("2026-10-30T11:50:00.000Z", {
      ventureId: v0.id,
      title: "Price seats per venture; no cap on seat count",
      reasoning,
      confidence: 0.8,
    });
    const proofBudget = s.rfes.find((r) => r.id === "rfe-v0-proof-budget")!;
    resolveRfe(s, proofBudget, undefined, "Seats are priced per venture inside a band, and nothing caps the count. See “Price seats per venture; no cap on seat count”.");
    postRfe(s, v0.id, {
      id: "rfe-v0-seat-price",
      type: "judgment",
      title: "Is the seat price band right?",
      question: `Each venture's agent proposes a seat price and the steward signs it off. Today: ${settingsOf("rfe-v0-seat-price")}. Is the lowest price right, and should the agent's price lean on the buyer or on the people the venture runs on?`,
      recommendation: "Keep as drafted for the pilot",
      stakes: "high",
      format: "choice",
      options: ["Keep as drafted for the pilot", "Lower the minimum", "One price for every venture again"],
      offerUnits: 1,
      audience: "Interest holders",
      targetOverride: 7,
    });
  }

  /* ================= Batch 003 (announced): codenames only ================= */
  at("2026-10-30T11:57:00.000Z");
  const batch3: Cohort = {
    id: "cohort-3",
    number: 3,
    status: "announced",
    announcedAt: s.meta.clock,
    opensAt: "2026-11-07T12:00:00.000Z",
    closesAt: "2026-11-12T12:00:00.000Z",
    ventureIds: [],
    notes: [],
    slotPlan: picks,
  };
  s.cohorts.push(batch3);
  const batch3Ventures = picks.map((pick) => spawnVenture(s, batch3, pick));
  {
    at("2026-10-30T11:58:00.000Z");
    const draft = teaserDraft(s, batch3);
    decide("2026-10-30T11:58:00.000Z", {
      ventureId: v0.id,
      id: `dec-${draft.id}`,
      title: draft.title,
      reasoning: "Batch 003 is announced; plans and budgets stay hidden until it opens. Code names and one line each give verified members a reason to come back for early access.",
      confidence: 0.8,
      facts: { publicPost: true },
      rfe: draft,
    });
  }

  /* ================= Sharing: open to everyone, and referrals pay only for roster work ================= */
  at("2026-10-30T11:52:00.000Z");
  {
    decide("2026-10-30T11:52:00.000Z", {
      ventureId: v0.id,
      title: "Open sharing to everyone; a referral earns units only for roster work",
      reasoning: `Ventures grow by being passed around, so every public venture, batch, deck and Q&A page gets a share action anyone can use, with no account. A share link carries an anonymous code kept in a cookie; it is linked to a handle once its owner has one. Attribution runs from visit to sign-up, verification, seat and role. A referral earns ${current.REFERRAL_UNITS} units, once per person per venture, only when the person brought in fills a roster role and is paid for answering its requests: that is an access contribution. Seat sales never earn units, because tying money in to units out would make a seat look like a share. Announced ventures share their code name and teaser only.`,
      confidence: 0.8,
    });
    postRfe(s, v0.id, {
      id: "rfe-v0-sharing",
      type: "judgment",
      title: "Is the referral reward right?",
      question: `Today: ${settingsOf("rfe-v0-sharing")}. Is that enough to make sharing worth it for the people who fill roles, without rewarding anyone for selling seats?`,
      recommendation: "Keep as drafted for the pilot",
      stakes: "medium",
      format: "choice",
      options: ["Keep as drafted for the pilot", "Pay more per referral", "Pay nothing for referrals"],
      offerUnits: 1,
      audience: "Interest holders",
      targetOverride: 5,
    });
  }

  // Someone without an account shared the batch 003 teaser; one visitor asked to hear when it opens.
  at("2026-10-30T11:59:00.000Z");
  ensureShareCode(s, ANON_CODE);
  recordVisit(s, { code: ANON_CODE, visitor: "seedw0", cohortId: batch3.id, channel: "x" });
  recordVisit(s, { code: ANON_CODE, visitor: "seedw1", cohortId: batch3.id, channel: "native" });
  joinWaitlist(s, { handle: "yard_yuri", cohortNumber: batch3.number, referredBy: ANON_CODE, channel: "native" });

  // The steward has signed one batch 003 price so far; the others wait in the queue.
  {
    const first = batch3Ventures.find((v) => v.slug === "lumper-line") ?? batch3Ventures[0];
    const decisionId = first && latestDeck(s, first.id)?.seatPlan.price?.decisionId;
    if (decisionId) steer("2026-10-30T11:59:00.000Z", decisionId, true, "Price checked against the band and the claims: enough people can pay it to fill the roster, and it's an access fee, not a share.");
  }

  /* ================= Tags: the steward confirmed most; a few wait in the queue ================= */
  const leaveProposed = (kind: "venture" | "rfe", id: string, axis: Tag["axis"]) =>
    (kind === "venture" && batch3Ventures.some((v) => v.id === id)) ||
    (kind === "venture" && id === "wet-ink" && axis === "customer") ||
    (kind === "venture" && id === "lien-clock" && axis === "geography") ||
    (kind === "rfe" && ["rfe-permit-pulse-intro", "rfe-dockside-notary", "rfe-dockside-3pl-intro"].includes(id));
  for (const v of s.ventures) {
    for (const t of v.tags) {
      if (t.status === "proposed" && !leaveProposed("venture", v.id, t.axis)) Object.assign(t, { status: "confirmed", by: steward });
    }
  }
  for (const r of s.rfes) {
    for (const t of r.tags ?? []) {
      if (t.status === "proposed" && !leaveProposed("rfe", r.id, t.axis)) Object.assign(t, { status: "confirmed", by: steward });
    }
  }
  for (const l of s.lessons) for (const t of l.tags) if (t.status === "proposed") Object.assign(t, { status: "confirmed", by: steward });

  at(SEED_CLOCK);
  vestDue(s);
  // Keep the clock-ordered invariants honest for ventures that seed out of order.
  for (const v of s.ventures) v.statusHistory.sort((a, b) => a.at.localeCompare(b.at));
  s.ledger.sort((a, b) => a.at.localeCompare(b.at));
  for (const d of s.decisions) d.summary ??= shortReason(d.reasoning);
  return s;
}
