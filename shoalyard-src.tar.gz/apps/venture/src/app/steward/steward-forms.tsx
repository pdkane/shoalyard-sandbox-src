"use client";

import { Bot, Check, RotateCcw, Skull, X } from "lucide-react";
import { toast } from "sonner";
import {
  advanceAgentAction,
  killAction,
  markPostedAction,
  resetDemoAction,
  stewardDecisionAction,
} from "@/app/actions";
import { KillReasonSelect, useToastAction } from "@/components/protocol-forms";
import { FormMessage, SubmitButton } from "@/components/submit-button";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";



export function AdvanceAgent({ ventures }: { ventures: { slug: string; name: string }[] }) {
  const [state, action] = useToastAction(advanceAgentAction);
  return (
    <div className="space-y-4">
      <form action={action} className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <div className="space-y-1.5">
          <Label htmlFor="venture">Venture</Label>
          <select id="venture" name="venture" className="h-9 w-full rounded-lg border border-zinc-200 bg-white px-2 text-sm sm:w-52">
            <option value="">All ventures</option>
            {ventures.map((v) => (
              <option key={v.slug} value={v.slug}>
                {v.name}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="ticks">Steps</Label>
          <select id="ticks" name="ticks" defaultValue="1" className="h-9 w-full rounded-lg border border-zinc-200 bg-white px-2 text-sm sm:w-28">
            <option value="1">1 step</option>
            <option value="3">3 steps</option>
            <option value="5">5 steps</option>
          </select>
        </div>
        <SubmitButton size="lg" className="h-9" pendingText="Agent working…">
          <Bot /> Run forward
        </SubmitButton>
      </form>
      {state.error && <FormMessage state={state} />}
      {state.lines && (
        <pre className="max-h-72 overflow-auto rounded-lg bg-zinc-950 p-3 font-mono text-xs leading-relaxed text-zinc-100">
          {state.lines.length ? state.lines.join("\n") : "Nothing happened this step."}
        </pre>
      )}
    </div>
  );
}

export function DecisionForm({ decisionId, publicPost }: { decisionId: string; publicPost: boolean }) {
  const [state, action] = useToastAction(stewardDecisionAction);
  return (
    <form action={action} className="space-y-2">
      <input type="hidden" name="decisionId" value={decisionId} />
      <Textarea name="note" rows={2} placeholder={publicPost ? "Note (optional). Approving doesn't post anything; you post by hand." : "Note for the log (optional)"} />
      <div className="flex flex-wrap items-center gap-2">
        <SubmitButton name="approve" value="yes" size="sm">
          <Check /> Approve
        </SubmitButton>
        <SubmitButton name="approve" value="no" size="sm" variant="outline">
          <X /> Reject
        </SubmitButton>
        <FormMessage state={state} />
      </div>
    </form>
  );
}

export function MarkPostedForm({ rfeId }: { rfeId: string }) {
  const [state, action] = useToastAction(markPostedAction);
  return (
    <form action={action} className="flex flex-col gap-2 sm:flex-row">
      <input type="hidden" name="rfeId" value={rfeId} />
      <Input name="url" type="url" placeholder="Link to the post (optional)" className="h-8" />
      <SubmitButton size="sm" variant="outline">
        Mark as posted
      </SubmitButton>
      <FormMessage state={state} />
    </form>
  );
}

export function KillDialog({ slug, name }: { slug: string; name: string }) {
  const [state, action] = useToastAction(killAction);
  return (
    <Dialog>
      <DialogTrigger render={<Button variant="destructive" size="sm" />}>
        <Skull /> Shut down
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Shut down {name}?</DialogTitle>
          <DialogDescription>
            This is irreversible. Open requests close, pending decisions are rejected, and a post-mortem is drafted for you to publish
            before the batch closes. Units already earned stay on the public record.
          </DialogDescription>
        </DialogHeader>
        <form action={action} className="space-y-3">
          <input type="hidden" name="slug" value={slug} />
          <div className="space-y-1.5">
            <Label htmlFor={`kr-kill-${slug}`}>Why it ended</Label>
            <KillReasonSelect id={`kr-kill-${slug}`} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor={`note-${slug}`}>What happened (published on the log)</Label>
            <Textarea id={`note-${slug}`} name="note" rows={2} required placeholder="Shut-down rule met: …" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor={`confirm-${slug}`}>
              Type <code className="rounded bg-zinc-100 px-1">{slug}</code> to confirm
            </Label>
            <Input id={`confirm-${slug}`} name="confirm" autoComplete="off" required />
          </div>
          <FormMessage state={state} />
          <DialogFooter>
            <DialogClose render={<Button variant="outline" type="button" />}>Cancel</DialogClose>
            <SubmitButton variant="destructive">Shut down venture</SubmitButton>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function ResetDemo() {
  return (
    <form
      action={async () => {
        await resetDemoAction();
        toast.success("Demo data reset to the seed.");
      }}
    >
      <SubmitButton variant="ghost" size="sm" pendingText="Resetting…">
        <RotateCcw /> Reset demo data
      </SubmitButton>
    </form>
  );
}
