import type { Cohort, ShareChannel, Store, Venture, WaitlistEntry } from "@av/schema";
import { latestDeck } from "./deck";
import { ensureMember, notify, ProtocolError, protocolVenture, seatsSold, ventureBySlug } from "./ops";
import { resolveParams } from "./params";
import { newId } from "./util";

/**
 * A waitlist exists only where it is true: a venture whose seats are all taken, or a batch that isn't open yet.
 * Nobody is told a seat is coming; they're told when one opens, when a batch opens, or when selling ends.
 */

const label = (n: number) => `Batch ${String(n).padStart(3, "0")}`;

export function nextAnnouncedBatch(store: Store): Cohort | undefined {
  return [...store.cohorts].filter((c) => c.status === "announced").sort((a, b) => a.number - b.number)[0];
}

export function waitlistFor(store: Store, target: { ventureId?: string; cohortId?: string }): WaitlistEntry[] {
  return store.waitlist.filter((w) => (target.ventureId ? w.ventureId === target.ventureId : w.kind === "batch" && w.cohortId === target.cohortId));
}

export function onWaitlist(store: Store, handle: string, target: { ventureId?: string; cohortId?: string }): WaitlistEntry | undefined {
  return waitlistFor(store, target).find((w) => w.handle === handle && !w.notifiedAt);
}

/** Every seat in the deck's maximum is taken while the venture is still selling. */
export function isFull(store: Store, venture: Venture): boolean {
  const deck = latestDeck(store, venture.id);
  return venture.status === "pitched" && !!deck && seatsSold(store, venture.id) >= deck.seatPlan.max;
}

export function joinWaitlist(
  store: Store,
  input: { handle: string; slug?: string; cohortNumber?: number; referredBy?: string; channel?: ShareChannel },
): WaitlistEntry {
  let entry: Omit<WaitlistEntry, "id" | "at" | "handle">;
  let message: string;
  if (input.slug) {
    const venture = ventureBySlug(store, input.slug);
    if (!venture || venture.isProtocol) throw new ProtocolError("That venture does not exist.");
    if (!isFull(store, venture)) {
      const deck = latestDeck(store, venture.id);
      throw new ProtocolError(
        venture.status === "pitched" && deck
          ? `${venture.name} has ${deck.seatPlan.max - seatsSold(store, venture.id)} of ${deck.seatPlan.max} seats left, so there's no waitlist. Take a seat instead.`
          : `${venture.name} isn't selling seats, so there's no waitlist.`,
      );
    }
    entry = { kind: "venture", ventureId: venture.id };
    message = `you're on the waitlist for ${venture.name}. If a seat frees up before the window closes, the first person waiting hears first. You can still claim a roster role without a seat.`;
  } else {
    const cohort = input.cohortNumber !== undefined ? store.cohorts.find((c) => c.number === input.cohortNumber) : nextAnnouncedBatch(store);
    if (input.cohortNumber !== undefined && !cohort) throw new ProtocolError("That batch does not exist.");
    if (cohort && cohort.status !== "announced") throw new ProtocolError(`${label(cohort.number)} is ${cohort.status === "live" ? "open now" : "closed"}, so there's nothing to wait for.`);
    entry = { kind: "batch", cohortId: cohort?.id };
    message = cohort
      ? `we'll tell you when ${label(cohort.number)} opens. Verified members get in first.`
      : "we'll tell you when the next batch is announced.";
  }
  const member = ensureMember(store, input.handle, "waitlist", input.referredBy, entry.ventureId);
  const existing = store.waitlist.find((w) => w.handle === member.handle && !w.notifiedAt && w.kind === entry.kind && w.ventureId === entry.ventureId && w.cohortId === entry.cohortId);
  if (existing) return existing;
  const w: WaitlistEntry = { id: newId(store, "wl"), at: store.meta.clock, handle: member.handle, ...entry, code: member.referredBy, channel: input.channel };
  store.waitlist.push(w);
  notify(store, entry.ventureId ?? protocolVenture(store).id, member.handle, message);
  return w;
}

function tell(store: Store, w: WaitlistEntry, ventureId: string, notice: string) {
  w.notifiedAt = store.meta.clock;
  w.notice = notice;
  notify(store, ventureId, w.handle, notice);
}

/** A seat came back: the people waiting longest hear first, one per seat. */
export function onSeatsFreed(store: Store, venture: Venture, count: number) {
  if (venture.status !== "pitched" || count <= 0) return;
  const waiting = waitlistFor(store, { ventureId: venture.id }).filter((w) => !w.notifiedAt);
  for (const w of waiting.slice(0, count)) tell(store, w, venture.id, `a seat in ${venture.name} just freed up. It goes to whoever takes it first.`);
}

/** A batch was announced: people waiting for "the next batch" hear its code names, and now wait for it to open. */
export function onBatchAnnounced(store: Store, cohort: Cohort, codenames: string[]) {
  const params = resolveParams(store);
  const early = new Date(Date.parse(cohort.opensAt) - params.EARLY_ACCESS_HOURS * 3600e3).toISOString().slice(0, 16).replace("T", " ");
  for (const w of store.waitlist.filter((x) => x.kind === "batch" && !x.notifiedAt && !x.cohortId)) {
    w.cohortId = cohort.id;
    notify(store, protocolVenture(store).id, w.handle, `${label(cohort.number)} is announced: ${codenames.join(", ")}. Verified members can take seats from ${early} UTC. You'll hear again when it opens.`);
  }
}

/** A batch opened to verified members: everyone waiting for it hears now. */
export function onBatchLive(store: Store, cohort: Cohort) {
  const params = resolveParams(store);
  const opens = cohort.opensAt.slice(0, 16).replace("T", " ");
  for (const w of store.waitlist.filter((x) => x.kind === "batch" && !x.notifiedAt && x.cohortId === cohort.id)) {
    const verified = store.members.find((m) => m.handle === w.handle)?.qualification === "qualified";
    tell(
      store,
      w,
      protocolVenture(store).id,
      verified
        ? `${label(cohort.number)} is open to verified members now, ${params.EARLY_ACCESS_HOURS} hours before everyone else (${opens} UTC).`
        : `${label(cohort.number)}'s plans are public now. Verified members can take seats today; everyone else from ${opens} UTC. Get verified to go first.`,
    );
  }
}

/** A full venture stopped selling: whoever is still waiting is told, so nobody waits for nothing. */
export function settleVentureWaitlists(store: Store) {
  for (const w of store.waitlist.filter((x) => x.kind === "venture" && !x.notifiedAt)) {
    const v = store.ventures.find((x) => x.id === w.ventureId);
    if (!v || v.status === "pitched") continue;
    tell(
      store,
      w,
      v.id,
      v.status === "killed"
        ? `${v.name} ended without opening more seats, and every seat was refunded. Its lessons are public.`
        : `${v.name} has stopped selling seats. You can still claim a roster role if one fits you.`,
    );
  }
}
