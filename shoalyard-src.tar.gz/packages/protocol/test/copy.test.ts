import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join, relative } from "node:path";
import { test } from "node:test";
import { PARAMS } from "@av/schema";
import { RETIRED_WORDS } from "../src/glossary";
import { buildSeed } from "../src/seed";
import { BANNED, OLD_NAME } from "./banned";
import { copyIn, LEGAL_RFE, root, seededCopy, walk } from "./copy-text";

function hits(label: string, text: string): string[] {
  return text.split("\n").flatMap((line, i) => BANNED.filter((re) => re.test(line)).map((re) => `${label}:${i + 1} ${re} → ${line.trim().slice(0, 140)}`));
}

test("app copy, README, constitution, params and agent script avoid the banned words", () => {
  const files = [
    ...walk(join(root, "apps/venture/src")),
    join(root, "README.md"),
    join(root, "packages/protocol/CONSTITUTION.md"),
    join(root, "packages/protocol/src/constitution.ts"),
    join(root, "packages/protocol/src/positioning.ts"),
    join(root, "packages/protocol/src/glossary.ts"),
    join(root, "packages/protocol/agent/script.ts"),
    join(root, "packages/schema/src/params.ts"),
  ];
  const found = files.flatMap((f) => hits(relative(root, f), readFileSync(f, "utf8")));
  assert.deepEqual(found, []);
});

test("seeded text avoids the banned words, except counsel's legal-structure question", () => {
  const s = buildSeed();
  const scrubbed = {
    ...s,
    rfes: s.rfes.filter((r) => r.id !== LEGAL_RFE),
    responses: s.responses.filter((r) => r.rfeId !== LEGAL_RFE),
    decisions: s.decisions.filter((d) => d.rfeId !== LEGAL_RFE),
  };
  assert.deepEqual(hits("seed", JSON.stringify(scrubbed, null, 1)), []);
  assert.ok(s.rfes.some((r) => r.id === LEGAL_RFE), "the legal-structure question is seeded");
});

test('"drop" no longer names a batch in app copy, docs, params, agent text or seed', () => {
  const files = [
    ...walk(join(root, "apps/venture/src")),
    join(root, "README.md"),
    join(root, "packages/protocol/CONSTITUTION.md"),
    ...walk(join(root, "packages/protocol/src")),
    ...walk(join(root, "packages/protocol/agent")),
    join(root, "packages/schema/src/params.ts"),
    join(root, "packages/schema/src/primitives.ts"),
  ];
  const lingering = files.flatMap((f) =>
    readFileSync(f, "utf8")
      .split("\n")
      .flatMap((line, i) => (OLD_NAME.test(line) ? [`${relative(root, f)}:${i + 1} → ${line.trim().slice(0, 140)}`] : [])),
  );
  assert.deepEqual(lingering, []);
  const seed = JSON.stringify(buildSeed());
  assert.equal(OLD_NAME.exec(seed)?.[0], undefined);
  const config = readFileSync(join(root, "apps/venture/next.config.ts"), "utf8");
  assert.match(config, /source: "\/drops\/:n", destination: "\/batches\/:n", permanent: true/);
});

test("every batch page says nobody picks the winners", () => {
  const batch = readFileSync(join(root, "apps/venture/src/components/batch-ui.tsx"), "utf8");
  assert.match(batch, /No one picks the winners\. A venture goes ahead if enough people take seats, and keeps going if a customer pays\./);
  for (const page of ["(index)/page.tsx", "[n]/page.tsx"]) {
    assert.match(readFileSync(join(root, "apps/venture/src/app/batches", page), "utf8"), /<NobodySelects \/>/);
  }
});

test("every live batch venture repeats the seat disclaimer next to the buy button", () => {
  const ui = readFileSync(join(root, "apps/venture/src/components/protocol-ui.tsx"), "utf8");
  assert.match(ui, /A seat gets you this venture's requests\. It is not a share and pays nothing back\./);
  const batch = readFileSync(join(root, "apps/venture/src/components/batch-ui.tsx"), "utf8");
  assert.match(batch, /<SeatDisclaimer \/>/);
});

test("the deck's ask slide renders the seat disclaimer and the refund lines, and no seeded text says drop-off", () => {
  const ui = readFileSync(join(root, "apps/venture/src/components/deck-ui.tsx"), "utf8");
  const ask = ui.slice(ui.indexOf("export function AskBlock"), ui.indexOf("export function DeckNav"));
  assert.match(ask, /<SeatDisclaimer\b/);
  assert.match(ask, /<RefundLines\b/);
  const page = readFileSync(join(root, "apps/venture/src/app/v/[slug]/deck/page.tsx"), "utf8");
  assert.match(page, /ask: \(\s*<AskBlock/);
  assert.doesNotMatch(JSON.stringify(buildSeed()), /drop-off/i);
});

/** The counsel note on /protocol may name the legal term for units. */
const COUNSEL_LINE = /compensatory profits interests in each venture/;

test("retired jargon stays out of app copy, the rules, settings and seeded text", () => {
  const lines = [
    ...walk(join(root, "apps/venture/src"), /\.tsx?$/).flatMap(copyIn),
    ...readFileSync(join(root, "packages/protocol/CONSTITUTION.md"), "utf8")
      .split("\n")
      .map((text, i) => ({ where: `CONSTITUTION.md:${i + 1}`, text })),
    ...Object.entries(PARAMS).flatMap(([key, d]) => [
      { where: `param ${key} label`, text: d.label },
      { where: `param ${key} reason`, text: d.reason },
    ]),
    ...seededCopy(),
  ].filter((l) => !COUNSEL_LINE.test(l.text));
  const found = lines.flatMap((l) =>
    RETIRED_WORDS.filter((r) => r.word.test(l.text)).map((r) => `${l.where} ${r.word} (use "${r.use}") → ${l.text.slice(0, 140)}`),
  );
  assert.deepEqual(found, []);
});
