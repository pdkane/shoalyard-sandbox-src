import type { ParamValues, ProofNeed, ProofPlan, ProofReshape, ProofRunner, ProofTask, RosterRole } from "@av/schema";

/**
 * Constrain the proof, not the idea. Any idea may be pitched; what's checked is whether the Protocol can run
 * its proof today, with the agent, member requests and contractors only. A proof that needs an employee, a
 * licence the Protocol doesn't hold, or someone in person whom nobody covers is sent back, and the agent
 * reshapes it. What's left after the proof is the hand-off: what an entrepreneur would need to build.
 */

/** The Protocol holds no licence while its legal form is an open question for counsel (rfe-v0-legal-structure). */
export const LICENCES_HELD: readonly string[] = [];

export interface OperabilityIssue {
  taskKey: string;
  need: ProofNeed;
  message: string;
}

const EMPLOYEE_WORDS = /\b(hire|hiring|employ(ee|ees|ing|ment)?|on (the )?payroll|full-time staff)\b/i;
const LICENCE_WORDS = /\blicen[cs](e|ed|ing)\b/i;
const IN_PERSON_WORDS = /\b(in person|in-person|on[- ]site|drive to|walk the site)\b/i;

/** What a task needs: what it declares, plus what its wording gives away. Reshaped tasks are taken at their word. */
export function taskNeeds(task: ProofTask, reshaped = false): Set<ProofNeed> {
  const needs = new Set(task.needs);
  if (task.licence) needs.add("licence");
  if (task.place) needs.add("in-person");
  if (!reshaped) {
    if (EMPLOYEE_WORDS.test(task.task)) needs.add("employee");
    // A member or contractor may hold their own licence or be there in person; the agent can do neither.
    if (task.runBy === "agent" && LICENCE_WORDS.test(task.task)) needs.add("licence");
    if (task.runBy === "agent" && IN_PERSON_WORDS.test(task.task)) needs.add("in-person");
  }
  return needs;
}

export function checkOperability(plan: ProofPlan, params: Pick<ParamValues, "EMPLOYMENT_ALLOWED">): OperabilityIssue[] {
  const issues: OperabilityIssue[] = [];
  const reshaped = new Set(plan.reshaped.map((r) => r.taskKey));
  for (const t of plan.tasks) {
    const needs = taskNeeds(t, reshaped.has(t.key));
    if (needs.has("employee") && !params.EMPLOYMENT_ALLOWED) {
      issues.push({ taskKey: t.key, need: "employee", message: `“${t.task}” needs an employee, and the Protocol can't employ anyone yet.` });
    }
    if (needs.has("licence") && !(t.licence && LICENCES_HELD.includes(t.licence))) {
      issues.push({ taskKey: t.key, need: "licence", message: `“${t.task}” needs ${t.licence ? `a ${t.licence}` : "a licence"}, which the Protocol doesn't hold.` });
    }
    if (needs.has("in-person") && t.runBy === "agent") {
      issues.push({ taskKey: t.key, need: "in-person", message: `“${t.task}” needs someone in person${t.place ? ` at ${t.place}` : ""}, and no member or contractor covers it.` });
    }
  }
  return issues;
}

/** A member request must name a role on the deck's roster, or nobody is asked. */
export function proofRosterErrors(plan: ProofPlan, roster: Pick<RosterRole, "key">[]): string[] {
  return plan.tasks
    .filter((t) => t.runBy === "member request" && (!t.roleKey || !roster.some((r) => r.key === t.roleKey)))
    .map((t) => `Proof task “${t.task}” is a member request, but no roster role answers it.`);
}

const lower = (s: string) => s.charAt(0).toLowerCase() + s.slice(1).replace(/\.$/, "");
const an = (s: string) => `${/^[aeiou]/i.test(s) ? "an" : "a"} ${s}`;

/** The agent's fix for each kind of issue: the work still gets done, by someone the Protocol can pay. */
function reshapeTask(t: ProofTask, need: ProofNeed): { task: ProofTask; why: string } {
  const what = t.what ?? lower(t.task);
  if (need === "employee") {
    return {
      task: { ...t, runBy: "contractor", roleKey: undefined, needs: t.needs.filter((n) => n !== "employee"), task: `Paid as contractor work with a price and an end, not a job: ${what}.` },
      why: "The Protocol can't employ anyone yet, so the work is scoped as a contractor's job.",
    };
  }
  if (need === "licence") {
    return {
      task: { key: t.key, runBy: "agent", needs: [], task: `Prove buyers want it without the licensed step: signed letters of intent for ${what}.` },
      why: `The Protocol holds no ${t.licence ?? "licence"}, so the proof stops at commitments; a licensed operator does that step after a hand-off.`,
    };
  }
  return {
    task: { ...t, runBy: "contractor", roleKey: undefined, task: `A local contractor, paid per visit, goes in person${t.place ? ` to ${t.place}` : ""}: ${what}.` },
    why: "The agent can't be anywhere in person, so a paid local contractor covers the visit.",
  };
}

/** Send the proof back until it passes. Every change is kept on the plan, so the deck shows what was reshaped and why. */
export function reshapeProof(plan: ProofPlan, issues: OperabilityIssue[]): ProofPlan {
  let next: ProofPlan = { ...plan, tasks: [...plan.tasks], reshaped: [...plan.reshaped] };
  for (const issue of issues) {
    const i = next.tasks.findIndex((t) => t.key === issue.taskKey);
    if (i < 0) continue;
    const was = next.tasks[i];
    const { task, why } = reshapeTask(was, issue.need);
    next.tasks[i] = task;
    next.reshaped.push({ taskKey: was.key, need: issue.need, was: was.task, now: task.task, why } satisfies ProofReshape);
    if (issue.need === "licence") {
      next = {
        ...next,
        longTermOperator: "hand-off expected",
        operatorReason: `${next.operatorReason.replace(/\.$/, "")}. A licensed operator would take over the step the Protocol can't do.`,
        entrepreneurBuilds: `${next.entrepreneurBuilds.replace(/\.$/, "")}. The licensed step needs ${an(was.licence ?? "licence")}.`,
      };
    }
  }
  return next;
}

export interface OperableProof {
  plan: ProofPlan;
  /** What the check rejected on the way. Empty when the first plan passed. */
  rejected: OperabilityIssue[];
}

export function operableProof(plan: ProofPlan, params: Pick<ParamValues, "EMPLOYMENT_ALLOWED">): OperableProof {
  const rejected: OperabilityIssue[] = [];
  let p = plan;
  for (let round = 0; round < 3; round++) {
    const issues = checkOperability(p, params);
    if (!issues.length) return { plan: p, rejected };
    rejected.push(...issues);
    p = reshapeProof(p, issues);
  }
  const left = checkOperability(p, params);
  if (left.length) throw new Error(`The proof can't be made operable: ${left.map((i) => i.message).join(" ")}`);
  return { plan: p, rejected };
}

const RUNNER_NOUN: Record<ProofRunner, [string, string]> = {
  agent: ["agent task", "agent tasks"],
  "member request": ["member request", "member requests"],
  contractor: ["contractor", "contractors"],
};

/** The deck's "Proof run by" line. */
export function proofRunBy(plan: ProofPlan): string {
  const n = (r: ProofRunner) => plan.tasks.filter((t) => t.runBy === r).length;
  const others = (["member request", "contractor"] as const).filter((r) => n(r)).map((r) => `${n(r)} ${RUNNER_NOUN[r][n(r) === 1 ? 0 : 1]}`);
  if (!n("agent")) return others.join(" and ");
  return others.length ? `The agent, with ${others.join(" and ")}` : "The agent alone";
}

export const LONG_TERM_LABELS: Record<ProofPlan["longTermOperator"], string> = {
  agents: "Agents",
  "hand-off expected": "Hand-off expected",
};
