# Shoalyard economics — SAFE seed + cash answers

**Status:** Agreed model (founder debate, memorialized Oct 31, 2026 America/New_York; holdco/platform duties extended Nov 1, 2026). **Source of truth for later site/constitution/params rollout.** Docs only — does **not** rewrite constitution or product copy.

**Not legal advice.** Securities, tax, entity, and offering posture are **counsel TBD** throughout. Numbers below are design intent, not filings.

Related prior notes (superseded for the **funding** story; keep for product history): `seat-price-per-venture.md`, equal-share economics in `STATUS.md` / README as of Oct 31 pilot build.

---

## 1. Architecture: holdco vs opco

### Holdco (Shoalyard operator)

- Operator entity that owns shared rails: infra, security, legal, platform product.
- **Founder reserves control** — e.g. **50.1%** discussed as intent; exact control instrument (voting stock, LLC voting, etc.) is **counsel TBD**.
- **Holdco capital is separate from opco seed.** Do not fund platform build from venture seed escrow, and do not treat holdco membership as “answering” an opco.
- Holdco membership / investor path ≠ opco answerer path. Keep the stories and money flows distinct on the ledger and in copy.

### Opco ventures

- Each venture is its own economic box (entity form **counsel TBD**).
- Capital into the opco comes from **accredited seed** (below), not from “buying a seat that is somehow equity.”
- Labor (answers) is paid in **cash** from the proof budget. Answerers do **not** buy equity by answering.

### Holdco / platform responsibilities

Holdco runs like a **VC firm’s platform**, not like a single opco CEO. The point of the yard is that **opcos get the best shot** because holdco owns the repeated, specialized work: raise, source, diligence, help them win, steward/board support, exits, and books.

**Intent:** holdco fields **agents (plural)** with **specialization** — sourcing, thesis/DD, capital formation, marketing, value-creation support, governance prep, exit prep, back office — not one undifferentiated bot pretending to be the whole firm. Opco agents run the venture day-to-day. Humans (seeders, stewards, answerers) supply capital, kill-switch judgment, and work the agent cannot fake. Securities / entity / offering posture remains **counsel TBD** (see §7); this table is an operating model, not a prospectus.

| Duty (VC analog) | Holdco (platform) | Opco agent | Humans |
| --- | --- | --- | --- |
| **Capital formation** | Raise and structure the attempt’s seed path; escrow/fill-or-kill rails; keep holdco rails capital separate from opco seed | Does not raise the seed round; may surface runway / proof-budget needs | **Seeders** put capital in (accredited path). **Stewards** sign off on go/no-go for the attempt |
| **Marketing** | Yard brand, batch cadence, honest public story of attempts; channel for counsel-cleared CTAs | Venture-level pitch / asks inside the attempt | **Stewards** approve sensitive claims; **answerers** may amplify with real relationships — not a substitute for attestation gates |
| **Sourcing** | Holdco **sourcing agent(s)** hunt and filter ideas / domains worth an attempt | Consumes a sourced thesis once spun up | Humans may nominate ideas; steward / holdco gate what becomes a Batch attempt |
| **Thesis development / DD** | Holdco **thesis & diligence agents** stress the idea before capital is at risk; publish what can be published | Owns live operating hypothesis once running; updates from proof | Stewards and domain **answerers** challenge assumptions; seeders underwrite residual risk |
| **Execution of thesis / value creation** | Platform playbooks, shared rails, cross-venture learning so the next attempt starts smarter | Primary operator of the venture’s zero-to-one loop | **Answerers** supply judgment, intros, craft for cash; **stewards** can kill |
| **Governance / BOD support** | Holdco agents prep packs, calendars, breach/mark hygiene, steward workflows | Surfaces decisions and ledger truth | **Stewards** hold the kill switch and board-like judgment; seeders’ governance rights are **counsel TBD** |
| **Exit preparation** | Holdco exit-prep agents: hand-off packs, buyer/partner narrative, wind-down paths per instrument riders | Keeps ops and books ready for hand-off or wind-down | Stewards / humans approve hand-off; capital outcomes follow SAFE/equity (**counsel TBD**) |
| **Back office (all of it)** | Shared back office at the yard: ledger, infra, security, legal ops coordination, protocol product | Uses shared rails; does not reinvent payroll/ledger/security per venture | Humans approve real money movement and counsel-gated actions; nothing autonomous that moves cash without approval |

Plain-language About/marketing equivalents (no VC jargon on the consumer homepage): see [`messaging.md`](messaging.md) — **What the yard does**.

---

## 2. Opco seed (accredited)

| Decision | Agreed shape |
| --- | --- |
| Who | Accredited investors only for the security path |
| Mechanics | Real capital via **fill-or-kill escrow** |
| On minimum met | Issue **SAFE** — **post-money style default**; discount/cap **TBD** |
| Riders | **Wind-down**, **hand-off**, and **unused capital** treatment spelled in the instrument (**counsel TBD**) |
| On miss | **Full refund**; **no SAFE** issued |
| Public solicitation | Public site may solicit **only** with proper exemption posture. Lean **Rule 506(c)** if advertising + accredited verification; otherwise quieter **506(b)**. Flag: **counsel-required**; not legal advice |
| Attestation | **No public “seed for equity” without attestation.** Any consumer / non-accredited path, if it exists at all, is **not** the security |

**Seed ≠ ticket that dies on a rejected answer.** Rejection is a work outcome. Seed risk is **venture risk**, shared with other seeders — not “you paid and your answer was declined, so your capital evaporated.”

---

## 3. Answers (labor)

| Decision | Agreed shape |
| --- | --- |
| Pay | **Cash** from the **proof budget** (operating expense) |
| Terms | **Equal treatment** for similar accepted work — no variable “ownership unit” gaming (no agent mispricing 10 vs 100 units of ownership for answers) |
| Equity | Answerers do **not** purchase equity by answering |
| Timing | Late answerers can still be paid for **accepted** work |
| “Earned not bought” | Keep **only** as labor-vs-buying-equity language — **not** as the funding narrative |

---

## 4. Published waterfall

Publish this (or a counsel-cleared equivalent) on venture / protocol surfaces when the model ships:

1. **Gross revenue**
2. − **Token / model costs** (and other explicit pass-throughs as defined)
3. − **Answer cash** (proof-budget labor)
4. − **Platform vig ~5%** — cost recovery / franchise-like rails fee to the operator
5. → Remainder subject to **equity / SAFE** economics

**Operator equity / carry:** also a **% equity or carry (~20% discussed)** into the upside. **Double dip is OK** if each line has a job:

- **Vig (~5%)** = rails / cost recovery
- **Equity / carry (~20%)** = upside alignment

Pilot may start with **one primary** instrument + a **smaller second**; do not invent a third fee line without a job.

Exact percentages, base (gross vs contribution margin), and whether vig sits above or inside SAFE-defined economics: **params + counsel TBD**.

---

## 5. Explicitly retired / superseded (funding story)

Do **not** revive these as the main capital path or public funding narrative:

- **Seat-as-only-consumer-good** as the main capital path
- **“Earned not bought”** as the **funding** story (keep only for labor vs buying equity)
- **Uncapped agent-weighted ownership units** for answers
- **Plain Kickstarter framing** for accredited seed

Pilot UI may still say “seat” until rollout; treat that copy as **legacy demo**, not the agreed raise.

---

## 6. Keep from prior product

These survive the pivot:

- **Fill-or-kill minimum** (escrow; miss → refund)
- **Published ledger / transparent flows**
- **Shoal mark** vs **Built at the Shoalyard** credit (provenance ≠ mark)
- **Equal cash terms** for similar accepted work (no agent ownership-unit mispricing)

---

## 7. Open counsel questions (non-exhaustive)

Label every public claim until cleared. Not legal advice.

1. Holdco control at ~50.1% — instrument, dilution protection, reserved matters.
2. Opco entity form; series / SPV / SAFE issuer identity vs holdco.
3. SAFE terms: post-money vs pre; discount; valuation cap; MFN; pro rata; most-favored.
4. Wind-down / hand-off / unused-capital riders; interaction with steward kill switch.
5. Escrow agent, release conditions, refund timing, state money-transmission issues.
6. Offering exemption: **506(c)** (general solicitation + accredited verification) vs **506(b)**; site advertising boundary.
7. Who may see seed CTAs; attestation UX; bad-actor / KYC / accreditation vendors.
8. Whether any non-security consumer product remains (access, merch, software) and how it is fenced from the SAFE.
9. Answerer cash: employment vs independent contractor; 1099 / wage; international.
10. Platform vig characterization (fee for service vs franchise vs something else); tax and consumer-protection optics.
11. Operator ~20% equity/carry: profits interest, option, SAFE side letter, or holdco ownership of opco units — and disclosure of “double dip.”
12. Public ledger: what amounts are shown without becoming an unregistered solicitation or selective disclosure problem.
13. Marketing claims to retire (Kickstarter analogy; “seat is not a security” if seed *is* a security; “earn equity by answering”).
14. Multi-state / non-US persons; website geo posture.

---

## 8. Site / product rollout checklist (later work)

Memorialization only in this commit. When implementing, change in roughly this order:

### Copy & pages

- [ ] Home / “how it works”: seed (accredited SAFE) vs answer (cash) — two paths, never conflated
- [ ] Venture pitch / seat page → **seed / raise** page: escrow, minimum, miss = refund, hit = SAFE
- [ ] Retire “seat ≠ share / never a return” as the **only** money story; replace with attested seed + separate labor
- [ ] Inbox / RFE: offer **cash**, not ownership units; equal-rate language
- [ ] Ledger: show seed inflows, refunds, SAFEs issued, answer cash out, vig, token costs
- [ ] Protocol / economics page: published waterfall + vig + carry jobs
- [ ] Holdings: SAFE positions vs cash earned — separate
- [ ] Onboarding / attestation gates before any “seed for equity” CTA
- [ ] Mark vs Shoalyard credit unchanged in meaning; economics copy must not imply Kickstarter

### Parameters (`packages/schema` / protocol) — later

- [ ] Seed minimum, escrow window, fill-or-kill
- [ ] SAFE defaults (post-money; discount/cap placeholders)
- [ ] Answer cash schedule / equal rate; proof-budget allocation
- [ ] `PLATFORM_VIG_PCT` (~5% intent)
- [ ] `OPERATOR_EQUITY_OR_CARRY_PCT` (~20% intent)
- [ ] Remove or hard-deprecate answer → ownership-unit grants as funding/comp mix
- [ ] Holdco vs opco ledger kinds so capital sources never mix

### Explicit non-goals for the first economics ship

- Full constitution rewrite in the same PR as first copy pass (unless counsel drives article text)
- Live payments / real SAFEs without human + counsel approval
- Public seed CTA without attestation and exemption posture

---

## 9. One-line summary for agents

**Accredited fill-or-kill seed → SAFE (post-money default) on hit / refund on miss; answers paid equal cash from the proof budget (no equity-by-answering); published waterfall takes token costs, answer cash, and ~5% platform vig before SAFE/equity economics; operator also ~20% equity/carry; holdco capital and control stay separate; holdco runs VC-analog platform duties via specialized agents so each opco gets the best shot; counsel TBD on all securities and entity points.**
