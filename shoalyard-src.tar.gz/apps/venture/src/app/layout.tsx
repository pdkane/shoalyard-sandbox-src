import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { Archivo, IBM_Plex_Mono, IBM_Plex_Sans } from "next/font/google";
import { CONSTITUTION_VERSION, stewardQueue, tagQueue } from "@av/protocol";
import { defaultParams } from "@av/schema";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/sonner";
import { AccountNav, MobileNav, NavLinks } from "@/components/site-nav";
import { RefCapture } from "@/components/share-menu";
import { getData, VISITOR } from "@/lib/data";
import { formatDateTime } from "@/lib/format";
import "./globals.css";

// Brand type (brand/README.md): Archivo for display, IBM Plex Sans for body, IBM Plex Mono for labels.
const archivo = Archivo({ variable: "--font-archivo", subsets: ["latin"], axes: ["wdth"] });
const plexSans = IBM_Plex_Sans({ variable: "--font-plex-sans", subsets: ["latin"], weight: ["400", "500", "600"] });
const plexMono = IBM_Plex_Mono({ variable: "--font-plex-mono", subsets: ["latin"], weight: ["400", "500"] });

const brand = defaultParams().BRAND_NAME;

export const metadata: Metadata = {
  title: { default: brand, template: `%s · ${brand}` },
  description:
    "Shoalyard — Many hands. One yard. AI agents build companies; people put capital in, steer, and teach them. The yard gets smarter every batch.",
  // Production: https://shoalyard.com (Cloudflare). Override with SITE_URL.
  metadataBase: new URL(process.env.SITE_URL ?? "http://localhost:43117"),
  twitter: { card: "summary_large_image" },
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const { store, params, viewer, member, isSteward, inboxCount } = await getData();
  const nav = {
    explore: [
      { href: "/", label: "Ventures" },
      { href: "/batches", label: "Batches" },
      { href: "/about", label: "About" },
      { href: "/learning", label: "Lessons" },
    ],
    explain: [
      { href: "/#how-it-works", label: "How it works" },
      { href: "/invest", label: "Put capital in" },
      { href: "/contribute", label: "Steer and teach" },
      { href: "/protocol", label: "Rules" },
      { href: "/protocol/services", label: "Shared services" },
      { href: "/glossary", label: "Glossary" },
    ],
    you: member
      ? [
          { href: "/inbox", label: "Inbox", count: inboxCount },
          { href: "/your-ventures", label: "Your ventures" },
          { href: "/holdings", label: "Your units" },
          { href: `/m/${viewer}`, label: "Your profile and verification" },
          { href: "/shares", label: "Your shares" },
        ]
      : [{ href: "/shares", label: "Your shares" }],
    steward: isSteward
      ? [
          { href: "/steward#sign-off", label: "Sign-off queue", count: stewardQueue(store, viewer).length },
          { href: "/steward#classification", label: "Classification queue", count: tagQueue(store).length },
          { href: "/steward", label: "All steward tools" },
        ]
      : [],
    viewer,
    inboxCount,
  };
  const handles = [
    { handle: VISITOR, label: "A visitor (not signed in)" },
    ...[...store.members]
    .sort((a, b) => {
      if (a.handle === params.FOUNDING_STEWARD_HANDLE) return -1;
      if (b.handle === params.FOUNDING_STEWARD_HANDLE) return 1;
      return a.handle.localeCompare(b.handle);
    })
    .map((m) => ({
      handle: m.handle,
      label: m.handle === params.FOUNDING_STEWARD_HANDLE ? `@${m.handle} (steward)` : `@${m.handle}`,
    })),
  ];

  return (
    <html lang="en" className={`${archivo.variable} ${plexSans.variable} ${plexMono.variable} h-full antialiased`}>
      <body className="flex min-h-full flex-col bg-white text-ink">
        <TooltipProvider>
          <header className="sticky top-0 z-40 border-b border-line bg-white/85 print:hidden backdrop-blur supports-[backdrop-filter]:bg-white/70">
            <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4 sm:px-6">
              <MobileNav {...nav} handles={handles} brand={params.BRAND_NAME} />
              <Link href="/" aria-label={params.BRAND_NAME} className="flex items-center">
                {/* eslint-disable-next-line @next/next/no-img-element -- outlined SVG logo, no optimisation needed */}
                <img src="/brand/wordmark-compact.svg" alt={params.BRAND_NAME} width={150} height={20} className="hidden h-5 w-auto sm:block" />
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/brand/mark.svg" alt={params.BRAND_NAME} width={23} height={20} className="h-5 w-auto sm:hidden" />
              </Link>
              <div className="ml-2 flex-1">
                <NavLinks explore={nav.explore} explain={nav.explain} />
              </div>
              <AccountNav you={nav.you} steward={nav.steward} viewer={viewer} inboxCount={inboxCount} handles={handles} />
            </div>
          </header>
          <Suspense fallback={null}>
            <RefCapture />
          </Suspense>
          <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">{children}</main>
          <footer className="border-t border-line bg-white">
            <div className="mx-auto flex max-w-6xl flex-col gap-1 px-4 py-5 text-xs text-metal sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <span>
                {params.BRAND_NAME} · Many hands. One yard. ·{" "}
                <Link href="/about" className="underline-offset-2 hover:text-ink hover:underline">
                  About
                </Link>{" "}
                ·{" "}
                <Link href="/protocol" className="underline-offset-2 hover:text-ink hover:underline">
                  Rules v{CONSTITUTION_VERSION}
                </Link>{" "}
                ·{" "}
                <Link href="/protocol#params" className="underline-offset-2 hover:text-ink hover:underline">
                  Settings v{store.meta.protocolVersion}
                </Link>{" "}
                ·{" "}
                <Link href="/glossary" className="underline-offset-2 hover:text-ink hover:underline">
                  Glossary
                </Link>
                . Pilot seat UI may linger; agreed path is SAFE seed + cash for answers.
              </span>
              <span>
                Demo time {formatDateTime(store.meta.clock)} UTC
                {isSteward ? ` · step ${store.meta.tick}` : ""}
                {member ? ` · viewing as @${viewer}` : ""}
              </span>
            </div>
          </footer>
          <Toaster position="bottom-right" />
        </TooltipProvider>
      </body>
    </html>
  );
}
