"use client";

import { useEffect, useRef } from "react";

type Species = {
  share: number;
  len: [number, number];
  girth: number;
  body: [number, number, number];
  flash: [number, number, number];
  spd: number;
};

type Stroke = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  ph: number;
  len: number;
  girth: number;
  B: [number, number, number];
  F: [number, number, number];
  spd: number;
  turn: number;
  h: number;
  th: number;
  rj: number;
  ou: number;
  ov: number;
  depth: number;
  settle: number;
  ang: number | null;
};

const SPECIES: Species[] = [
  { share: 0.4, len: [6, 9], girth: 0.3, body: [127, 184, 176], flash: [11, 33, 40], spd: 1.25 },
  { share: 0.26, len: [10, 14], girth: 0.34, body: [47, 111, 106], flash: [11, 33, 40], spd: 1.0 },
  { share: 0.13, len: [15, 21], girth: 0.2, body: [75, 87, 91], flash: [210, 222, 219], spd: 1.1 },
  { share: 0.11, len: [16, 24], girth: 0.48, body: [106, 78, 58], flash: [201, 168, 140], spd: 0.7 },
  { share: 0.1, len: [18, 27], girth: 0.34, body: [11, 33, 40], flash: [127, 184, 176], spd: 0.82 },
];

const MARK_STROKES: [number, number, number, number][] = [
  [6, 22, 44, 22],
  [26, 36, 70, 36],
  [16, 50, 52, 50],
  [40, 64, 88, 64],
];

const CYCLE = 14;
/** Hold-phase midpoint: settled mark, not the opening column. */
const SETTLED_T = 9;
const DESKTOP_N = 460;
const MOBILE_N = 230;

function createRng(seed0 = 7) {
  let seed = seed0;
  return () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };
}

function pickSpecies(rnd: () => number): Species {
  const r = rnd();
  let acc = 0;
  for (const sp of SPECIES) {
    acc += sp.share;
    if (r <= acc) return sp;
  }
  return SPECIES[0]!;
}

function buildSlots(W: number, H: number) {
  const mk = { x: W * 0.53, y: H * 0.2, s: Math.min(6.2, (H * 0.55) / 64) };
  const slots: { x: number; y: number }[] = [];
  for (const [x1, y1, x2] of MARK_STROKES) {
    const n = Math.round((x2 - x1) * 1.6);
    for (let k = 0; k < n; k++) {
      for (let r = -2; r <= 2; r++) {
        slots.push({
          x: mk.x + (x1 + (x2 - x1) * (k / (n - 1))) * mk.s,
          y: mk.y + y1 * mk.s + r * 10,
        });
      }
    }
  }
  return slots;
}

function makeStrokes(n: number, W: number, H: number, rnd: () => number): Stroke[] {
  const fish: Stroke[] = [];
  for (let i = 0; i < n; i++) {
    const a = rnd() * Math.PI * 2;
    const sp = pickSpecies(rnd);
    fish.push({
      x: W * (0.45 + rnd() * 0.4),
      y: H * (0.3 + rnd() * 0.5),
      vx: Math.cos(a),
      vy: Math.sin(a) * 0.4,
      ph: rnd() * 6.283,
      len: sp.len[0] + rnd() * (sp.len[1] - sp.len[0]),
      girth: sp.girth,
      B: sp.body,
      F: sp.flash,
      spd: sp.spd,
      turn: 0,
      h: (rnd() + rnd() + rnd()) / 3 - 0.5,
      th: rnd() * 6.283,
      rj: rnd() < 0.08 ? 1.15 + rnd() * 0.4 : 0.5 + rnd() * 0.6,
      ou: Math.sqrt(rnd()) * Math.cos(a),
      ov: Math.sqrt(rnd()) * Math.sin(a),
      depth: 0,
      settle: 0,
      ang: null,
    });
  }
  return fish;
}

function stepMill(fish: Stroke[], slots: { x: number; y: number }[], W: number, H: number, t: number, dt: number, speed: number) {
  const c = t % CYCLE;
  const settle = c < 6 ? 0 : c < 8.5 ? (c - 6) / 2.5 : c < 12 ? 1 : 1 - (c - 12) / 2;
  const e = settle * settle * (3 - 2 * settle);
  fish.forEach((f, i) => {
    f.th += dt * speed * f.spd * (0.95 + 0.2 * Math.sin(f.ph));
    const hz = f.h;
    const env = Math.max(0.18, 1 - 2.4 * hz * hz);
    const R =
      W *
      0.12 *
      env *
      f.rj *
      (0.62 + 0.32 * Math.sin(hz * 5.3 + t * 0.27) + 0.18 * Math.sin(hz * 11.7 - t * 0.41 + 1.3));
    const lean = 70 * Math.sin(hz * 3.4 + t * 0.33) + 34 * Math.sin(hz * 8.1 - t * 0.23);
    const lane = hz * H * 0.66 + Math.sin(t * 0.21 + f.ph) * 16;
    const mx = W * 0.69 + lean + Math.cos(f.th) * R;
    const my = H * 0.52 + lane + Math.sin(f.th + f.ph) * R * 0.12;
    const s = slots[Math.floor((i * slots.length) / fish.length)]!;
    const ox = f.x;
    const oy = f.y;
    const sx = s.x + Math.sin(f.ph * 5.1) * 4 + Math.sin(t * 1.3 + f.ph) * 1.5;
    const sy = s.y + Math.sin(f.ph * 3.7) * 3 + Math.sin(t * 1.7 + f.ph * 2) * 1;
    f.x = mx + (sx - mx) * e;
    f.y = my + (sy - my) * e;
    f.depth = Math.sin(f.th) * (1 - e);
    f.settle = e;
    const vx = f.x - ox;
    const vy = f.y - oy;
    if (Math.hypot(vx, vy) > 0.05) {
      f.vx = vx;
      f.vy = vy;
    }
    let a = Math.atan2(f.vy, f.vx);
    if (a > Math.PI / 2) a -= Math.PI;
    if (a < -Math.PI / 2) a += Math.PI;
    f.ang = e > 0.02 ? a * (1 - Math.min(1, e * 1.6)) : null;
    f.turn = (1 - e) * Math.max(0, Math.cos(f.th)) * 1.2 + e * 0.15 * (1 + Math.sin(t * 3 + i));
  });
}

function drawFrame(ctx: CanvasRenderingContext2D, fish: Stroke[], W: number, H: number, t: number) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "#FFFFFF");
  g.addColorStop(1, "#F2F5F4");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.globalCompositeOperation = "source-over";
  for (let k = 0; k < 7; k++) {
    const x0 = ((k * 233 + t * (14 + k * 3)) % (W + 600)) - 300;
    const lg = ctx.createLinearGradient(x0, 0, x0 + 160, H);
    lg.addColorStop(0, "rgba(255,255,255,0)");
    lg.addColorStop(0.5, "rgba(227,239,237,0.5)");
    lg.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = lg;
    ctx.beginPath();
    ctx.moveTo(x0, 0);
    ctx.lineTo(x0 + 70, 0);
    ctx.lineTo(x0 + 260, H);
    ctx.lineTo(x0 + 120, H);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  const order = fish.slice().sort((a, b) => a.depth - b.depth);
  for (const f of order) {
    const ang = f.ang != null ? f.ang : Math.atan2(f.vy * 0.35, f.vx);
    const flank = Math.pow(0.5 + 0.5 * Math.cos(2 * ang + f.ph * 0.35 + t * 0.9 - f.x * 0.006 + f.y * 0.004), 5);
    const flash = Math.min(1, flank * 0.85 + f.turn * 0.8);
    const depth = f.depth;
    const L = (f.len + (Math.min(f.len, 12) - f.len) * f.settle) * (1 + depth * 0.25);
    ctx.save();
    ctx.translate(f.x, f.y);
    ctx.rotate(ang);
    ctx.globalAlpha = 0.55 + (0.45 * (depth + 1)) / 2;
    const B = f.B;
    const F = f.F;
    const r = (B[0] + (F[0] - B[0]) * flash) | 0;
    const gch = (B[1] + (F[1] - B[1]) * flash) | 0;
    const b = (B[2] + (F[2] - B[2]) * flash) | 0;
    ctx.strokeStyle = `rgb(${r},${gch},${b})`;
    ctx.lineCap = "round";
    ctx.lineWidth = Math.max(2.4, L * f.girth * 0.62);
    ctx.beginPath();
    ctx.moveTo(-L * 0.8, 0);
    ctx.lineTo(L * 0.8, 0);
    ctx.stroke();
    ctx.restore();
  }
}

/**
 * Concept C: a mixed shoal of rounded strokes mills as a column, then settles
 * into the four strokes of the mark (14s loop). Reduced motion shows the
 * settled mark as a still — never the opening column.
 */
export function HeroShoal({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const reduceMq = window.matchMedia("(prefers-reduced-motion: reduce)");
    let reduce = reduceMq.matches;
    let raf = 0;
    let running = false;
    let visible = true;
    let pageVisible = document.visibilityState === "visible";
    let last = performance.now();
    let t = 0;
    let W = 0;
    let H = 0;
    let fish: Stroke[] = [];
    let slots: { x: number; y: number }[] = [];

    const count = () => (window.matchMedia("(max-width: 640px)").matches ? MOBILE_N : DESKTOP_N);

    const paint = () => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      stepMill(fish, slots, W, H, t, 1 / 60, 1);
      drawFrame(ctx, fish, W, H, t);
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      W = Math.max(1, rect.width);
      H = Math.max(1, rect.height);
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      slots = buildSlots(W, H);
      const n = count();
      if (fish.length !== n) {
        fish = makeStrokes(n, W, H, createRng(7));
        t = reduce ? SETTLED_T : 0;
      }
      // Reduced motion: jump to the settled mark (hold phase), never the opening column.
      if (reduce) t = SETTLED_T;
      paint();
    };

    const tick = (now: number) => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      t += dt;
      stepMill(fish, slots, W, H, t, dt, 1);
      drawFrame(ctx, fish, W, H, t);
      if (!reduce && visible && pageVisible) raf = requestAnimationFrame(tick);
      else running = false;
    };

    const start = () => {
      if (reduce || !visible || !pageVisible || running) return;
      running = true;
      last = performance.now();
      raf = requestAnimationFrame(tick);
    };

    const stop = () => {
      cancelAnimationFrame(raf);
      raf = 0;
      running = false;
    };

    resize();
    if (!reduce) start();

    const onReduce = () => {
      reduce = reduceMq.matches;
      stop();
      resize();
      if (!reduce) start();
    };
    reduceMq.addEventListener("change", onReduce);

    const ro = new ResizeObserver(() => {
      stop();
      resize();
      if (!reduce) start();
    });
    ro.observe(canvas);

    const io = new IntersectionObserver(
      ([entry]) => {
        visible = !!entry?.isIntersecting;
        if (visible) start();
        else stop();
      },
      { threshold: 0.05 },
    );
    io.observe(canvas);

    const onVis = () => {
      pageVisible = document.visibilityState === "visible";
      if (pageVisible) start();
      else stop();
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      stop();
      reduceMq.removeEventListener("change", onReduce);
      document.removeEventListener("visibilitychange", onVis);
      ro.disconnect();
      io.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={className}
    />
  );
}
