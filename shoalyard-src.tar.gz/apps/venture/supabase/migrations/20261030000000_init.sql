-- Future storage seam for the pilot. NOT applied: the pilot runs on the local
-- JSON store (data/store.json). Shapes mirror packages/schema/src/primitives.ts.
--
-- Access model:
--   * RLS is enabled on every table. Anything without a policy is denied to
--     anon/authenticated clients; the operator agent writes with the service role.
--   * Policies key on auth.uid() via members.auth_user_id only. Nothing reads
--     auth.jwt() -> 'user_metadata', which users can edit themselves.
--   * Embargoed decisions are never readable directly; the public reads the
--     public_decisions view, which keeps only the reason and release date.

create extension if not exists pgcrypto;

create table public.ventures (
  id text primary key,
  slug text not null unique,
  name text not null,
  tagline text not null,
  pitch text not null,
  is_protocol boolean not null default false,
  objective text not null check (objective in ('scale', 'profitability', 'exit')),
  distribution_policy text not null,
  budget jsonb not null default '[]',
  min_raise_usd numeric not null,
  status text not null check (status in ('generated','pitched','funded','formed','operating','customer1','distributing','dormant','killed')),
  status_history jsonb not null default '[]',
  kill_rules text[] not null default '{}',
  kill_date timestamptz,
  steward_handle text not null,
  protocol_version text not null,
  voice text not null default '',
  accent text not null default '#18181b',
  customers jsonb not null default '{}',
  quarters jsonb not null default '[]',
  post_mortem jsonb,
  created_at timestamptz not null default now()
);

create table public.members (
  handle text primary key check (handle ~ '^[A-Za-z0-9_]{2,24}$'),
  auth_user_id uuid unique references auth.users (id) on delete set null,
  role text not null,
  industry text not null,
  seniority text not null check (seniority in ('early','mid','senior','executive')),
  reputation_tier text not null default 'new' check (reputation_tier in ('new','contributor','trusted')),
  cluster text not null,
  profile jsonb not null default '{}',
  daily_push_cap int not null default 3,
  credibility_name text,
  onboarded_at timestamptz,
  joined_at timestamptz not null default now(),
  source text
);

create table public.rfes (
  id text primary key,
  venture_id text not null references public.ventures (id),
  type text not null check (type in ('judgment','knowledge','access','credibility','action','capital','stewardship')),
  kind text not null default 'request' check (kind in ('request','governance')),
  title text not null,
  question text not null,
  recommendation text not null,
  confidence numeric not null check (confidence between 0 and 1),
  stakes text not null check (stakes in ('low','medium','high')),
  format text not null check (format in ('choice','scale','text','action')),
  options text[],
  scale_labels text[],
  offer_units numeric not null default 0,
  audience text not null,
  target_override int,
  extended boolean not null default false,
  status text not null check (status in ('drafted','posted','quorum','resolved','scored')),
  posted_at timestamptz not null,
  resolved_at timestamptz,
  resolution text,
  decision_id text,
  assigned_to text references public.members (handle),
  governance jsonb,
  gtm jsonb
);
create index rfes_venture_idx on public.rfes (venture_id, status);

create table public.responses (
  id text primary key default gen_random_uuid()::text,
  rfe_id text not null references public.rfes (id),
  handle text not null references public.members (handle),
  via text not null check (via in ('structured','text','voice')),
  choice text,
  scale int,
  text text,
  transcript text,
  extracted_by text,
  counter_units numeric,
  weight numeric,
  at timestamptz not null default now(),
  unique (rfe_id, handle)
);
create index responses_handle_idx on public.responses (handle);

create table public.grants (
  id text primary key,
  venture_id text not null references public.ventures (id),
  handle text not null references public.members (handle),
  slice text not null check (slice in ('rfe','seats','steward','cohort','founder')),
  rfe_id text references public.rfes (id),
  units numeric not null check (units >= 0),
  status text not null check (status in ('offered','accepted','vested','distributing','forfeited')),
  at timestamptz not null,
  vests_at timestamptz,
  note text
);
create index grants_venture_idx on public.grants (venture_id, handle);

create table public.decisions (
  id text primary key,
  venture_id text not null references public.ventures (id),
  title text not null,
  reasoning text not null,
  confidence numeric not null,
  facts jsonb not null default '{}',
  bin text not null check (bin in ('auto','advisory','gated')),
  bin_reasons text[] not null default '{}',
  status text not null check (status in ('awaiting_members','awaiting_steward','taken','rejected')),
  at timestamptz not null,
  taken_at timestamptz,
  outcome text,
  steward_note text,
  rfe_id text,
  embargo_until timestamptz,
  embargo_reason text,
  transition text,
  model text not null
);
create index decisions_venture_idx on public.decisions (venture_id, at desc);

create table public.ledger_entries (
  id text primary key,
  at timestamptz not null,
  venture_id text not null references public.ventures (id),
  kind text not null check (kind in ('seat','grant','vest','forfeit','distribution','redaction','amendment','notify','status')),
  handle text,
  usd numeric,
  units numeric,
  ref text,
  note text not null
);
create index ledger_venture_idx on public.ledger_entries (venture_id, at desc);

create table public.distributions (
  id text primary key,
  venture_id text not null references public.ventures (id),
  quarter text not null,
  at timestamptz not null,
  profit_usd numeric not null,
  pass_through_usd numeric not null,
  protocol_usd numeric not null,
  contributor_usd numeric not null,
  treasury_usd numeric not null,
  per_unit_usd numeric not null
);

create table public.amendments (
  id text primary key,
  param_key text not null,
  old_value jsonb,
  new_value jsonb,
  rfe_id text not null references public.rfes (id),
  version text not null,
  at timestamptz not null
);

alter table public.ventures enable row level security;
alter table public.members enable row level security;
alter table public.rfes enable row level security;
alter table public.responses enable row level security;
alter table public.grants enable row level security;
alter table public.decisions enable row level security;
alter table public.ledger_entries enable row level security;
alter table public.distributions enable row level security;
alter table public.amendments enable row level security;

-- Public by design (Article 3: decisions, cap tables and reports are public).
create policy "ventures are public" on public.ventures for select to anon, authenticated using (true);
create policy "rfes are public" on public.rfes for select to anon, authenticated using (true);
create policy "grants are public" on public.grants for select to anon, authenticated using (true);
create policy "distributions are public" on public.distributions for select to anon, authenticated using (true);
create policy "amendments are public" on public.amendments for select to anon, authenticated using (true);
create policy "ledger is public except notices" on public.ledger_entries for select to anon, authenticated
  using (kind <> 'notify' or handle = (select m.handle from public.members m where m.auth_user_id = (select auth.uid())));

-- Handles are public; profiles are not. Members read and edit only their own row.
create policy "members read own profile" on public.members for select to authenticated
  using (auth_user_id = (select auth.uid()));
create policy "members update own profile" on public.members for update to authenticated
  using (auth_user_id = (select auth.uid()))
  with check (auth_user_id = (select auth.uid()));

-- Responses: members read and insert their own. Tallies are served by the operator.
create policy "members read own responses" on public.responses for select to authenticated
  using (handle = (select m.handle from public.members m where m.auth_user_id = (select auth.uid())));
create policy "members answer as themselves" on public.responses for insert to authenticated
  with check (handle = (select m.handle from public.members m where m.auth_user_id = (select auth.uid())));

-- No select policy on decisions: clients read the redacting view below.
create view public.public_decisions
with (security_invoker = false) as
select
  d.id,
  d.venture_id,
  d.at,
  d.bin,
  d.status,
  (d.embargo_until is not null and d.embargo_until > now()) as redacted,
  d.embargo_until,
  d.embargo_reason,
  case when d.embargo_until > now() then null else d.title end as title,
  case when d.embargo_until > now() then null else d.reasoning end as reasoning,
  case when d.embargo_until > now() then null else d.confidence end as confidence,
  case when d.embargo_until > now() then null else d.bin_reasons end as bin_reasons,
  case when d.embargo_until > now() then null else d.outcome end as outcome,
  case when d.embargo_until > now() then null else d.steward_note end as steward_note,
  case when d.embargo_until > now() then null else d.rfe_id end as rfe_id,
  case when d.embargo_until > now() then null else d.model end as model
from public.decisions d;

revoke all on public.public_decisions from anon, authenticated;
grant select on public.public_decisions to anon, authenticated;
