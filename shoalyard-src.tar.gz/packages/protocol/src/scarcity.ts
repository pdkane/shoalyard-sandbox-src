import type { Cohort, Store, Venture } from "@av/schema";
import { batchLabel, batchVentures, cohortFor, isRevealed, seatWindow } from "./batches";
import { latestDeck } from "./deck";
import { isLive, seatsSold } from "./ops";
import { resolveParams } from "./params";
import { rosterFill } from "./roster";

/**
 * Scarcity, only ever as true numbers from the store (Article 8): seats left against the deck's maximum,
 * roles claimed against the roster, and the real batch window.
 */
export interface SeatsLeft {
  sold: number;
  max: number;
  left: number;
}

export function seatsLeft(store: Store, venture: Venture): SeatsLeft | undefined {
  const deck = latestDeck(store, venture.id);
  if (!deck) return undefined;
  const sold = seatsSold(store, venture.id);
  const max = deck.seatPlan.max;
  return { sold, max, left: Math.max(0, max - sold) };
}

export interface RolesClaimed {
  filled: number;
  total: number;
  open: number;
}

export function rolesClaimed(store: Store, venture: Venture): RolesClaimed {
  const rows = rosterFill(store, venture);
  const filled = rows.reduce((s, r) => s + r.filled.length, 0);
  const total = rows.reduce((s, r) => s + r.role.count, 0);
  return { filled, total, open: Math.max(0, total - filled) };
}

export interface Scarcity {
  seats?: SeatsLeft & { full: boolean };
  roles: RolesClaimed;
  /** When verified members could first take seats, while the venture still sells them. */
  firstLook?: { at: string; hoursAgo: number };
  /** Before the public opening: verified members are already in. */
  publicOpensAt?: string;
  closesAt?: string;
  waiting: number;
  /** The same numbers as sentences, for badges and share text. Empty when nothing is scarce. */
  lines: string[];
}

const ago = (h: number) => (h < 1 ? "less than an hour ago" : h < 72 ? `${h}h ago` : `${Math.floor(h / 24)} days ago`);

/** How scarce a venture's seats and roles really are, right now. Every number comes from the store. */
export function scarcityFor(store: Store, venture: Venture): Scarcity {
  const params = resolveParams(store);
  const roles = rolesClaimed(store, venture);
  const waiting = store.waitlist.filter((w) => w.ventureId === venture.id && !w.notifiedAt).length;
  const out: Scarcity = { roles, waiting, lines: [] };
  if (!isRevealed(store, venture) || venture.isProtocol) return out;
  const live = isLive(venture);
  if (venture.status === "pitched") {
    const s = seatsLeft(store, venture);
    if (s) {
      out.seats = { ...s, full: s.left === 0 };
      out.lines.push(s.left === 0 ? `All ${s.max} seats taken` : `${s.left} of ${s.max} seats left`);
    }
    const w = seatWindow(store, venture, params);
    if ((w.state === "early" || w.state === "open") && w.earlyAt) {
      const hoursAgo = Math.floor((new Date(store.meta.clock).getTime() - new Date(w.earlyAt).getTime()) / 3600e3);
      out.firstLook = { at: w.earlyAt, hoursAgo };
      out.lines.push(`Members got first look ${ago(hoursAgo)}`);
      if (w.state === "early") out.publicOpensAt = w.opensAt;
      out.closesAt = w.closesAt;
    }
  }
  if (live && roles.total) out.lines.push(`Roles: ${roles.filled} of ${roles.total} claimed`);
  return out;
}

export interface ShareCard {
  title: string;
  line: string;
  accent: string;
  eyebrow: string;
  stats: { label: string; value: string }[];
  /** True for an announced venture or batch: codename and teaser only. */
  teaser: boolean;
}

const day = (iso: string) => new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });

/** What a share card may show. An announced venture shows its codename, its teaser and the opening date, nothing more. */
export function ventureShareCard(store: Store, venture: Venture): ShareCard {
  const params = resolveParams(store);
  const cohort = cohortFor(store, venture);
  if (!isRevealed(store, venture)) {
    return {
      title: venture.codename ?? "A new venture",
      line: venture.teaser ?? "An agent-run venture in the next batch.",
      accent: "#18181b",
      eyebrow: cohort ? `${batchLabel(cohort.number)} · announced` : "Announced",
      stats: cohort
        ? [
            { label: "Verified members get first look", value: day(new Date(new Date(cohort.opensAt).getTime() - params.EARLY_ACCESS_HOURS * 3600e3).toISOString()) },
            { label: "Seats open to everyone", value: day(cohort.opensAt) },
          ]
        : [],
      teaser: true,
    };
  }
  const stats: ShareCard["stats"] = [];
  const sc = scarcityFor(store, venture);
  if (sc.seats) stats.push({ label: "Seats left", value: `${sc.seats.left} of ${sc.seats.max}` });
  if (isLive(venture) && sc.roles.total) stats.push({ label: "Roles claimed", value: `${sc.roles.filled} of ${sc.roles.total}` });
  if (sc.closesAt) stats.push({ label: "Window closes", value: day(sc.closesAt) });
  if (venture.status === "killed") stats.push({ label: "Status", value: "Ended; lessons public" });
  return { title: venture.name, line: venture.tagline, accent: venture.accent, eyebrow: cohort ? batchLabel(cohort.number) : "Agent-run venture", stats, teaser: false };
}

export function batchShareCard(store: Store, cohort: Cohort): ShareCard {
  const ventures = batchVentures(store, cohort);
  if (cohort.status === "announced") {
    const names = ventures.map((v) => v.codename).filter(Boolean).join(", ");
    return {
      title: batchLabel(cohort.number),
      line: names ? `Coming soon: ${names}.` : "Coming soon.",
      accent: "#18181b",
      eyebrow: "Announced",
      stats: [
        { label: "Ventures", value: String(ventures.length) },
        { label: "Seats open", value: day(cohort.opensAt) },
      ],
      teaser: true,
    };
  }
  const selling = ventures.filter((v) => v.status === "pitched");
  const left = selling.reduce((s, v) => s + (seatsLeft(store, v)?.left ?? 0), 0);
  const roles = ventures.filter(isLive).reduce((s, v) => s + rolesClaimed(store, v).open, 0);
  const stats: ShareCard["stats"] = [{ label: "Ventures", value: String(ventures.length) }];
  if (selling.length) stats.push({ label: "Seats left", value: String(left) });
  if (roles) stats.push({ label: "Roles open", value: String(roles) });
  if (cohort.status === "live") stats.push({ label: "Window closes", value: day(cohort.closesAt) });
  return {
    title: batchLabel(cohort.number),
    line: ventures.map((v) => v.name).join(" · "),
    accent: "#18181b",
    eyebrow: cohort.status === "live" ? "Selling seats now" : "Closed",
    stats,
    teaser: false,
  };
}
