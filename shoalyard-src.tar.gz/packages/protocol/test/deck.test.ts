import assert from "node:assert/strict";
import { test } from "node:test";
import type { Claim, Store } from "@av/schema";
import { allClaims, amendDeck, basisCounts, buildDeck, canWithdrawForDeck, claimById, decksFor, latestDeck, settleClaim, stampSeatDeck, validateDeck, type DeckDraft } from "../src/deck";
import { DECK_DRAFTS, deckDraftFor, pub, rec } from "../src/deck-content";
import { IDEA_LIBRARY } from "../src/ideas";
import { buySeat, stewardDecide, ventureBySlug } from "../src/ops";
import { buildSeed } from "../src/seed";
import { spawnVenture } from "../src/spawn";

const seed = buildSeed();

function fresh() {
  return structuredClone(seed) as Store;
}

/** Replace one claim in a draft. */
function withClaim(draft: DeckDraft, id: string, patch: Partial<Claim>): DeckDraft {
  const d = structuredClone(draft);
  for (const s of d.slides) s.claims = s.claims.map((c) => (c.id === id ? { ...c, ...patch } : c));
  return d;
}

test("every seeded deck validates, and every library idea gets one at spawn", () => {
  for (const slug of Object.keys(DECK_DRAFTS)) {
    const v = ventureBySlug(seed, slug)!;
    assert.deepEqual(validateDeck(seed, v, DECK_DRAFTS[slug]()), [], slug);
  }
  const s = fresh();
  const batch = s.cohorts.find((c) => c.status === "announced")!;
  for (const idea of IDEA_LIBRARY.filter((i) => !ventureBySlug(s, i.slug))) {
    const v = spawnVenture(s, batch, idea.classification, { idea });
    const deck = latestDeck(s, v.id)!;
    assert.equal(deck.seatPlan.rule, "derived", idea.slug);
    assert.ok(!deck.market, `${idea.slug} has no written market, so it shows as not sized yet`);
    assert.ok(allClaims(deck).every((c) => c.basis === "assumption" || c.id.startsWith("c-budget-") || c.basis === "estimate"));
    assert.equal(v.minRaiseUsd, deck.seatPlan.minRaiseUsd);
  }
});

test("each basis rule rejects its violations", () => {
  const v = ventureBySlug(seed, "site-record")!;
  const draft = DECK_DRAFTS["site-record"]();
  const errs = (d: DeckDraft) => validateDeck(seed, v, d).join(" ");
  assert.match(errs(withClaim(draft, "c-status-quo", { basis: "evidence", sources: [] })), /evidence needs a source/);
  assert.match(errs(withClaim(draft, "c-market-accounts", { basis: "evidence" })), /unchecked public data can back an estimate, not evidence/);
  assert.match(errs(withClaim(draft, "c-wedge", { method: undefined })), /an estimate needs its method/);
  assert.match(errs(withClaim(draft, "c-icp", { test: undefined })), /an assumption needs a test/);
  assert.match(errs(withClaim(draft, "c-icp", { text: "Per L-002, not for homeowners." })), /cite lessons as sources/);
  assert.match(errs(withClaim(draft, "c-gtm", { sources: [rec("rfe", "rfe-nope", "A request that doesn't exist")] })), /isn't on the record/);
  assert.ok(errs(withClaim(draft, "c-market-accounts", { sources: [{ ...pub("census-cbp", "Census"), verified: true }], basis: "evidence" })) === "", "checked public data can be evidence");
});

test("the office-hours answers are required and held to their bar", () => {
  const v = ventureBySlug(seed, "site-record")!;
  const draft = DECK_DRAFTS["site-record"]();
  const errs = (d: DeckDraft) => validateDeck(seed, v, d).join(" ");
  const noBuyer = structuredClone(draft);
  noBuyer.slides[0].claims = noBuyer.slides[0].claims.filter((c) => c.id !== "c-named-buyer");
  assert.match(errs(noBuyer), /Missing c-named-buyer/);
  assert.match(errs(withClaim(draft, "c-named-buyer", { text: "Subcontractors in the US." })), /names a category/);
  assert.match(errs(withClaim(draft, "c-demand", { text: "Forty people joined the waitlist." })), /Only commitments count/);
  assert.match(errs(withClaim(draft, "c-demand", { basis: "evidence", sources: [{ ...pub("x", "a survey"), verified: true }], test: undefined })), /must point at a commitment/);
  assert.match(errs({ ...draft, killCriteria: [] }), /kill rule/);
  assert.match(errs({ ...draft, premortem: draft.premortem.slice(0, 2) }), /top three ways/);
});

test("market, budget, contractor and ledger numbers have to add up", () => {
  const v = ventureBySlug(seed, "bid-desk")!;
  const draft = DECK_DRAFTS["bid-desk"]();
  const errs = (d: DeckDraft) => validateDeck(seed, v, d).join(" ");
  assert.match(errs(withClaim(draft, "c-market-som", { value: { n: 9_000_000, unit: "usd/yr" } })), /obtainable share must fit/);
  const pricier = structuredClone(draft);
  pricier.contractors[0].rateUsd = 250;
  assert.match(errs(pricier), /pays \$500 from seat money but the budget lists \$400/);
  const agentOnly = ventureBySlug(seed, "site-record")!;
  assert.match(validateDeck(seed, agentOnly, { ...DECK_DRAFTS["site-record"](), contractors: draft.contractors }).join(" "), /agent-only venture has no contractor plan/);
  const row = seed.ledger.find((l) => l.kind === "seat" && l.usd)!;
  assert.match(errs(withClaim(draft, "c-unit-margin", { basis: "evidence", sources: [rec("ledger", row.id, "A seat")], value: { n: row.usd! + 5, unit: "usd" } })), /ledger row shows/);
});

test("the ask is computed by code; a draft can't write it or set seats", () => {
  const s = fresh();
  const v = ventureBySlug(s, "bid-desk")!;
  const draft = DECK_DRAFTS["bid-desk"]();
  assert.match(validateDeck(s, v, { ...draft, slides: [...draft.slides, { key: "ask", headline: "Buy 5 seats", claims: [] }] }).join(" "), /ask is computed/);
  const deck = buildDeck(s, v, { ...draft, seatPlan: { min: 1 }, roster: [] } as DeckDraft, { author: "test", cause: { kind: "pitch" } });
  const plan = deck.seatPlan;
  assert.ok(plan.price && plan.priceUsd >= plan.price.minUsd && plan.priceUsd <= plan.price.upperUsd, "the price sits inside the band");
  assert.equal(plan.price!.upperUsd, Math.min(100, Math.floor(plan.proofBudgetUsd / plan.headcount)), "the top is proof ÷ the people it runs on, at most the maximum");
  assert.equal(plan.min, Math.max(plan.headcount, Math.ceil(plan.proofBudgetUsd / plan.priceUsd)));
  assert.equal(plan.cap, undefined, "nothing caps the count");
  assert.equal(plan.shortfallUsd, 0);
  assert.deepEqual(
    plan.atPrices.map((a) => a.priceUsd),
    [10, plan.price!.upperUsd],
  );
  assert.deepEqual(
    plan.price!.claims.map((c) => c.id),
    ["c-seat-people", "c-seat-buyer", "c-seat-market"],
  );
  assert.equal(deck.roster.reduce((t, r) => t + r.count, 0), 11);
  assert.deepEqual(deck.seatPlan.criticalRoles, ["icp-operator", "domain-expert", "legal"]);
  assert.equal(deck.slides.at(-1)?.key, "ask");
  const counts = basisCounts(deck);
  assert.equal(counts.evidence + counts.estimate + counts.assumption, allClaims(deck).length);
});

test("ventures pitched under the old rule keep their minimum and show the current rule", () => {
  const lien = latestDeck(seed, "lien-clock")!;
  assert.equal(lien.seatPlan.rule, "legacy-budget");
  assert.equal(lien.seatPlan.min, 22);
  assert.equal(lien.seatPlan.contingencyUsd, 0);
  assert.equal(lien.seatPlan.shortfallUsd, lien.seatPlan.proofBudgetUsd - 220, "the gap is on the deck");
  assert.equal(lien.seatPlan.priceUsd, 10, "it keeps the price it was pitched at");
  const cur = lien.currentRule!;
  assert.equal(cur.rule, "derived");
  assert.ok(cur.min >= cur.headcount && cur.priceUsd >= 10 && cur.priceUsd <= 100);
  assert.equal(ventureBySlug(seed, "lien-clock")!.minRaiseUsd, 220);
  assert.ok(lien.roster.some((r) => r.key === "legal" && r.critical), "the deck touches legal advice, so counsel is on the roster");
  assert.ok(!ventureBySlug(seed, "lien-clock")!.budget.some((b) => /buffer/i.test(b.label)), "the buffer line is shown as contingency");
});

test("a small change publishes at once; ids are stable and the old version is superseded", () => {
  const s = fresh();
  const v = ventureBySlug(s, "site-record")!;
  const { deck, decision } = amendDeck(s, v, { claims: [{ id: "c-icp", text: "Not for: homeowners, residential-only crews or GCs." }], title: "narrow the customer", reason: "A member asked who it is for.", cause: { kind: "qa" } });
  assert.equal(decision.status, "taken");
  assert.equal(deck.version, 2);
  assert.equal(decksFor(s, v.id)[0].status, "superseded");
  assert.equal(latestDeck(s, v.id)?.id, deck.id);
  assert.deepEqual(allClaims(deck).map((c) => c.id), allClaims(decksFor(s, v.id)[0]).map((c) => c.id));
  assert.ok(deck.changes.some((c) => c.path === "claims.c-icp" && !c.material));
});

test("moving a kill rule is a steward decision with old and new values on the record", () => {
  const s = fresh();
  const v = ventureBySlug(s, "site-record")!;
  const before = latestDeck(s, v.id)!;
  const moved = before.killCriteria.map((k) => (k.key === "first-sub" ? { ...k, by: "2027-08-31T00:00:00.000Z" } : k));
  const { deck, decision } = amendDeck(s, v, { patch: { killCriteria: moved }, title: "give it until August", reason: "Disputes take longer than planned.", cause: { kind: "steward" } });
  assert.equal(decision.status, "awaiting_steward");
  assert.ok(decision.binReasons.some((r) => /no quiet goalpost moves/.test(r)));
  assert.match(decision.reasoning, /2027-05-31 → .*2027-08-31/);
  assert.equal(deck.status, "proposed");
  assert.equal(latestDeck(s, v.id)?.id, before.id, "nothing changes until the steward signs");
  assert.throws(() => amendDeck(s, v, { claims: [{ id: "c-icp", text: "x y z" }], title: "t", reason: "r", cause: { kind: "steward" } }), /already has a deck change waiting/);
  stewardDecide(s, decision.id, true, "Fine; disputes do run long.", v.stewardHandle);
  assert.equal(latestDeck(s, v.id)?.version, 2);
  assert.equal(v.killDate, "2027-08-31T00:00:00.000Z");
});

test("a material change during the raise notifies holders, who may withdraw", () => {
  const s = fresh();
  const v = ventureBySlug(s, "lien-clock")!;
  const holder = "hvac_hank";
  stampSeatDeck(s, v.id, holder);
  const { decision } = amendDeck(s, v, { patch: { pricing: { ...latestDeck(s, v.id)!.pricing, price: 59 } }, title: "raise the price to $59", reason: "Postage costs more than planned.", cause: { kind: "steward" } });
  assert.equal(decision.status, "awaiting_steward");
  assert.equal(canWithdrawForDeck(s, v, holder), false);
  stewardDecide(s, decision.id, true, "Checked the postage quote.", v.stewardHandle);
  assert.ok(s.ledger.some((l) => l.kind === "notify" && l.handle === holder && /deck changed \(v2\).*withdraw/.test(l.note ?? "")));
  assert.equal(canWithdrawForDeck(s, v, holder), true);
  buySeat(s, { slug: v.slug, handle: "fresh_fay" });
  stampSeatDeck(s, v.id, "fresh_fay");
  assert.equal(canWithdrawForDeck(s, v, "fresh_fay"), false, "someone who bought under the new version can't");
});

test("a rejected change leaves the deck as it was", () => {
  const s = fresh();
  const v = ventureBySlug(s, "lumper-line")!;
  const { decision } = amendDeck(s, v, { patch: { pricing: { ...latestDeck(s, v.id)!.pricing, price: 149 } }, title: "raise the price", reason: "Brokers pay more for data.", cause: { kind: "steward" } });
  stewardDecide(s, decision.id, false, "Not without a pricing answer.", v.stewardHandle);
  assert.equal(decksFor(s, v.id).length, 1);
  assert.equal(latestDeck(s, v.id)?.pricing.price, 99);
});

test("a request settles a claim: supported becomes evidence, disproved is struck through and kept", () => {
  const s = fresh();
  const v = ventureBySlug(s, "lien-clock")!;
  const rfeId = "rfe-lien-clock-demand";
  settleClaim(s, v, { claimId: "c-status-quo", rfeId, result: "disproved", label: "Demand check" });
  const struck = claimById(latestDeck(s, v.id)!, "c-status-quo")!;
  assert.ok(struck.disproved);
  assert.ok(struck.sources.some((x) => x.ref === rfeId));
  settleClaim(s, v, { claimId: "c-icp", rfeId, result: "supported", label: "Demand check" });
  const backed = claimById(latestDeck(s, v.id)!, "c-icp")!;
  assert.equal(backed.basis, "evidence");
  assert.equal(backed.test, undefined);
  assert.equal(latestDeck(s, v.id)?.version, 3);
});

test("a regulated activity needs a counsel line in the risks", () => {
  const v = ventureBySlug(seed, "lien-clock")!;
  const draft = deckDraftFor("lien-clock")!;
  const risks = draft.slides.find((x) => x.key === "risks")!;
  risks.claims = risks.claims.filter((c) => !/counsel|lawyer/i.test(c.text));
  assert.match(validateDeck(seed, v, draft).join(" "), /touches legal advice; its risks need a line on what counsel checks/);
});
