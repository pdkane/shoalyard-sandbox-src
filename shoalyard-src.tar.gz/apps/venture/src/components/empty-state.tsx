import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon: Icon,
  title,
  children,
  className,
}: {
  icon: LucideIcon;
  title: string;
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center rounded-xl border border-dashed border-zinc-300 px-6 py-10 text-center", className)}>
      <span className="mb-3 flex size-10 items-center justify-center rounded-full bg-zinc-100 text-zinc-500">
        <Icon className="size-5" />
      </span>
      <p className="font-medium text-zinc-900">{title}</p>
      {children && <div className="mt-1 max-w-sm text-sm text-zinc-500">{children}</div>}
    </div>
  );
}
