import Link from "next/link";
import { Lock } from "lucide-react";
import type { LessonTeaser } from "@av/protocol";
import { Pill } from "@/components/badges";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const MEMBERS_PROMPT = "Become a member to see what earlier ventures learned";

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

/** What a visitor sees in place of the lessons: that they exist, and how to read them. */
export function MembersOnlyLessons({
  teaser,
  title,
  className,
  showTopics = true,
}: {
  teaser: LessonTeaser;
  title?: string;
  className?: string;
  showTopics?: boolean;
}) {
  return (
    <div className={cn("space-y-3 rounded-xl border border-dashed border-zinc-300 bg-white p-4 text-sm", className)}>
      <p className="flex items-center gap-2 font-medium text-zinc-900">
        <Lock className="size-4 text-zinc-500" aria-hidden />
        {title ?? `${plural(teaser.count, "lesson")} from ${plural(teaser.ventures, "earlier venture")}`}
      </p>
      <p className="text-pretty text-zinc-600">
        Every decision stays public. The lessons drawn from them are for members: they are what members built by doing the work.
      </p>
      {showTopics && teaser.topics.length > 0 && (
        <div className="flex flex-wrap gap-1.5" aria-label="Lesson topics">
          {teaser.topics.map((t) => (
            <Pill key={t}>{t}</Pill>
          ))}
        </div>
      )}
      <Link href="/onboarding" className={cn(buttonVariants({ size: "sm", variant: "outline" }), "h-auto py-1.5 text-left whitespace-normal")}>
        {MEMBERS_PROMPT}
      </Link>
    </div>
  );
}

/** A lesson citation on public pages: the count, never the text. */
export function lessonCitation(n: number) {
  return `Followed ${plural(n, "earlier lesson")} (visible to members)`;
}
