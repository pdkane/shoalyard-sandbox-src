import Link from "next/link";
import { SearchX } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-3 py-16 text-center">
      <span className="flex size-11 items-center justify-center rounded-full bg-zinc-100 text-zinc-500">
        <SearchX className="size-5" />
      </span>
      <h1 className="text-lg font-semibold">Not found</h1>
      <p className="text-sm text-zinc-500">That venture, batch or request doesn&apos;t exist, or the demo data was reset.</p>
      <Link href="/" className={buttonVariants()}>
        Back to ventures
      </Link>
    </div>
  );
}
