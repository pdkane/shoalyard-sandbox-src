# Shoalyard brand

The brand kit for the site. The full board, with sample pages and motion, is the Shoalyard Brand design canvas; this folder is what ships.

One brand: **Shoalyard**, the yard that builds ventures. Tagline: **Many hands. One yard.** Clarity: *Agents build. People decide.*

## Files

| Path | What it is |
| --- | --- |
| `svg/wordmark.svg` | Primary lead-in wordmark on white: four sea-glass strokes, then SHOALYARD in ink. 600 × 84. |
| `svg/wordmark-on-ink.svg` | The same for ink headers and footers: light sea-glass strokes, white name. |
| `svg/wordmark-compact*.svg` | Nav size (210 × 28), drawn heavier so it holds at 20–28px tall. |
| `svg/wordmark-mono-ink.svg`, `-mono-white.svg` | One colour, for fax, emboss, single-colour print. |
| `svg/mark.svg`, `mark-on-ink.svg` | The four strokes alone. |
| `svg/app-icon.svg` | Strokes on an ink tile. |
| `svg/favicon.svg` | Three strokes on an ink tile, for 16–48px. |
| `svg/seal.svg`, `seal-on-ink.svg` | Double-ring seal: "A SHOALYARD VENTURE" between the rings, top and bottom. |
| `svg/seal-small*.svg` | Below 40px: rings and three strokes, no ring text. |
| `png/` | PNG renders of the above at the sizes in the file names. |
| `tokens.css`, `tokens.json` | Color and type tokens. |
| `build/` | The script that drew these files from the canvas geometry. |

All text in the SVGs is outlined, so they render without the fonts installed. Copies of the SVGs live in `apps/venture/public/brand/` so the app can use `/brand/wordmark.svg`. The app's favicon (`src/app/favicon.ico`, `icon.svg`) and Apple touch icon (`apple-icon.png`) come from here too.

## Wordmark

- SHOAL is Archivo 740, YARD is Archivo 380, both at width 112. The weight split is what makes the compound read; never set the name in one weight.
- Strokes are sea-glass (`#2F6F6A`) on white, light sea-glass (`#7FB8B0`) on ink. The name is ink on white, white on ink.
- Clear space on every side is twice the gap between two strokes.
- In running text, write **Shoalyard** as one word, normal case. The caps are the logo only.
- Don't redraw it in live text. Use the SVG.

## Seal

- Only on ventures Shoalyard builds. It is the mark "{Name}, a Shoalyard venture" (Article 7).
- A venture handed off to an entrepreneur stops showing it, and three upheld breaches remove it for good.
- Below 40px use `seal-small`, which drops the ring text.

## Color

| Token | Hex | Use |
| --- | --- | --- |
| white | `#FFFFFF` | Every page background. |
| mist | `#F2F5F4` | Quiet panels, alternating rows. |
| line | `#D9E1DF` | Borders and dividers. |
| ink | `#0B2128` | Text, wordmark, header and footer grounds. |
| metal | `#4B575B` | Secondary text. |
| chalk | `#DCE6E3` | Text on ink. |
| seaglass | `#2F6F6A` | CTAs, links, the strokes. |
| seaglass-deep | `#245652` | CTA hover and pressed. |
| seaglass-light | `#7FB8B0` | Strokes and accents on ink. |
| seaglass-tint | `#E3EFED` | Selected and highlighted backgrounds. |
| timber | `#6A4E3A` | Mono labels and eyebrows. |

Rules: pages are white. Ink and sea-glass are for headers, footers and CTAs, never a whole page background. No yellow.

In the app these are Tailwind colors (`bg-seaglass`, `hover:bg-seaglass-deep`, `text-timber`, `border-line`, `bg-mist`, `text-metal`), and the shadcn roles point at them: `primary` is sea-glass, `muted` is mist, `border` is line, `ring` is light sea-glass.

## Type

| Role | Face | In the app |
| --- | --- | --- |
| Display and wordmark | Archivo, width 112 (headings at 100) | `font-heading`, plus `[font-stretch:112%]` for display |
| Body | IBM Plex Sans 400 / 500 / 600 | `font-sans` (default) |
| Labels | IBM Plex Mono 400 / 500, uppercase, `tracking-[0.08em]`, timber | `font-mono` |

## Motion

One move only: the four strokes, at the mark's height, chase each other around a vertical axis seen from the side, then settle into the mark. CSS keyframes with `rotateY` and `translateZ` under `perspective`; the canvas Motion board has the working keyframes. Respect `prefers-reduced-motion` and show the settled mark.

## Don'ts

- No purple AI gradients, crypto imagery, cream and terracotta, serifs, broadsheet layouts, or a dark dashboard as the brand face.
- No one-weight wordmark, no teal or ink page backgrounds, no yellow.
- Never suggest paying earns units, or that some answers earn more. Every accepted answer earns the same share.
- Don't show features, payments or numbers that are not built or real.

## What's done in the app, and what isn't

Done: the brand fonts load through `next/font`, the colors are tokens in `globals.css`, the header uses the compact wordmark, the page background is white, and the favicon and touch icon are the brand's.

Not done: most components still use Tailwind's `zinc` greys and `rose` accents directly. Swap them for the tokens above (`zinc-900` → `ink`, `zinc-500/600` → `metal`, `zinc-200` → `line`, `zinc-50` → `mist`, `rose` accents → `seaglass` or `timber`). The Open Graph images (`src/lib/og.tsx`) still use the default look.

## Regenerating

```bash
cd brand/build
mkdir -p fonts
curl -sSLf -o fonts/Archivo.ttf "https://github.com/google/fonts/raw/main/ofl/archivo/Archivo%5Bwdth,wght%5D.ttf"
curl -sSLf -o fonts/PlexMono-Regular.ttf "https://github.com/google/fonts/raw/main/ofl/ibmplexmono/IBMPlexMono-Regular.ttf"
python3 -m venv .venv && .venv/bin/pip install fonttools uharfbuzz
.venv/bin/python build.py ../svg
node png.cjs "$(cd ../.. && pwd)/node_modules/.pnpm/$(ls ../../node_modules/.pnpm | grep '^sharp@' | head -1)/node_modules/sharp" ../svg ../png
```
