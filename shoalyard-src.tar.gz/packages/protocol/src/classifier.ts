import type { DecisionBin, DecisionFacts, ParamValues } from "@av/schema";

export interface Classification {
  bin: DecisionBin;
  reasons: string[];
}

type ClassifierParams = Pick<
  ParamValues,
  | "GATE_SPEND_USD"
  | "GATE_CONTRACTS"
  | "GATE_PRICING"
  | "GATE_NEW_OUTBOUND_DOMAIN"
  | "GATE_PUBLIC_POSTS"
  | "GATE_HIRING"
  | "GATE_GOALPOST_MOVES"
  | "ADVISORY_CONFIDENCE"
>;

/**
 * Default classifier. Hard gates first (any one sends the decision to the
 * steward), then the advisory threshold on the agent's own confidence.
 */
export function classify(
  facts: Partial<DecisionFacts>,
  confidence: number,
  params: ClassifierParams,
): Classification {
  const gates: string[] = [];
  const spend = facts.spendUsd ?? 0;
  if (spend > params.GATE_SPEND_USD) {
    gates.push(`Spends $${spend.toLocaleString("en-US")}, over the $${params.GATE_SPEND_USD} that needs sign-off`);
  }
  if (facts.contract && params.GATE_CONTRACTS) gates.push("Signs or changes a contract");
  if (facts.pricingChange && params.GATE_PRICING) gates.push("Changes a price");
  if (facts.newOutboundDomain && params.GATE_NEW_OUTBOUND_DOMAIN) gates.push("Sends email from a new domain");
  if (facts.publicPost && params.GATE_PUBLIC_POSTS) gates.push("Public post: the agent writes it, the steward posts it");
  if (facts.hiresPerson && params.GATE_HIRING) gates.push("Hires or contracts a person");
  if (facts.contractorPitch && params.GATE_HIRING) gates.push("Pitches a venture that pays contractors for the work");
  if (facts.goalpostMove && params.GATE_GOALPOST_MOVES) gates.push("Moves a kill rule, a target or the primary metric: no quiet goalpost moves");
  else if (facts.materialDeckChange) gates.push("Changes a part of the deck people relied on when they took a seat");
  if (facts.liftoff) gates.push("The roster isn't filled in time: the steward extends once, or the venture ends and refunds");
  if (facts.review) gates.push(`Monthly review (${facts.review}): the agent recommends, the steward signs`);
  if (gates.length) return { bin: "gated", reasons: gates };

  const pct = (n: number) => `${Math.round(n * 100)}%`;
  if (confidence < params.ADVISORY_CONFIDENCE) {
    return {
      bin: "advisory",
      reasons: [`The agent is only ${pct(confidence)} sure, so it asked members first (it asks below ${pct(params.ADVISORY_CONFIDENCE)})`],
    };
  }
  return {
    bin: "auto",
    reasons: [`Nothing here needs sign-off, and the agent is ${pct(confidence)} sure (it asks members below ${pct(params.ADVISORY_CONFIDENCE)})`],
  };
}
