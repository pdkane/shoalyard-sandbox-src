import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ATTRIBUTE_LABELS, attributeStatuses, badgesFor, hasSeat, memberByHandle, seatRefunds, SOURCE_LABELS, verifiedShare } from "@av/protocol";
import { AccountLabel } from "@/components/account-label";
import { Pill } from "@/components/badges";
import { AttributeTable, MemberBadges } from "@/components/protocol-ui";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { formatDate } from "@/lib/format";

export async function generateMetadata(props: PageProps<"/m/[handle]">): Promise<Metadata> {
  const { handle } = await props.params;
  return { title: `@${handle}` };
}

/** Public profile: badges and the verified share only. Linked account URLs and names stay with the steward. */
export default async function MemberPage(props: PageProps<"/m/[handle]">) {
  const { handle } = await props.params;
  const { store, params, viewer } = await getData();
  const m = memberByHandle(store, decodeURIComponent(handle));
  if (!m) notFound();
  const seats = store.ventures.filter((v) => hasSeat(store, v.id, m.handle));
  const refunded = store.ventures.filter((v) => seatRefunds(store, v.id, m.handle).count > 0);
  const answers = store.responses.filter((r) => r.handle === m.handle).length;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="space-y-3">
        {m.handle === viewer && <AccountLabel />}
        <h1 className="text-2xl font-semibold tracking-tight">@{m.handle}</h1>
        <p className="text-sm text-zinc-600">
          {m.role} · {m.industry} · joined {formatDate(m.joinedAt)}
        </p>
        <MemberBadges badges={badgesFor(m)} labels={SOURCE_LABELS} share={verifiedShare(m, params)} qualification={m.qualification} />
      </div>
      <Card size="sm">
        <CardHeader>
          <CardTitle>Profile</CardTitle>
          <CardDescription>Which details have been checked, and how. The linked accounts are never shown.</CardDescription>
        </CardHeader>
        <CardContent>
          <AttributeTable rows={attributeStatuses(m, params)} labels={ATTRIBUTE_LABELS} sourceLabels={SOURCE_LABELS} />
        </CardContent>
      </Card>
      <Card size="sm">
        <CardHeader>
          <CardTitle>Activity</CardTitle>
          <CardDescription>
            {answers} answer{answers === 1 ? "" : "s"} · {m.reputationTier[0].toUpperCase() + m.reputationTier.slice(1)} member
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-1.5">
          {seats.length === 0 && refunded.length === 0 ? (
            <span className="text-sm text-zinc-500">No seats yet.</span>
          ) : (
            <>
              {seats.map((v) => (
                <Link key={v.id} href={`/v/${v.slug}`}>
                  <Pill>{v.name}</Pill>
                </Link>
              ))}
              {refunded.map((v) => (
                <Link key={v.id} href={`/v/${v.slug}`}>
                  <Pill className="border-emerald-200 bg-emerald-50 text-emerald-800">{v.name} · refunded</Pill>
                </Link>
              ))}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
