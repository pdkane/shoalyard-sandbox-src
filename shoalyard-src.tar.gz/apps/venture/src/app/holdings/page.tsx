import type { Metadata } from "next";
import Link from "next/link";
import { Wallet } from "lucide-react";
import { holdingsFor } from "@av/protocol";
import { GRANT_STATUS_LABELS } from "@av/schema";
import { Pill, StatusBadge } from "@/components/badges";
import { AccountLabel } from "@/components/account-label";
import { EmptyState } from "@/components/empty-state";
import { buttonVariants } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { formatDate, formatNumber, formatPct, formatUnits, formatUsd } from "@/lib/format";

export const metadata: Metadata = { title: "Your units" };

export default async function HoldingsPage() {
  const { store, params, viewer, member } = await getData();
  const rows = member ? holdingsFor(store, viewer, params) : [];
  const grants = store.grants.filter((g) => g.handle === viewer).sort((a, b) => b.at.localeCompare(a.at));
  const vName = new Map(store.ventures.map((v) => [v.id, v.name]));
  const totalDistributed = rows.reduce((s, r) => s + r.distributedUsd, 0);
  const seats = rows.filter((r) => r.seat).length;

  return (
    <div className="space-y-8">
      <div>
        <AccountLabel />
        <h1 className="text-2xl font-semibold tracking-tight">Your units</h1>
        <p className="text-sm text-zinc-500">
          @{viewer}&apos;s seats and the <TermServer id="unit">units</TermServer> you&apos;ve earned. Units{" "}
          <TermServer id="vesting">vest</TermServer> {params.VESTING_DAYS} days after you earn them. Vested units get a vote and a share of each
          payout.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          ["Seats", String(seats)],
          ["Ventures with units", String(rows.filter((r) => r.units > 0).length)],
          ["Times you earned units", String(grants.length)],
          ["Payouts received", formatUsd(totalDistributed, true)],
        ].map(([k, v]) => (
          <div key={k} className="rounded-xl border border-zinc-200 bg-white p-4">
            <p className="text-2xl font-semibold tabular-nums">{v}</p>
            <p className="text-xs text-zinc-500">{k}</p>
          </div>
        ))}
      </div>

      {rows.length === 0 ? (
        <EmptyState icon={Wallet} title="No units yet">
          Take a seat, get verified and answer a request to earn your first units.
          <div className="mt-3">
            <Link href="/" className={buttonVariants({ size: "sm" })}>
              Find a venture
            </Link>
          </div>
        </EmptyState>
      ) : (
        <div className="overflow-hidden rounded-xl border border-zinc-200 bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Venture</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Seat</TableHead>
                <TableHead className="text-right">Units</TableHead>
                <TableHead className="text-right">Vested</TableHead>
                <TableHead className="text-right">Share of venture</TableHead>
                <TableHead className="text-right">Paid to you</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.venture.id}>
                  <TableCell>
                    <Link href={`/v/${r.venture.slug}`} className="font-medium hover:underline">
                      {r.venture.name}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={r.venture.status} />
                  </TableCell>
                  <TableCell>
                    {r.seat ? (
                      "Yes"
                    ) : r.refundedUsd > 0 ? (
                      <span className="inline-flex items-center gap-1.5">
                        <Pill className="border-emerald-200 bg-emerald-50 text-emerald-800">Refunded</Pill>
                        <span className="text-xs text-emerald-700 tabular-nums">{formatUsd(-r.refundedUsd, true)}</span>
                      </span>
                    ) : r.venture.isProtocol ? (
                      "Member (no seat needed)"
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">{formatNumber(r.units)}</TableCell>
                  <TableCell className="text-right tabular-nums">{formatNumber(r.vested)}</TableCell>
                  <TableCell className="text-right tabular-nums">{formatPct(r.pctOfInterests, 2)}</TableCell>
                  <TableCell className="text-right tabular-nums">{formatUsd(r.distributedUsd, true)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {grants.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold tracking-tight">Times you earned units</h2>
          <ul className="divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white">
            {grants.map((g) => (
              <li key={g.id} className="flex flex-col gap-1 p-4 text-sm sm:flex-row sm:items-center sm:gap-4">
                <span className="w-36 shrink-0 font-medium">{vName.get(g.ventureId)}</span>
                <span className="flex-1 text-zinc-600">
                  {g.slice === "rfe" && g.rfeId ? (
                    <Link href={`/rfe/${g.rfeId}`} className="hover:underline">
                      {store.rfes.find((r) => r.id === g.rfeId)?.title ?? "Request"}
                    </Link>
                  ) : (
                    (g.note ?? { steward: "Steward's units", cohort: "Batch-wide share", founder: "Founding steward's units", rfe: "Request" }[g.slice])
                  )}
                </span>
                <span className="tabular-nums">{formatUnits(g.units)}</span>
                <span className="w-44 text-xs text-zinc-500 sm:text-right">
                  {GRANT_STATUS_LABELS[g.status]}
                  {g.vestsAt && g.status === "accepted" ? ` · vests ${formatDate(g.vestsAt)}` : ""}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
