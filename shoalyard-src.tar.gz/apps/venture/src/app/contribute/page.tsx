import type { Metadata } from "next";
import Link from "next/link";
import { CONTRIBUTE_PATH_LINE, EARNED_NOT_BOUGHT, HERO_CLARITY, LEGACY_SEAT_NOTE } from "@av/protocol";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Steer and teach",
  description: "Contribute judgment, taste, and knowledge. Accepted work is paid in cash from the proof budget — answering does not buy ownership.",
};

export default function ContributePage() {
  return (
    <div className="mx-auto max-w-3xl space-y-10">
      <header className="space-y-4">
        <p className="font-mono text-[13px] tracking-[0.08em] text-timber">CONTRIBUTE</p>
        <h1
          className="font-heading text-[clamp(2rem,4vw,2.75rem)] leading-none tracking-[-0.02em] text-ink"
          style={{ fontStretch: "112%", fontWeight: 760 }}
        >
          Steer and teach
        </h1>
        <p className="text-lg leading-relaxed text-metal">{HERO_CLARITY}</p>
      </header>

      <section className="space-y-3 text-base leading-relaxed text-ink">
        <p>{CONTRIBUTE_PATH_LINE}</p>
        <p className="text-sm text-metal">{EARNED_NOT_BOUGHT}</p>
        <ul className="list-disc space-y-2 pl-5 text-sm text-metal">
          <li>Judgment, taste, knowledge, introductions — work the agent cannot fake.</li>
          <li>Equal cash treatment for similar accepted work.</li>
          <li>Late accepted work can still be paid.</li>
          <li>Capital belongs on the seed path — not mixed into answering.</li>
        </ul>
      </section>

      <p className="text-sm text-metal">{LEGACY_SEAT_NOTE}</p>

      <div className="flex flex-wrap gap-3">
        <Link href="/batches" className={cn(buttonVariants({ size: "lg" }), "rounded-none")}>
          Browse ventures
        </Link>
        <Link href="/invest" className={cn(buttonVariants({ size: "lg", variant: "outline" }), "rounded-none")}>
          I want to put capital in
        </Link>
        <Link href="/about" className="self-center text-sm font-semibold text-seaglass hover:text-seaglass-deep">
          About the yard
        </Link>
      </div>
    </div>
  );
}
