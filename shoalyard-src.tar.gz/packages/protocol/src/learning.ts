import { seatPriceOf } from "./sizing";
import {
  RFE_TYPE_LABELS,
  type ClassificationAxis,
  type Cohort,
  type DecisionBin,
  type DecisionFacts,
  type Evidence,
  type Lesson,
  type ParamKey,
  type ParamValues,
  type Rfe,
  type RfeType,
  type ShareChannel,
  type Store,
  type Tag,
  type Venture,
} from "@av/schema";
import { batchLabel } from "./batches";
import { clusterLabel, clusterLookup, isOpen, nStatusFor, postRfe, responsesFor, protocolVenture, seatRefunds, seatsSold } from "./ops";
import { seatsNeeded } from "./n-engine";
import { IDEA_LIBRARY } from "./ideas";
import { settingChangeTitle } from "./glossary";
import { resolveParams } from "./params";
import { SHARE_CHANNEL_LABELS, shareFunnelStats, type ShareFunnelStats } from "./sharing";
import { classificationLine, classificationOf } from "./tags";
import { addDays, DAY_MS, HOUR_MS, round } from "./util";

/* ---------- statistics ---------- */

export function median(xs: number[]): number {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

const hoursBetween = (a: string, b: string) => (Date.parse(b) - Date.parse(a)) / HOUR_MS;
const daysBetween = (a: string, b: string) => (Date.parse(b) - Date.parse(a)) / DAY_MS;

export interface TypeStat {
  type: RfeType;
  samples: number;
  medianUnits: number;
  counters: number;
  medianHoursToFill: number;
  evidence: Evidence[];
}

export interface ClusterStat {
  cluster: string;
  answers: number;
  followed: number;
  right: number;
}

export interface DraftStat {
  rfeId: string;
  ventureId: string;
  channel: string;
  title: string;
  arrivals: number;
  qualified: number;
  seats: number;
  responses: number;
  followed: number;
  right: number;
}

/** Outcomes for ventures sharing the same values on some classification axes. */
export interface OutcomeStat {
  key: string;
  /** "Subscription software · Small business · Healthcare" */
  label: string;
  values: Partial<Record<ClassificationAxis, string>>;
  ventureIds: string[];
  tried: number;
  /** Reached the minimum: sold enough seats to start. */
  funded: number;
  survived: number;
  /** Funded and still alive. */
  survivedFunded: number;
  medianDaysToFirstCustomer?: number;
  killed: number;
}

/** The standard cut for outcomes and lessons: business model, customer, end market. */
export const OUTCOME_CUT: readonly ClassificationAxis[] = ["businessModel", "customer", "endMarket"];

export interface LearningStats {
  byType: TypeStat[];
  agreement: { type: RfeType; samples: number; medianResponses: number; medianAgreement: number }[];
  clusters: ClusterStat[];
  killTimes: { ventureId: string; name: string; days: number; reason?: string }[];
  drafts: DraftStat[];
  /** Outcomes by business model, customer and end market. */
  cuts: OutcomeStat[];
  advisory: { samples: number; agreedRate: number; minConfidence: number; evidence: Evidence[] };
  /** Share links by channel and venture: visit to sign-up, verification, seat and role. */
  shares: ShareFunnelStats;
  /** Seats sold against seats needed, by venture, with the price and customer type, so later prices come from evidence. */
  sellThrough: SellThroughRow[];
}

export interface SellThroughRow {
  ventureId: string;
  priceUsd: number;
  customer: string;
  sold: number;
  needed: number;
  status: string;
}

function inScope(store: Store, ventureIds?: Set<string>) {
  return (ventureId: string) => !ventureIds || ventureIds.has(ventureId);
}

/** Has a grant been forfeited (proved wrong)? Otherwise it stood. */
function provedRight(store: Store, rfeId: string, handle: string): boolean {
  const gs = store.grants.filter((g) => g.rfeId === rfeId && g.handle === handle);
  return gs.length > 0 && gs.every((g) => g.status !== "forfeited");
}

/** Attribution for one recruiting draft: arrivals → qualified → seats → answers followed → answers that stood. */
export function draftStat(store: Store, r: Rfe, params: ParamValues = resolveParams(store)): DraftStat & { handles: string[] } {
  const arrivals = store.members.filter((m) => m.source === r.id);
  const handles = new Set(arrivals.map((m) => m.handle));
  const responses = store.responses.filter((x) => handles.has(x.handle));
  let followed = 0;
  let right = 0;
  for (const resp of responses) {
    const rfe = store.rfes.find((x) => x.id === resp.rfeId);
    if (!rfe || rfe.status !== "resolved" || rfe.kind !== "request") continue;
    const n = nStatusFor(store, rfe, params);
    if (rfe.format !== "choice" || resp.choice === n.leading) {
      followed++;
      if (provedRight(store, rfe.id, resp.handle)) right++;
    }
  }
  return {
    rfeId: r.id,
    ventureId: r.ventureId,
    channel: r.gtm?.channel ?? "outreach",
    title: r.title,
    arrivals: arrivals.length,
    qualified: arrivals.filter((m) => m.qualification === "qualified").length,
    seats: store.ledger.filter((l) => l.kind === "seat" && l.ref === r.id).length,
    responses: responses.length,
    followed,
    right,
    handles: [...handles],
  };
}

export function learningStats(store: Store, scope?: { ventureIds?: string[] }): LearningStats {
  const params = resolveParams(store);
  const ids = scope?.ventureIds ? new Set(scope.ventureIds) : undefined;
  const ok = inScope(store, ids);
  const resolved = store.rfes.filter((r) => ok(r.ventureId) && r.kind === "request" && !r.gtm && r.status === "resolved" && r.resolvedAt);

  const byType: TypeStat[] = [];
  for (const type of Object.keys(RFE_TYPE_LABELS) as RfeType[]) {
    if (type === "capital") continue;
    const rows = resolved.filter((r) => r.type === type);
    const units = rows.flatMap((r) => store.grants.filter((g) => g.rfeId === r.id).map((g) => g.units));
    if (!rows.length) continue;
    byType.push({
      type,
      samples: rows.length,
      medianUnits: round(median(units), 2),
      counters: rows.reduce((s, r) => s + responsesFor(store, r.id).filter((x) => x.counterUnits).length, 0),
      medianHoursToFill: round(median(rows.map((r) => hoursBetween(r.postedAt, r.resolvedAt!))), 1),
      evidence: rows.slice(0, 4).map((r) => ({ kind: "rfe", id: r.id, label: r.title })),
    });
  }

  const agreement = (["judgment", "knowledge"] as RfeType[])
    .map((type) => {
      const rows = resolved.filter((r) => r.type === type && (r.format === "choice" || r.format === "scale"));
      const ns = rows.map((r) => nStatusFor(store, r, params));
      return {
        type,
        samples: rows.length,
        medianResponses: median(ns.map((n) => n.effective)),
        medianAgreement: round(median(ns.map((n) => n.agreement)), 2),
      };
    })
    .filter((a) => a.samples > 0);

  const cluster = clusterLookup(store);
  const clusterMap = new Map<string, ClusterStat>();
  for (const r of resolved) {
    const n = nStatusFor(store, r, params);
    for (const resp of responsesFor(store, r.id)) {
      const c = cluster(resp.handle);
      const row = clusterMap.get(c) ?? { cluster: c, answers: 0, followed: 0, right: 0 };
      row.answers++;
      const followed = r.format === "choice" ? !!n.leading && resp.choice === n.leading : true;
      if (followed) {
        row.followed++;
        if (provedRight(store, r.id, resp.handle)) row.right++;
      }
      clusterMap.set(c, row);
    }
  }

  const ventures = store.ventures.filter((v) => !v.isProtocol && ok(v.id));
  const killTimes = ventures
    .filter((v) => v.status === "killed")
    .map((v) => {
      const start = v.statusHistory.find((h) => h.status === "pitched")?.at ?? v.createdAt;
      const end = v.statusHistory.find((h) => h.status === "killed")?.at ?? store.meta.clock;
      return { ventureId: v.id, name: v.name, days: Math.round(daysBetween(start, end)), reason: v.postMortem?.killReason };
    });

  const drafts: DraftStat[] = store.rfes.filter((r) => r.gtm?.postedAt && ok(r.ventureId)).map((r) => draftStat(store, r, params));

  const cuts = outcomesBy(store, OUTCOME_CUT, ids);

  const advisoryRows = store.decisions.filter(
    (d) => ok(d.ventureId) && d.bin === "advisory" && d.rfeId && (d.status === "taken" || d.status === "rejected") && !d.contradicts?.length,
  );
  const advisory = {
    samples: advisoryRows.length,
    agreedRate: advisoryRows.length ? advisoryRows.filter((d) => d.status === "taken").length / advisoryRows.length : 0,
    minConfidence: advisoryRows.length ? Math.min(...advisoryRows.map((d) => d.confidence)) : 0,
    evidence: advisoryRows.slice(0, 4).map((d) => ({ kind: "decision" as const, id: d.id, label: d.title })),
  };

  return {
    byType,
    agreement,
    clusters: [...clusterMap.values()].sort((a, b) => b.right - a.right || b.answers - a.answers),
    killTimes,
    drafts,
    cuts,
    advisory,
    shares: shareFunnelStats(store, ids),
    sellThrough: ventures
      .filter((v) => v.statusHistory.some((h) => h.status === "pitched"))
      .map((v) => {
        const priceUsd = seatPriceOf(v, params);
        return {
          ventureId: v.id,
          priceUsd,
          customer: classificationOf(v).customer ?? "Not classified",
          sold: seatsSold(store, v.id) + (v.status === "killed" ? seatRefunds(store, v.id).count : 0),
          needed: seatsNeeded(v.minRaiseUsd, priceUsd),
          status: v.status,
        };
      })
      .sort((a, b) => a.priceUsd - b.priceUsd || b.sold / b.needed - a.sold / a.needed),
  };
}

const reached = (v: Venture, s: Venture["status"]) => v.statusHistory.some((h) => h.status === s);

/**
 * Group ventures that have left "generated" by their values on `axes` (confirmed
 * tags, else the agent's proposals) and count what happened to each group.
 */
export function outcomesBy(store: Store, axes: readonly ClassificationAxis[], ventureIds?: Set<string>): OutcomeStat[] {
  type Group = { values: Partial<Record<ClassificationAxis, string>>; ventures: Venture[] };
  const groups = new Map<string, Group>();
  for (const v of store.ventures) {
    if (v.isProtocol || v.status === "generated" || (ventureIds && !ventureIds.has(v.id))) continue;
    const c = classificationOf(v);
    if (axes.some((a) => !c[a])) continue;
    const values = Object.fromEntries(axes.map((a) => [a, c[a]!]));
    const key = axes.map((a) => c[a]).join("|");
    const g: Group = groups.get(key) ?? { values, ventures: [] };
    g.ventures.push(v);
    groups.set(key, g);
  }
  return [...groups.entries()]
    .map(([key, { values, ventures: vs }]) => {
      const firstCustomer = vs
        .map((v) => {
          const a = v.statusHistory.find((h) => h.status === "pitched")?.at;
          const b = v.statusHistory.find((h) => h.status === "customer1")?.at;
          return a && b ? daysBetween(a, b) : undefined;
        })
        .filter((x): x is number => x !== undefined);
      return {
        key,
        label: classificationLine(values, axes),
        values,
        ventureIds: vs.map((v) => v.id),
        tried: vs.length,
        funded: vs.filter((v) => reached(v, "funded")).length,
        survived: vs.filter((v) => v.status !== "killed" && v.status !== "dormant").length,
        killed: vs.filter((v) => v.status === "killed").length,
        survivedFunded: vs.filter((v) => reached(v, "funded") && v.status !== "killed" && v.status !== "dormant").length,
        medianDaysToFirstCustomer: firstCustomer.length ? Math.round(median(firstCustomer)) : undefined,
      };
    })
    .sort((a, b) => b.tried - a.tried || a.label.localeCompare(b.label));
}

/** The standard-cut key for one venture, if it is classified on every axis of the cut. */
export function outcomeCutKey(v: Venture): string | undefined {
  const c = classificationOf(v);
  return OUTCOME_CUT.every((a) => c[a]) ? OUTCOME_CUT.map((a) => c[a]).join("|") : undefined;
}

/* ---------- lessons ---------- */

export interface LessonDraft extends Omit<Lesson, "id" | "status" | "at" | "cohortId" | "writtenBy"> {
  key: string;
}

const confidenceFor = (n: number) => round(Math.min(0.95, 0.45 + 0.1 * n), 2);

/** The plain "how sure" line shown instead of the internal confidence number. */
export function howSure(confidence: number, reason: string): Lesson["howSure"] {
  const level = confidence >= 0.8 ? "Strong" : confidence >= 0.6 ? "Moderate" : "Early signal";
  return { level, reason };
}

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

const KILL_GUARDS: Record<string, string[]> = {
  "no demand": ["build before", "build first", "skip the demand check"],
  "could not reach buyer": ["cold outbound", "cold email", "buy a list", "scraped list"],
  price: ["discount", "price cut", "lower the price", "free trial"],
  execution: [],
  legal: ["without counsel", "skip counsel"],
  "ran out of time": ["extend the window", "extend the deadline"],
};

const KILL_PLAIN: Record<string, { why: string; headline: (name: string) => string }> = {
  "no demand": { why: "buyers didn't want it enough to pay", headline: (n) => `Check that buyers will pay before building an idea like ${n}.` },
  "could not reach buyer": {
    why: "it couldn't reach the people who buy",
    headline: (n) => `Make sure members can reach the buyer before starting an idea like ${n}.`,
  },
  price: { why: "the price didn't work for buyers", headline: (n) => `Test the price with real buyers before launching an idea like ${n}.` },
  execution: { why: "it couldn't deliver in time", headline: (n) => `Give an idea like ${n} a shorter deadline.` },
  legal: { why: "of a legal problem", headline: (n) => `Get legal advice before launching an idea like ${n}.` },
  "ran out of time": { why: "it ran out of time", headline: (n) => `Give an idea like ${n} a shorter deadline.` },
};

const CHANNEL_NAMES: Record<string, string> = { x_post: "X posts", linkedin: "LinkedIn posts" };

/** Classification axes a lesson can be scoped to; a lesson applies only to ventures that match its values. */
export const LESSON_AXES: readonly ClassificationAxis[] = ["endMarket", "customer", "businessModel", "goToMarket", "marketType"];

/** "Healthcare · Small business · Marketplace · Before the first customer" */
export function appliesToLine(l: Pick<Lesson, "tags" | "appliesTo">): string {
  const values = LESSON_AXES.flatMap((axis) => l.tags.filter((t) => t.axis === axis).map((t) => t.value));
  if (!values.length && l.appliesTo.stage === "Any stage") return "Every venture";
  return [...values, ...(l.appliesTo.stage === "Any stage" ? [] : [l.appliesTo.stage])].join(" · ");
}

function ventureTags(v: Venture | undefined): Tag[] {
  return (v?.tags ?? [])
    .filter((t) => (OUTCOME_CUT as readonly string[]).includes(t.axis))
    .map((t) => ({ ...t, status: "proposed" as const, by: "rules" }));
}

/** Templated lessons from the statistics. Claude Sonnet rewrites the wording when a key is set. */
export function templateLessons(store: Store, stats: LearningStats, cohort?: Cohort): LessonDraft[] {
  const params = resolveParams(store);
  const where = cohort ? ` in ${batchLabel(cohort.number)}` : "";
  const out: LessonDraft[] = [];

  for (const t of stats.byType) {
    if (t.samples < 2 || t.medianUnits <= 0) continue;
    const label = RFE_TYPE_LABELS[t.type].label;
    const confidence = confidenceFor(t.samples);
    out.push({
      key: `pricing:${t.type}`,
      topic: "pricing-requests",
      headline: `${label} requests usually pay about ${t.medianUnits} units.`,
      whatHappened: `Across ${plural(t.samples, `${label.toLowerCase()} request`)}${where}, the typical answer was paid ${t.medianUnits} units and came in within ${t.medianHoursToFill} hours.${t.counters ? ` Members asked for more ${plural(t.counters, "time")}.` : ""}`,
      whatWeDoDifferently: `New ${label.toLowerCase()} requests start their offer near ${t.medianUnits} units.`,
      howSure: howSure(confidence, `seen in ${plural(t.samples, "request")}`),
      appliesTo: { stage: "Any stage" },
      metric: { name: `median clearing units, ${t.type}`, value: t.medianUnits, unit: "units" },
      evidence: t.evidence,
      confidence,
      tags: [],
    });
  }
  for (const a of stats.agreement) {
    if (a.samples < 2) continue;
    const label = RFE_TYPE_LABELS[a.type].label.toLowerCase();
    const confidence = confidenceFor(a.samples);
    out.push({
      key: `responses:${a.type}`,
      topic: "answers-needed",
      headline: `A ${label} request usually settles after about ${a.medianResponses} answers.`,
      whatHappened: `${plural(a.samples, `${label} request`)}${where} closed once about ${a.medianResponses} people with different backgrounds had answered. ${a.medianAgreement >= 0.999 ? "They all agreed." : `Typically ${Math.round(a.medianAgreement * 100)}% of them agreed.`}`,
      whatWeDoDifferently: `The agent plans for about ${a.medianResponses} answers on a ${label} request before it acts.`,
      howSure: howSure(confidence, `seen in ${plural(a.samples, "request")}`),
      appliesTo: { stage: "Any stage" },
      metric: { name: `median responses to settle, ${a.type}`, value: a.medianResponses, unit: "responses" },
      evidence: [],
      confidence,
      tags: [],
    });
  }
  for (const c of stats.clusters.slice(0, 2)) {
    if (c.followed < 2) continue;
    const who = clusterLabel(c.cluster);
    const confidence = confidenceFor(c.followed);
    out.push({
      key: `cluster:${c.cluster}`,
      topic: "whose-advice",
      headline: `Advice from members in ${who} has held up.`,
      whatHappened: `Members in ${who} gave ${plural(c.answers, "answer")}. The agent followed ${c.followed === c.answers ? "all of them" : c.followed}, and ${c.right} of those still hold up.`,
      whatWeDoDifferently: `When a request is about ${who}, the agent gives these members' answers more weight.`,
      howSure: howSure(confidence, `${plural(c.answers, "answer")}, ${c.right} held up`),
      appliesTo: { stage: "Any stage" },
      metric: { name: `followed-and-right, ${c.cluster}`, value: c.right, unit: "answers" },
      evidence: [],
      confidence,
      tags: [],
    });
  }
  for (const k of stats.killTimes) {
    const v = store.ventures.find((x) => x.id === k.ventureId);
    if (v && !reached(v, "funded")) {
      const sold = seatsSold(store, v.id) + seatRefunds(store, v.id).count;
      const needed = seatsNeeded(v.minRaiseUsd, seatPriceOf(v, params));
      out.push({
        key: `kill:${k.ventureId}`,
        topic: "why-ventures-end",
        headline: `Too few members took seats in ${k.name}; check members can help before proposing an idea like it.`,
        whatHappened: `${k.name} sold ${sold} of the ${needed} seats it needed before its deadline and ended after ${k.days} days. Everyone who took a seat was refunded in full.`,
        whatWeDoDifferently: "Before proposing a similar idea, the agent checks how many members work in or sell to its buyers, and says so in the pitch.",
        howSure: howSure(0.7, "one venture that didn't reach its minimum"),
        appliesTo: { stage: "Selling seats" },
        metric: { name: `days to kill signal, ${k.name}`, value: k.days, unit: "days" },
        evidence: [{ kind: "venture", id: k.ventureId, label: `${k.name} post-mortem` }],
        confidence: 0.7,
        tags: ventureTags(v),
      });
      continue;
    }
    const plain = KILL_PLAIN[k.reason ?? ""] ?? { why: "it hit one of its shut-down rules", headline: (n: string) => `Give an idea like ${n} a shorter deadline.` };
    out.push({
      key: `kill:${k.ventureId}`,
      topic: "why-ventures-end",
      headline: plain.headline(k.name),
      whatHappened: `${k.name} ended after ${k.days} days because ${plain.why}. Its post-mortem has the details.`,
      whatWeDoDifferently: `Similar ventures set a shut-down date no later than ${k.days} days after launch.`,
      howSure: howSure(0.75, "one venture's post-mortem"),
      appliesTo: { stage: "Before the first customer" },
      metric: { name: `days to kill signal, ${k.name}`, value: k.days, unit: "days" },
      evidence: [{ kind: "venture", id: k.ventureId, label: `${k.name} post-mortem` }],
      confidence: 0.75,
      tags: ventureTags(v),
      guard: k.reason && KILL_GUARDS[k.reason]?.length ? { keywords: KILL_GUARDS[k.reason] } : undefined,
    });
  }
  const byChannel = new Map<string, { drafts: number; qualified: number; right: number; evidence: Evidence[] }>();
  for (const d of stats.drafts) {
    const row = byChannel.get(d.channel) ?? { drafts: 0, qualified: 0, right: 0, evidence: [] };
    row.drafts++;
    row.qualified += d.qualified;
    row.right += d.right;
    row.evidence.push({ kind: "draft", id: d.rfeId, label: d.title });
    byChannel.set(d.channel, row);
  }
  for (const [channel, row] of byChannel) {
    if (!row.qualified) continue;
    const name = CHANNEL_NAMES[channel] ?? "Direct outreach";
    const each = round(row.qualified / row.drafts, 1);
    const confidence = confidenceFor(row.drafts + row.qualified / 2);
    out.push({
      key: `channel:${channel}`,
      topic: "finding-members",
      headline: `${name} brought about ${each} verified ${each === 1 ? "member" : "members"} each.`,
      whatHappened: `${plural(row.drafts, "recruiting post")} on this channel${where} brought ${plural(row.qualified, "member")} who got verified. Their answers held up ${plural(row.right, "time")}.`,
      whatWeDoDifferently: `The agent keeps using ${name.toLowerCase()} to find members and counts who joins from each one.`,
      howSure: howSure(confidence, `${plural(row.drafts, "post")}, ${plural(row.qualified, "verified member")}`),
      appliesTo: { stage: "Selling seats" },
      metric: { name: `verified members per post, ${channel}`, value: each, unit: "members" },
      evidence: row.evidence.slice(0, 4),
      confidence,
      tags: [],
    });
  }
  for (const c of stats.cuts) {
    if (!c.tried) continue;
    const names = c.ventureIds.map((id) => store.ventures.find((v) => v.id === id)?.name ?? id);
    const confidence = confidenceFor(c.tried);
    const firstCustomer =
      c.medianDaysToFirstCustomer !== undefined
        ? `, and ${c.tried === 1 ? "found" : "the typical one found"} a first customer ${c.medianDaysToFirstCustomer} days after launch`
        : "";
    out.push({
      key: `cut:${c.key}`,
      topic: "which-ideas",
      headline: `${c.label}: ${c.funded} of ${c.tried} reached ${c.tried === 1 ? "its" : "their"} minimum.`,
      whatHappened:
        c.tried === 1
          ? `Tried once, as ${names[0]}. It ${c.funded ? `sold enough seats to start${firstCustomer}` : "didn't sell enough seats to start"}${c.killed ? `${c.funded ? ", then ended" : " and ended"}` : ""}.`
          : `Tried as ${names.join(", ")}. ${c.funded} sold enough seats to start${firstCustomer}.${c.killed ? ` ${c.killed} ended.` : ""}`,
      whatWeDoDifferently:
        c.funded * 2 >= c.tried
          ? "The agent keeps giving this kind of venture spots in new batches."
          : "The agent gives this kind of venture fewer spots in new batches until one works.",
      howSure: howSure(confidence, `seen in ${plural(c.tried, "venture")}`),
      appliesTo: { stage: "Choosing ideas" },
      metric: { name: `reached the minimum, ${c.label}`, value: round(c.funded / c.tried, 2) },
      evidence: c.ventureIds.slice(0, 4).map((id, i) => ({ kind: "venture" as const, id, label: names[i] })),
      confidence,
      tags: OUTCOME_CUT.map((axis) => ({ axis, value: c.values[axis]!, status: "proposed" as const, by: "rules" })),
    });
  }
  const a = stats.advisory;
  const threshold = params.ADVISORY_CONFIDENCE;
  if (a.samples >= 3 && a.agreedRate >= 0.8 && a.minConfidence < threshold - 0.04) {
    const proposed = round(a.minConfidence, 2);
    const confidence = confidenceFor(a.samples);
    out.push({
      key: "param:ADVISORY_CONFIDENCE",
      topic: "when-to-ask",
      headline: `The agent can ask members less often: they agreed with it even when it was only ${Math.round(a.minConfidence * 100)}% sure.`,
      whatHappened: `Members agreed with ${Math.round(a.agreedRate * 100)}% of the ${a.samples} decisions the agent asked them about${where}, including ones where it was only ${Math.round(a.minConfidence * 100)}% sure.`,
      whatWeDoDifferently: `If holders vote yes, the agent asks members first only when it is under ${Math.round(proposed * 100)}% sure, instead of ${Math.round(threshold * 100)}%.`,
      howSure: howSure(confidence, `seen in ${plural(a.samples, "decision")}`),
      appliesTo: { stage: "Any stage" },
      metric: { name: "advisory agreement rate", value: round(a.agreedRate, 2) },
      evidence: a.evidence,
      confidence,
      tags: [],
      paramKey: "ADVISORY_CONFIDENCE",
      proposedValue: proposed,
    });
  }
  return out;
}

export function nextLessonId(store: Store): string {
  const max = store.lessons.reduce((m, l) => Math.max(m, Number(l.id.slice(2)) || 0), 0);
  return `L-${String(max + 1).padStart(3, "0")}`;
}

/** Key a lesson so a later pass refreshes it instead of adding a duplicate. */
export function lessonKey(l: Pick<Lesson, "topic" | "metric">): string {
  return `${l.topic}:${l.metric.name}`;
}

/**
 * Store new lessons. Lessons act only inside the parameters: a lesson that
 * implies a parameter change stays proposed and posts an amendment vote on
 * the Protocol. Learning proposes, holders decide.
 */
export function recordLessons(store: Store, drafts: LessonDraft[], cohortId: string, writtenBy = "template"): Lesson[] {
  const params = resolveParams(store);
  const added: Lesson[] = [];
  const v0 = protocolVenture(store);
  for (const d of drafts) {
    const { key: _key, ...rest } = d;
    const existing = store.lessons.find((l) => l.status !== "retired" && lessonKey(l) === lessonKey(d));
    if (existing) {
      if (Math.abs(existing.metric.value - d.metric.value) < 1e-6) continue;
      existing.status = "retired";
    }
    const lesson: Lesson = {
      ...rest,
      id: nextLessonId(store),
      cohortId,
      status: "proposed",
      writtenBy,
      at: store.meta.clock,
    };
    if (lesson.paramKey) {
      const current = (params as Record<string, unknown>)[lesson.paramKey];
      const already = store.rfes.some((r) => isOpen(r) && r.governance?.paramKey === lesson.paramKey);
      if (!already && current !== lesson.proposedValue) {
        const rfe = postRfe(store, v0.id, {
          type: "judgment",
          kind: "governance",
          title: `${settingChangeTitle(lesson.paramKey as ParamKey, current, lesson.proposedValue)} (from lesson ${lesson.id})`,
          question: `${lesson.headline} ${lesson.whatWeDoDifferently} Lessons only propose; unit holders decide. Change the setting?`,
          recommendation: "Yes",
          confidence: lesson.confidence,
          stakes: "medium",
          format: "choice",
          options: ["Yes", "No"],
          offerUnits: 0,
          audience: "Protocol unit holders",
          governance: {
            matter: "parameter-amendment",
            threshold: "simple",
            windowEndsAt: addDays(store.meta.clock, params.VOTE_WINDOW_DAYS),
            paramKey: lesson.paramKey,
            currentValue: current,
            proposedValue: lesson.proposedValue,
            effect: `If it passes, ${lesson.paramKey} becomes ${String(lesson.proposedValue)} and lesson ${lesson.id} is adopted.`,
          },
          lessonIds: [lesson.id],
        });
        lesson.amendmentRfeId = rfe.id;
      }
    } else if (lesson.confidence >= params.LESSON_ADOPT_CONFIDENCE) {
      lesson.status = "adopted";
    }
    store.lessons.push(lesson);
    added.push(lesson);
  }
  return added;
}

export type LearningTrigger = { kind: "kill" | "customer1"; ventureId: string } | { kind: "cohort-close"; cohortId: string };

/** The learning pass: statistics in, lessons out. Runs on a kill, a first customer, or a batch closing. */
export function runLearningPass(store: Store, trigger: LearningTrigger): { stats: LearningStats; lessons: Lesson[] } {
  const cohortId =
    trigger.kind === "cohort-close" ? trigger.cohortId : store.ventures.find((v) => v.id === trigger.ventureId)?.cohortId ?? store.cohorts.at(-1)?.id ?? "none";
  const cohort = store.cohorts.find((c) => c.id === cohortId);
  const ventureIds = trigger.kind === "cohort-close" ? cohort?.ventureIds : undefined;
  const stats = learningStats(store, { ventureIds });
  let drafts = templateLessons(store, stats, cohort);
  if (trigger.kind !== "cohort-close") {
    const v = store.ventures.find((x) => x.id === trigger.ventureId);
    const cut = v && outcomeCutKey(v);
    drafts = drafts.filter((d) => d.key === `kill:${trigger.ventureId}` || d.key.startsWith("pricing:") || (cut && d.key === `cut:${cut}`));
  }
  const lessons = recordLessons(store, drafts, cohortId);
  if (trigger.kind === "cohort-close" && cohort) {
    cohort.notes = batchNotes(store, cohort, stats, lessons);
  }
  return { stats, lessons };
}

export function batchNotes(store: Store, cohort: Cohort, stats: LearningStats, lessons: Lesson[]): string[] {
  const vs = cohort.ventureIds.map((id) => store.ventures.find((v) => v.id === id)).filter((v): v is Venture => !!v);
  const funded = vs.filter((v) => v.statusHistory.some((h) => h.status === "funded"));
  const died = vs.filter((v) => v.status === "killed");
  const notes = [
    `${funded.length} of ${vs.length} ventures reached their minimum${funded.length ? ` (${funded.map((v) => v.name).join(", ")})` : ""}; ${died.length} ended${died.length ? ` (${died.map((v) => v.name).join(", ")})` : ""}.`,
  ];
  const best = stats.byType.filter((t) => t.samples >= 2).sort((a, b) => b.samples - a.samples)[0];
  if (best) notes.push(`${RFE_TYPE_LABELS[best.type].label} requests were the most common, usually paying about ${best.medianUnits} units.`);
  const sharesIn = shareFunnelStats(store, new Set(vs.map((v) => v.id)));
  if (sharesIn.totals.visit) {
    const top = [...sharesIn.byChannel].sort((a, b) => b.stages.candidate - a.stages.candidate || b.stages.visit - a.stages.visit)[0];
    notes.push(
      `Share links brought ${sharesIn.totals.visit} visits, ${sharesIn.totals.candidate} sign-ups and ${sharesIn.totals.role} roster claims${top ? `; ${SHARE_CHANNEL_LABELS[top.key as ShareChannel] ?? top.key} brought the most sign-ups` : ""}.`,
    );
  }
  if (lessons.length) notes.push(`The batch produced ${lessons.length} lesson${lessons.length === 1 ? "" : "s"} for members.`);
  return notes;
}

/* ---------- using lessons ---------- */

/** Lessons that apply to a venture: adopted, with matching classification tags where the lesson has them. */
export function lessonsFor(store: Store, venture: Venture): Lesson[] {
  return store.lessons.filter((l) => {
    if (l.status !== "adopted") return false;
    for (const axis of LESSON_AXES) {
      const wanted = l.tags.filter((t) => t.axis === axis).map((t) => t.value);
      if (!wanted.length) continue;
      const have = venture.tags.filter((t) => t.axis === axis).map((t) => t.value);
      if (!wanted.some((w) => have.includes(w))) return false;
    }
    return true;
  });
}

export interface PlannedAction {
  title: string;
  reasoning: string;
  facts?: Partial<DecisionFacts>;
  /** Lessons the plan cites; a plan that follows a lesson does not contradict it. */
  lessonIds?: string[];
}

/** The repeat-mistake check: adopted lessons, with matching tags, that the planned action contradicts. */
export function contradictedLessons(store: Store, venture: Venture, plan: PlannedAction): Lesson[] {
  const text = `${plan.title} ${plan.reasoning}`.toLowerCase();
  const cited = new Set(plan.lessonIds ?? []);
  return lessonsFor(store, venture).filter((l) => {
    if (!l.guard || cited.has(l.id)) return false;
    if (l.guard.keywords.some((k) => text.includes(k.toLowerCase()))) return true;
    if (l.guard.maxSpendUsd !== undefined && (plan.facts?.spendUsd ?? 0) > l.guard.maxSpendUsd) return true;
    if (l.guard.pricingChange && plan.facts?.pricingChange) return true;
    return false;
  });
}

export function escalate(bin: DecisionBin): DecisionBin {
  return bin === "auto" ? "advisory" : "gated";
}

/** Lesson ids cited in free text ("per L-004"). */
export function citedLessonIds(text: string): string[] {
  return [...new Set(text.match(/\bL-\d{3}\b/g) ?? [])];
}

/* ---------- batch slot allocation ---------- */

/** One batch slot's target: an end market and a business model. */
export interface Segment {
  endMarket: string;
  businessModel: string;
}

export interface SlotPick extends Segment {
  kind: "overdue" | "exploration" | "outcomes";
  reason: string;
}

const SEGMENT_AXES = ["endMarket", "businessModel"] as const;

export const segmentKey = (s: Segment) => `${s.endMarket}|${s.businessModel}`;
export const segmentLabel = (s: Segment) => `${s.businessModel} · ${s.endMarket}`;

/** Every end market and business model pair the library or the registry has an idea in. */
export function knownSegments(store: Store): Segment[] {
  const out = new Map<string, Segment>();
  const add = (s: Partial<Segment>) => {
    if (s.endMarket && s.businessModel) out.set(segmentKey(s as Segment), { endMarket: s.endMarket, businessModel: s.businessModel });
  };
  for (const i of IDEA_LIBRARY) add(i.classification);
  for (const v of store.ventures) if (!v.isProtocol) add(classificationOf(v));
  return [...out.values()].sort((a, b) => segmentKey(a).localeCompare(segmentKey(b)));
}

/**
 * Spread a batch's slots across end markets and business models, learned from
 * outcomes. Any end market or business model with fewer than
 * BATCH_MIN_SLOTS_PER_SEGMENT slots in the last rotation goes first, then an
 * exploration share for the least-tried pairs, then the rest by smoothed
 * rate of reaching the minimum. Within each step, pairs that add a new end market or business
 * model to the batch come first.
 */
export function allocateBatchSlots(
  store: Store,
  params: ParamValues = resolveParams(store),
  slots = params.VENTURES_PER_BATCH,
  available: (segment: Segment) => boolean = () => true,
): SlotPick[] {
  const universe = knownSegments(store);
  const pool = universe.filter(available);
  const stats = new Map(outcomesBy(store, SEGMENT_AXES).map((o) => [o.key, o]));
  const statFor = (s: Segment) => stats.get(segmentKey(s)) ?? { tried: 0, funded: 0, survivedFunded: 0 };
  const distinct = (axis: (typeof SEGMENT_AXES)[number], list: Segment[]) => [...new Set(list.map((s) => s[axis]))];
  const widest = Math.max(...SEGMENT_AXES.map((a) => distinct(a, universe).length), 1);
  const rotation = Math.max(1, Math.ceil(widest / Math.max(1, slots)));
  const ordered = [...store.cohorts].sort((a, b) => b.number - a.number);
  const recent = ordered.slice(0, rotation);
  const valueOf = (ventureId: string, axis: (typeof SEGMENT_AXES)[number]) => {
    const v = store.ventures.find((x) => x.id === ventureId);
    return v ? classificationOf(v)[axis] : undefined;
  };
  const recentCount = (axis: (typeof SEGMENT_AXES)[number], value: string) =>
    recent.reduce((n, c) => n + c.ventureIds.filter((id) => valueOf(id, axis) === value).length, 0);
  const lastSeen = (axis: (typeof SEGMENT_AXES)[number], value: string) =>
    ordered.find((c) => c.ventureIds.some((id) => valueOf(id, axis) === value))?.number ?? 0;

  const picks: SlotPick[] = [];
  const taken = new Set<string>();
  const take = (s: Segment, kind: SlotPick["kind"], reason: string) => {
    picks.push({ endMarket: s.endMarket, businessModel: s.businessModel, kind, reason });
    taken.add(segmentKey(s));
  };
  const novelty = (s: Segment) => SEGMENT_AXES.filter((a) => !picks.some((p) => p[a] === s[a])).length;
  const best = (list: Segment[], order: (a: Segment, b: Segment) => number) =>
    list.filter((s) => !taken.has(segmentKey(s))).sort((a, b) => novelty(b) - novelty(a) || order(a, b) || segmentKey(a).localeCompare(segmentKey(b)))[0];
  const leastTried = (a: Segment, b: Segment) => statFor(a).tried - statFor(b).tried;
  const min = params.BATCH_MIN_SLOTS_PER_SEGMENT;

  const overdue = SEGMENT_AXES.flatMap((axis) =>
    distinct(axis, pool)
      .map((value) => ({ axis, value, count: recentCount(axis, value) }))
      .filter((o) => o.count < min),
  ).sort((a, b) => lastSeen(a.axis, a.value) - lastSeen(b.axis, b.value) || a.value.localeCompare(b.value));
  for (const o of overdue) {
    if (picks.length >= slots) break;
    if (picks.some((p) => p[o.axis] === o.value)) continue;
    const s = best(
      pool.filter((x) => x[o.axis] === o.value),
      leastTried,
    );
    const had = o.count === 0 ? "wasn't tried" : `had only ${o.count} spot${o.count === 1 ? "" : "s"}`;
    if (s) take(s, "overdue", `${o.value} ${had} in the last ${rotation} batches; every kind gets a turn.`);
  }

  const explore = Math.round(slots * params.BATCH_EXPLORATION_SHARE);
  while (picks.length < Math.min(slots, explore)) {
    const s = best(pool, leastTried);
    if (!s) break;
    const tried = statFor(s).tried;
    take(s, "exploration", tried ? `Tried only ${tried === 1 ? "once" : `${tried} times`}, so we're testing it more.` : "Never tried yet, so we're testing it.");
  }

  // Half credit for reaching the minimum, half for surviving after it; Laplace-smoothed.
  const score = (s: Segment) => {
    const x = statFor(s);
    return ((x.funded + x.survivedFunded) / 2 + 1) / (x.tried + 2);
  };
  while (picks.length < slots) {
    const s = best(pool, (a, b) => score(b) - score(a));
    if (!s) break;
    const x = statFor(s);
    const record = x.tried
      ? `Tried ${x.tried === 1 ? "once" : `${x.tried} times`} before: ${x.funded} sold enough seats and ${x.survivedFunded} ${x.survivedFunded === 1 ? "is" : "are"} still running.`
      : "Not tried yet, and untried kinds rank above kinds that have done worse.";
    take(s, "outcomes", record);
  }
  return picks;
}
