import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import {
  DECISION_TRANSITIONS,
  GRANT_TRANSITIONS,
  PRIMITIVES,
  RFE_TRANSITIONS,
  Report,
  VENTURE_TRANSITIONS,
} from "../src/index";

const outDir = join(dirname(fileURLToPath(import.meta.url)), "..", "json");
mkdirSync(outDir, { recursive: true });

const all = { ...PRIMITIVES, Report };
for (const [name, schema] of Object.entries(all)) {
  const json = z.toJSONSchema(schema, { io: "input", unrepresentable: "any" });
  writeFileSync(join(outDir, `${name}.schema.json`), JSON.stringify({ title: name, ...json }, null, 2) + "\n");
}

writeFileSync(
  join(outDir, "transitions.json"),
  JSON.stringify(
    { Venture: VENTURE_TRANSITIONS, Rfe: RFE_TRANSITIONS, Grant: GRANT_TRANSITIONS, Decision: DECISION_TRANSITIONS },
    null,
    2,
  ) + "\n",
);

console.log(`Wrote ${Object.keys(all).length} schemas and transitions.json to ${outDir}`);
