import { z } from "zod";
import {
  DECISION_BINS,
  DECISION_STATUSES,
  GRANT_STATUSES,
  RFE_STATUSES,
  VENTURE_STATUSES,
} from "./states";

export const RFE_TYPES = [
  "judgment",
  "knowledge",
  "access",
  "credibility",
  "action",
  "capital",
  "stewardship",
] as const;
export type RfeType = (typeof RFE_TYPES)[number];

export const RFE_TYPE_LABELS: Record<RfeType, { label: string; asks: string }> = {
  judgment: { label: "Judgment", asks: "A decision, with the agent's recommendation, confidence and stakes" },
  knowledge: { label: "Knowledge", asks: "A fact or data the agent can't verify alone" },
  access: { label: "Introduction", asks: "An introduction to a buyer, partner or supplier" },
  credibility: { label: "Credibility", asks: "A named person vouching, or sitting in on a call" },
  action: { label: "Task", asks: "Something physical or legal a person must do" },
  capital: { label: "Seats", asks: "Seats the venture still needs to reach its minimum" },
  stewardship: { label: "Sign-off", asks: "A sign-off the steward must give" },
};

export const Iso = z.string().describe("ISO 8601 timestamp on the simulated clock");
export const Handle = z.string().regex(/^[A-Za-z0-9_]{2,24}$/).describe("Pseudonymous member handle, without @");
export const Stakes = z.enum(["low", "medium", "high"]);
export type Stakes = z.infer<typeof Stakes>;

export const Objective = z.enum(["scale", "profitability", "exit"]);
export type Objective = z.infer<typeof Objective>;

export const OBJECTIVE_LABELS: Record<Objective, { label: string; meaning: string }> = {
  scale: { label: "Grow first", meaning: "Profit is spent on growth, and payouts start later." },
  profitability: { label: "Pay out early", meaning: "Most profit is paid to unit holders every quarter." },
  exit: { label: "Build to sell", meaning: "Unit holders share in the sale price." },
};

/* ---------- classification ---------- */

export const END_MARKETS = [
  "Fintech",
  "Healthcare",
  "Commerce and retail",
  "Software and IT",
  "Media and entertainment",
  "Education",
  "Industrials and logistics",
  "Real estate and construction",
  "Energy and climate",
  "Consumer services",
  "Professional services",
  "Public sector",
] as const;
export const CUSTOMER_TYPES = ["Consumer", "Small business", "Mid-market", "Enterprise", "Government"] as const;
export const BUSINESS_MODELS = [
  "Subscription software",
  "Marketplace",
  "Transactional or payments",
  "Usage-based",
  "E-commerce or direct-to-consumer",
  "Advertising",
  "Tech-enabled services",
  "Data or licensing",
] as const;
export const GO_TO_MARKETS = ["Self-serve", "Sales-led", "Partner or channel", "Community and content"] as const;
export const MARKET_TYPES = ["Existing market", "Resegmented", "New market"] as const;
export const GEOGRAPHIES = ["US", "UK", "EU", "Global"] as const;
/** Who does the venture's work: level 1, 2 or 3. Contractors are paid cash per job and never earn units. */
export const WORK_DELIVERIES = ["Agent only", "Agent plus contractors", "Employees"] as const;
export type WorkDelivery = (typeof WORK_DELIVERIES)[number];
export const WORK_LEVEL: Record<WorkDelivery, 1 | 2 | 3> = { "Agent only": 1, "Agent plus contractors": 2, Employees: 3 };

/**
 * The standard classification every idea and venture carries. The agent
 * proposes it; the steward confirms or corrects it as tags. Values beyond
 * these founding lists join only by a Protocol vote.
 */
const governedValue = <T extends readonly [string, ...string[]]>(values: T) =>
  z.union([z.enum(values), z.string().describe("A value added by a Protocol vote")]);

export const Classification = z.object({
  endMarket: governedValue(END_MARKETS),
  subVertical: z.string().describe("Free text, e.g. 'dental practices'"),
  customer: governedValue(CUSTOMER_TYPES),
  businessModel: governedValue(BUSINESS_MODELS),
  goToMarket: governedValue(GO_TO_MARKETS),
  marketType: governedValue(MARKET_TYPES),
  geography: governedValue(GEOGRAPHIES),
  workDelivery: z.enum(WORK_DELIVERIES).describe("Who does the work: the agent alone, the agent plus paid contractors, or employees"),
});
export type Classification = z.infer<typeof Classification>;

export const CLASSIFICATION_AXES = ["endMarket", "subVertical", "customer", "businessModel", "goToMarket", "marketType", "geography", "workDelivery"] as const;
export type ClassificationAxis = (typeof CLASSIFICATION_AXES)[number];

export type CustomerModel = "B2B" | "B2C" | "B2B2C";

const CONSUMER_END_MARKETS: readonly string[] = ["Commerce and retail", "Consumer services", "Media and entertainment"];

/** B2C sells to consumers; B2B2C sells to a business whose own customers are consumers. */
export function customerModel(c: { customer?: string; endMarket?: string }): CustomerModel | undefined {
  if (!c.customer) return undefined;
  if (c.customer === "Consumer") return "B2C";
  return c.endMarket && CONSUMER_END_MARKETS.includes(c.endMarket) ? "B2B2C" : "B2B";
}

/* ---------- tags ---------- */

export const TAG_AXES = [...CLASSIFICATION_AXES, "stage", "killReason"] as const;
export type TagAxis = (typeof TAG_AXES)[number];

export const TAG_AXIS_LABELS: Record<TagAxis, string> = {
  endMarket: "End market",
  subVertical: "Sub-vertical",
  customer: "Customer",
  businessModel: "Business model",
  goToMarket: "Go-to-market",
  marketType: "Market type",
  geography: "Geography",
  workDelivery: "Who does the work",
  stage: "Stage reached",
  killReason: "Why it ended",
};

export const Tag = z.object({
  axis: z.enum(TAG_AXES),
  value: z.string(),
  status: z.enum(["proposed", "confirmed"]),
  by: z.string().describe("'agent', 'rules', a model id, or the steward handle that confirmed it"),
});
export type Tag = z.infer<typeof Tag>;

export const TagLogEntry = z.object({
  id: z.string(),
  at: Iso,
  axis: z.enum(TAG_AXES),
  action: z.enum(["add", "rename", "merge"]),
  from: z.string().optional(),
  to: z.string(),
  by: z.string(),
  affected: z.number().describe("How many tags were rewritten"),
});
export type TagLogEntry = z.infer<typeof TagLogEntry>;

/* ---------- memo and roster ---------- */

export const RosterSlot = z.object({
  type: z.string().describe("Stable key, e.g. buyer-operator"),
  label: z.string(),
  count: z.number(),
  clusters: z.array(z.string()).describe("Profile clusters that fill this slot"),
  keywords: z.array(z.string()).describe("Role or vertical words that also fill it"),
});
export type RosterSlot = z.infer<typeof RosterSlot>;

/** A light standard memo: the questions any venture should answer before it asks for seats. */
export const Memo = z.object({
  problem: z.string(),
  customer: z.string(),
  marketSize: z.string(),
  whyNow: z.string(),
  competition: z.string(),
  unitEconomics: z.string(),
  killMetric: z.string(),
});
export type Memo = z.infer<typeof Memo>;

export const MEMO_LABELS: Record<keyof Memo, string> = {
  problem: "Problem",
  customer: "Customer",
  marketSize: "Market size",
  whyNow: "Why now",
  competition: "Competition",
  unitEconomics: "Unit economics",
  killMetric: "When we'd stop",
};

export const KILL_REASONS = [
  "no demand",
  "could not reach buyer",
  "price",
  "execution",
  "legal",
  "ran out of time",
  "flawed business model",
  "outcompeted",
  "mistimed",
  "poor product",
  "ran out of money",
] as const;
export type KillReason = (typeof KILL_REASONS)[number];

export const PostMortem = z.object({
  summary: z.string(),
  whatWeTried: z.array(z.string()),
  whyItEnded: z.string(),
  costUsd: z.number(),
  lessons: z.array(z.string()),
  killReason: z.enum(KILL_REASONS).optional(),
  stageReached: z.string().optional(),
  daysToKillSignal: z.number().optional(),
  counterfactual: z.string().optional().describe("What a later rule would have done, computed from the record and labelled as an estimate"),
  publishedAt: Iso.optional().describe("A killed venture's batch cannot close until this is set"),
});
export type PostMortem = z.infer<typeof PostMortem>;

/* ---------- pitch deck ---------- */

/** Every claim in a deck says what it rests on. */
export const CLAIM_BASES = ["evidence", "estimate", "assumption"] as const;
export type ClaimBasis = (typeof CLAIM_BASES)[number];

export const SOURCE_KINDS = ["rfe", "decision", "ledger", "lesson", "public-data", "member-answer"] as const;

export const Source = z.object({
  kind: z.enum(SOURCE_KINDS),
  ref: z.string().describe("Store id, or a dataset name for public-data"),
  label: z.string(),
  verified: z.boolean().describe("Public data starts unverified; internal records are verified by construction"),
});
export type Source = z.infer<typeof Source>;

export const Claim = z.object({
  id: z.string().describe("Stable across deck versions, e.g. c-market-accounts"),
  text: z.string(),
  basis: z.enum(CLAIM_BASES),
  sources: z.array(Source).default([]),
  method: z.string().optional().describe("Required for an estimate: the arithmetic or reasoning"),
  test: z.object({ how: z.string(), rfeId: z.string().optional() }).optional().describe("Required for an assumption: how it gets tested"),
  value: z.object({ n: z.number(), unit: z.string() }).optional(),
  disproved: z.object({ at: Iso, by: z.string() }).optional().describe("Struck through, never deleted"),
});
export type Claim = z.infer<typeof Claim>;

export const SLIDE_KEYS = [
  "problem",
  "demand",
  "solution",
  "customer",
  "market",
  "whyNow",
  "alternatives",
  "model",
  "gtm",
  "howItRuns",
  "unitEconomics",
  "milestones",
  "budget",
  "plan",
  "risks",
  "ask",
] as const;
export type SlideKey = (typeof SLIDE_KEYS)[number];

export const SLIDE_TITLES: Record<SlideKey, string> = {
  problem: "Problem",
  demand: "Demand so far",
  solution: "The wedge",
  customer: "Customer",
  market: "Market",
  whyNow: "Why now",
  alternatives: "Alternatives",
  model: "Model and pricing",
  gtm: "Go-to-market",
  howItRuns: "Who does the work",
  unitEconomics: "Unit economics",
  milestones: "Milestones",
  budget: "Proof budget",
  plan: "Business plan",
  risks: "Pre-mortem and kill rules",
  ask: "The ask",
};

export const Slide = z.object({ key: z.enum(SLIDE_KEYS), headline: z.string(), claims: z.array(Claim) });
export type Slide = z.infer<typeof Slide>;

export const BUDGET_CATEGORIES = [
  "api",
  "tools",
  "domain",
  "hosting",
  "data",
  "ads-test",
  "outreach",
  "contractors",
  "insurance",
  "legal",
  "formation",
  "shared-services",
  "contingency",
] as const;
export type BudgetCategory = (typeof BUDGET_CATEGORIES)[number];

export const BUDGET_CATEGORY_LABELS: Record<BudgetCategory, string> = {
  api: "Agent compute",
  tools: "Tools and subscriptions",
  domain: "Domains and email",
  hosting: "Hosting",
  data: "Data access",
  "ads-test": "Paid tests and ads",
  outreach: "Outreach",
  contractors: "Contractor time",
  insurance: "Insurance",
  legal: "Legal templates and review",
  formation: "Formation",
  "shared-services": "Shared services",
  contingency: "Contingency",
};

export const BudgetLine = z.object({
  key: z.string(),
  label: z.string(),
  category: z.enum(BUDGET_CATEGORIES),
  usd: z.number().describe("For the whole proof phase"),
  monthlyUsd: z.number().optional().describe("Recurring lines: usd is this × the proof months, and the business plan carries it every month"),
  claimId: z.string().describe("A quote is evidence; anything else is an estimate with a method"),
  stretch: z.boolean().default(false).describe("Paid only by seats between the minimum and the maximum"),
});
export type BudgetLine = z.infer<typeof BudgetLine>;

/**
 * The inputs to the 12-month plan. Code computes every month from these, the
 * budget lines and the price; the agent only fills them in, each with a claim.
 */
export const PlanInput = z.object({
  proofMonths: z.number().int().describe("Months the proof budget covers"),
  horizonMonths: z.number().int(),
  usesPerCustomerMonth: z.number().describe("1 for a monthly price; jobs or shifts a month for a per-use price"),
  variableUsdPerUse: z.number().describe("Model calls, postage and contractor pay for one use"),
  firstLeadMonth: z.number().int().describe("Month the first intros or sign-ups arrive"),
  leadsPerMonth: z.number().describe("Intros or sign-ups in the first month of selling"),
  leadGrowthPct: z.number().describe("Monthly growth in leads"),
  leadToPaid: z.number().optional().describe("Set only when the intro funnel setting doesn't fit, e.g. self-serve"),
  churnPct: z.number().describe("Share of paying customers lost each month"),
  claims: z.object({ uses: z.string(), variable: z.string(), leads: z.string(), churn: z.string(), conversion: z.string().optional() }),
});
export type PlanInput = z.infer<typeof PlanInput>;

/** Level-2 ventures: the paid jobs a person does, priced per job. Contractors are paid cash and never earn units. */
export const ContractorLine = z.object({
  job: z.string(),
  rateUsd: z.number(),
  per: z.string().describe("e.g. 'notarised signing', 'shift'"),
  count: z.number().int(),
  paidFrom: z.enum(["seat money", "job fee"]).describe("Seat money pays only trial jobs in the budget; the rest comes out of what the customer pays"),
  claimId: z.string(),
});
export type ContractorLine = z.infer<typeof ContractorLine>;

export const RequestPlanItem = z.object({
  key: z.string(),
  title: z.string(),
  type: z.enum(RFE_TYPES),
  stakes: Stakes,
  audience: z.string().describe("'any-holder' or a roster role key"),
});
export type RequestPlanItem = z.infer<typeof RequestPlanItem>;

export const Milestone = z.object({
  key: z.string(),
  label: z.string(),
  metric: z.string(),
  target: z.number(),
  dueDays: z.number().describe("Days after the raise succeeds"),
});
export type Milestone = z.infer<typeof Milestone>;

/** A kill rule written as a condition and a date, so nobody argues later about whether it fired. */
export const KillCriterion = z.object({
  key: z.string(),
  condition: z.string().describe("A measurable state, e.g. 'no paying contractor'"),
  by: Iso,
  killReason: z.enum(KILL_REASONS),
});
export type KillCriterion = z.infer<typeof KillCriterion>;

export const PremortemItem = z.object({ way: z.string(), killReason: z.enum(KILL_REASONS) });

export const ROSTER_ROLE_KEYS = ["icp-operator", "introducer", "domain-expert", "builder", "channel", "legal", "credibility"] as const;
export type RosterRoleKey = (typeof ROSTER_ROLE_KEYS)[number];

export const RosterRole = z.object({
  key: z.enum(ROSTER_ROLE_KEYS),
  label: z.string().describe("Venture-specific, e.g. 'Contractor sales lead'"),
  count: z.number().int(),
  critical: z.boolean().describe("Needs a claim before the raise can succeed"),
  qualifications: z.array(z.string()),
  clusters: z.array(z.string()),
  keywords: z.array(z.string()),
  minDistinctClusters: z.number().int().default(1),
  serves: z.array(z.enum(RFE_TYPES)),
  derivation: z.string().describe("Rendered from the inputs by code"),
});
export type RosterRole = z.infer<typeof RosterRole>;

export const SeatPrice = z.object({
  proposedBy: z.enum(["agent", "script", "kept"]).describe("kept: pitched before per-venture pricing (Article 6)"),
  minUsd: z.number().describe("SEAT_PRICE_MIN_USD when priced"),
  maxUsd: z.number().describe("SEAT_PRICE_MAX_USD when priced"),
  upperUsd: z.number().describe("The highest price the people allow: proof budget ÷ headcount, within the bounds"),
  claims: z.array(Claim).default([]).describe("Why this price: tagged claims from the roster, the market and the buyer"),
  decisionId: z.string().optional().describe("The steward's pricing sign-off"),
});
export type SeatPrice = z.infer<typeof SeatPrice>;

export const SeatPlan = z.object({
  rule: z.enum(["derived", "legacy-budget"]).describe("legacy-budget: pitched before the current rule and kept under Article 6"),
  priceUsd: z.number(),
  price: SeatPrice.optional(),
  budgetUsd: z.number(),
  budgetSeats: z.number(),
  budgetLines: z.number(),
  coverageSeats: z.number(),
  coverage: z.object({ requestKey: z.string(), title: z.string(), type: z.enum(RFE_TYPES), stakes: Stakes, target: z.number(), rate: z.number() }).optional(),
  rosterSeats: z.number().default(0).describe("People on the roster"),
  headcount: z.number().default(0).describe("max(roster, seats for answer coverage): the fewest holders the venture can run on"),
  binding: z.enum(["budget", "coverage", "roster", "floor"]),
  bufferPct: z.number(),
  floor: z.number(),
  cap: z.number().optional().describe("The old seat cap, kept on decks pitched under it"),
  min: z.number(),
  max: z.number(),
  minRaiseUsd: z.number(),
  contingencyUsd: z.number(),
  proofBudgetUsd: z.number().default(0).describe("Itemized lines plus contingency at the seat buffer, at any seat price"),
  shortfallUsd: z.number().default(0).describe("Proof budget the minimum doesn't cover; shown, never hidden"),
  atPrices: z
    .array(z.object({ priceUsd: z.number(), min: z.number(), minRaiseUsd: z.number(), overCap: z.boolean().optional(), shortfallUsd: z.number().default(0) }))
    .default([])
    .describe("The same rule at the ends of the price band"),
  stretchUsd: z.number(),
  overCap: z.boolean().optional(),
  criticalRoles: z.array(z.string()).describe("Role keys that need a claim before the raise succeeds"),
  paramsAt: z.string().describe("Protocol version whose settings produced this"),
});
export type SeatPlan = z.infer<typeof SeatPlan>;

/**
 * How a venture proves itself before anyone builds a company around it. The idea is never constrained;
 * the proof is: every task is run by the agent, a member request, or a contractor.
 */
export const PROOF_RUNNERS = ["agent", "member request", "contractor"] as const;
export type ProofRunner = (typeof PROOF_RUNNERS)[number];
export const PROOF_NEEDS = ["employee", "licence", "in-person"] as const;
export type ProofNeed = (typeof PROOF_NEEDS)[number];
export const LONG_TERM_OPERATORS = ["agents", "hand-off expected"] as const;
export type LongTermOperator = (typeof LONG_TERM_OPERATORS)[number];

export const ProofTask = z.object({
  key: z.string(),
  task: z.string(),
  what: z.string().optional().describe("The work itself as a short phrase, used if the task has to be reshaped"),
  runBy: z.enum(PROOF_RUNNERS),
  roleKey: z.enum(ROSTER_ROLE_KEYS).optional().describe("A member request: the roster role that answers it"),
  needs: z.array(z.enum(PROOF_NEEDS)).default([]).describe("What the task needs that the Protocol may not have"),
  licence: z.string().optional().describe("The licence the task needs, if any"),
  place: z.string().optional().describe("Where someone must be in person, if anywhere"),
});
export type ProofTask = z.infer<typeof ProofTask>;

export const ProofReshape = z.object({
  taskKey: z.string(),
  need: z.enum(PROOF_NEEDS),
  was: z.string(),
  now: z.string(),
  why: z.string(),
});
export type ProofReshape = z.infer<typeof ProofReshape>;

export const ProofPlan = z.object({
  tasks: z.array(ProofTask).min(1),
  longTermOperator: z.enum(LONG_TERM_OPERATORS),
  operatorReason: z.string(),
  entrepreneurBuilds: z.string().describe("What an entrepreneur would need to build to run it after a hand-off"),
  reshaped: z.array(ProofReshape).default([]).describe("Where the operability check sent the proof back, and what the agent changed"),
});
export type ProofPlan = z.infer<typeof ProofPlan>;

export const PitchDeck = z.object({
  id: z.string().describe("deck-<slug>-v<n>"),
  ventureId: z.string(),
  version: z.number().int(),
  status: z.enum(["published", "superseded", "proposed"]).describe("proposed: a material change waiting for the steward"),
  publishedAt: Iso,
  author: z.string().describe("Model id, 'script', or 'reconstructed'"),
  protocolVersion: z.string(),
  purpose: z.string().describe("One declarative sentence"),
  slides: z.array(Slide),
  market: z
    .object({
      method: z.enum(["bottom-up", "top-down"]),
      formula: z.string(),
      steps: z.array(z.string()).describe("Claim ids, in order"),
      tam: z.string(),
      sam: z.string(),
      som: z.string(),
      somHorizonMonths: z.number(),
    })
    .optional()
    .describe("Absent: not sized yet"),
  alternatives: z.array(z.object({ name: z.string(), kind: z.enum(["incumbent", "workaround", "do-nothing", "adjacent"]), claimId: z.string() })),
  pricing: z.object({ claimId: z.string(), price: z.number(), unit: z.string(), cadence: z.enum(["month", "year", "one-time", "per-use"]) }),
  budget: z.array(BudgetLine),
  plan: PlanInput.optional().describe("Absent on decks written before the business plan"),
  contractors: z.array(ContractorLine).default([]),
  requestPlan: z.array(RequestPlanItem),
  milestones: z.array(Milestone),
  killCriteria: z.array(KillCriterion),
  premortem: z.array(PremortemItem),
  primaryMetric: z.object({ name: z.string(), unit: z.string(), target: z.number(), by: z.string().describe("Milestone key") }),
  seatPlan: SeatPlan.describe("Computed by code, never by the model"),
  currentRule: SeatPlan.optional().describe("Legacy decks: what the current rule would ask for"),
  roster: z.array(RosterRole).describe("Computed by code from the plan"),
  proof: ProofPlan.optional().describe("Absent on decks written before proof plans"),
  rosterInput: z.object({
    motions: z.array(z.string()),
    needsIntegration: z.boolean(),
    regulated: z.array(z.string()),
    hints: z.record(z.string(), z.object({ label: z.string(), qualifications: z.array(z.string()), clusters: z.array(z.string()), keywords: z.array(z.string()) })),
  }),
  changes: z.array(z.object({ path: z.string(), before: z.unknown().optional(), after: z.unknown().optional(), material: z.boolean() })).default([]),
  cause: z.object({ kind: z.enum(["pitch", "qa", "rfe", "steward", "lesson", "migration"]), ref: z.string().optional(), note: z.string().optional() }),
  decisionId: z.string().optional(),
  banner: z.string().optional().describe("e.g. reconstructed at migration"),
});
export type PitchDeck = z.infer<typeof PitchDeck>;

/** A claim on a roster role. Nobody needs a seat to claim one; it counts once the member is verified and fits. */
export const RoleClaim = z.object({
  id: z.string(),
  ventureId: z.string(),
  roleKey: z.enum(ROSTER_ROLE_KEYS),
  handle: Handle,
  at: Iso,
  status: z.enum(["claimed", "withdrawn"]),
  note: z.string().optional(),
});
export type RoleClaim = z.infer<typeof RoleClaim>;

/* ---------- member Q&A ---------- */

export const Citation = z.object({ deckVersion: z.number(), slideKey: z.enum(SLIDE_KEYS), claimId: z.string() });
export type Citation = z.infer<typeof Citation>;

export const Answer = z.object({
  at: Iso,
  by: z.string().describe("Model id or 'script'; always the operating agent"),
  status: z.enum(["answered", "partial", "unknown"]),
  text: z.string(),
  citations: z.array(Citation),
  restsOn: z.array(z.string()).describe("Cited claim ids whose basis is an estimate or an assumption"),
  material: z.boolean(),
  materialReason: z.string().optional(),
  routed: z.object({ rfeId: z.string().optional(), deckVersion: z.number().optional() }).optional(),
  updates: z.array(z.object({ at: Iso, text: z.string(), ref: z.string() })).default([]),
});
export type Answer = z.infer<typeof Answer>;

export const Question = z.object({
  id: z.string(),
  ventureId: z.string(),
  handle: Handle,
  text: z.string(),
  at: Iso,
  deckVersion: z.number().describe("Version on screen when asked"),
  status: z.enum(["open", "answered", "routed", "held", "hidden"]),
  upvotes: z.array(Handle).default([]),
  answer: Answer.optional(),
  stewardNote: z.string().optional(),
  hidden: z.object({ by: z.string(), reason: z.string(), at: Iso }).optional(),
});
export type Question = z.infer<typeof Question>;

/* ---------- operating loop ---------- */

export const DEFAULT_ALIVE = ["alive", "dead", "too early"] as const;

/** The weekly member update: one number, an honest default-alive check, lowlights, and at most a few asks that become requests. */
export const MemberUpdate = z.object({
  id: z.string(),
  ventureId: z.string(),
  at: Iso,
  week: z.number().int().describe("Weeks since formation"),
  metric: z.object({ name: z.string(), value: z.number(), unit: z.string(), previous: z.number().optional(), changePct: z.number().optional(), note: z.string() }),
  defaultAlive: z.object({ status: z.enum(DEFAULT_ALIVE), detail: z.string() }),
  highlights: z.array(z.string()),
  lowlights: z.array(z.string()).min(1),
  decisions: z.object({ taken: z.number(), pending: z.number() }),
  asks: z.array(z.object({ text: z.string(), rfeId: z.string() })),
  credits: z.array(z.object({ handle: Handle, units: z.number() })),
});
export type MemberUpdate = z.infer<typeof MemberUpdate>;

export const REVIEW_CALLS = ["persevere", "pivot", "propose shutdown"] as const;

/** The monthly steward review: the agent recommends; the steward signs. */
export const StewardReview = z.object({
  id: z.string(),
  ventureId: z.string(),
  at: Iso,
  metricTrend: z.string(),
  defaultAlive: z.enum(DEFAULT_ALIVE),
  killRules: z.array(z.object({ key: z.string(), condition: z.string(), by: Iso, status: z.enum(["on track", "at risk", "fired", "met"]) })),
  experiments: z.array(z.string()).describe("Open experiment ids"),
  call: z.enum(REVIEW_CALLS),
  reason: z.string(),
  decisionId: z.string(),
});
export type StewardReview = z.infer<typeof StewardReview>;

/** Written down before any money is spent on a test: what would count as success, and when to stop. */
export const Experiment = z.object({
  id: z.string(),
  ventureId: z.string(),
  at: Iso,
  premise: z.string().describe("The assumption under test, as one falsifiable sentence"),
  hypothesis: z.string(),
  metric: z.string(),
  successBar: z.string(),
  stopRule: z.string(),
  budgetUsd: z.number(),
  endsAt: Iso,
  status: z.enum(["running", "passed", "failed", "stopped"]),
  result: z.string().optional(),
  scoredAt: Iso.optional(),
  premiseTestRfeId: z.string().optional(),
});
export type Experiment = z.infer<typeof Experiment>;

export const Venture = z.object({
  id: z.string(),
  slug: z.string(),
  name: z.string(),
  tagline: z.string(),
  pitch: z.string(),
  isProtocol: z.boolean().default(false),
  objective: Objective,
  distributionPolicy: z.string(),
  budget: z.array(z.object({ label: z.string(), usd: z.number() })),
  minRaiseUsd: z.number(),
  seatPriceUsd: z.number().optional().describe("This venture's seat price; unset means the price before per-venture pricing (SEAT_PRICE_USD)"),
  status: z.enum(VENTURE_STATUSES),
  statusHistory: z.array(z.object({ status: z.enum(VENTURE_STATUSES), at: Iso, note: z.string().optional() })),
  killRules: z.array(z.string()),
  killDate: Iso.optional(),
  stewardHandle: Handle,
  protocolVersion: z.string(),
  voice: z.string().describe("How the venture writes, used for recruiting drafts"),
  accent: z.string().describe("Hex colour for the venture's brand"),
  customers: z.object({ count: z.number(), segment: z.string(), retention: z.string().optional() }),
  quarters: z.array(
    z.object({
      quarter: z.string(),
      revenueUsd: z.number(),
      costsUsd: z.number(),
      passThroughUsd: z.number(),
      runwayUsd: z.number(),
    }),
  ),
  postMortem: PostMortem.optional(),
  memo: Memo.optional(),
  cohortId: z.string().optional(),
  codename: z.string().optional().describe("Shown while the venture's batch is announced"),
  teaser: z.string().optional().describe("One line shown while the batch is announced"),
  roster: z.array(RosterSlot).default([]),
  liftoff: z
    .object({ askedAt: Iso.optional(), extendedUntil: Iso.optional(), passedAt: Iso.optional() })
    .optional()
    .describe("After the raise: filling the roster before formation money is spent"),
  tags: z.array(Tag).default([]),
  lessonIds: z.array(z.string()).default([]).describe("Adopted lessons the venture was spawned or run with"),
  contradictions: z
    .array(z.object({ lessonId: z.string(), reason: z.string() }))
    .default([])
    .describe("Adopted lessons the idea contradicts, with the agent's reason this case differs"),
  handOff: z
    .object({ offerId: z.string(), at: Iso, entrepreneur: Handle, priceUsd: z.number(), payoutUsd: z.number(), retainedSharePct: z.number() })
    .optional()
    .describe("Set when unit holders approved an adoption offer and the venture left the Protocol"),
  createdAt: Iso,
});
export type Venture = z.infer<typeof Venture>;

export const VERIFY_SOURCES = ["linkedin", "x", "steward"] as const;
export type VerifySource = (typeof VERIFY_SOURCES)[number];

export const MEMBER_ATTRIBUTES = ["role", "company", "seniority", "industry", "handle", "reach"] as const;
export type MemberAttribute = (typeof MEMBER_ATTRIBUTES)[number];

export const Verification = z.object({
  id: z.string(),
  source: z.enum(VERIFY_SOURCES),
  ref: z.string().describe("Profile URL or handle. Private: shown only to the steward, never on public pages."),
  attributes: z.array(z.enum(MEMBER_ATTRIBUTES)),
  status: z.enum(["pending", "confirmed", "rejected"]),
  requestedAt: Iso,
  decidedAt: Iso.optional(),
  decidedBy: z.string().optional(),
});
export type Verification = z.infer<typeof Verification>;

export const Member = z.object({
  handle: Handle,
  role: z.string(),
  industry: z.string(),
  seniority: z.enum(["early", "mid", "senior", "executive"]),
  reputationTier: z.enum(["new", "contributor", "trusted"]).describe("Public tier. Calibration scoring is a stub."),
  cluster: z.string().describe("Profile cluster. Responses from one cluster count once."),
  profile: z.object({
    companies: z.array(z.string()),
    buyingAuthority: z.string(),
    tools: z.array(z.string()),
    verticals: z.array(z.string()),
    canReach: z.array(z.string()),
  }),
  dailyPushCap: z.number(),
  credibilityName: z.string().optional().describe("Shown only on Credibility RFEs the member opted into"),
  onboardedAt: Iso.optional().describe("Interview completed"),
  qualification: z.enum(["pending", "qualified", "declined"]).default("pending"),
  qualifiedAt: Iso.optional(),
  verifications: z.array(Verification).default([]),
  joinedAt: Iso,
  source: z.string().optional().describe("GTM draft id that brought this member in"),
  referredBy: z.string().optional().describe("The share code whose link brought this member in, first touch only"),
  simulated: z.boolean().optional().describe("Seeded demo member; the simulator answers on their behalf"),
});
export type Member = z.infer<typeof Member>;

export const GovernanceSpec = z.object({
  matter: z.string(),
  threshold: z.enum(["simple", "super"]),
  windowEndsAt: Iso,
  paramKey: z.string().optional(),
  currentValue: z.unknown().optional(),
  proposedValue: z.unknown().optional(),
  effect: z.string(),
});

export const GtmSpec = z.object({
  channel: z.enum(["x_post", "outreach", "linkedin"]),
  purpose: z.enum(["launch", "gap", "teaser"]).optional(),
  gap: z.string().optional().describe("Roster slot type or request id this draft recruits for"),
  cohortId: z.string().optional(),
  posts: z.array(z.string()).optional(),
  segments: z
    .array(z.object({ segment: z.string(), queries: z.array(z.string()), template: z.string() }))
    .optional(),
  postedAt: Iso.optional(),
});

export const Rfe = z.object({
  id: z.string(),
  ventureId: z.string(),
  type: z.enum(RFE_TYPES),
  kind: z.enum(["request", "governance"]).default("request"),
  title: z.string(),
  question: z.string(),
  recommendation: z.string().describe("The agent's current answer, stated up front"),
  confidence: z.number().min(0).max(1),
  stakes: Stakes,
  format: z.enum(["choice", "scale", "text", "action"]),
  options: z.array(z.string()).optional(),
  scaleLabels: z.tuple([z.string(), z.string()]).optional(),
  offerUnits: z.number(),
  audience: z.string().describe("Who should answer"),
  targetOverride: z.number().optional(),
  extended: z.boolean().optional().describe("Set once the N rule has extended the target for divergence"),
  status: z.enum(RFE_STATUSES),
  postedAt: Iso,
  resolvedAt: Iso.optional(),
  resolution: z.string().optional(),
  decisionId: z.string().optional(),
  assignedTo: Handle.optional(),
  governance: GovernanceSpec.optional(),
  gtm: GtmSpec.optional(),
  demandCheck: z.boolean().optional().describe("Public demand check: any qualified member may answer"),
  notes: z.array(z.object({ label: z.string(), text: z.string() })).optional().describe("Notes for the people asked, e.g. counsel"),
  flagId: z.string().optional().describe("Set on the member vote that resolves a conduct flag"),
  lessonIds: z.array(z.string()).optional(),
  tags: z.array(Tag).optional(),
});
export type Rfe = z.infer<typeof Rfe>;

export const Response = z.object({
  id: z.string(),
  rfeId: z.string(),
  handle: Handle,
  via: z.enum(["structured", "text", "voice"]),
  choice: z.string().optional(),
  scale: z.number().optional(),
  text: z.string().optional(),
  transcript: z.string().optional(),
  extractedBy: z.string().optional(),
  counterUnits: z.number().optional(),
  weight: z.number().optional().describe("Vested units, for governance votes"),
  at: Iso,
});
export type Response = z.infer<typeof Response>;

export const Grant = z.object({
  id: z.string(),
  ventureId: z.string(),
  handle: Handle,
  slice: z.enum(["rfe", "steward", "cohort", "founder"]),
  rfeId: z.string().optional(),
  units: z.number(),
  status: z.enum(GRANT_STATUSES),
  at: Iso,
  vestsAt: Iso.optional(),
  note: z.string().optional(),
  referred: Handle.optional().describe("A referral grant: the member whose roster work it rewards"),
});
export type Grant = z.infer<typeof Grant>;

export const SHARE_CHANNELS = ["copy", "native", "x", "linkedin", "other"] as const;
export type ShareChannel = (typeof SHARE_CHANNELS)[number];
export const REF_STAGES = ["visit", "candidate", "qualified", "seat", "role"] as const;
export type RefStage = (typeof REF_STAGES)[number];

export const ShareCode = z.object({
  code: z.string().regex(/^[a-z0-9]{6,16}$/),
  createdAt: Iso,
  handle: Handle.optional().describe("Set once the sharer has a handle; anonymous until then"),
  linkedAt: Iso.optional(),
});
export type ShareCode = z.infer<typeof ShareCode>;

export const RefEvent = z.object({
  id: z.string(),
  code: z.string(),
  at: Iso,
  stage: z.enum(REF_STAGES),
  ventureId: z.string().optional(),
  cohortId: z.string().optional(),
  handle: Handle.optional().describe("The referred member, from the candidate stage on"),
  visitor: z.string().optional().describe("Anonymous visitor id, so repeat visits count once"),
  channel: z.enum(SHARE_CHANNELS).optional(),
});
export type RefEvent = z.infer<typeof RefEvent>;

export const WAITLIST_KINDS = ["venture", "batch"] as const;
export const WaitlistEntry = z.object({
  id: z.string(),
  at: Iso,
  kind: z.enum(WAITLIST_KINDS).describe("A full venture, or the next batch"),
  handle: Handle,
  ventureId: z.string().optional(),
  cohortId: z.string().optional().describe("The announced batch; empty means whichever batch is announced next"),
  code: z.string().optional().describe("The share code that brought them, if any"),
  channel: z.enum(SHARE_CHANNELS).optional(),
  notifiedAt: Iso.optional(),
  notice: z.string().optional().describe("What they were told, and why"),
});
export type WaitlistEntry = z.infer<typeof WaitlistEntry>;

export const DecisionFacts = z.object({
  spendUsd: z.number().default(0),
  contract: z.boolean().default(false),
  pricingChange: z.boolean().default(false),
  newOutboundDomain: z.boolean().default(false),
  publicPost: z.boolean().default(false),
  hiresPerson: z.boolean().default(false).describe("Hires or contracts a person to do work"),
  contractorPitch: z.boolean().default(false).describe("Pitches a venture whose work is done by the agent plus paid contractors"),
  bigQuestion: z.string().optional().describe("A big-question key from RESERVED_MATTERS; unit holders vote on it"),
  goalpostMove: z.boolean().default(false).describe("Changes a kill rule, a target or the primary metric"),
  materialDeckChange: z.boolean().default(false).describe("Changes a part of the deck holders relied on"),
  budgetLine: z.string().optional().describe("The published budget line this spend comes from"),
  channelTest: z.boolean().default(false).describe("Spends on a test of a new channel or tactic; needs an experiment written first"),
  experimentId: z.string().optional(),
  deckId: z.string().optional().describe("The deck version this decision publishes"),
  seatPriceDeckId: z.string().optional().describe("The deck whose seat price this decision signs off"),
  liftoff: z.enum(["extend", "end"]).optional().describe("The steward's call when the roster isn't filled in time"),
  review: z.enum(REVIEW_CALLS).optional().describe("The monthly steward review's recommendation; the steward signs"),
});
export type DecisionFacts = z.infer<typeof DecisionFacts>;

export const Decision = z.object({
  id: z.string(),
  ventureId: z.string(),
  title: z.string(),
  reasoning: z.string(),
  summary: z.string().optional().describe("One short reason for verified members; the full reasoning is for unit holders"),
  confidence: z.number().min(0).max(1),
  facts: DecisionFacts,
  bin: z.enum(DECISION_BINS),
  binReasons: z.array(z.string()),
  status: z.enum(DECISION_STATUSES),
  at: Iso,
  takenAt: Iso.optional(),
  outcome: z.string().optional(),
  stewardNote: z.string().optional(),
  rfeId: z.string().optional(),
  embargo: z.object({ until: Iso, reason: z.string() }).optional(),
  transition: z.enum(VENTURE_STATUSES).optional().describe("Lifecycle move applied when the decision is taken"),
  model: z.string().describe("Model id, or 'script' for the replayed pilot script"),
  lessonIds: z.array(z.string()).optional().describe("Adopted lessons cited in the reasoning"),
  contradicts: z.array(z.string()).optional().describe("Adopted lessons this decision contradicts; each moved it up a bin"),
  conduct: z
    .object({
      result: z.enum(["pass", "concern", "stop"]),
      findings: z.array(z.string()),
      regulated: z.array(z.string()),
      counselNote: z.string().optional(),
      reviewedBy: z.string(),
    })
    .optional(),
});
export type Decision = z.infer<typeof Decision>;

export const LESSON_TOPICS = [
  "pricing-requests",
  "answers-needed",
  "why-ventures-end",
  "whose-advice",
  "finding-members",
  "reaching-buyers",
  "which-ideas",
  "when-to-ask",
] as const;
export type LessonTopic = (typeof LESSON_TOPICS)[number];

export const LESSON_TOPIC_LABELS: Record<LessonTopic, string> = {
  "pricing-requests": "Pricing requests",
  "answers-needed": "How many answers to wait for",
  "why-ventures-end": "Why ventures end",
  "whose-advice": "Whose advice to weight",
  "finding-members": "Finding members",
  "reaching-buyers": "Reaching buyers",
  "which-ideas": "Which ideas work",
  "when-to-ask": "When the agent asks first",
};

export const LESSON_STAGES = ["Any stage", "Choosing ideas", "Selling seats", "Before the first customer", "After the first customer"] as const;
export type LessonStage = (typeof LESSON_STAGES)[number];

export const HOW_SURE_LEVELS = ["Strong", "Moderate", "Early signal"] as const;
export type HowSureLevel = (typeof HOW_SURE_LEVELS)[number];

export const Evidence = z.object({
  kind: z.enum(["decision", "rfe", "venture", "draft", "cohort"]),
  id: z.string(),
  label: z.string(),
});
export type Evidence = z.infer<typeof Evidence>;

/**
 * A lesson, written for a member to read in ten seconds. The classification it
 * applies to lives in its tags, so renames and merges keep it current.
 */
export const Lesson = z.object({
  id: z.string().describe("L-001, L-002, …"),
  topic: z.enum(LESSON_TOPICS),
  headline: z.string().describe("One plain sentence: the takeaway"),
  whatHappened: z.string().describe("Two or three sentences naming the venture, the event and the number"),
  whatWeDoDifferently: z.string().describe("The concrete change later ventures inherit"),
  howSure: z.object({
    level: z.enum(HOW_SURE_LEVELS),
    reason: z.string().describe("Plain reason, e.g. 'seen in 1 venture, 2 answers'"),
  }),
  appliesTo: z.object({ stage: z.enum(LESSON_STAGES) }),
  metric: z
    .object({ name: z.string(), value: z.number(), unit: z.string().optional() })
    .describe("Internal: what the lesson measured. Refreshes the lesson when it changes; not shown."),
  evidence: z.array(Evidence),
  cohortId: z.string(),
  confidence: z.number().min(0).max(1).describe("Internal: decides adoption and the howSure level; not shown"),
  status: z.enum(["proposed", "adopted", "retired"]),
  tags: z.array(Tag).default([]),
  guard: z
    .object({
      keywords: z.array(z.string()).describe("A planned action whose title or reasoning matches any of these contradicts the lesson"),
      maxSpendUsd: z.number().optional(),
      pricingChange: z.boolean().optional(),
    })
    .optional(),
  paramKey: z.string().optional().describe("Set when the lesson implies a parameter change; it then posts a vote"),
  proposedValue: z.unknown().optional(),
  amendmentRfeId: z.string().optional(),
  writtenBy: z.string().describe("Model id, or 'template'"),
  at: Iso,
});
export type Lesson = z.infer<typeof Lesson>;

export const COHORT_STATUSES = ["announced", "live", "closed"] as const;
export type CohortStatus = (typeof COHORT_STATUSES)[number];

export const Cohort = z.object({
  id: z.string(),
  number: z.number().describe("Shown as Batch 001, 002, …"),
  status: z.enum(COHORT_STATUSES),
  announcedAt: Iso,
  opensAt: Iso.describe("Public seat window opens; qualified members get in EARLY_ACCESS_HOURS before"),
  closesAt: Iso,
  closedAt: Iso.optional(),
  ventureIds: z.array(z.string()),
  notes: z.array(z.string()).default([]).describe("Batch notes, written by the learning loop at close"),
  slotPlan: z
    .array(
      z.object({
        endMarket: z.string(),
        businessModel: z.string(),
        kind: z.enum(["pilot", "overdue", "exploration", "outcomes"]),
        reason: z.string(),
      }),
    )
    .default([])
    .describe("Why each slot went to its end market and business model"),
});
export type Cohort = z.infer<typeof Cohort>;

export const Flag = z.object({
  id: z.string(),
  ventureId: z.string(),
  target: z.object({ kind: z.enum(["decision", "rfe", "venture"]), id: z.string(), label: z.string() }),
  by: Handle,
  reason: z.string(),
  at: Iso,
  voteRfeId: z.string().optional(),
  status: z.enum(["voting", "upheld", "dismissed"]),
  certifiedAt: Iso.optional(),
  certifiedBy: z.string().optional(),
});
export type Flag = z.infer<typeof Flag>;

export const OFFER_STATUSES = ["submitted", "voting", "approved", "declined", "withdrawn"] as const;
export type OfferStatus = (typeof OFFER_STATUSES)[number];

/**
 * An entrepreneur's offer to adopt a venture and run it with their own money. The agent
 * summarises it, the steward checks it against the rules, and unit holders vote.
 */
export const HandOffOffer = z.object({
  id: z.string(),
  ventureId: z.string(),
  entrepreneur: Handle.describe("A verified member; a pseudonymous handle is fine"),
  at: Iso,
  priceUsd: z.number().describe("What the entrepreneur pays for the venture"),
  plan: z.string().describe("What they will do with it, in their words"),
  contributors: z.object({
    cashUsd: z.number().describe("Paid now to people with earned units, split by vested units"),
    retainedSharePct: z.number().describe("Share of profit contributors keep after the hand-off; 0 for none"),
    note: z.string().optional(),
  }),
  summary: z.string().describe("The agent's plain summary for unit holders"),
  check: z
    .object({
      by: Handle,
      at: Iso,
      passed: z.boolean(),
      items: z.array(z.object({ label: z.string(), ok: z.boolean(), detail: z.string() })),
      warnings: z.array(z.string()).default([]),
    })
    .optional()
    .describe("The steward's conformance check"),
  voteRfeId: z.string().optional(),
  status: z.enum(OFFER_STATUSES),
  decidedAt: Iso.optional(),
  outcome: z.string().optional(),
});
export type HandOffOffer = z.infer<typeof HandOffOffer>;

export const LedgerEntry = z.object({
  id: z.string(),
  at: Iso,
  ventureId: z.string(),
  kind: z.enum([
    "seat",
    "refund",
    "grant",
    "vest",
    "forfeit",
    "distribution",
    "redaction",
    "amendment",
    "notify",
    "status",
    "breach",
    "qualification",
    "contractor-pay",
    "service-charge",
    "service-cost",
    "handoff",
    "handoff-payout",
  ]),
  handle: Handle.optional(),
  usd: z.number().optional(),
  units: z.number().optional(),
  ref: z.string().optional(),
  deckId: z.string().optional().describe("Seats: the deck version it was taken under"),
  note: z.string(),
});
export type LedgerEntry = z.infer<typeof LedgerEntry>;

export const Distribution = z.object({
  id: z.string(),
  ventureId: z.string(),
  quarter: z.string(),
  at: Iso,
  profitUsd: z.number(),
  passThroughUsd: z.number(),
  protocolUsd: z.number(),
  contributorUsd: z.number(),
  treasuryUsd: z.number().describe("Share of ungranted reserve, retained"),
  perUnitUsd: z.number(),
});
export type Distribution = z.infer<typeof Distribution>;

export const Amendment = z.object({
  id: z.string(),
  paramKey: z.string(),
  oldValue: z.unknown(),
  newValue: z.unknown(),
  rfeId: z.string(),
  version: z.string(),
  at: Iso,
});
export type Amendment = z.infer<typeof Amendment>;

export const Store = z.object({
  meta: z.object({
    clock: Iso,
    protocolVersion: z.string(),
    scriptCursor: z.record(z.string(), z.number()),
    tick: z.number(),
    seq: z.number().default(0).describe("Id sequence, so simulations are reproducible"),
  }),
  ventures: z.array(Venture),
  members: z.array(Member),
  rfes: z.array(Rfe),
  responses: z.array(Response),
  grants: z.array(Grant),
  decisions: z.array(Decision),
  ledger: z.array(LedgerEntry),
  distributions: z.array(Distribution),
  amendments: z.array(Amendment),
  cohorts: z.array(Cohort).default([]),
  lessons: z.array(Lesson).default([]),
  flags: z.array(Flag).default([]),
  tagLog: z.array(TagLogEntry).default([]),
  decks: z.array(PitchDeck).default([]),
  roleClaims: z.array(RoleClaim).default([]),
  questions: z.array(Question).default([]),
  updates: z.array(MemberUpdate).default([]),
  reviews: z.array(StewardReview).default([]),
  experiments: z.array(Experiment).default([]),
  offers: z.array(HandOffOffer).default([]),
  shareCodes: z.array(ShareCode).default([]),
  refEvents: z.array(RefEvent).default([]),
  waitlist: z.array(WaitlistEntry).default([]),
});
export type Store = z.infer<typeof Store>;

export const PRIMITIVES = {
  Venture,
  Member,
  Rfe,
  Response,
  Grant,
  Decision,
  LedgerEntry,
  HandOffOffer,
  Distribution,
  Amendment,
  Cohort,
  Lesson,
  Classification,
  Flag,
  PitchDeck,
  RoleClaim,
  Question,
  MemberUpdate,
  StewardReview,
  Experiment,
  ShareCode,
  RefEvent,
  WaitlistEntry,
} as const;
