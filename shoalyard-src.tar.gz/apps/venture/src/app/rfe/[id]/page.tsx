import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Bot, CheckCircle2, Lock, Megaphone } from "lucide-react";
import {
  atLeast,
  canReadLessons,
  canAnswer,
  decisionTier,
  decisionView,
  gtmStats,
  hasSeat,
  isLive,
  isOpen,
  matterLabel,
  nStatusFor,
  responsesFor,
  rfeById,
  settingValueText,
  ventureById,
  voteStatus,
  voteWeightFor,
  whyAPerson,
} from "@av/protocol";
import { formatParamValue, PARAMS, RFE_TYPE_LABELS, type ParamKey, type ParamValue } from "@av/schema";
import { Pill, RfeTypeBadge, StatusBadge } from "@/components/badges";
import { lessonCitation } from "@/components/lessons-gate";
import { FlagForm } from "@/components/protocol-forms";
import { TagList } from "@/components/protocol-ui";
import { NProgress } from "@/components/n-progress";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getData } from "@/lib/data";
import { TermServer } from "@/lib/terms";
import { formatAgo, formatDateTime, formatPct, formatUnits } from "@/lib/format";
import { AnswerForm } from "./answer-form";

export async function generateMetadata(props: PageProps<"/rfe/[id]">): Promise<Metadata> {
  const { id } = await props.params;
  const { store } = await getData();
  return { title: rfeById(store, id)?.title ?? "Request not found" };
}

export default async function RfePage(props: PageProps<"/rfe/[id]">) {
  const { id } = await props.params;
  const { store, params, viewer, member } = await getData();
  const rfe = rfeById(store, id);
  if (!rfe) notFound();
  const venture = ventureById(store, rfe.ventureId);
  const clock = store.meta.clock;
  const responses = responsesFor(store, rfe.id).sort((a, b) => b.at.localeCompare(a.at));
  const mine = responses.find((r) => r.handle === viewer);
  const open = isOpen(rfe) && isLive(venture);
  const governance = rfe.kind === "governance";
  const n = !governance && !rfe.gtm && rfe.type !== "capital" && !rfe.assignedTo ? nStatusFor(store, rfe, params) : undefined;
  const vote = governance ? voteStatus(store, rfe, params) : undefined;
  const weight = governance ? voteWeightFor(store, rfe, viewer) : 0;
  const grants = store.grants.filter((g) => g.rfeId === rfe.id);
  const myGrant = grants.find((g) => g.handle === viewer);
  const tier = decisionTier(store, venture, member, params);
  const seesAnswers = atLeast(tier, "unit holder");
  const shownResponses = seesAnswers ? responses : responses.filter((r) => r.handle === viewer);
  const linked = rfe.decisionId ? store.decisions.find((d) => d.id === rfe.decisionId) : undefined;
  const decision = linked ? decisionView(store, linked, tier, params) : undefined;
  const gtm = rfe.gtm ? gtmStats(store, rfe.id) : undefined;
  const allowed = member ? canAnswer(store, rfe, viewer) : false;
  const style = { "--accent-color": venture.accent } as React.CSSProperties;

  let blocker: React.ReactNode = null;
  if (!open) blocker = null;
  else if (mine) blocker = null;
  else if (rfe.gtm) blocker = <>The steward posts recruiting drafts by hand. The agent never posts or sends DMs.</>;
  else if (rfe.type === "capital")
    blocker = (
      <>
        This request is answered by taking seats.{" "}
        <Link className="font-medium underline" href={`/v/${venture.slug}/seat`}>
          Take a seat
        </Link>
      </>
    );
  else if (!allowed && rfe.assignedTo) blocker = <>Assigned to @{rfe.assignedTo}. Switch “view as” to answer.</>;
  else if (member && member.qualification !== "qualified")
    blocker =
      member.qualification === "declined" ? (
        <>The steward declined @{viewer}&apos;s profile, so it can&apos;t answer requests.</>
      ) : (
        <>
          Get <TermServer id="verified">verified</TermServer> to answer:{" "}
          <Link className="font-medium underline" href="/onboarding?step=qualify#qualify">
            link LinkedIn or X (2 minutes)
          </Link>
        </>
      );
  else if (!allowed)
    blocker = (
      <>
        Answering needs a seat in {venture.name}.{" "}
        {!venture.isProtocol && (
          <Link className="font-medium underline" href={`/v/${venture.slug}/seat`}>
            Take a seat
          </Link>
        )}
      </>
    );
  else if (governance && weight <= 0) blocker = (
      <>
        You can vote once you have <TermServer id="vesting">vested</TermServer> units in {venture.isProtocol ? "the Protocol" : venture.name}.
      </>
    );

  return (
    <div style={style} className="mx-auto max-w-5xl space-y-6">
      <Link href={`/v/${venture.slug}#requests`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900">
        <ArrowLeft className="size-4" /> {venture.name}
      </Link>

      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="space-y-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-1.5">
              <RfeTypeBadge type={rfe.type} governance={governance} />
              <Pill>How much rides on it: {rfe.stakes}</Pill>
              <Pill>{open ? (rfe.status === "quorum" ? "Enough answers in" : "Open") : "Closed"}</Pill>
              <span className="text-xs text-zinc-500">Posted {formatAgo(rfe.postedAt, clock)}</span>
            </div>
            <h1 className="text-2xl font-semibold tracking-tight text-balance">{rfe.title}</h1>
            <p className="text-pretty text-zinc-700">{rfe.question}</p>
            <div className="rounded-lg border-l-4 border-zinc-900 bg-white py-2 pr-3 pl-3 text-sm">
              <p className="font-medium text-zinc-900">Why this needs a person</p>
              <p className="text-zinc-700">{whyAPerson(rfe)}</p>
            </div>
            <p className="text-sm text-zinc-500">
              {RFE_TYPE_LABELS[rfe.type].asks}. Who should answer: {rfe.audience}.
            </p>
            {rfe.tags && <TagList tags={rfe.tags} />}
            {member?.qualification === "qualified" && !rfe.flagId && (
              <p className="text-xs text-zinc-500">
                <FlagForm kind="rfe" id={rfe.id} label={rfe.title} />
              </p>
            )}
            {!!rfe.lessonIds?.length && !canReadLessons(member, params) && (
              <p className="text-xs text-zinc-500">{lessonCitation(rfe.lessonIds.length)}</p>
            )}
            {!!rfe.lessonIds?.length && canReadLessons(member, params) && (
              <ul className="space-y-1 text-xs text-zinc-500">
                {rfe.lessonIds.map((lid) => (
                  <li key={lid}>
                    Based on lesson{" "}
                    <Link href={`/learning#${lid}`} className="font-mono font-medium text-sky-800 hover:underline">
                      {lid}
                    </Link>
                    {store.lessons.find((l) => l.id === lid) ? `: ${store.lessons.find((l) => l.id === lid)!.headline}` : ""}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {rfe.notes?.map((note) => (
            <div key={note.label} className="rounded-xl border border-amber-200 bg-amber-50/60 p-4 text-sm">
              <p className="text-xs font-medium tracking-wide text-amber-800 uppercase">{note.label}</p>
              <p className="mt-1 text-amber-950">{note.text}</p>
            </div>
          ))}

          <div className="rounded-xl border border-zinc-200 bg-white p-4">
            <p className="flex items-center gap-1.5 text-xs font-medium tracking-wide text-zinc-500 uppercase">
              <Bot className="size-3.5" /> {governance ? "The proposal" : "The agent's current answer"}
            </p>
            <p className="mt-2 text-zinc-900">{rfe.recommendation}</p>
            {!governance && <p className="mt-2 text-xs text-zinc-500">How sure it is: {Math.round(rfe.confidence * 100)}%</p>}
            {rfe.governance && (
              <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-xs text-zinc-500">What&apos;s being decided</dt>
                  <dd className="first-letter:uppercase">{matterLabel(rfe.governance.matter)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-zinc-500">Passes if</dt>
                  <dd>
                    more than {formatPct((vote?.threshold ?? 0) * 100, 1)} vote yes, and at least {formatPct(params.QUORUM_PCT * 100, 0)} of vested units
                    vote
                  </dd>
                </div>
                {rfe.governance.paramKey && (
                  <div>
                    <dt className="text-xs text-zinc-500">Setting</dt>
                    <dd>
                      <Link href="/protocol#params" className="underline">
                        {rfe.governance.paramKey in PARAMS ? PARAMS[rfe.governance.paramKey as ParamKey].label : rfe.governance.paramKey}
                      </Link>
                      :{" "}
                      {rfe.governance.paramKey in PARAMS
                        ? `${settingValueText(rfe.governance.paramKey as ParamKey, rfe.governance.currentValue)} → ${settingValueText(rfe.governance.paramKey as ParamKey, rfe.governance.proposedValue)}`
                        : `${formatParamValue(rfe.governance.currentValue as ParamValue)} → ${formatParamValue(rfe.governance.proposedValue as ParamValue)}`}
                    </dd>
                  </div>
                )}
                <div>
                  <dt className="text-xs text-zinc-500">Voting closes</dt>
                  <dd>{formatDateTime(rfe.governance.windowEndsAt)} UTC</dd>
                </div>
                <div className="sm:col-span-2">
                  <dt className="text-xs text-zinc-500">Effect if passed</dt>
                  <dd>{rfe.governance.effect}</dd>
                </div>
              </dl>
            )}
          </div>

          {rfe.gtm && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Megaphone className="size-4" /> {rfe.gtm.channel === "x_post" ? "Draft posts for X" : rfe.gtm.channel === "linkedin" ? "Draft post for LinkedIn" : "Outreach plan"}
                </CardTitle>
                <CardDescription>
                  Assigned to @{rfe.assignedTo ?? venture.stewardHandle}. The agent writes it; the steward posts it.
                  {rfe.gtm.postedAt && ` Posted ${formatAgo(rfe.gtm.postedAt, clock)}.`}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {rfe.gtm.posts?.map((p, i) => (
                  <blockquote key={i} className="rounded-lg border border-zinc-200 bg-zinc-50 p-3 text-sm whitespace-pre-line text-zinc-800">
                    {p}
                  </blockquote>
                ))}
                {rfe.gtm.segments?.map((s) => (
                  <div key={s.segment} className="rounded-lg border border-zinc-200 p-3 text-sm">
                    <p className="font-medium">{s.segment}</p>
                    <p className="mt-1 text-xs text-zinc-500">Search: {s.queries.join(" · ")}</p>
                    <p className="mt-2 whitespace-pre-line text-zinc-700">{s.template}</p>
                  </div>
                ))}
                {gtm && (
                  <p className="text-sm text-zinc-600">
                    From this post: {gtm.arrivals} {gtm.arrivals === 1 ? "person" : "people"} joined, {gtm.qualified} got verified, {gtm.seats}{" "}
                    {gtm.seats === 1 ? "took a seat" : "took seats"}, {gtm.responses} answer{gtm.responses === 1 ? "" : "s"}, {gtm.followed} followed by the
                    agent, {gtm.right} held up
                    {gtm.handles.length > 0 && ` (${gtm.handles.map((h) => `@${h}`).join(", ")})`}. Link: <code className="text-xs">/v/{venture.slug}/seat?ref={rfe.id}</code>
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>{governance ? "Your vote" : "Your answer"}</CardTitle>
              {governance && member && (
                <CardDescription>
                  @{viewer} votes with {formatUnits(weight)} vested in {venture.isProtocol ? "the Protocol" : venture.name}.
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              {mine ? (
                <div className="space-y-2 text-sm">
                  <p className="flex items-center gap-1.5 font-medium text-emerald-800">
                    <CheckCircle2 className="size-4" /> You answered {formatAgo(mine.at, clock)} via {mine.via}.
                  </p>
                  {mine.choice && <p>Choice: {mine.choice}</p>}
                  {mine.scale && <p>Scale: {mine.scale}/5</p>}
                  {(mine.text || mine.transcript) && <p className="text-zinc-600">“{mine.text ?? mine.transcript}”</p>}
                  {mine.counterUnits && <p className="text-zinc-600">You asked for {formatUnits(mine.counterUnits)}.</p>}
                  {myGrant ? (
                    <p className="rounded-lg bg-emerald-50 px-3 py-2 text-emerald-900">
                      Units earned, on the ledger: {formatUnits(myGrant.units)}, {myGrant.status}
                      {myGrant.vestsAt && myGrant.status === "accepted" ? `, vests ${formatDateTime(myGrant.vestsAt)} UTC` : ""}.
                    </p>
                  ) : governance ? (
                    <p className="text-zinc-600">Your vote counted for your {formatUnits(mine.weight ?? 0)} vested.</p>
                  ) : open && n ? (
                    <p className="text-zinc-600">
                      {n.effective} of {n.target} answers so far. You&apos;ll get your units when the request closes.
                    </p>
                  ) : null}
                </div>
              ) : !open ? (
                <p className="flex items-center gap-1.5 text-sm text-zinc-500">
                  <Lock className="size-4" /> This request is closed.
                </p>
              ) : blocker ? (
                <p className="text-sm text-zinc-600">{blocker}</p>
              ) : (
                <div className="space-y-3">
                  {!governance && (
                    <p className="text-sm text-zinc-600">
                      The agent has a guess (above). Tell it if you&apos;d do something different, and why.
                    </p>
                  )}
                  <AnswerForm rfe={rfe} />
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <aside className="space-y-4">
          <Card size="sm">
            <CardHeader>
              <CardTitle className="text-sm">{venture.name}</CardTitle>
              <CardDescription>
                <StatusBadge status={venture.status} />
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              {rfe.offerUnits > 0 && (
                <p>
                  <strong>{formatUnits(rfe.offerUnits)}</strong> equal share per accepted answer. Vests in {params.VESTING_DAYS}{" "}
                  days.
                </p>
              )}
              {n && <NProgress n={n} />}
              {vote && (
                <div className="space-y-2">
                  <div className="flex h-2 overflow-hidden rounded-full bg-zinc-100">
                    <div className="bg-fuchsia-500" style={{ width: `${vote.yesShare * 100}%` }} />
                  </div>
                  <p className="text-xs text-zinc-600">
                    {formatPct(vote.yesShare * 100, 0)} yes · {vote.voters} voters · {formatUnits(vote.votedWeight)} of {formatUnits(vote.eligibleWeight)} ·
                    {formatPct(vote.turnout * 100, 0)} of units voted {vote.quorumMet ? "(enough to count)" : "(not enough yet)"}
                  </p>
                </div>
              )}
              {!hasSeat(store, venture.id, viewer) && !venture.isProtocol && isLive(venture) && (
                <Link href={`/v/${venture.slug}/seat`} className={buttonVariants({ variant: "outline", size: "sm" })}>
                  Take a seat to answer
                </Link>
              )}
            </CardContent>
          </Card>

          {(rfe.resolution || grants.length > 0 || decision) && (
            <Card size="sm">
              <CardHeader>
                <CardTitle className="text-sm">Outcome</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                {rfe.resolution && <p>{rfe.resolution}</p>}
                {decision && (
                  <p className="text-zinc-600">
                    Linked decision:{" "}
                    <Link href={`/v/${venture.slug}/decisions/${decision.id}`} className="underline">
                      {decision.redacted ? "kept private for now" : decision.title}
                    </Link>{" "}
                    ({decision.status.replace("_", " ")})
                  </p>
                )}
                {grants.length > 0 && (
                  <ul className="space-y-1">
                    {grants.map((g) => (
                      <li key={g.id} className="flex justify-between text-zinc-700">
                        <span className={g.handle === viewer ? "font-semibold" : ""}>@{g.handle}</span>
                        <span className="tabular-nums">
                          {formatUnits(g.units)} · {g.status}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          )}

          <Card size="sm">
            <CardHeader>
              <CardTitle className="text-sm">Answers ({responses.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {!seesAnswers && responses.length > 0 && (
                <p className="mb-2.5 text-sm text-zinc-500">
                  {member?.qualification === "qualified"
                    ? "Members' answers are for people with units in this venture or in the Protocol."
                    : "Members' answers are for people with units. You see how many there are."}
                </p>
              )}
              {responses.length === 0 ? (
                <p className="text-sm text-zinc-500">No answers yet.</p>
              ) : (
                <ul className="space-y-2.5 text-sm">
                  {shownResponses.slice(0, 15).map((r) => (
                    <li key={r.id} className="space-y-0.5">
                      <div className="flex justify-between gap-2">
                        <span className={r.handle === viewer ? "font-semibold" : "font-medium"}>@{r.handle}</span>
                        <span className="text-xs text-zinc-500">{formatAgo(r.at, clock)}</span>
                      </div>
                      <p className="text-zinc-600">
                        {r.choice ?? (r.scale ? `${r.scale}/5` : "")}
                        {governance && r.weight !== undefined && ` · weight ${r.weight}`}
                        {r.via !== "structured" && <span className="text-xs text-zinc-400"> · {r.via}</span>}
                      </p>
                      {(r.text || r.transcript) && !r.choice && <p className="line-clamp-2 text-zinc-500">“{r.text ?? r.transcript}”</p>}
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}
