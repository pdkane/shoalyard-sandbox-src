import { REF_STAGES, type Member, type RefEvent, type RefStage, type ShareChannel, type ShareCode, type Store } from "@av/schema";
import { newId } from "./util";

/**
 * Sharing is open to everyone. A share link carries an anonymous code, made on first share and kept
 * in a cookie, so nobody needs an account to share. The code is linked to a handle only once its
 * owner has one. Attribution is first touch: the code that brought a member in keeps them.
 */
export const SHARE_CODE_RE = /^[a-z0-9]{6,16}$/;

export const REFERRAL_RULE =
  "Share a venture with someone who'd crush its asks. A referral earns a share only when they fill a role and do the work. Seats never earn shares.";

export const SHARE_CHANNEL_LABELS: Record<ShareChannel, string> = { copy: "Copied link", native: "Phone share sheet", x: "X", linkedin: "LinkedIn", other: "Other" };

export const STAGE_LABELS: Record<RefStage, string> = {
  visit: "Visited",
  candidate: "Signed up",
  qualified: "Verified",
  seat: "Took a seat",
  role: "Claimed a role",
};

export function shareCodeOf(store: Pick<Store, "shareCodes">, code: string | undefined): ShareCode | undefined {
  return code ? store.shareCodes.find((c) => c.code === code) : undefined;
}

export function shareCodesFor(store: Pick<Store, "shareCodes">, handle: string): ShareCode[] {
  return store.shareCodes.filter((c) => c.handle === handle);
}

/** Make the code if it's new, and link it to a handle if it has none yet. A code never moves to a second handle. */
export function ensureShareCode(store: Store, code: string, handle?: string): ShareCode {
  if (!SHARE_CODE_RE.test(code)) throw new Error("Share codes are 6–16 lowercase letters or digits.");
  let c = shareCodeOf(store, code);
  if (!c) {
    c = { code, createdAt: store.meta.clock };
    store.shareCodes.push(c);
  }
  if (handle && !c.handle) {
    c.handle = handle;
    c.linkedAt = store.meta.clock;
  }
  return c;
}

/** A visit through a share link. Unknown codes are ignored; one visitor counts once per page subject. */
export function recordVisit(
  store: Store,
  input: { code: string; visitor?: string; ventureId?: string; cohortId?: string; channel?: ShareChannel },
): RefEvent | undefined {
  if (!shareCodeOf(store, input.code)) return undefined;
  const dup = store.refEvents.some(
    (e) => e.stage === "visit" && e.code === input.code && e.visitor && e.visitor === input.visitor && e.ventureId === input.ventureId && e.cohortId === input.cohortId,
  );
  if (dup) return undefined;
  const e: RefEvent = { id: newId(store, "ref"), code: input.code, at: store.meta.clock, stage: "visit", ventureId: input.ventureId, cohortId: input.cohortId, visitor: input.visitor, channel: input.channel };
  store.refEvents.push(e);
  return e;
}

/** A new member arrived through a share link: they're the code's candidate from now on. Nobody refers themselves. */
export function attributeNewMember(store: Store, member: Member, code: string | undefined, ventureId?: string) {
  const c = shareCodeOf(store, code);
  if (!c || member.referredBy || c.handle === member.handle) return;
  member.referredBy = c.code;
  const lastVisit = store.refEvents.filter((e) => e.code === c.code && e.stage === "visit").at(-1);
  recordStage(store, member, "candidate", ventureId ?? lastVisit?.ventureId, lastVisit?.channel);
}

/** A referred member moved a stage further: verified, a seat, a role. Each counts once per venture. */
export function recordStage(store: Store, member: Pick<Member, "handle" | "referredBy">, stage: RefStage, ventureId?: string, channel?: ShareChannel) {
  const code = member.referredBy;
  if (!code) return;
  const first = store.refEvents.find((e) => e.code === code && e.handle === member.handle && e.stage === "candidate");
  // Verification belongs to no venture; credit it to the one the link brought them to.
  const vid = ventureId ?? (stage === "qualified" ? first?.ventureId : undefined);
  if (store.refEvents.some((e) => e.code === code && e.handle === member.handle && e.stage === stage && e.ventureId === vid)) return;
  store.refEvents.push({ id: newId(store, "ref"), code, at: store.meta.clock, stage, ventureId: vid, handle: member.handle, channel: channel ?? first?.channel });
}

export interface ReferralDue {
  ventureId: string;
  referrer: string;
  referred: string;
  code: string;
}

/**
 * Referrals that have earned their units: the referred member holds a counted roster role in the venture
 * and has been paid for answering one of its requests. Seats play no part. Paid once per person per venture.
 */
export function referralsDue(store: Store, ventureId?: string): ReferralDue[] {
  const due: ReferralDue[] = [];
  for (const m of store.members) {
    const c = shareCodeOf(store, m.referredBy);
    if (!c?.handle || c.handle === m.handle || m.qualification !== "qualified") continue;
    const ventures = new Set(store.roleClaims.filter((r) => r.handle === m.handle && r.status === "claimed" && (!ventureId || r.ventureId === ventureId)).map((r) => r.ventureId));
    for (const vid of ventures) {
      const venture = store.ventures.find((v) => v.id === vid);
      if (!venture || venture.stewardHandle === c.handle) continue;
      const worked = store.grants.some((g) => g.ventureId === vid && g.handle === m.handle && g.slice === "rfe" && !g.referred && g.status !== "forfeited");
      const paid = store.grants.some((g) => g.ventureId === vid && g.referred === m.handle);
      if (worked && !paid) due.push({ ventureId: vid, referrer: c.handle, referred: m.handle, code: c.code });
    }
  }
  return due;
}

export interface FunnelRow {
  stage: RefStage;
  label: string;
  count: number;
}

export interface ReferrerFunnel {
  codes: string[];
  stages: FunnelRow[];
  byVenture: { ventureId: string; stages: Record<RefStage, number> }[];
  byChannel: { channel: string; visits: number; candidates: number }[];
  unitsEarned: number;
  referralsPaid: number;
}

const zero = (): Record<RefStage, number> => Object.fromEntries(REF_STAGES.map((s) => [s, 0])) as Record<RefStage, number>;

/** What the codes brought in, stage by stage. Visits count visitors; later stages count people. */
export function referrerFunnel(store: Store, codes: string[], handle?: string): ReferrerFunnel {
  const set = new Set(codes);
  const events = store.refEvents.filter((e) => set.has(e.code));
  const people = (stage: RefStage, ventureId?: string) => {
    const es = events.filter((e) => e.stage === stage && (ventureId === undefined || e.ventureId === ventureId));
    return stage === "visit" ? es.length : new Set(es.map((e) => (stage === "candidate" || stage === "qualified" ? e.handle : `${e.handle}|${e.ventureId}`))).size;
  };
  const ventureIds = [...new Set(events.map((e) => e.ventureId).filter((v): v is string => !!v))];
  const channels = [...new Set(events.map((e) => e.channel ?? "other"))];
  const grants = handle ? store.grants.filter((g) => g.handle === handle && g.referred) : [];
  return {
    codes,
    stages: REF_STAGES.map((stage) => ({ stage, label: STAGE_LABELS[stage], count: people(stage) })),
    byVenture: ventureIds.map((ventureId) => {
      const stages = zero();
      for (const s of REF_STAGES) stages[s] = people(s, ventureId);
      return { ventureId, stages };
    }),
    byChannel: channels.map((channel) => ({
      channel,
      visits: events.filter((e) => e.stage === "visit" && (e.channel ?? "other") === channel).length,
      candidates: events.filter((e) => e.stage === "candidate" && (e.channel ?? "other") === channel).length,
    })),
    unitsEarned: Math.round(grants.reduce((s, g) => s + g.units, 0) * 100) / 100,
    referralsPaid: grants.length,
  };
}

export interface ShareFunnelRow {
  key: string;
  stages: Record<RefStage, number>;
}

export interface ShareFunnelStats {
  byChannel: ShareFunnelRow[];
  byVenture: (ShareFunnelRow & { waiting: number })[];
  totals: Record<RefStage, number>;
  waitlist: { ventures: number; batches: number };
}

/** Every share link's funnel for the learning loop, split by channel and by venture. Counts people, not clicks. */
export function shareFunnelStats(store: Store, ventureIds?: Set<string>): ShareFunnelStats {
  const events = store.refEvents.filter((e) => !ventureIds || !e.ventureId || ventureIds.has(e.ventureId));
  const count = (es: RefEvent[]) => {
    const stages = zero();
    for (const s of REF_STAGES) {
      const at = es.filter((e) => e.stage === s);
      stages[s] = s === "visit" ? at.length : new Set(at.map((e) => (s === "seat" || s === "role" ? `${e.handle}|${e.ventureId}` : e.handle))).size;
    }
    return stages;
  };
  const row = (key: string, es: RefEvent[]): ShareFunnelRow => ({ key, stages: count(es) });
  const channels = [...new Set(events.map((e) => e.channel ?? "other"))].sort();
  const ventures = [...new Set([...events.map((e) => e.ventureId), ...store.waitlist.map((w) => w.ventureId)].filter((v): v is string => !!v && (!ventureIds || ventureIds.has(v))))];
  const open = store.waitlist.filter((w) => !w.notifiedAt);
  return {
    byChannel: channels.map((c) => row(c, events.filter((e) => (e.channel ?? "other") === c))),
    byVenture: ventures.map((v) => ({ ...row(v, events.filter((e) => e.ventureId === v)), waiting: open.filter((w) => w.ventureId === v).length })),
    totals: count(events),
    waitlist: { ventures: open.filter((w) => w.kind === "venture").length, batches: open.filter((w) => w.kind === "batch").length },
  };
}

/** Prefilled share text. A codenamed venture shares its codename and teaser only. */
export function shareText(subject: { kind: "venture"; name: string; codename?: string; announced: boolean; line: string } | { kind: "batch"; label: string; line: string }): string {
  if (subject.kind === "batch") return `${subject.label}: ${subject.line}`;
  if (subject.announced) return `${subject.codename ?? subject.name}, an agent-run venture coming in the next batch: ${subject.line}`;
  return `${subject.name}, an agent-run venture: ${subject.line}`;
}
