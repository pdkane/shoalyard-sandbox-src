"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { useFocusPopover } from "@/lib/use-focus-popover";
import { Popover, PopoverContent, PopoverDescription, PopoverTitle, PopoverTrigger } from "@/components/ui/popover";

export interface TermText {
  id: string;
  term: string;
  short: string;
  example?: string;
}

/**
 * A glossary term in body text. Opens on hover, keyboard focus or tap, and
 * closes on an outside tap or Escape. It is a button, not a link, so a tap on a
 * phone shows the definition instead of navigating. Use it in prose only:
 * never in headings, buttons, badges, table headers or links.
 */
export function Term({ id, term, short, example, children }: TermText & { children?: ReactNode }) {
  const { open, onOpenChange, onFocus } = useFocusPopover();
  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger
        openOnHover
        delay={150}
        closeDelay={100}
        onFocus={onFocus}
        className="inline cursor-help rounded-sm bg-transparent p-0 text-inherit underline decoration-zinc-400 decoration-dotted underline-offset-[3px] hover:decoration-zinc-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-400"
      >
        {children ?? term}
      </PopoverTrigger>
      <PopoverContent>
        <PopoverTitle className="font-semibold text-zinc-900">{term}</PopoverTitle>
        <PopoverDescription className="mt-1 leading-relaxed">{short}</PopoverDescription>
        {example && <p className="mt-2 text-xs leading-relaxed text-zinc-500">Example: {example}</p>}
        <Link href={`/glossary#${id}`} className="mt-2 inline-block text-xs font-medium text-zinc-900 underline underline-offset-2">
          More in the glossary →
        </Link>
      </PopoverContent>
    </Popover>
  );
}
