import Link from "next/link";
import { ArrowLeft, ArrowRight, ChevronDown, Undo2 } from "lucide-react";
import { basisCounts, claimById, currentRuleLine, LONG_TERM_LABELS, planSummary, priceSource, proofRunBy, seatMath, type BusinessPlan, type SeatPriceStatus } from "@av/protocol";
import { BUDGET_CATEGORY_LABELS, SLIDE_TITLES, type Claim, type PitchDeck, type ProofPlan, type ProofRunner, type SeatPlan, type Slide, type SlideKey, type Source } from "@av/schema";
import { REFUND_GUARANTEE, SeatDisclaimer } from "@/components/protocol-ui";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatDate, formatUsd } from "@/lib/format";
import { cn } from "@/lib/utils";

type Basis = Claim["basis"] | "disproved";

const BASIS: Record<Basis, { word: string; className: string; expand: string }> = {
  evidence: { word: "Evidence", className: "border-emerald-600 bg-emerald-600 text-white", expand: "Where it comes from" },
  estimate: { word: "Estimate", className: "border-amber-300 bg-amber-50 text-amber-900", expand: "Method" },
  assumption: { word: "Assumption", className: "border-dashed border-zinc-400 bg-white text-zinc-700", expand: "How it gets tested" },
  disproved: { word: "Disproved", className: "border-rose-200 bg-rose-50 text-rose-800 line-through", expand: "Disproved" },
};

const basisOf = (c: Claim): Basis => (c.disproved ? "disproved" : c.basis);

export function BasisBadge({ basis, className }: { basis: Basis; className?: string }) {
  const b = BASIS[basis];
  return <span className={cn("inline-flex shrink-0 items-center rounded-full border px-2 py-0.5 text-[11px] font-medium", b.className, className)}>{b.word}</span>;
}

function sourceHref(s: Source, slug: string): string | undefined {
  switch (s.kind) {
    case "rfe":
      return `/rfe/${s.ref}`;
    case "decision":
      return `/v/${slug}/decisions/${s.ref}`;
    case "ledger":
      return `/v/${slug}/ledger`;
    case "lesson":
      return `/learning#${s.ref}`;
    case "member-answer":
      return s.ref.startsWith("rfe-") ? `/rfe/${s.ref}` : `/v/${slug}/qa#${s.ref}`;
    default:
      return undefined;
  }
}

export function SourceLine({ sources, slug }: { sources: Source[]; slug: string }) {
  if (!sources.length) return null;
  return (
    <p className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-zinc-500">
      {sources.map((s, i) => {
        const href = sourceHref(s, slug);
        return (
          <span key={i}>
            {href ? (
              <Link href={href} className="underline underline-offset-2 hover:text-zinc-900">
                {s.label}
              </Link>
            ) : (
              s.label
            )}
            {s.kind === "public-data" && !s.verified && <span className="text-zinc-400"> · public data, unchecked</span>}
          </span>
        );
      })}
    </p>
  );
}

export function ClaimRow({ claim, slug }: { claim: Claim; slug: string }) {
  const basis = basisOf(claim);
  const more = claim.disproved
    ? `Struck through ${formatDate(claim.disproved.at)} by ${claim.disproved.by}. It stays on the deck so the record shows what changed.`
    : claim.basis === "estimate"
      ? claim.method
      : claim.basis === "assumption"
        ? claim.test?.how
        : undefined;
  return (
    <li id={claim.id} className="scroll-mt-28 py-2.5">
      <details className="group">
        <summary className={cn("flex cursor-pointer list-none items-start gap-2 [&::-webkit-details-marker]:hidden", !more && "cursor-default")}>
          <BasisBadge basis={basis} className="mt-0.5" />
          <span className={cn("flex-1 text-sm text-pretty text-zinc-800", claim.disproved && "text-zinc-500 line-through")}>{claim.text}</span>
          {more && <ChevronDown className="mt-0.5 size-4 shrink-0 text-zinc-400 transition-transform group-open:rotate-180" aria-hidden />}
        </summary>
        {more && (
          <div className="mt-1.5 ml-1 rounded-md bg-zinc-50 px-3 py-2 text-xs text-zinc-600">
            <span className="font-medium text-zinc-800">{BASIS[basis].expand}: </span>
            {more}
            {claim.basis === "assumption" && claim.test?.rfeId && (
              <>
                {" "}
                <Link href={`/rfe/${claim.test.rfeId}`} className="underline underline-offset-2">
                  The request testing it
                </Link>
              </>
            )}
          </div>
        )}
      </details>
      <SourceLine sources={claim.sources} slug={slug} />
    </li>
  );
}

/** Share of the deck's claims by what they rest on. */
export function HonestyBar({ deck, className }: { deck: Pick<PitchDeck, "slides">; className?: string }) {
  const c = basisCounts(deck);
  const total = c.evidence + c.estimate + c.assumption + c.disproved || 1;
  const parts: { key: Basis; n: number; bar: string }[] = [
    { key: "evidence", n: c.evidence, bar: "bg-emerald-600" },
    { key: "estimate", n: c.estimate, bar: "bg-amber-300" },
    { key: "assumption", n: c.assumption, bar: "bg-[repeating-linear-gradient(45deg,#d4d4d8_0,#d4d4d8_3px,#fff_3px,#fff_6px)]" },
    { key: "disproved", n: c.disproved, bar: "bg-rose-300" },
  ];
  return (
    <div className={cn("space-y-1.5", className)}>
      <div className="flex h-2.5 overflow-hidden rounded-full bg-zinc-100" aria-hidden>
        {parts.map((p) => p.n > 0 && <div key={p.key} className={p.bar} style={{ width: `${(p.n / total) * 100}%` }} />)}
      </div>
      <p className="flex flex-wrap gap-x-3 text-xs text-zinc-600">
        {parts
          .filter((p) => p.n > 0)
          .map((p) => (
            <span key={p.key}>
              {p.n} {BASIS[p.key].word.toLowerCase()}
              {p.key === "evidence" ? "" : p.n === 1 ? "" : "s"}
            </span>
          ))}
      </p>
    </div>
  );
}

const short = (n: number) =>
  n >= 1e9 ? `${+(n / 1e9).toFixed(1)}B` : n >= 1e6 ? `${+(n / 1e6).toFixed(n >= 1e7 ? 0 : 2)}M` : n >= 1e4 ? `${+(n / 1e3).toFixed(0)}K` : n.toLocaleString("en-US");

function compact(n: number, unit: string): string {
  const u = unit.toLowerCase();
  if (u.startsWith("usd")) return `$${short(n)}${u.endsWith("/yr") ? " a year" : u.endsWith("/mo") ? " a month" : ""}`;
  return `${short(n)} ${unit}`;
}

export function MarketBars({ deck }: { deck: PitchDeck }) {
  const m = deck.market;
  if (!m) return <p className="text-sm text-zinc-500">Not sized yet.</p>;
  const rows = (
    [
      ["Total market", m.tam],
      ["Serviceable", m.sam],
      [`Obtainable in ${m.somHorizonMonths} months`, m.som],
    ] as const
  ).map(([label, id]) => ({ label, claim: claimById(deck, id) }));
  const top = rows[0].claim?.value?.n || 1;
  return (
    <div className="space-y-2 rounded-lg bg-zinc-50 p-3">
      {rows.map((r, i) => (
        <div key={r.label} style={{ paddingLeft: `${i * 6}%` }}>
          <div className="flex items-baseline justify-between gap-2 text-xs">
            <span className="text-zinc-600">{r.label}</span>
            <span className="font-medium tabular-nums text-zinc-900">{r.claim?.value ? compact(r.claim.value.n, r.claim.value.unit) : "—"}</span>
          </div>
          <div className="mt-1 h-2 rounded-full bg-white">
            <div
              className="h-full rounded-full bg-[var(--accent-color,#18181b)]"
              style={{ width: `${Math.max(3, ((r.claim?.value?.n ?? 0) / top) * 100)}%`, opacity: 1 - i * 0.2 }}
            />
          </div>
        </div>
      ))}
      <p className="pt-1 text-xs text-zinc-500">
        {m.method === "bottom-up" ? "Bottom-up" : "Top-down"}: {m.formula}
      </p>
    </div>
  );
}

export function BudgetTable({ deck }: { deck: PitchDeck }) {
  const core = deck.budget.filter((b) => !b.stretch && b.category !== "contingency");
  const stretch = deck.budget.filter((b) => b.stretch);
  const coreTotal = core.reduce((s, b) => s + b.usd, 0);
  const plan = deck.currentRule ?? deck.seatPlan;
  const proof = plan.proofBudgetUsd || coreTotal;
  const months = deck.plan?.proofMonths;
  return (
    <div className="space-y-3">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Line</TableHead>
            <TableHead className="text-right">Amount</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {core.map((b) => (
            <TableRow key={b.key}>
              <TableCell className="whitespace-normal">
                <a href={`#${b.claimId}`} className="hover:underline">
                  {b.label}
                </a>
                <span className="block text-xs text-zinc-500">
                  {BUDGET_CATEGORY_LABELS[b.category]}
                  {b.monthlyUsd !== undefined && months ? ` · ${formatUsd(b.monthlyUsd)} a month × ${months}` : " · once"}
                </span>
              </TableCell>
              <TableCell className="text-right align-top tabular-nums">{formatUsd(b.usd)}</TableCell>
            </TableRow>
          ))}
          <TableRow>
            <TableCell>Itemized</TableCell>
            <TableCell className="text-right tabular-nums">{formatUsd(coreTotal)}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell className="whitespace-normal">
              Contingency{" "}
              <Link href="/protocol#SEAT_BUFFER_PCT" className="text-xs text-zinc-500 underline underline-offset-2">
                {plan.bufferPct}%, one setting for every venture
              </Link>
            </TableCell>
            <TableCell className="text-right tabular-nums">{formatUsd(proof - coreTotal)}</TableCell>
          </TableRow>
          <TableRow className="bg-zinc-50 font-medium">
            <TableCell className="whitespace-normal">Proof budget{months ? `, ${months} months` : ""}</TableCell>
            <TableCell className="text-right tabular-nums">{formatUsd(proof)}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell className="whitespace-normal">
              The minimum raises
              <span className="block text-xs text-zinc-500">
                {deck.seatPlan.min} seats at {formatUsd(deck.seatPlan.priceUsd)}
                {deck.seatPlan.rule === "legacy-budget" ? ", the minimum kept from its pitch" : ""}
              </span>
            </TableCell>
            <TableCell className="text-right align-top tabular-nums">{formatUsd(deck.seatPlan.minRaiseUsd)}</TableCell>
          </TableRow>
          {deck.seatPlan.shortfallUsd > 0 && (
            <TableRow className="bg-rose-50 text-rose-900">
              <TableCell className="whitespace-normal">
                Not covered by seats
                <span className="block text-xs">Shown on purpose. It kept the minimum it was pitched with; a smaller wedge or an amended deck closes the gap.</span>
              </TableCell>
              <TableCell className="text-right align-top font-medium tabular-nums">{formatUsd(deck.seatPlan.shortfallUsd)}</TableCell>
            </TableRow>
          )}
          {stretch.map((b) => (
            <TableRow key={b.key} className="text-zinc-500">
              <TableCell className="whitespace-normal">Stretch: {b.label}</TableCell>
              <TableCell className="text-right tabular-nums">{formatUsd(b.usd)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {deck.contractors.length > 0 && (
        <div>
          <p className="mb-1 text-xs font-medium tracking-wide text-zinc-500 uppercase">Labour: paid per job, in cash</p>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job</TableHead>
                <TableHead className="text-right">Rate</TableHead>
                <TableHead className="text-right">Paid from</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deck.contractors.map((c) => (
                <TableRow key={c.job}>
                  <TableCell className="whitespace-normal">
                    {c.job} × {c.count}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {formatUsd(c.rateUsd)} / {c.per}
                  </TableCell>
                  <TableCell className="text-right text-zinc-600">{c.paidFrom}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <p className="mt-1 text-xs text-zinc-500">Contractors are paid cash and never earn units.</p>
        </div>
      )}
      <p className="text-xs text-zinc-500">Seat money is spent only on these lines, and never past what seats raised. Seats past the minimum pay only for the stretch lines.</p>
    </div>
  );
}

const usdShort = (n: number) => (Math.abs(n) >= 10_000 ? `${n < 0 ? "−" : ""}$${Math.round(Math.abs(n) / 1000)}k` : formatUsd(n).replace("-", "−"));

/** Monthly net as bars and cumulative cash as a line; proof months shaded. */
function PlanChart({ plan }: { plan: BusinessPlan }) {
  const w = 360;
  const h = 140;
  const pad = { l: 4, r: 4, t: 10, b: 18 };
  const values = plan.months.flatMap((m) => [m.netUsd, m.cumulativeUsd, 0]);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const y = (v: number) => pad.t + ((max - v) / (max - min || 1)) * (h - pad.t - pad.b);
  const bw = (w - pad.l - pad.r) / plan.months.length;
  const x = (i: number) => pad.l + i * bw;
  const line = plan.months.map((m, i) => `${i ? "L" : "M"}${(x(i) + bw / 2).toFixed(1)},${y(m.cumulativeUsd).toFixed(1)}`).join(" ");
  return (
    <figure className="space-y-1">
      <svg viewBox={`0 0 ${w} ${h}`} className="h-auto w-full" role="img" aria-label="Monthly net and cumulative cash over twelve months">
        <rect x={pad.l} y={pad.t} width={bw * plan.proofMonths} height={h - pad.t - pad.b} className="fill-zinc-100" />
        <line x1={pad.l} x2={w - pad.r} y1={y(0)} y2={y(0)} className="stroke-zinc-300" strokeWidth={1} />
        {plan.months.map((m, i) => (
          <rect
            key={m.month}
            x={x(i) + bw * 0.2}
            width={bw * 0.6}
            y={Math.min(y(m.netUsd), y(0))}
            height={Math.max(1, Math.abs(y(m.netUsd) - y(0)))}
            className={m.netUsd >= 0 ? "fill-emerald-500" : "fill-rose-400"}
          />
        ))}
        <path d={line} fill="none" className="stroke-zinc-900" strokeWidth={1.75} />
        {plan.months.map((m, i) => (
          <text key={m.month} x={x(i) + bw / 2} y={h - 5} textAnchor="middle" className="fill-zinc-500 text-[9px]">
            {m.month}
          </text>
        ))}
      </svg>
      <figcaption className="flex flex-wrap gap-x-3 text-xs text-zinc-500">
        <span>
          <span className="mr-1 inline-block size-2 bg-zinc-200 align-middle" />
          Proof months
        </span>
        <span>
          <span className="mr-1 inline-block size-2 bg-emerald-500 align-middle" />
          <span className="mr-1 inline-block size-2 bg-rose-400 align-middle" />
          Monthly net
        </span>
        <span>
          <span className="mr-1 inline-block h-0.5 w-3 bg-zinc-900 align-middle" />
          Cumulative cash
        </span>
      </figcaption>
    </figure>
  );
}

/** Three numbers from the plan, for the venture page. */
export function PlanGlance({ plan, slug, services }: { plan: BusinessPlan; slug: string; services?: { monthlyUsd: number; billedUsd: number } }) {
  return (
    <div className="space-y-1 rounded-lg border border-zinc-200 p-3 text-sm">
      <p className="font-medium text-zinc-900">Business plan</p>
      <p className="text-zinc-600">
        {formatUsd(plan.proofBudgetUsd)} for {plan.proofMonths} months of proof.{" "}
        {plan.breakEvenMonth ? `Covers its costs in month ${plan.breakEvenMonth} on its ramp.` : `Doesn't cover its costs within ${plan.horizonMonths} months on its ramp.`}{" "}
        {plan.afterProofNeedUsd > 0 ? `An adopter would need about ${formatUsd(plan.afterProofNeedUsd)} after the proof.` : "After the proof it pays its own way."}
      </p>
      {services && (
        <p className="text-zinc-600">
          Runs on the{" "}
          <Link href="/protocol/services" className="underline underline-offset-2 hover:text-zinc-900">
            shared back office
          </Link>{" "}
          at {formatUsd(services.monthlyUsd)} a month, at cost{services.billedUsd > 0 ? `; ${formatUsd(services.billedUsd)} billed so far` : ""}.
        </p>
      )}
      <Link href={`/v/${slug}/deck#plan`} className="inline-flex items-center gap-1 text-xs text-zinc-600 underline underline-offset-2 hover:text-zinc-900">
        Month by month <ArrowRight className="size-3" />
      </Link>
    </div>
  );
}

/** The 12-month plan, computed by code from the deck's lines, price and plan inputs. */
export function BusinessPlanBlock({ plan, unit }: { plan: BusinessPlan; unit: string }) {
  const recurring = new Map<string, number>();
  for (const [k, v] of Object.entries(plan.months.at(-1)!.byCategory)) recurring.set(k, v ?? 0);
  const stats = [
    { label: "Proof budget", value: formatUsd(plan.proofBudgetUsd), detail: `${plan.proofMonths} months, contingency included` },
    { label: "Covers its costs", value: plan.breakEvenMonth ? `Month ${plan.breakEvenMonth}` : `Not in ${plan.horizonMonths} months`, detail: plan.breakEvenCustomers ? `at ${plan.breakEvenCustomers} paying ${unit}s` : "each customer loses money" },
    { label: "To take it forward", value: formatUsd(plan.afterProofNeedUsd), detail: plan.breakEvenMonth ? `months ${plan.proofMonths + 1}–${plan.horizonMonths}` : `months ${plan.proofMonths + 1}–${plan.horizonMonths}, and more after` },
  ];
  return (
    <div className="space-y-4">
      <dl className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-lg border border-zinc-200 px-3 py-2">
            <dt className="text-xs text-zinc-500">{s.label}</dt>
            <dd className="text-lg font-semibold tabular-nums text-zinc-900">{s.value}</dd>
            <dd className="text-xs text-zinc-500">{s.detail}</dd>
          </div>
        ))}
      </dl>
      <PlanChart plan={plan} />
      <div className="-mx-1 overflow-x-auto">
        <Table className="text-xs sm:text-sm">
          <TableHeader>
            <TableRow>
              <TableHead className="px-1.5">Month</TableHead>
              <TableHead className="px-1.5 text-right">Paying</TableHead>
              <TableHead className="px-1.5 text-right">Revenue</TableHead>
              <TableHead className="hidden px-1.5 text-right sm:table-cell">Costs</TableHead>
              <TableHead className="px-1.5 text-right">Net</TableHead>
              <TableHead className="px-1.5 text-right">Cash</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {plan.months.map((m) => (
              <TableRow key={m.month} className={cn(m.proof && "bg-zinc-50", m.month === plan.breakEvenMonth && "font-medium")}>
                <TableCell className="px-1.5">
                  {m.month}
                  {m.month === plan.proofMonths && <span className="block text-[10px] text-zinc-500 sm:ml-1 sm:inline">end of proof</span>}
                </TableCell>
                <TableCell className="px-1.5 text-right tabular-nums">{m.customers}</TableCell>
                <TableCell className="px-1.5 text-right tabular-nums">{usdShort(m.revenueUsd)}</TableCell>
                <TableCell className="hidden px-1.5 text-right tabular-nums sm:table-cell">{usdShort(m.variableUsd + m.fixedUsd + m.oneTimeUsd)}</TableCell>
                <TableCell className={cn("px-1.5 text-right tabular-nums", m.netUsd < 0 ? "text-rose-700" : "text-emerald-700")}>{usdShort(m.netUsd)}</TableCell>
                <TableCell className="px-1.5 text-right tabular-nums">{usdShort(m.cumulativeUsd)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <p className="mb-1 text-xs font-medium tracking-wide text-zinc-500 uppercase">Monthly costs by category</p>
          <ul className="divide-y divide-zinc-100 text-sm">
            {[...recurring].map(([k, v]) => (
              <li key={k} className="flex justify-between gap-2 py-1">
                <span className="text-zinc-700">{BUDGET_CATEGORY_LABELS[k as keyof typeof BUDGET_CATEGORY_LABELS] ?? k}</span>
                <span className="tabular-nums">{formatUsd(v)}</span>
              </li>
            ))}
            <li className="flex justify-between gap-2 py-1">
              <span className="text-zinc-700">To serve each paying {unit}, card fees included</span>
              <span className="tabular-nums">{formatUsd(plan.variablePerCustomerMonthUsd, true)}</span>
            </li>
          </ul>
        </div>
        <div>
          <p className="mb-1 text-xs font-medium tracking-wide text-zinc-500 uppercase">Revenue assumptions</p>
          <ul className="space-y-1 text-sm text-zinc-700">
            <li>
              {formatUsd(plan.revenuePerCustomerMonthUsd, plan.revenuePerCustomerMonthUsd % 1 !== 0)} a month per paying {unit}.
            </li>
            <li>
              {Math.round(plan.conversion * 1000) / 10}% of leads pay,{" "}
              {plan.conversionFrom === "funnel" ? (
                <Link href="/protocol#FUNNEL_RATES" className="underline underline-offset-2">
                  from the intro funnel setting
                </Link>
              ) : (
                "set by the deck, with its own test"
              )}
              .
            </li>
            <li>{plan.revenueTotalUsd > 0 ? `${formatUsd(plan.revenueTotalUsd)} of revenue over ${plan.horizonMonths} months on this ramp.` : "No revenue on this ramp."}</li>
          </ul>
        </div>
      </div>
      <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3 text-sm text-zinc-700">
        <p className="font-medium text-zinc-900">What an entrepreneur would need to take this forward</p>
        <ul className="mt-1 list-disc space-y-0.5 pl-4">
          {planSummary(plan).map((l) => (
            <li key={l}>{l}</li>
          ))}
        </ul>
        <p className="mt-2 text-xs text-zinc-500">Computed by code from the inputs above. The ramp is an assumption until the weekly updates replace it.</p>
      </div>
    </div>
  );
}

export function MilestoneList({ deck }: { deck: PitchDeck }) {
  return (
    <ol className="relative space-y-3 border-l border-zinc-200 pl-4">
      {deck.milestones.map((m) => (
        <li key={m.key} className="relative">
          <span className="absolute top-1.5 -left-[21px] size-2.5 rounded-full border-2 border-white bg-[var(--accent-color,#18181b)]" aria-hidden />
          <p className="text-sm font-medium text-zinc-900">{m.label}</p>
          <p className="text-xs text-zinc-500">
            {m.target} {m.metric} · day {m.dueDays} after the raise
          </p>
        </li>
      ))}
    </ol>
  );
}

const RUNNER_BADGE: Record<ProofRunner, { word: string; className: string }> = {
  agent: { word: "Agent", className: "border-zinc-900 bg-zinc-900 text-white" },
  "member request": { word: "Member request", className: "border-sky-200 bg-sky-50 text-sky-900" },
  contractor: { word: "Contractor", className: "border-amber-300 bg-amber-50 text-amber-900" },
};

/** Who runs the proof, who runs it after, and what's left for an entrepreneur. */
export function ProofBlock({ proof }: { proof: ProofPlan }) {
  const reshaped = new Map(proof.reshaped.map((r) => [r.taskKey, r]));
  return (
    <div className="space-y-4">
      <dl className="grid gap-3 text-sm sm:grid-cols-3">
        <div className="rounded-lg bg-zinc-50 px-3 py-2">
          <dt className="text-xs font-medium tracking-wide text-zinc-500 uppercase">Proof run by</dt>
          <dd className="mt-0.5 font-medium text-zinc-900">{proofRunBy(proof)}</dd>
        </div>
        <div className="rounded-lg bg-zinc-50 px-3 py-2 sm:col-span-2">
          <dt className="text-xs font-medium tracking-wide text-zinc-500 uppercase">Long-term operator</dt>
          <dd className="mt-0.5 text-zinc-700">
            <span className="font-medium text-zinc-900">{LONG_TERM_LABELS[proof.longTermOperator]}.</span> {proof.operatorReason}
          </dd>
        </div>
      </dl>
      <ol className="space-y-2">
        {proof.tasks.map((t) => {
          const r = reshaped.get(t.key);
          return (
            <li key={t.key} className="rounded-md border border-zinc-200 px-3 py-2">
              <div className="flex flex-wrap items-start gap-2">
                <span className={cn("shrink-0 rounded border px-1.5 py-0.5 text-[11px] leading-none font-medium", RUNNER_BADGE[t.runBy].className)}>{RUNNER_BADGE[t.runBy].word}</span>
                <p className="min-w-0 flex-1 text-sm text-zinc-800">{t.task}</p>
              </div>
              {r && (
                <p className="mt-1.5 text-xs text-zinc-500">
                  Reshaped: it was “{r.was}” {r.why}
                </p>
              )}
            </li>
          );
        })}
      </ol>
      <div>
        <p className="mb-1 text-xs font-medium tracking-wide text-zinc-500 uppercase">What an entrepreneur would need to build</p>
        <p className="text-sm text-zinc-700">{proof.entrepreneurBuilds}</p>
      </div>
      <p className="text-xs text-zinc-500">
        Code checks every proof: no employees, no licence the Protocol doesn&apos;t hold, and nobody needed in person unless a member or contractor covers it. A proof that fails goes back to the agent to reshape; the idea stays.
      </p>
    </div>
  );
}

export function RisksBlock({ deck }: { deck: PitchDeck }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <div>
        <p className="mb-1.5 text-xs font-medium tracking-wide text-zinc-500 uppercase">Kill rules</p>
        <ul className="space-y-1.5 text-sm">
          {deck.killCriteria.map((k) => (
            <li key={k.key} className="rounded-md border border-zinc-200 px-2.5 py-1.5 text-zinc-700">
              {k.condition} by {formatDate(k.by)}
            </li>
          ))}
        </ul>
      </div>
      <div>
        <p className="mb-1.5 text-xs font-medium tracking-wide text-zinc-500 uppercase">How it could fail</p>
        <ul className="list-disc space-y-1 pl-4 text-sm text-zinc-700">
          {deck.premortem.map((p) => (
            <li key={p.way}>
              {p.way} <span className="text-zinc-400">({p.killReason})</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/** The worked calculation for the minimum, rendered from the plan object. */
export function SeatMath({ plan, current, roles, compact: small }: { plan: SeatPlan; current?: SeatPlan; roles?: { label: string; key: string }[]; compact?: boolean }) {
  const lines = seatMath(plan, roles);
  const shown = small ? lines.filter((l) => l.total || /^Larger|^Proof|^Enough|^Not covered|^Gap/.test(l.label)) : lines;
  const legacyNote = currentRuleLine(plan, current);
  return (
    <div className="space-y-2">
      <dl className="divide-y divide-zinc-100 rounded-lg border border-zinc-200 text-sm">
        {shown.map((l) => (
          <div key={l.label} className={cn("flex flex-col gap-0.5 px-3 py-2 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4", l.total && "bg-zinc-50 font-medium")}>
            <dt className="min-w-0">
              <span className="text-zinc-900">{l.label}</span>
              {l.detail && !small && <span className="block text-xs font-normal text-zinc-500">{l.detail}</span>}
            </dt>
            <dd className="shrink-0 tabular-nums text-zinc-900">
              {l.param ? (
                <Link href={`/protocol#${l.param}`} className="underline decoration-zinc-300 underline-offset-2 hover:decoration-zinc-900" title={`Setting: ${l.param}`}>
                  {l.value}
                </Link>
              ) : (
                l.value
              )}
            </dd>
          </div>
        ))}
      </dl>
      {legacyNote && <p className="text-xs text-zinc-600">{legacyNote}</p>}
    </div>
  );
}

export function RefundLines({ plan, params }: { plan: SeatPlan; params: { LIFTOFF_WINDOW_DAYS: number; LIFTOFF_EXTENSION_DAYS: number; ROSTER_FILL_AT_FORMATION: number } }) {
  const lines = [`Below ${plan.min} seats when the window closes: every seat is refunded in full.`];
  if (plan.rule === "derived") {
    if (plan.criticalRoles.length) lines.push("Critical roles not claimed by then: every seat is refunded in full, even with the minimum met.");
    lines.push(
      `Roster under ${params.ROSTER_FILL_AT_FORMATION}% filled ${params.LIFTOFF_WINDOW_DAYS} days after the raise (${params.LIFTOFF_WINDOW_DAYS + params.LIFTOFF_EXTENSION_DAYS} with the one extension): the venture ends before forming and every seat is refunded in full.`,
    );
  }
  return (
    <ul className="space-y-1 text-sm text-zinc-700">
      {lines.map((l) => (
        <li key={l} className="flex gap-2">
          <Undo2 className="mt-0.5 size-4 shrink-0 text-emerald-700" />
          <span>{l}</span>
        </li>
      ))}
    </ul>
  );
}

const PRICE_STATUS: Record<SeatPriceStatus, { text: string; tone: string }> = {
  kept: { text: "Kept from its pitch", tone: "border-zinc-200 bg-zinc-50 text-zinc-700" },
  awaiting: { text: "Waiting for the steward: no seats sell until the price is signed off", tone: "border-amber-200 bg-amber-50 text-amber-900" },
  signed: { text: "Signed off by the steward", tone: "border-emerald-200 bg-emerald-50 text-emerald-900" },
  declined: { text: "Declined by the steward: the agent proposes a new price", tone: "border-rose-200 bg-rose-50 text-rose-900" },
};

/** The proposed price, why, who signed it, and the seat counts at the band ends. */
export function SeatPriceBlock({ plan, status, slug }: { plan: SeatPlan; status: SeatPriceStatus; slug: string }) {
  const s = PRICE_STATUS[status];
  const ends = plan.atPrices.filter((a) => a.priceUsd !== plan.priceUsd);
  return (
    <div className="rounded-lg border border-zinc-200 p-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-sm text-zinc-600">
          Seat price <span className="text-2xl font-semibold text-zinc-900 tabular-nums">{formatUsd(plan.priceUsd)}</span>{" "}
          <span className="text-xs text-zinc-500">once, {priceSource(plan)}</span>
        </p>
        <span className={cn("rounded-md border px-2 py-0.5 text-xs", s.tone)}>{s.text}</span>
      </div>
      <p className="mt-1 text-sm text-zinc-700">
        {plan.min} seats needed at {formatUsd(plan.priceUsd)}
        {ends.map((a) => `; ${a.min} at ${formatUsd(a.priceUsd)}`).join("")}.
        {plan.price && plan.rule === "derived" && (
          <span className="text-zinc-500">
            {" "}
            The band runs from {formatUsd(plan.price.minUsd)} to {formatUsd(plan.price.upperUsd)}.
          </span>
        )}
      </p>
      {plan.price && plan.price.claims.length > 0 && (
        <ul className="mt-2 divide-y divide-zinc-100 border-t border-zinc-100">
          {plan.price.claims.map((c) => (
            <ClaimRow key={c.id} claim={c} slug={slug} />
          ))}
        </ul>
      )}
    </div>
  );
}

export function AskBlock({
  deck,
  params,
  roster,
  priceStatus,
  slug,
}: {
  deck: PitchDeck;
  params: { LIFTOFF_WINDOW_DAYS: number; LIFTOFF_EXTENSION_DAYS: number; ROSTER_FILL_AT_FORMATION: number };
  roster?: React.ReactNode;
  priceStatus?: SeatPriceStatus;
  slug?: string;
}) {
  return (
    <div className="space-y-4">
      {priceStatus && slug && <SeatPriceBlock plan={deck.seatPlan} status={priceStatus} slug={slug} />}
      <SeatMath plan={deck.seatPlan} current={deck.currentRule} roles={deck.roster} />
      <RefundLines plan={deck.seatPlan} params={params} />
      {roster}
      <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
        <SeatDisclaimer className="text-sm text-zinc-700" />
        <p className="mt-1 text-xs text-zinc-500">{REFUND_GUARANTEE}</p>
      </div>
    </div>
  );
}

export function DeckNav({ slides, className }: { slides: Pick<Slide, "key">[]; className?: string }) {
  return (
    <nav aria-label="Slides" className={cn("print:hidden", className)}>
      <ol className="flex gap-1.5 overflow-x-auto pb-1 lg:flex-col lg:gap-0.5 lg:overflow-visible lg:pb-0">
        {slides.map((s, i) => (
          <li key={s.key} className="shrink-0">
            <a
              href={`#${s.key}`}
              className="block rounded-full border border-zinc-200 bg-white px-3 py-1 text-xs whitespace-nowrap text-zinc-700 hover:border-zinc-400 lg:rounded-md lg:border-transparent lg:bg-transparent lg:px-2 lg:py-1 lg:text-sm lg:hover:bg-zinc-100"
            >
              <span className="text-zinc-400 tabular-nums">{i + 1}.</span> {SLIDE_TITLES[s.key]}
            </a>
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function SlideCard({
  slide,
  index,
  prev,
  next,
  slug,
  children,
}: {
  slide: Slide;
  index: number;
  prev?: SlideKey;
  next?: SlideKey;
  slug: string;
  children?: React.ReactNode;
}) {
  return (
    <section id={slide.key} className="scroll-mt-28 rounded-xl border border-zinc-200 bg-white p-4 sm:p-5 print:break-after-page print:border-0 lg:scroll-mt-20">
      <p className="text-xs font-medium tracking-wide text-zinc-500 uppercase">
        {index + 1}. {SLIDE_TITLES[slide.key]}
      </p>
      <h2 className="mt-1 text-lg font-semibold tracking-tight text-pretty">{slide.headline}</h2>
      {slide.claims.length > 0 && (
        <ul className="mt-2 divide-y divide-zinc-100">
          {slide.claims.map((c) => (
            <ClaimRow key={c.id} claim={c} slug={slug} />
          ))}
        </ul>
      )}
      {children && <div className="mt-4">{children}</div>}
      <div className="mt-4 flex justify-between gap-2 border-t border-zinc-100 pt-3 text-xs print:hidden">
        {prev ? (
          <a href={`#${prev}`} className="inline-flex items-center gap-1 text-zinc-500 hover:text-zinc-900">
            <ArrowLeft className="size-3" /> {SLIDE_TITLES[prev]}
          </a>
        ) : (
          <span />
        )}
        {next && (
          <a href={`#${next}`} className="inline-flex items-center gap-1 text-zinc-500 hover:text-zinc-900">
            {SLIDE_TITLES[next]} <ArrowRight className="size-3" />
          </a>
        )}
      </div>
    </section>
  );
}

export const CAUSE_WORDS: Record<PitchDeck["cause"]["kind"], string> = {
  pitch: "at pitch",
  qa: "after a member question",
  rfe: "after a request resolved",
  steward: "by the steward",
  lesson: "after a lesson",
  migration: "at the migration to decks",
};

export function causeHref(deck: PitchDeck, slug: string): string | undefined {
  const ref = deck.cause.ref;
  if (!ref) return undefined;
  if (deck.cause.kind === "qa") return `/v/${slug}/qa#${ref}`;
  if (deck.cause.kind === "rfe") return `/rfe/${ref}`;
  if (deck.cause.kind === "lesson") return `/learning#${ref}`;
  return undefined;
}

/** "v3 · amended 29 Oct after a member question" */
export function versionLine(deck: PitchDeck): string {
  return `v${deck.version} · ${deck.version === 1 ? "published" : "amended"} ${formatDate(deck.publishedAt)} ${CAUSE_WORDS[deck.cause.kind]}`;
}