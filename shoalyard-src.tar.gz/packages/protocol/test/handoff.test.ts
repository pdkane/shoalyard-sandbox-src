import assert from "node:assert/strict";
import { test } from "node:test";
import type { Store } from "@av/schema";
import { vestedByHandle } from "../src/economics";
import { handOffChecklist, offersFor, pendingConductVotes, payoutPreview, settleHandOffVote, stewardCheckOffer, submitOffer, withdrawOffer } from "../src/handoff";
import { closeGovernance, isLive, respond, rfeById, seatHolders, ventureBySlug } from "../src/ops";
import { flagItem } from "../src/flags";
import { buildSeed } from "../src/seed";
import { runBackOffice } from "../src/services";

const seed = buildSeed();
const STEWARD = "MP";
const YES = ["quiet_quinn", "lanehauler", "dispatch_dana", "tms_tara"];

/** Members settle Dockside's open concern (dismissed), so the hand-off can go ahead. */
function settleConcern(s: Store) {
  const flag = s.flags.find((f) => f.ventureId === "dockside" && f.status === "voting")!;
  const rfe = rfeById(s, flag.voteRfeId!)!;
  for (const h of ["lanehauler", "tms_tara", "cfo_ines"]) respond(s, { rfeId: rfe.id, handle: h, via: "structured", choice: "Dismiss the flag" });
  closeGovernance(s, rfe);
  assert.equal(flag.status, "dismissed");
  return s;
}
const fresh = () => settleConcern(structuredClone(seed) as Store);

function toVote(s: Store) {
  const offer = offersFor(s, "dockside").find((o) => o.status === "submitted")!;
  stewardCheckOffer(s, { offerId: offer.id, by: STEWARD });
  return { offer, rfe: rfeById(s, offer.voteRfeId!)! };
}

test("a conduct vote still open blocks the hand-off until it's resolved", () => {
  const s = structuredClone(seed) as Store;
  const dock = ventureBySlug(s, "dockside")!;
  assert.equal(pendingConductVotes(s, "dockside"), 1);
  const list = handOffChecklist(s, dock);
  assert.equal(list.ready, false);
  assert.equal(list.items.find((i) => i.key === "conduct")!.met, false);
  const offer = offersFor(s, "dockside")[0];
  assert.throws(() => stewardCheckOffer(s, { offerId: offer.id, by: STEWARD }), /still being voted on/);
  assert.equal(offer.status, "submitted", "the offer waits; it isn't declined");
  assert.throws(() => submitOffer(s, { slug: "dockside", handle: "llc_lena", priceUsd: 9000, cashUsd: 6000, retainedSharePct: 0, plan: "Run it with my own money and add a second desk." }), /clean conduct record/);
  settleConcern(s);
  assert.equal(handOffChecklist(s, dock).ready, true);
  assert.equal(stewardCheckOffer(s, { offerId: offer.id, by: STEWARD }).status, "voting");
});

test("a concern reported during the vote stops the hand-off from applying", () => {
  const s = fresh();
  const { offer, rfe } = toVote(s);
  flagItem(s, { by: "policy_pia", kind: "venture", id: "dockside", reason: "The pricing page still doesn't disclose the new-account rate." });
  for (const h of YES) respond(s, { rfeId: rfe.id, handle: h, via: "structured", choice: rfe.options![0] });
  closeGovernance(s, rfe);
  assert.equal(offer.status, "declined");
  assert.match(offer.outcome ?? "", /still being voted on/);
  assert.equal(ventureBySlug(s, "dockside")!.status, "distributing");
});

test("the growth record counts quarterly revenue and says so", () => {
  const item = handOffChecklist(fresh(), ventureBySlug(seed, "dockside")!).items.find((i) => i.key === "growth")!;
  assert.match(item.detail, /from quarterly revenue/);
});

test("Dockside is ready to hand off once its concern is settled, and the seeded offer waits for the steward's check", () => {
  const settled = fresh();
  const dock = ventureBySlug(settled, "dockside")!;
  const list = handOffChecklist(settled, dock);
  assert.ok(list.ready, list.items.filter((i) => !i.met).map((i) => i.label).join("; "));
  assert.deepEqual(list.items.map((i) => i.key), ["customers", "growth", "books", "roster", "conduct"]);
  const offers = offersFor(seed, "dockside");
  assert.equal(offers.length, 1);
  assert.equal(offers[0].status, "submitted");
  assert.match(offers[0].summary, /Seat holders without units get nothing/);
  assert.ok(rfeById(seed, "rfe-v0-handoff-price"), "the price question is open");
  assert.equal(handOffChecklist(seed, ventureBySlug(seed, "permit-pulse")!).ready, false);
});

test("only a verified member who isn't the steward can offer, and only for a ready venture", () => {
  const s = fresh();
  const base = { slug: "dockside", priceUsd: 10000, cashUsd: 8000, retainedSharePct: 0, plan: "Run it with my own money and add a second desk in Dallas." };
  const unverified = s.members.find((m) => m.qualification !== "qualified")!.handle;
  assert.throws(() => submitOffer(s, { ...base, handle: unverified }), /verified member/);
  assert.throws(() => submitOffer(s, { ...base, handle: STEWARD }), /steward can't make one/);
  assert.throws(() => submitOffer(s, { ...base, handle: "llc_lena", cashUsd: 12000 }), /can't be more than the price/);
  assert.throws(() => submitOffer(s, { ...base, handle: "llc_lena", cashUsd: 0 }), /what contributors get/);
  assert.throws(() => submitOffer(s, { ...base, slug: "permit-pulse", handle: "llc_lena" }), /paying customers|isn't ready/);
  const dock = ventureBySlug(s, "dockside")!;
  dock.customers.count = 3;
  assert.throws(() => submitOffer(s, { ...base, handle: "llc_lena" }), /isn't ready to hand off yet: at least 10 paying customers/);
});

test("the steward's check sends the offer to a unit-holder vote; it never hands off on its own", () => {
  const s = fresh();
  const offer = offersFor(s, "dockside")[0];
  assert.throws(() => stewardCheckOffer(s, { offerId: offer.id, by: "quiet_quinn" }), /Only @MP checks offers/);
  const checked = stewardCheckOffer(s, { offerId: offer.id, by: STEWARD });
  assert.equal(checked.status, "voting");
  assert.ok(checked.check?.passed);
  const rfe = rfeById(s, checked.voteRfeId!)!;
  assert.equal(rfe.kind, "governance");
  assert.equal(rfe.governance?.threshold, "super", "a hand-off is one of Article 5's big decisions");
  const dock = ventureBySlug(s, "dockside")!;
  assert.equal(dock.status, "distributing");
  assert.equal(s.ledger.filter((l) => l.kind === "handoff-payout").length, 0, "nothing is paid before the vote");
});

test("the vote is required: settling an open vote as passed throws, and a failed vote keeps the venture", () => {
  const s = fresh();
  const { offer, rfe } = toVote(s);
  assert.throws(() => settleHandOffVote(s, rfe, true, "forced"), /needs a passed unit-holder vote/);
  assert.equal(ventureBySlug(s, "dockside")!.status, "distributing");
  rfe.governance!.windowEndsAt = s.meta.clock;
  closeGovernance(s, rfe);
  assert.equal(offer.status, "declined", "nobody voted, so quorum wasn't met");
  assert.equal(ventureBySlug(s, "dockside")!.status, "distributing");
  assert.equal(s.ledger.filter((l) => l.kind === "handoff-payout").length, 0);
});

test("on approval, earned units are paid by vested units, seat holders without units get nothing, and the venture is handed off", () => {
  const s = fresh();
  const dock = ventureBySlug(s, "dockside")!;
  const { offer, rfe } = toVote(s);
  for (const h of YES) respond(s, { rfeId: rfe.id, handle: h, via: "structured", choice: rfe.options![0] });
  rfe.governance!.windowEndsAt = s.meta.clock;
  closeGovernance(s, rfe);
  assert.match(rfe.resolution ?? "", /^Passed: Dockside/);
  assert.equal(offer.status, "approved");
  assert.equal(dock.status, "handed-off");
  assert.equal(dock.handOff?.entrepreneur, offer.entrepreneur);
  assert.equal(isLive(dock), false);

  const rows = s.ledger.filter((l) => l.kind === "handoff-payout" && l.ref === offer.id);
  const vested = vestedByHandle(s, dock.id);
  const paid = rows.filter((r) => r.handle);
  assert.ok(paid.length > 0);
  for (const r of paid) assert.ok(vested[r.handle!] > 0, `@${r.handle} has earned units`);
  const seatOnly = seatHolders(s, dock.id).filter((h) => !(vested[h] > 0));
  assert.ok(seatOnly.length > 0, "Dockside has seat holders without units");
  for (const h of seatOnly) assert.ok(!rows.some((r) => r.handle === h), `@${h} holds only a seat and gets nothing`);
  const total = rows.reduce((t, r) => t + (r.usd ?? 0), 0);
  assert.ok(Math.abs(total - offer.contributors.cashUsd) < 0.05 * paid.length, `paid $${total} of $${offer.contributors.cashUsd}`);
  const p = payoutPreview(s, dock, offer.contributors.cashUsd);
  const top = paid.find((r) => r.handle === "quiet_quinn")!;
  assert.equal(top.usd, p.payouts.find((x) => x.handle === "quiet_quinn")!.usd, "split by vested units");

  assert.equal(s.rfes.filter((r) => r.ventureId === dock.id && (r.status === "posted" || r.status === "quorum")).length, 0);
  s.meta.clock = "2026-11-02T12:00:00.000Z";
  assert.equal(runBackOffice(s).filter((r) => r.ventureId === dock.id).length, 0, "a handed-off venture leaves the back office");
});

test("an entrepreneur can withdraw an open offer, which closes its vote", () => {
  const s = fresh();
  const { offer, rfe } = toVote(s);
  assert.throws(() => withdrawOffer(s, { offerId: offer.id, by: STEWARD }), /Only the person who made the offer/);
  withdrawOffer(s, { offerId: offer.id, by: offer.entrepreneur });
  assert.equal(offer.status, "withdrawn");
  assert.equal(rfe.status, "resolved");
});
