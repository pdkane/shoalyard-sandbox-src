import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultParams } from "@av/schema";
import { ARTICLES } from "../src/constitution";
import { screenText, loosensBelowFloor } from "../src/conduct";
import { advanceBatches, cohortById, lookupVenture, seatWindow, ventureHref } from "../src/batches";
import { flagItem, certifyFlag, flagConfirmer, MEMBER_VOTE_STANDS } from "../src/flags";
import { allocateBatchSlots } from "../src/learning";
import { rosterFill, readiness } from "../src/network";
import {
  buySeat,
  closeGovernance,
  completeOnboarding,
  decideVerification,
  linkAccount,
  logDecision,
  memberByHandle,
  respond,
  stewardDecide,
  ventureBySlug,
} from "../src/ops";
import { buildSeed } from "../src/seed";
import { latestDeck, seatPriceStatus } from "../src/deck";
import { confirmTag, rewriteTagValue, tagQueue } from "../src/tags";
import { verificationScore } from "../src/verification";

const profile = {
  role: "Estimator",
  industry: "Commercial roofing",
  seniority: "mid" as const,
  companies: [],
  buyingAuthority: "Recommends",
  tools: [],
  verticals: ["roofing"],
  canReach: [],
  cluster: "construction-sales",
};

test("the constitution has eight articles; Article 8 says the agent is honest", () => {
  assert.equal(ARTICLES.length, 8);
  assert.match(ARTICLES[7].text, /must obey the law and must never mislead anyone\. Whenever it writes to a person, it says it is an AI agent\./);
  assert.match(ARTICLES[2].text, /The public sees what was decided, by whom and what it cost; people who have earned units see the reasoning\./);
  assert.match(ARTICLES[2].text, /\{PRIVATE_DECISION_MAX_DAYS\} days/);
});

test("members get no requests until qualified; a confirmed link qualifies them", () => {
  const s = buildSeed();
  const steward = ventureBySlug(s, "protocol")!.stewardHandle;
  buySeat(s, { slug: "permit-pulse", handle: "estimator_eve" });
  const pending = completeOnboarding(s, "estimator_eve", profile);
  assert.equal(pending.qualified, false);
  assert.equal(pending.firstRfe, undefined);
  assert.throws(() => respond(s, { rfeId: "rfe-permit-pulse-trade", handle: "estimator_eve", via: "structured", choice: "Roofing first" }), /qualif/i);

  const x = linkAccount(s, "estimator_eve", "x", "estimator_eve");
  assert.equal(x.status, "pending");
  const li = linkAccount(s, "estimator_eve", "linkedin", "https://www.linkedin.com/in/estimator-eve");
  decideVerification(s, { by: steward, handle: "estimator_eve", verificationId: x.id, approve: false });
  const r = decideVerification(s, { by: steward, handle: "estimator_eve", verificationId: li.id, approve: true });
  assert.ok(r.qualified);
  const m = memberByHandle(s, "estimator_eve")!;
  assert.ok(verificationScore(m, defaultParams()) >= defaultParams().QUALIFY_MIN_SCORE);
  assert.ok(s.ledger.some((l) => l.kind === "qualification" && l.handle === "estimator_eve"));
  respond(s, { rfeId: "rfe-permit-pulse-trade", handle: "estimator_eve", via: "structured", choice: "Roofing first" });
});

test("only a steward confirms a linked account; LinkedIn needs a profile URL", () => {
  const s = buildSeed();
  buySeat(s, { slug: "permit-pulse", handle: "estimator_eve" });
  assert.throws(() => linkAccount(s, "estimator_eve", "linkedin", "estimator-eve"));
  const li = linkAccount(s, "estimator_eve", "linkedin", "linkedin.com/in/estimator-eve");
  assert.throws(() => decideVerification(s, { by: "cfo_ines", handle: "estimator_eve", verificationId: li.id, approve: true }));
});

test("repeat-mistake check: a plan contradicting an adopted lesson moves up a bin and cites it", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  const plain = logDecision(s, { ventureId: pp.id, title: "Write the Monday email template", reasoning: "Short, one permit per line.", confidence: 0.9, model: "script" }).decision;
  assert.equal(plain.bin, "auto");
  const repeat = logDecision(s, {
    ventureId: pp.id,
    title: "Send cold email to 500 roofers",
    reasoning: "A cold email blast reaches more of the trade.",
    confidence: 0.9,
    model: "script",
  }).decision;
  assert.deepEqual(repeat.contradicts, ["L-005"]);
  assert.equal(repeat.bin, "advisory");
  assert.ok(repeat.binReasons.some((r) => r.includes("Goes against L-005")));
});

test("conduct screen: invented proof stops, missing disclosure and regulated activity escalate", () => {
  const p = defaultParams();
  assert.equal(screenText({ text: "Rated #1 by brokers. 500 happy customers.", customers: 14 }, p).result, "stop");
  const quiet = screenText({ text: "Monday permit lists for roofers.", outbound: true }, p);
  assert.equal(quiet.result, "concern");
  assert.equal(screenText({ text: "Monday permit lists, run by an AI agent.", outbound: true }, p).result, "pass");
  const lending = screenText({ text: "Offer contractors a cash advance against liens." }, p);
  assert.equal(lending.result, "concern");
  assert.deepEqual(lending.regulated, ["lending"]);
  assert.ok(lending.counselNote);
  assert.equal(screenText({ text: "A seat gets you this venture's requests. It is not a share and pays nothing back.", nearSeats: true }, p).result, "pass");
  assert.equal(screenText({ text: "A seat is access to requests, not an investment.", nearSeats: true }, p).result, "pass");
  assert.equal(screenText({ text: "Seats with 10x upside.", nearSeats: true }, p).result, "concern");
  assert.deepEqual(loosensBelowFloor(["agent-disclosure"]).length, 4);
});

test("a stopped decision is rejected and nothing is posted", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  const before = s.rfes.length;
  const { decision } = logDecision(s, {
    ventureId: pp.id,
    title: "Post a testimonial",
    reasoning: "Add a 5-star testimonial to the landing page.",
    confidence: 0.9,
    model: "script",
  });
  assert.equal(decision.status, "rejected");
  assert.equal(s.rfes.length, before);
});

test("the conduct checklist can't be loosened below Article 8 by a vote", () => {
  const s = buildSeed();
  const v0 = ventureBySlug(s, "protocol")!;
  const { rfe } = logDecision(s, {
    ventureId: v0.id,
    title: "Remove the disclosure check",
    reasoning: "Proposed by a member.",
    confidence: 0.5,
    model: "script",
    rfe: {
      type: "judgment",
      kind: "governance",
      title: "Amend CONDUCT_CHECKLIST",
      question: "Remove agent-disclosure?",
      recommendation: "No",
      stakes: "high",
      format: "choice",
      options: ["Yes", "No"],
      offerUnits: 0,
      audience: "Holders",
      governance: { matter: "Parameter amendment", threshold: "simple", windowEndsAt: "2026-11-06T12:00:00.000Z", paramKey: "CONDUCT_CHECKLIST", proposedValue: ["no-invented-proof"], effect: "Removes the disclosure check." },
    },
  });
  for (const h of ["policy_pia", "counsel_kemi", "cfo_ines", "ux_uma"]) respond(s, { rfeId: rfe!.id, handle: h, via: "structured", choice: "Yes" });
  s.meta.clock = "2026-11-07T00:00:00.000Z";
  closeGovernance(s, rfe!);
  assert.match(rfe!.resolution ?? "", /not applied/);
  assert.equal(s.amendments.filter((a) => a.paramKey === "CONDUCT_CHECKLIST").length, 0);
});

test("flags: members vote; the steward confirms unless they run the venture, and an upheld flag is a public breach", () => {
  const s = buildSeed();
  const dockside = ventureBySlug(s, "dockside")!;
  const protocolSteward = s.ventures.find((v) => v.isProtocol)!.stewardHandle;
  assert.equal(dockside.stewardHandle, protocolSteward);
  // The founding steward runs Dockside, so the member vote stood without their confirmation.
  const dismissed = s.flags.find((f) => f.status === "dismissed")!;
  assert.equal(flagConfirmer(s, dismissed).conflicted, true);
  assert.equal(dismissed.certifiedBy, MEMBER_VOTE_STANDS);
  assert.ok(dismissed.certifiedAt);
  const upheldFlag = () => {
    const flag = flagItem(s, { by: "ux_uma", kind: "decision", id: "dec-dockside-dpa", reason: "The DPA terms aren't public." });
    for (const h of ["dispatch_dana", "lanehauler", "tms_tara"]) respond(s, { rfeId: flag.voteRfeId!, handle: h, via: "structured", choice: "Uphold the flag" });
    return flag;
  };
  const flag = upheldFlag();
  s.meta.clock = "2026-11-08T00:00:00.000Z";
  closeGovernance(s, s.rfes.find((r) => r.id === flag.voteRfeId)!);
  assert.equal(flag.status, "upheld");
  assert.equal(flag.certifiedBy, MEMBER_VOTE_STANDS);
  assert.ok(s.ledger.some((l) => l.kind === "breach" && l.ref === flag.id));

  // With a different steward running the venture, the Protocol's steward confirms, and the venture's steward can't.
  const t = buildSeed();
  const v = ventureBySlug(t, "dockside")!;
  v.stewardHandle = "ops_odile";
  const f2 = flagItem(t, { by: "ux_uma", kind: "decision", id: "dec-dockside-dpa", reason: "The DPA terms aren't public." });
  for (const h of ["dispatch_dana", "lanehauler", "tms_tara"]) respond(t, { rfeId: f2.voteRfeId!, handle: h, via: "structured", choice: "Uphold the flag" });
  t.meta.clock = "2026-11-08T00:00:00.000Z";
  closeGovernance(t, t.rfes.find((r) => r.id === f2.voteRfeId)!);
  assert.equal(flagConfirmer(t, f2).conflicted, false);
  assert.equal(f2.certifiedAt, undefined);
  assert.throws(() => certifyFlag(t, f2.id, "ops_odile"), /runs Dockside/);
  assert.throws(() => certifyFlag(t, f2.id, "cfo_ines"));
  certifyFlag(t, f2.id, protocolSteward);
  assert.equal(f2.certifiedBy, protocolSteward);
  assert.ok(t.ledger.some((l) => l.kind === "breach" && l.ref === f2.id));
});

test("batch windows: announced hides seats, early access is for qualified members, the close kills unfunded ventures", () => {
  const s = buildSeed();
  const kestrel = ventureBySlug(s, "site-record")!;
  assert.equal(seatWindow(s, kestrel).state, "announced");
  assert.equal(kestrel.status, "generated");

  s.meta.clock = "2026-11-06T13:00:00.000Z";
  advanceBatches(s);
  assert.equal(cohortById(s, "cohort-2")!.status, "closed", "Batch 002's window ended; unfunded ventures ended and refunded every seat in full");
  assert.equal(cohortById(s, "cohort-3")!.status, "live");
  assert.equal(kestrel.status, "pitched");
  assert.equal(seatWindow(s, kestrel).state, "early");
  assert.throws(() => buySeat(s, { slug: "site-record", handle: "gis_greta" }), /seat price waits for the steward's sign-off/, "no seat sells before the steward signs the price");
  const price = latestDeck(s, kestrel.id)!.seatPlan.price!;
  stewardDecide(s, price.decisionId!, true, "Checked.", kestrel.stewardHandle);
  assert.equal(seatPriceStatus(s, latestDeck(s, kestrel.id)), "signed");
  assert.throws(() => buySeat(s, { slug: "site-record", handle: "stranger_sam" }), /Only verified members can take a seat this early/);
  buySeat(s, { slug: "site-record", handle: "gis_greta" });
  assert.equal(s.ledger.filter((l) => l.kind === "seat").at(-1)!.usd, kestrel.seatPriceUsd, "the seat costs the venture's own price");
  s.meta.clock = "2026-11-07T12:30:00.000Z";
  buySeat(s, { slug: "site-record", handle: "stranger_sam" });

  const ended = ["permit-pulse", "lien-clock", "wet-ink"].map((slug) => ventureBySlug(s, slug)!).filter((v) => v.status === "killed");
  assert.ok(ended.length >= 1);
  for (const v of ended) assert.ok(v.postMortem?.publishedAt && v.postMortem.killReason === "no demand");
});

test("announced ventures are reachable only by codename until their batch goes live", () => {
  const s = buildSeed();
  const kestrel = ventureBySlug(s, "site-record")!;
  assert.equal(kestrel.codename, "KESTREL");
  assert.equal(lookupVenture(s, "site-record"), undefined, "the real slug would give the name away");
  assert.deepEqual(lookupVenture(s, "kestrel"), { venture: kestrel, canonical: "kestrel" });
  assert.equal(ventureHref(s, kestrel), "/v/kestrel");

  s.meta.clock = "2026-11-06T13:00:00.000Z";
  advanceBatches(s);
  assert.deepEqual(lookupVenture(s, "site-record"), { venture: kestrel, canonical: "site-record" });
  assert.equal(lookupVenture(s, "kestrel")?.canonical, "site-record", "the codename slug now redirects to the real one");
  assert.equal(ventureHref(s, kestrel), "/v/site-record");
});

test("slot allocation: overdue end markets and business models first, then exploration, then outcomes", () => {
  const s = buildSeed();
  const batch3 = cohortById(s, "cohort-3")!;
  const overdue = batch3.slotPlan.filter((p) => p.kind === "overdue");
  assert.ok(overdue.length >= 1, "Batch 003 filled an end market or business model no recent batch had tried");
  assert.ok(overdue.some((p) => p.endMarket === "Public sector"));
  assert.ok(batch3.slotPlan.some((p) => p.kind === "outcomes"));
  assert.equal(new Set(batch3.slotPlan.map((p) => p.endMarket)).size, batch3.slotPlan.length, "Batch 003 spreads across end markets");

  const picks = allocateBatchSlots(s);
  assert.equal(picks.length, defaultParams().VENTURES_PER_BATCH);
  assert.equal(new Set(picks.map((p) => `${p.endMarket}|${p.businessModel}`)).size, picks.length);

  const exploring = allocateBatchSlots(s, { ...defaultParams(), BATCH_MIN_SLOTS_PER_SEGMENT: 0, BATCH_EXPLORATION_SHARE: 1 });
  assert.ok(exploring.every((p) => p.kind === "exploration"));
});

test("roster and readiness are disclosures; nothing blocks a pitch", () => {
  const s = buildSeed();
  const pp = ventureBySlug(s, "permit-pulse")!;
  const rows = rosterFill(s, pp);
  assert.ok(rows.some((r) => r.filled.length > 0));
  const items = readiness(s, pp);
  assert.deepEqual(items.map((i) => i.key), ["budget", "reach", "demand", "lessons"]);
  const lien = ventureBySlug(s, "lien-clock")!;
  const lessons = readiness(s, lien).find((i) => i.key === "lessons")!;
  assert.match(lessons.value, /L-005/);
  assert.equal(lien.status, "pitched");
});

test("tagging: the queue never blocks; confirm, correct and merge are logged", () => {
  const s = buildSeed();
  const queue = tagQueue(s);
  assert.ok(queue.length > 0);
  const item = queue.find((q) => q.kind === "venture" && q.id === "bid-desk" && q.tag.axis === "endMarket")!;
  assert.equal(item.tag.value, "Public sector");
  confirmTag(s, { kind: "venture", id: "bid-desk", axis: "endMarket", value: item.tag.value, newValue: "Real estate and construction", by: "mp" });
  const bid = ventureBySlug(s, "bid-desk")!.tags.find((t) => t.axis === "endMarket")!;
  assert.deepEqual([bid.value, bid.status], ["Real estate and construction", "confirmed"]);
  assert.throws(
    () => confirmTag(s, { kind: "venture", id: "bid-desk", axis: "endMarket", value: bid.value, newValue: "Govtech", by: "mp" }),
    /Protocol request/,
    "a new standard value needs a vote",
  );
  const before = s.tagLog.length;
  rewriteTagValue(s, { axis: "endMarket", from: "Software and IT", to: "Professional services", by: "mp" });
  assert.equal(s.tagLog.length, before + 1);
  assert.equal(s.tagLog.at(-1)!.action, "merge");
  assert.equal(ventureBySlug(s, "wet-ink")!.tags.find((t) => t.axis === "endMarket")!.value, "Professional services");
  assert.throws(() => rewriteTagValue(s, { axis: "customer", from: "Small business", to: "SMB", by: "mp" }), /needs a Protocol vote/);
  rewriteTagValue(s, { axis: "subVertical", from: "Dental practices", to: "Dental and orthodontic practices", by: "mp" });
  assert.equal(ventureBySlug(s, "chairside")!.tags.find((t) => t.axis === "subVertical")!.value, "Dental and orthodontic practices");
});
