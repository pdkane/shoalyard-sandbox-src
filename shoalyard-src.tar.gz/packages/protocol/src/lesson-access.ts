import { LESSON_TOPIC_LABELS, LESSON_TOPICS, type Decision, type Lesson, type Member, type ParamValues, type Store, type Venture } from "@av/schema";
import { rosterFill } from "./network";
import { hasSeat } from "./ops";
import { publicDecisions } from "./queries";

/**
 * Who reads the lessons (Article 3). Decisions stay public; the lessons drawn
 * from them are for members, unless a vote sets LESSONS_VISIBLE_TO to "public".
 */

export const LESSON_AUDIENCES = ["qualified members", "public"] as const;

export function lessonsArePublic(params: ParamValues): boolean {
  return params.LESSONS_VISIBLE_TO === "public";
}

export function canReadLessons(member: Pick<Member, "qualification"> | undefined, params: ParamValues): boolean {
  return lessonsArePublic(params) || member?.qualification === "qualified";
}

export interface LessonTeaser {
  count: number;
  /** Earlier ventures the lessons were drawn from. */
  ventures: number;
  topics: string[];
}

/** What the public sees: that the lessons exist, not what they say. */
export function lessonTeaser(store: Store): LessonTeaser {
  const kept = store.lessons.filter((l) => l.status !== "retired");
  const ventureOf = (e: Lesson["evidence"][number]) =>
    e.kind === "venture"
      ? e.id
      : e.kind === "decision"
        ? store.decisions.find((d) => d.id === e.id)?.ventureId
        : e.kind === "rfe"
          ? store.rfes.find((r) => r.id === e.id)?.ventureId
          : undefined;
  const protocolIds = new Set(store.ventures.filter((v) => v.isProtocol).map((v) => v.id));
  const ventures = new Set(kept.flatMap((l) => l.evidence.map(ventureOf)).filter((id): id is string => !!id && !protocolIds.has(id)));
  const topics = LESSON_TOPICS.filter((t) => kept.some((l) => l.topic === t)).map((t) => LESSON_TOPIC_LABELS[t]);
  return { count: kept.length, ventures: ventures.size, topics };
}

/** Seat holders, the team on the roster and the steward see how each lesson was used in their venture. */
export function seesLessonUse(store: Store, venture: Venture, member: Member | undefined, params: ParamValues): boolean {
  if (!member || !canReadLessons(member, params)) return false;
  if (venture.stewardHandle === member.handle || hasSeat(store, venture.id, member.handle)) return true;
  return rosterFill(store, venture).some((r) => r.filled.includes(member.handle));
}

/** The public decisions in a venture that followed each lesson. */
export function lessonUse(store: Store, venture: Venture): Map<string, Pick<Decision, "id" | "title" | "at">[]> {
  const out = new Map<string, Pick<Decision, "id" | "title" | "at">[]>();
  for (const d of publicDecisions(store, venture.id)) {
    if (d.redacted) continue;
    for (const id of d.lessonIds ?? []) out.set(id, [...(out.get(id) ?? []), { id: d.id, title: d.title, at: d.at }]);
  }
  return out;
}
