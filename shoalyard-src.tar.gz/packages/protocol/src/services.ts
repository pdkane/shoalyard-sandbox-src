import type { LedgerEntry, ParamKey, ParamValues, Store, Venture, VentureStatus } from "@av/schema";
import { resolveParams } from "./params";
import { newId } from "./util";

/**
 * The shared back office: one legal, finance and operations setup behind every
 * venture, billed to each at cost. Rates are settings; this file only does the
 * arithmetic and keeps the books on it.
 */
export const SERVICE_AREAS = ["legal", "finance", "operations"] as const;
export type ServiceArea = (typeof SERVICE_AREAS)[number];
export const SERVICE_AREA_LABELS: Record<ServiceArea, string> = { legal: "Legal", finance: "Finance", operations: "Operations" };

export interface ServiceItem {
  key: string;
  area: ServiceArea;
  name: string;
  what: string;
  /** "shared": one cost split across SERVICES_SHARED_BY ventures. "each": billed per venture a month. "once": per venture, at the start. */
  basis: "shared" | "each" | "once";
  param: ParamKey;
  /** What a venture would otherwise buy for itself. */
  instead: string;
}

export const SERVICE_CATALOGUE: ServiceItem[] = [
  {
    key: "entity",
    area: "legal",
    name: "Umbrella entity",
    what: "One umbrella entity holds every venture as its own series, with separate books, units and liabilities. Which legal form and which state is an open question for counsel.",
    basis: "shared",
    param: "SVC_ENTITY_USD",
    instead: "its own company filing, registered agent and annual fees",
  },
  {
    key: "series",
    area: "legal",
    name: "Opening the venture's series",
    what: "The filing and paperwork that adds one venture under the umbrella once its roster is in place.",
    basis: "once",
    param: "SVC_SERIES_SETUP_USD",
    instead: "a standalone formation, about $400",
  },
  {
    key: "templates",
    area: "legal",
    name: "Template library",
    what: "Customer terms, privacy notice, contractor agreement and NDA, reviewed once by counsel and used by every venture. Venture-specific questions still go to counsel on the venture's own budget.",
    basis: "shared",
    param: "SVC_TEMPLATES_USD",
    instead: "its own terms and a lawyer's review, about $600",
  },
  {
    key: "payments",
    area: "finance",
    name: "Bank and payments",
    what: "One bank account and one payments account, with the Protocol as merchant of record: customers pay through it and each sale is booked to the venture that made it. Includes the sales-tax service.",
    basis: "shared",
    param: "SVC_PAYMENTS_USD",
    instead: "its own bank, payments and sales-tax accounts",
  },
  {
    key: "books",
    area: "finance",
    name: "Master books",
    what: "Accounting software and a monthly close for the whole umbrella, with each venture kept as its own class.",
    basis: "shared",
    param: "SVC_BOOKS_USD",
    instead: "its own accounting software and quarterly close, about $90 a month",
  },
  {
    key: "books-each",
    area: "finance",
    name: "The venture's books",
    what: "Reconciling the venture's class each month, so its report and its payouts rest on closed books.",
    basis: "each",
    param: "SVC_BOOKS_PER_VENTURE_USD",
    instead: "—",
  },
  {
    key: "contractor-pay",
    area: "finance",
    name: "Contractor payments and tax forms",
    what: "Collects contractors' tax details, pays them and files the year-end forms, for every venture.",
    basis: "shared",
    param: "SVC_CONTRACTOR_PAY_USD",
    instead: "its own contractor-payments account",
  },
  {
    key: "insurance",
    area: "operations",
    name: "Master insurance policy",
    what: "General liability, technology errors and omissions and a cyber rider, with each venture named. A venture with a risk the policy doesn't cover buys its own top-up.",
    basis: "shared",
    param: "SVC_INSURANCE_USD",
    instead: "its own policy, about $95 a month",
  },
  {
    key: "mailboxes",
    area: "operations",
    name: "Email",
    what: "Two mailboxes on the shared email setup. The venture's own domain stays in its own budget.",
    basis: "each",
    param: "SVC_MAILBOX_USD",
    instead: "two mailboxes at list price, about $17 a month",
  },
  {
    key: "tools",
    area: "operations",
    name: "Shared tools",
    what: "One set of seats for the CRM, forms, analytics and status page.",
    basis: "shared",
    param: "SVC_TOOLS_USD",
    instead: "its own subscriptions",
  },
  {
    key: "hosting",
    area: "operations",
    name: "Hosting and logs",
    what: "The servers the agents run on, with logs and backups. Each venture's model use is metered and stays in its own budget.",
    basis: "shared",
    param: "SVC_HOSTING_USD",
    instead: "its own hosting",
  },
];

export interface ChargeItem {
  item: ServiceItem;
  /** What one venture pays for it a month, or once for "once" items. */
  usd: number;
}

export interface SharedServicesCharge {
  sharedBy: number;
  /** Flat monthly charge per venture, whole dollars. */
  monthlyUsd: number;
  /** One-time charge when the venture's series opens. */
  setupUsd: number;
  byArea: Record<ServiceArea, number>;
  items: ChargeItem[];
  /** What the Protocol pays a month for the shared items, before any venture's own items. */
  pooledMonthlyUsd: number;
}

const rate = (params: ParamValues, key: ParamKey) => params[key] as number;
const cents = (n: number) => Math.round(n * 100) / 100;

/** The flat per-venture charge, computed from the catalogue's at-cost rates. */
export function sharedServicesCharge(params: ParamValues): SharedServicesCharge {
  const sharedBy = Math.max(1, params.SERVICES_SHARED_BY);
  const items = SERVICE_CATALOGUE.map((item) => ({
    item,
    usd: item.basis === "shared" ? cents(rate(params, item.param) / sharedBy) : rate(params, item.param),
  }));
  const byArea = Object.fromEntries(
    SERVICE_AREAS.map((a) => [a, Math.ceil(items.filter((i) => i.item.area === a && i.item.basis !== "once").reduce((s, i) => s + i.usd, 0))]),
  ) as Record<ServiceArea, number>;
  return {
    sharedBy,
    monthlyUsd: SERVICE_AREAS.reduce((s, a) => s + byArea[a], 0),
    setupUsd: items.filter((i) => i.item.basis === "once").reduce((s, i) => s + i.usd, 0),
    byArea,
    items,
    pooledMonthlyUsd: SERVICE_CATALOGUE.filter((i) => i.basis === "shared").reduce((s, i) => s + rate(params, i.param), 0),
  };
}

/** The same items bought separately by one venture, at the list prices in the catalogue's "instead". */
export const STANDALONE_MONTHLY_USD = { books: 90, insurance: 95, mailboxes: 17 } as const;
export const STANDALONE_ONCE_USD = { formation: 400, templates: 600 } as const;

function ledger(store: Store, entry: Omit<LedgerEntry, "id" | "at">): LedgerEntry {
  const row: LedgerEntry = { id: newId(store, "l"), at: store.meta.clock, ...entry };
  store.ledger.push(row);
  return row;
}

function protocolVenture(store: Pick<Store, "ventures">): Venture {
  const v = store.ventures.find((x) => x.isProtocol);
  if (!v) throw new Error("No Protocol venture in the store");
  return v;
}

/** A month as "2026-10". */
export const monthOf = (iso: string) => iso.slice(0, 7);
const monthName = (month: string) => new Date(`${month}-01T00:00:00Z`).toLocaleString("en-US", { month: "long", year: "numeric", timeZone: "UTC" });

/** Statuses in which a venture runs on the back office and pays for it. */
export const USES_BACK_OFFICE: readonly VentureStatus[] = ["formed", "operating", "customer1", "distributing"];

export function backOfficeOpen(store: Pick<Store, "ledger">): boolean {
  return store.ledger.some((l) => l.kind === "service-cost");
}

/**
 * Bill one venture for a month of shared services, once per area, plus the series
 * setup the first time. The Protocol books the venture's own items at the same cost
 * on its side, so charges and costs can be read against each other. Idempotent.
 */
export function chargeSharedServices(store: Store, venture: Venture, month = monthOf(store.meta.clock), params = resolveParams(store)): LedgerEntry[] {
  if (venture.isProtocol || !USES_BACK_OFFICE.includes(venture.status)) return [];
  const rows: LedgerEntry[] = [];
  const charge = sharedServicesCharge(params);
  const protocol = protocolVenture(store);
  const has = (ventureId: string, kind: LedgerEntry["kind"], ref: string) => store.ledger.some((l) => l.ventureId === ventureId && l.kind === kind && l.ref === ref);
  if (!has(venture.id, "service-charge", "svc:setup")) {
    rows.push(
      ledger(store, { ventureId: venture.id, kind: "service-charge", usd: charge.setupUsd, ref: "svc:setup", note: `Shared services, legal: opening ${venture.name}'s series under the umbrella, at cost.` }),
      ledger(store, { ventureId: protocol.id, kind: "service-cost", usd: charge.setupUsd, ref: `svc:setup:${venture.slug}`, note: `Opened ${venture.name}'s series, paid at cost.` }),
    );
  }
  for (const area of SERVICE_AREAS) {
    const ref = `svc:${month}:${area}`;
    if (has(venture.id, "service-charge", ref)) continue;
    const names = charge.items.filter((i) => i.item.area === area && i.item.basis !== "once").map((i) => i.item.name.toLowerCase());
    rows.push(
      ledger(store, {
        ventureId: venture.id,
        kind: "service-charge",
        usd: charge.byArea[area],
        ref,
        note: `Shared services, ${area}, for ${monthName(month)}: ${names.join(", ")}. At cost, shared across ${charge.sharedBy} ventures.`,
      }),
    );
  }
  for (const i of charge.items.filter((c) => c.item.basis === "each")) {
    const ref = `svc:${month}:${i.item.key}:${venture.slug}`;
    if (has(protocol.id, "service-cost", ref)) continue;
    rows.push(ledger(store, { ventureId: protocol.id, kind: "service-cost", usd: i.usd, ref, note: `${i.item.name} for ${venture.name}, ${monthName(month)}, paid at cost.` }));
  }
  return rows;
}

/** The Protocol's own bills for the shared items in a month, published on its record. Idempotent. */
export function publishServiceCosts(store: Store, month = monthOf(store.meta.clock), params = resolveParams(store)): LedgerEntry[] {
  const protocol = protocolVenture(store);
  const rows: LedgerEntry[] = [];
  for (const item of SERVICE_CATALOGUE.filter((i) => i.basis === "shared")) {
    const ref = `svc:${month}:${item.key}`;
    if (store.ledger.some((l) => l.ventureId === protocol.id && l.kind === "service-cost" && l.ref === ref)) continue;
    rows.push(ledger(store, { ventureId: protocol.id, kind: "service-cost", usd: rate(params, item.param), ref, note: `${item.name}, ${monthName(month)}: paid at cost.` }));
  }
  return rows;
}

/** Run the back office for this month: the Protocol's bills, then every venture that uses it. */
export function runBackOffice(store: Store, params = resolveParams(store)): LedgerEntry[] {
  if (!backOfficeOpen(store)) return [];
  const month = monthOf(store.meta.clock);
  const rows = publishServiceCosts(store, month, params);
  for (const v of store.ventures) rows.push(...chargeSharedServices(store, v, month, params));
  return rows;
}

export interface ServicesAccount {
  chargedUsd: number;
  costUsd: number;
  /** Costs not yet covered by charges; the Protocol carries it from its own share. */
  uncoveredUsd: number;
  months: { month: string; chargedUsd: number; costUsd: number }[];
  ventures: { ventureId: string; chargedUsd: number }[];
}

const areaOfRef = (ref = "") => ref.split(":")[2];

/** What the Protocol has collected in charges against what the back office cost it. */
export function servicesAccount(store: Pick<Store, "ledger" | "ventures">): ServicesAccount {
  const charges = store.ledger.filter((l) => l.kind === "service-charge");
  const costs = store.ledger.filter((l) => l.kind === "service-cost");
  const monthKey = (l: LedgerEntry) => (l.ref?.startsWith("svc:setup") ? monthOf(l.at) : (l.ref?.split(":")[1] ?? monthOf(l.at)));
  const months = [...new Set([...charges, ...costs].map(monthKey))].sort();
  const sum = (rows: LedgerEntry[]) => cents(rows.reduce((s, l) => s + (l.usd ?? 0), 0));
  const chargedUsd = sum(charges);
  const costUsd = sum(costs);
  const byVenture = new Map<string, number>();
  for (const c of charges) byVenture.set(c.ventureId, cents((byVenture.get(c.ventureId) ?? 0) + (c.usd ?? 0)));
  return {
    chargedUsd,
    costUsd,
    uncoveredUsd: cents(Math.max(0, costUsd - chargedUsd)),
    months: months.map((m) => ({ month: m, chargedUsd: sum(charges.filter((l) => monthKey(l) === m)), costUsd: sum(costs.filter((l) => monthKey(l) === m)) })),
    ventures: [...byVenture.entries()].map(([ventureId, usd]) => ({ ventureId, chargedUsd: usd })).sort((a, b) => b.chargedUsd - a.chargedUsd),
  };
}

/** The public line for the shortfall the Protocol absorbs while fewer ventures share the back office than it's priced for. */
export function protocolCoveringLine(account: Pick<ServicesAccount, "uncoveredUsd">): string | undefined {
  if (!(account.uncoveredUsd > 0)) return undefined;
  return `Protocol covering $${Math.round(account.uncoveredUsd).toLocaleString("en-US")} until more ventures share it`;
}

/** Shared-services charges billed to one venture so far. */
export function serviceChargesFor(store: Pick<Store, "ledger">, ventureId: string): { totalUsd: number; byArea: Record<ServiceArea, number> } {
  const rows = store.ledger.filter((l) => l.ventureId === ventureId && l.kind === "service-charge");
  const byArea = Object.fromEntries(SERVICE_AREAS.map((a) => [a, 0])) as Record<ServiceArea, number>;
  for (const r of rows) {
    const area = r.ref === "svc:setup" ? "legal" : (areaOfRef(r.ref) as ServiceArea);
    if (area in byArea) byArea[area] = cents(byArea[area] + (r.usd ?? 0));
  }
  return { totalUsd: cents(rows.reduce((s, l) => s + (l.usd ?? 0), 0)), byArea };
}
