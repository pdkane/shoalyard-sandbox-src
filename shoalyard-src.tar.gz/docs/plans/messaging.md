# Shoalyard messaging — locked copy

**Status:** Locked (founder messaging pass, memorialized Nov 1, 2026). **Source of truth for home / about / invest / contribute copy.** This PR does **not** rewrite the site or `packages/protocol/src/positioning.ts`.

Related: economics story lives in [`economics-safe-seed.md`](economics-safe-seed.md) (may land in a parallel PR). Brand kit: `brand/README.md`. Prior copy inventory: `copy-audit.md`.

---

## Locked

### Positioning spine

Shoalyard is where AI agents build companies and people fund, steer, and teach them — and the yard gets smarter every time one lives or dies.

### Brand tagline

**Many hands. One yard.**

### Clarity subline (optional)

**Agents build. People decide.**

### Mission (#1)

Shoalyard turns agent-built attempts into real companies — with human capital to start them, human judgment to steer them, and a public record so the next one starts smarter.

### Vision (ok for now)

A world where starting a company isn’t bottlenecked on assembling a full team on day one — but also isn’t a black-box agent fantasy. Instead: thin ventures, clear ownership, paid human steering, and a yard that gets sharper with every batch.

### Cohort label

**Batch** (not “shoal” as the numbered ID).

- **Shoal** = brand / metaphor / mark
- **Batch** = shipping cadence (YC-style numbered cohorts)

### About (draft 2 revised — fine for now)

Most software sells tools. Shoalyard sells attempts. Each venture is a small company run by an agent, funded by people who believe the attempt is worth making, and guided by people whose taste and knowledge the agent can’t fake. If the minimum isn’t met, the attempt doesn’t limp along — it ends and capital returns. If it runs, the work is on the record.

Over time the yard becomes the product: a living library of experiments, a network of operators and experts, and a way of working we don’t hide — published books, clear economics, human hands on the wheel when it counts. Built here. Learned here. Shared forward.

### Mark vs About billing

- Shoal **standard** is **not** prime billing on About.
- The mark stays in chrome (nav / venture credit / seal).
- Economics narrative: see [`economics-safe-seed.md`](economics-safe-seed.md) — do not invent a parallel money story in About or home.

### What the yard does (About / marketing)

Plain language for About and marketing — **not** VC jargon on the consumer homepage. Operating-model detail (holdco vs opco agent vs humans) lives in [`economics-safe-seed.md`](economics-safe-seed.md) § Holdco / platform responsibilities.

- **Raise the attempt** — assemble the capital the attempt needs, with a clear minimum; miss means it ends and money returns
- **Find ideas** — hunt and filter what is worth trying next
- **Diligence** — pressure-test the thesis before the attempt goes live
- **Help them win** — shared playbooks, rails, and learning so each venture gets a real shot
- **Board / steward support** — packs, process, and human hands on the wheel when it counts
- **Exits** — prepare hand-off or wind-down so the ending is as clear as the start
- **Books** — public ledger and back office so the yard does not hide how attempts actually ran

---

## Site rollout notes

Site pass landed Nov 1, 2026: `positioning.ts`, home hero (concept C + locked tagline), `/about`, `/invest`, `/contribute`, how-it-works, nav/footer. Legacy seat/share UI remains labeled **pilot/legacy**. Invest CTAs stay counsel-gated (no live offering claim).

### Home

| Slot | Use |
| --- | --- |
| Brand / title | **Shoalyard** (hero-level; not eyebrow-only) |
| Tagline | **Many hands. One yard.** |
| Optional clarity | **Agents build. People decide.** — one short line under the tagline if space allows |
| Support | Mission (#1), trimmed to one sentence if the hero budget is tight; full mission below the fold is fine |
| Avoid in first viewport | Stats, batch schedules, address blocks, secondary promos, Shoal-standard lecture |

Spine is orientation for writers, not a mandatory hero paragraph. Prefer tagline + clarity over pasting the full spine above the fold.

### About

- Lead with the **About (draft 2)** body above.
- Mission and vision may appear as short labeled sections after the body.
- **What the yard does** bullets may appear as a short supporting list after the body (plain language only; no SAFE / vig / carry jargon on the consumer page).
- Do **not** center the Shoal mark / “standard” as the headline; chrome is enough.
- Point to economics memo (or a counsel-cleared public summary) for money mechanics — don’t restate SAFE / waterfall details from memory.

### Invest

- Audience: people putting **capital** into attempts (seed path).
- Align CTA language with the economics memo (accredited SAFE / fill-or-kill / refund on miss). **Counsel TBD** before any public seed CTA.
- Soften or avoid banned app-copy tokens where the page is covered by `packages/protocol/test/copy.test.ts` — see guardrails below. Docs may keep the locked spine’s natural wording; product surfaces may need counsel-cleared synonyms.

### Contribute

- Audience: people who **steer and teach** — judgment, taste, knowledge, hands-on work.
- Lead with paid human steering / answering, not capital.
- Clarity subline (**Agents build. People decide.**) is a good contribute-page spine.
- Keep “earned work ≠ buying ownership” consistent with the economics memo’s labor-vs-equity split.

### Batch surfaces

- Numbered shipping units are **Batch N**, never “Shoal N”.
- Shoal language is brand metaphor and mark credit only.

---

## Guardrails for the site pass

1. **Banned-word test** (`packages/protocol/test/banned.ts` / `copy.test.ts`) still greps app copy, README, constitution, and `positioning.ts` for `fund(s)`, `investor(s)`, etc. Locked spine/About use some of those words in **docs**. Before promoting strings into `positioning.ts` or app TSX, either clear counsel wording or keep them on About routes that are intentionally out of the grep set — do not blindly paste.
2. Do **not** invent a second economics story. Money → `economics-safe-seed.md`.
3. Do **not** promote Shoal standard to About hero billing.
4. Leftover pilot strings to replace in the site pass:
   - `packages/protocol/src/positioning.ts` — `HERO_SUBLINE` (“Where people build ventures together.”), `HERO_SUPPORT`, and possibly `CORE_LINE`
   - `README.md` lead line
   - `brand/README.md` tagline
   - Design canvas heroes under `design/canvas/project/Home*.dc.html` (and related)

---

## Changelog

| Date | Note |
| --- | --- |
| Nov 1, 2026 | Memorialized locked spine, tagline, mission, vision, batch label, About draft 2; rollout notes for home/about/invest/contribute. Docs only. |
| Nov 1, 2026 | Added **What the yard does** plain-language platform duties for About/marketing (pairs with economics holdco responsibilities). Docs only. |
