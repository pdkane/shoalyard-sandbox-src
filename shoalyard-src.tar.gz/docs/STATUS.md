# Shoalyard: status

Start here in a new session. Read this file, then `README.md`, then the plan notes in `docs/plans/`.

Last updated Nov 1, 2026.

## Source of truth

- **Canonical git remote:** [github.com/pdkane/shoalyard](https://github.com/pdkane/shoalyard) (`origin` should point here).
- **Cloud Agents:** use the **GitHub shoalyard** environment going forward.
- **Origin / Cursor mirror:** optional legacy only — do **not** require Origin for workflow; do not treat it as SoT. Keep history; just stop writing process notes that assume Origin is primary.
- Branch habit: land work via PRs `cursor/<name>-3fb7` (or session suffix) into **GitHub `main`**.

## What this is

One brand, **Shoalyard** (domain **shoalyard.com** on Cloudflare): the yard that builds ventures.

- Mark: `{name}, a Shoalyard venture`, only for ventures the Protocol builds; it ends at hand-off and is lost after 3 upheld breaches (Article 7)
- Constitution v1.16
- Tagline: **Many hands. One yard.** Clarity: **Agents build. People decide.**

**Messaging (locked):** → [`docs/plans/messaging.md`](plans/messaging.md)  
**Economics (agreed):** → [`docs/plans/economics-safe-seed.md`](plans/economics-safe-seed.md)  
**Counsel packet (placeholders — not legal advice):** → [`docs/plans/counsel/`](plans/counsel/)  
**Holdco agent map (stubs):** → [`docs/plans/holdco-agents.md`](plans/holdco-agents.md)

An AI operating agent (Claude) proposes and runs zero-to-one experiments called ventures. People bring judgment, taste, knowledge and relationships.

## Economics (pivot — source of truth)

**Agreed model:** accredited **SAFE** seed via fill-or-kill escrow; answers paid in **cash** from the proof budget (equal treatment; no equity-by-answering); published waterfall (token costs → answer cash → ~5% platform vig → then SAFE/equity); operator ~20% equity (upside alignment); holdco capital/control separate from opco seed. **Counsel TBD** — not legal advice.

**Holdco / platform duties** (VC-analog; specialized holdco **agents**): economics memo § Holdco / platform responsibilities; plain-language About list in messaging **What the yard does**; role stubs in `packages/schema` (`HoldcoAgentRole`).

**Pilot code may still show** seat-as-access and equal ownership shares per accepted answer — treat as **pilot/legacy** until the economics rollout checklist is finished. Keep: fill-or-kill minimum, published ledger, Shoal mark vs Built at the Shoalyard credit, equal cash terms for similar accepted work.

- Founding steward: **MP**. Ventures run in YC-style **batches** (Shoal = brand/mark only).

## Domain

- **shoalyard.com** purchased on Cloudflare (Oct 31, 2026). Point `SITE_URL` / production host here when deploying. Local default remains `http://localhost:43117`.

## Stack and running it

- pnpm workspace: `packages/schema`, `packages/protocol`, `apps/venture` (Next.js 16, Tailwind v4).
- Data: `data/store.json`; `pnpm seed`. Supabase migration written, not applied. Do not touch Supabase project "Quiver".
- Dev: `pnpm dev` on 43117. Checks: `pnpm typecheck`, `pnpm test`, `pnpm lint`, `pnpm build`.
- Agent: scripted demo by default; `ANTHROPIC_API_KEY` for Claude only.

## Built (high level)

- Constitution, classification, decision tiers, visibility, lessons, pitch/deck/Q&A/roster, operating loop.
- Proof budget, 12-month plan, shared back office, hand-off, per-venture seat price, sharing/scarcity/waitlists, proof plans.
- Brand kit + homepage hero concept C (live canvas shoal).
- Site surfaces: About (locked draft), Invest (capital / SAFE path, counsel-gated), Contribute (cash answers).
- Pilot equal-share economics still in code; **agreed successor** is SAFE seed + cash answers.
- Shoal mark vs Shoalyard credit split.
- Counsel placeholders: YC post-money SAFE forms + term sheet + riders checklist + 506(b)/(c) open note.

## Next

- Wire production DNS / `SITE_URL` to shoalyard.com when ready to deploy.
- Execute remaining economics rollout checklist (params, ledger kinds, attestation) after counsel.
- Wire specialized holdco agents from the stub map.
- Embeddable badge; deck promotion plan.
- Counsel before real seed or real answer cash.
- Dockside monthly review awaiting steward signature.

## Open questions

- Q&A “legal” holds; public experiment details; unverified askers earn nothing (keep).
- Play-money forecasts; Protocol licences.
- Securities / entity / SAFE / **506(b) vs 506(c)** — see counsel packet (**OPEN**, counsel TBD).

## Not built

Real payments, login, X/LinkedIn verification and email are mocks. Nothing posts to X autonomously; no real money moves without human approval. No live SAFE issuance or accredited attestation flow yet.

## Design notes (`docs/plans/`)

- **`messaging.md`** — locked positioning, tagline, mission, About draft, batch vs shoal, What the yard does.
- **`economics-safe-seed.md`** — agreed funding + answer economics + holdco/platform responsibilities.
- **`counsel/`** — YC SAFE placeholders + term sheet + riders + 506 decision note (**not legal advice**).
- **`holdco-agents.md`** — specialized holdco agent role stubs.
- `foundation-plan.md`, `founding-dna-research.md`, `pitch-deck-spec.md`, `decision-framework.md`, `copy-audit.md`, `seat-price-per-venture.md` (seat notes = prior product; superseded for funding story).
