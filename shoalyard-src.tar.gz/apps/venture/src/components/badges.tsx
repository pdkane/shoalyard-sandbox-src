import {
  OBJECTIVE_LABELS,
  RFE_TYPE_LABELS,
  VENTURE_STATUS_LABELS,
  type DecisionBin,
  type Objective,
  type RfeType,
  type VentureStatus,
} from "@av/schema";
import { Explain } from "@/components/explain";
import { cn } from "@/lib/utils";

const base = "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium whitespace-nowrap";

const STATUS_STYLES: Record<VentureStatus, string> = {
  generated: "border-zinc-200 bg-zinc-50 text-zinc-700",
  pitched: "border-sky-200 bg-sky-50 text-sky-800",
  funded: "border-indigo-200 bg-indigo-50 text-indigo-800",
  formed: "border-violet-200 bg-violet-50 text-violet-800",
  operating: "border-teal-200 bg-teal-50 text-teal-800",
  customer1: "border-emerald-200 bg-emerald-50 text-emerald-800",
  distributing: "border-emerald-300 bg-emerald-100 text-emerald-900",
  dormant: "border-zinc-200 bg-zinc-100 text-zinc-600",
  killed: "border-rose-200 bg-rose-50 text-rose-800",
  "handed-off": "border-amber-200 bg-amber-50 text-amber-900",
};

export function StatusBadge({ status, className }: { status: VentureStatus; className?: string }) {
  return (
    <span className={cn(base, STATUS_STYLES[status], className)}>
      <span className={cn("size-1.5 rounded-full bg-current", status === "killed" ? "opacity-60" : "")} />
      {VENTURE_STATUS_LABELS[status]}
    </span>
  );
}

const BIN_STYLES: Record<DecisionBin, string> = {
  auto: "border-emerald-200 bg-emerald-50 text-emerald-800",
  advisory: "border-amber-200 bg-amber-50 text-amber-800",
  gated: "border-rose-200 bg-rose-50 text-rose-800",
};
export const BIN_LABELS: Record<DecisionBin, string> = {
  auto: "Agent decided",
  advisory: "Asked members first",
  gated: "Needs sign-off",
};
export const BIN_HELP: Record<DecisionBin, string> = {
  auto: "The agent decided on its own and recorded why.",
  advisory: "The agent asked members first; it decides unless their answers move it.",
  gated: "Needs the steward's sign-off.",
};

/** Pass explain={false} when the badge sits inside a link. */
export function BinBadge({ bin, className, explain = true }: { bin: DecisionBin; className?: string; explain?: boolean }) {
  const badge = <span className={cn(base, BIN_STYLES[bin], className)}>{BIN_LABELS[bin]}</span>;
  if (!explain) return badge;
  return (
    <Explain title={BIN_LABELS[bin]} text={BIN_HELP[bin]} href={bin === "gated" ? "/glossary#sign-off" : "/glossary#ledger"}>
      {badge}
    </Explain>
  );
}

const TYPE_STYLES: Record<RfeType, string> = {
  judgment: "border-violet-200 bg-violet-50 text-violet-800",
  knowledge: "border-sky-200 bg-sky-50 text-sky-800",
  access: "border-teal-200 bg-teal-50 text-teal-800",
  credibility: "border-amber-200 bg-amber-50 text-amber-800",
  action: "border-orange-200 bg-orange-50 text-orange-800",
  capital: "border-indigo-200 bg-indigo-50 text-indigo-800",
  stewardship: "border-zinc-300 bg-zinc-50 text-zinc-800",
};

export function RfeTypeBadge({
  type,
  governance,
  className,
  explain = true,
}: {
  type: RfeType;
  governance?: boolean;
  className?: string;
  /** Pass false when the badge sits inside a link. */
  explain?: boolean;
}) {
  if (governance) {
    const vote = <span className={cn(base, "border-fuchsia-200 bg-fuchsia-50 text-fuchsia-800", className)}>Holder vote</span>;
    if (!explain) return vote;
    return (
      <Explain title="Holder vote" text="People with vested units in this venture vote on it. The agent can propose a vote but never votes." href="/glossary#holder-vote">
        {vote}
      </Explain>
    );
  }
  const badge = <span className={cn(base, TYPE_STYLES[type], className)}>{RFE_TYPE_LABELS[type].label}</span>;
  if (!explain) return badge;
  return (
    <Explain title={RFE_TYPE_LABELS[type].label} text={`${RFE_TYPE_LABELS[type].asks}.`} href="/glossary#request">
      {badge}
    </Explain>
  );
}

export function ObjectiveBadge({ objective, className, explain = true }: { objective: Objective; className?: string; explain?: boolean }) {
  const badge = <span className={cn(base, "border-zinc-200 bg-white text-zinc-700", className)}>Goal: {OBJECTIVE_LABELS[objective].label}</span>;
  if (!explain) return badge;
  return (
    <Explain title={`Goal: ${OBJECTIVE_LABELS[objective].label}`} text={OBJECTIVE_LABELS[objective].meaning}>
      {badge}
    </Explain>
  );
}

export function Pill({ children, className }: { children: React.ReactNode; className?: string }) {
  return <span className={cn(base, "border-zinc-200 bg-zinc-50 text-zinc-700", className)}>{children}</span>;
}
