import { cookies } from "next/headers";
import { SHARE_CODE_RE } from "@av/protocol";

/** The visitor's own share code, made on their first share. */
export const SHARE_COOKIE = "av_ref";
/** The share code whose link first brought this visitor here. */
export const FROM_COOKIE = "av_from";
/** An anonymous visitor id, so a repeat visit through the same link counts once. */
export const VISITOR_ID_COOKIE = "av_vid";

const YEAR = 60 * 60 * 24 * 365;
const opts = { path: "/", sameSite: "lax" as const, maxAge: YEAR };

export const newCode = () => crypto.randomUUID().replace(/-/g, "").slice(0, 10);

export async function readShareCookies() {
  const jar = await cookies();
  const valid = (v?: string) => (v && SHARE_CODE_RE.test(v) ? v : undefined);
  return { own: valid(jar.get(SHARE_COOKIE)?.value), from: valid(jar.get(FROM_COOKIE)?.value), visitor: jar.get(VISITOR_ID_COOKIE)?.value };
}

export async function setShareCookie(name: string, value: string) {
  (await cookies()).set(name, value, opts);
}

/** This visit came through a share link: the code is still in the URL, or an earlier one was remembered. */
export async function isShareLanding(searchParams: Record<string, string | string[] | undefined>): Promise<boolean> {
  const r = searchParams.r;
  if (typeof r === "string" && SHARE_CODE_RE.test(r)) return true;
  return !!(await readShareCookies()).from;
}
